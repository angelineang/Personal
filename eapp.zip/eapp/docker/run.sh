#! /bin/sh
#java $JAVA_OPTIONS -jar /app/eapp.jar
ls /app
echo "--------ls /app end--------"
ls /configuration
echo "-------ls /configuration end---------"
source /app/script.sh
echo "--------source /app/script.sh end--------"
# -Dsun.security.krb5.debug=true -Dsun.security.jgss.debug=true
exec java  -Dsun.security.krb5.debug=true -Dsun.security.jgss.debug=true -Djava.library.path=/app/ -Djava.security.auth.login.config=/app/SQLJDBCDriver.conf -Djava.security.krb5.conf=/app/krb5.conf -jar /app/app.jar

