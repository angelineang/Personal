#!/usr/bin/bash
for KEY_MAPPER in `echo "$AKV_KEYS" | sed 's/,/\n/g'`
do
  APP_KEY=`echo ${KEY_MAPPER#*|}`
  AKV_KEY=`echo ${KEY_MAPPER%|*}`
  if [ "$AKV_KEY" == "pid-id" ];then 
     akv_value=$(cat /configuration/$AKV_KEY)@AIAAZURE.BIZ
  else 
     akv_value=$(cat /configuration/$AKV_KEY)
  fi
  export "$APP_KEY=$akv_value"
done
export AZ_TENANT_ID="7f2c1900-9fd4-4b89-91d3-79a649996f0a"
