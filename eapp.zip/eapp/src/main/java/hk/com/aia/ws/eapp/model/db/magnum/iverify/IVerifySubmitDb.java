package hk.com.aia.ws.eapp.model.db.magnum.iverify;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import hk.com.aia.ws.eapp.model.base.Payload;
import hk.com.aia.ws.eapp.model.db.mag.iverify.*;
import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.util.List;

@ApiModel(value = "Submit Policy - iVerify - Model ")
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class IVerifySubmitDb extends Payload {

    private VCBooking vcBooking;
    private List<TPrcOcrRetakeInfo> tPrcOcrRetakeInfo;
    private List<TPrcDoc> tPrcDoc;
    private List<TPrcClient> tPrcClient;
    private List<TPrcOtherServicePolicy> tPrcOtherServicePolicy;
    private List<TPrcDoc0> tPrcDoc0;
    private List<TPrcDoc1> tPrcDoc1;
    private List<TPrcDoc2> tPrcDoc2;
    private List<TPrcDoc3> tPrcDoc3;
    private List<TPrcDoc4> tPrcDoc4;
    private List<TPrcDoc5> tPrcDoc5;
    private List<TPrcDoc6> tPrcDoc6;
    private List<TPrcDoc7> tPrcDoc7;
    private List<TPrcDoc8> tPrcDoc8;
    private List<TPrcDoc9> tPrcDoc9;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("IVerifySubmitDb{");
        sb.append("vcBooking=").append(vcBooking);
        sb.append('}');
        return sb.toString();
    }
}
