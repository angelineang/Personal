package hk.com.aia.ws.eapp.model.request.ipos;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.annotation.AllowedValuesIntValidation;
import hk.com.aia.ws.eapp.annotation.AllowedValuesValidation;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.util.Date;

import static hk.com.aia.ws.eapp.constant.Constants.TIMEZONE;

@ApiModel(value = "T_EAPPCITIEXTRA Model")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TEappCitiExtraDto {

    @ApiModelProperty(value = "citi Extra Id", required = true)
    @JsonProperty("citi_extra_id")
    @Size(max = 60)
    @NotBlank
    private String citiExtraId;

    @JsonProperty("eapp_id")
    @Size(max = 60)
    private String eappId;

    @JsonProperty("fna_id")
    @Size(max = 60)
    private String fnaId;

    @JsonProperty("fna_duplicated_id")
    @Size(max = 60)
    private String fnaDuplicatedId;

    @JsonProperty("citi_gold")
    private Integer citiGold;

    @JsonProperty("hnw")
    private Integer hnw;

    @JsonProperty("irr_accept_declaration")
    private Integer irrAcceptDeclaration;

    @JsonProperty("irr_accept_receipt")
    private Integer irrAcceptReceipt;

    @JsonProperty("referrer_name")
    private String referrerName;

    @JsonProperty("soe_id")
    @Size(max = 60)
    private String soeId;

    @JsonProperty("ge_id")
    @Size(max = 60)
    private String geId;

    @JsonProperty("plan_consultant")
    private Integer planConsultant;

    @JsonProperty("branch_code")
    @Size(max = 60)
    private String branchCode;

    @JsonProperty("branch_code_others")
    @Size(max = 60)
    private String branchCodeOthers;

    @JsonProperty("business_group")
    @Size(max = 60)
    private String businessGroup;

    @JsonProperty("guaranteed_payment_option")
    @Size(max = 10)
    private String guaranteedPaymentOption;

    @JsonProperty("ccbcwa")
    private Integer ccbcwa;

    @JsonProperty("is_special_customer")
    @AllowedValuesValidation(values = {"Y", "N"})
    @Size(max = 1)
    @ApiModelProperty(value = "string accepts Y and N only", example = "Y")
    private String isSpecialCustomer;

    @JsonProperty("opt_out_audio")
    @Size(max = 1)
    private String optOutAudio;

    @ApiModelProperty(value = "audio recorded date, format = yyyy-MM-dd", example = "2020-12-31")
    @JsonProperty("audio_recorded_date")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = TIMEZONE)
    private Date audioRecordedDate;

    @JsonProperty("audio_recorded_time")
    @Size(max = 10)
    private String audioRecordedTime;

    @JsonProperty("audio_recorded_ext")
    @Size(max = 10)
    private String audioRecordedExt;

    @JsonProperty("is_pregnancy_22_weeks")
    @AllowedValuesIntValidation(values = {0, 1})
    @ApiModelProperty(value = "integer accepts 0 and 1 only", example = "0")
    private Integer isPregnancy22Weeks;

    @JsonProperty("deferred_annuity_box_status")
    private Integer deferredAnnuityBoxStatus;

    @JsonProperty("deferred_annuity_option")
    private Integer deferredAnnuityOption;

    @JsonProperty("is_stt")
    @AllowedValuesValidation(values = {"Y", "N"})
    @Size(max = 1)
    @ApiModelProperty(value = "string accepts Y and N only", example = "Y")
    private String isStt;

    @JsonProperty("sct_reason")
    @Size(max = 50)
    private String sctReason;

    @JsonProperty("stt_reason")
    @Size(max = 50)
    private String sttReason;

    @JsonProperty("stt_reason_other")
    @Size(max = 1000)
    private String sttReasonOther;

    @JsonProperty("apply_premium_financing")
    @Size(max = 1)
    private String applyPremiumFinancing;

    @JsonProperty("eapp_audio_status")
    @Size(max = 5)
    private String eappAudioStatus;

    @JsonProperty("eapp_tick_hybrid_model")
    @Size(max = 5)
    private String eappTickHybridModel;

    @JsonProperty("prc_holder")
    @Size(max = 5)
    private String prcHolder;

    @JsonProperty("is_twa_cus")
    private Integer isTwaCus;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TEappCitiExtraDto{");
        sb.append("citiExtraId='").append(citiExtraId).append('\'');
        sb.append(", eappId='").append(eappId).append('\'');
        sb.append(", fnaId='").append(fnaId).append('\'');
        sb.append(", fnaDuplicatedId='").append(fnaDuplicatedId).append('\'');
        sb.append(", citiGold=").append(citiGold);
        sb.append(", hnw=").append(hnw);
        sb.append(", irrAcceptDeclaration=").append(irrAcceptDeclaration);
        sb.append(", irrAcceptReceipt=").append(irrAcceptReceipt);
        sb.append(", referrerName='").append(referrerName).append('\'');
        sb.append(", soeId='").append(soeId).append('\'');
        sb.append(", geId='").append(geId).append('\'');
        sb.append(", planConsultant=").append(planConsultant);
        sb.append(", branchCode='").append(branchCode).append('\'');
        sb.append(", branchCodeOthers='").append(branchCodeOthers).append('\'');
        sb.append(", businessGroup='").append(businessGroup).append('\'');
        sb.append(", guaranteedPaymentOption='").append(guaranteedPaymentOption).append('\'');
        sb.append(", ccbcwa=").append(ccbcwa);
        sb.append(", isSpecialCustomer='").append(isSpecialCustomer).append('\'');
        sb.append(", optOutAudio='").append(optOutAudio).append('\'');
        sb.append(", audioRecordedDate=").append(audioRecordedDate);
        sb.append(", audioRecordedTime='").append(audioRecordedTime).append('\'');
        sb.append(", audioRecordedExt='").append(audioRecordedExt).append('\'');
        sb.append(", isPregnancy22Weeks=").append(isPregnancy22Weeks);
        sb.append(", deferredAnnuityBoxStatus=").append(deferredAnnuityBoxStatus);
        sb.append(", deferredAnnuityOption=").append(deferredAnnuityOption);
        sb.append(", isStt='").append(isStt).append('\'');
        sb.append(", sctReason='").append(sctReason).append('\'');
        sb.append(", sttReason='").append(sttReason).append('\'');
        sb.append(", sttReasonOther='").append(sttReasonOther).append('\'');
        sb.append(", applyPremiumFinancing='").append(applyPremiumFinancing).append('\'');
        sb.append(", eappAudioStatus='").append(eappAudioStatus).append('\'');
        sb.append(", eappTickHybridModel='").append(eappTickHybridModel).append('\'');
        sb.append(", prcHolder='").append(prcHolder).append('\'');
        sb.append(", isTwaCus=").append(isTwaCus);
        sb.append('}');
        return sb.toString();
    }
}
