package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class PendingPolicy extends Payload {

    @JsonProperty("policy_no")
    @NotBlank
    @Size(min =15 , max = 15)
    private String policyNo;

    @JsonProperty("agent_code")
    @NotBlank
    @Size(min = 15, max = 15)
    private String agentCode;

    @JsonProperty("lang")
    private String language;

    @JsonProperty("access_id")
    private String accessId;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("PendingPolicy{");
        sb.append("policyNo='").append(ConversionHandler.mask(policyNo)).append('\'');
        sb.append(", agentCode='").append(agentCode).append('\'');
        sb.append(", language='").append(language).append('\'');
        sb.append(", accessId='").append(accessId).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
