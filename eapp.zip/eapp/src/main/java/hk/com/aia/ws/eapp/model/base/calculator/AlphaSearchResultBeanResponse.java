package hk.com.aia.ws.eapp.model.base.calculator;

import hk.com.aia.ws.eapp.model.base.ResponseMetaInfo;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class AlphaSearchResultBeanResponse {

    private AlphaSearchResultBean data;
    private ResponseMetaInfo meta;
	public AlphaSearchResultBean getData() {
		return data;
	}
	public void setData(AlphaSearchResultBean data) {
		this.data = data;
	}
	public ResponseMetaInfo getMeta() {
		return meta;
	}
	public void setMeta(ResponseMetaInfo meta) {
		this.meta = meta;
	}
}
