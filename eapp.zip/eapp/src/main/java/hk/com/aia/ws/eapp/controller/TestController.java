package hk.com.aia.ws.eapp.controller;

import static hk.com.aia.ws.eapp.constant.Constants.RETURN_FAIL_CODE;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import hk.com.aia.ws.eapp.model.base.CustomResponseStatus;
import hk.com.aia.ws.eapp.model.base.Payload;
import hk.com.aia.ws.eapp.model.base.ResultMessage;
import hk.com.aia.ws.eapp.model.request.Request;
import hk.com.aia.ws.eapp.model.request.SubTaskletUsersRequest;
import hk.com.aia.ws.eapp.model.response.Response;
import hk.com.aia.ws.eapp.model.response.ipos.FilResult;
import hk.com.aia.ws.eapp.model.token.CTRequest;
import hk.com.aia.ws.eapp.model.token.CTResponse;
import hk.com.aia.ws.eapp.model.token.TokenPayloadRequest;
import hk.com.aia.ws.eapp.service.SubmissionTaskletService;
import hk.com.aia.ws.eapp.service.jwt.JwtService;
import hk.com.aia.ws.eapp.service.key.KeyService;
import hk.com.aia.ws.eapp.service.sftp.SftpServices;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@AllArgsConstructor
@RestController
@RequestMapping("/test")
public class TestController {

    @Autowired
    KeyService keyService;
	
	
    @Autowired
    SftpServices sftpServices;

    @Autowired
    JwtService jwtService;

    @Autowired
    SubmissionTaskletService submissionTaskletService;

    @PostMapping(value = "/sftp-conn", produces = MediaType.APPLICATION_JSON_VALUE)
    public Response<Payload> sftpConn() {
        Response<Payload> response = new Response<>();
       if(sftpServices.testSftpConn()) {
           log.info("Citi SFTP connection successful");
           response.setStatus(CustomResponseStatus.SUCCESS.getDescription());
       } else {
           log.info("Citi SFTP connection failed");
           response.setStatus(CustomResponseStatus.ERROR.getDescription());
       }
       return response;
    }
 
    @PostMapping(value = "/gen-token", produces = MediaType.APPLICATION_JSON_VALUE)
    public Response<FilResult> generateToken(@RequestBody Request<TokenPayloadRequest> tokenPayloadRequest) {
        Response<FilResult> response = new Response<>();
        FilResult data = new FilResult();

        try {
            data.setReturnCode(jwtService.generateJwtToken(tokenPayloadRequest.getData() ));
            assert(true);
            response.setStatus(CustomResponseStatus.SUCCESS.getDescription());
        } catch (Exception ex) {
            response.setStatus(CustomResponseStatus.ERROR.getDescription());
            data.setReturnCode(RETURN_FAIL_CODE);
            List<ResultMessage> errList = new ArrayList<>();
            errList.add(new ResultMessage(RETURN_FAIL_CODE, ex.getMessage()));
            response.setResultMessages(errList);
        }
        response.setData(data);
        return response;
    }

    @PostMapping(value = "/get-ct", produces = MediaType.APPLICATION_JSON_VALUE)
    public Response<CTResponse> getCommonToken(@RequestBody Request<CTRequest> ctRequest) {
        Response<CTResponse> response = new Response<>();
        CTResponse data = new CTResponse();
        try {
            data = jwtService.generateCommonTokenTest(ctRequest.getData().getJwt());
            response.setStatus(CustomResponseStatus.SUCCESS.getDescription());
        } catch (Exception ex) {
            response.setStatus(CustomResponseStatus.ERROR.getDescription());
            assert(true);
            data.setReturnCode(RETURN_FAIL_CODE);
            List<ResultMessage> errList = new ArrayList<>();
            errList.add(new ResultMessage(RETURN_FAIL_CODE, ex.getMessage()));
            response.setResultMessages(errList);
        }
        response.setData(data);
        return response;
    }

    @PostMapping(value = "/validate-ct", produces = MediaType.APPLICATION_JSON_VALUE)
    public Response<CTResponse> validateCommonToken(@RequestBody Request<CTRequest> ctRequest) {
        Response<CTResponse> response = new Response<>();
        CTResponse data = new CTResponse();
        try {
            data = jwtService.validateCommonTokenTest(ctRequest.getData().getJwt());
            response.setStatus(CustomResponseStatus.SUCCESS.getDescription());
        } catch (Exception ex) {
            response.setStatus(CustomResponseStatus.ERROR.getDescription());
            data.setReturnCode(RETURN_FAIL_CODE);
            assert(true);
            List<ResultMessage> errList = new ArrayList<>();
            errList.add(new ResultMessage(RETURN_FAIL_CODE, ex.getMessage()));
            response.setResultMessages(errList);
        }
        response.setData(data);
        return response;
    }


    @PostMapping(value = "/unlock-user", produces = MediaType.APPLICATION_JSON_VALUE)
    public Response<Payload> unlockUser(@RequestBody Request<SubTaskletUsersRequest> request) {
        return submissionTaskletService.unlockSubTaskletUsers(request);
    }

	@PostMapping(value = "/check-version", produces = MediaType.APPLICATION_JSON_VALUE)
	public Response<Payload> checkVersion() {
		Response<Payload> response = new Response<>();
		response.setStatus("PRD_20230610 EAPP-5826 EAPP-5397 EAPP-6403 EAPP-6409 EAPP-6091");
		return response;
	}
 
	
	@GetMapping(value = "/check-version", produces = MediaType.APPLICATION_JSON_VALUE)
	public Response<Payload> getcheckVersion() {
		return checkVersion() ;
	}
	
	@GetMapping(value = "/check-java-version", produces = MediaType.APPLICATION_JSON_VALUE)
	public Response<Payload> getcheckJavaVersion() {
		Response<Payload> response = new Response<>();
		response.setStatus("java version" +System.getProperty("java.version"));
		return response;
	}

	@PostMapping(value = "/check-app-detail", produces = MediaType.APPLICATION_JSON_VALUE)
	public Response<Payload> getAppDetail() {
		Response<Payload> response = new Response<>();
		response.setStatus("app detail " +keyService.getAppDetail());
		return response;
	}
	

	@PostMapping(value = "/get-secret", produces = MediaType.APPLICATION_JSON_VALUE)
	public Response<Payload> getsecret() {
		Response<Payload> response = new Response<>();

		response.setStatus(keyService.getPGSKey());

 		return response;
	}
 
}
