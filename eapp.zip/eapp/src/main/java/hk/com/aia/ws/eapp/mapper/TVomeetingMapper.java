package hk.com.aia.ws.eapp.mapper;

import hk.com.aia.ws.eapp.model.db.magnum.ipos.TCitiFna;
import hk.com.aia.ws.eapp.model.db.magnum.ipos.TEappPayor;
import hk.com.aia.ws.eapp.model.db.magnum.ipos.TVomeeting;
import hk.com.aia.ws.eapp.model.request.ipos.TCitiFnaDto;
import hk.com.aia.ws.eapp.model.request.ipos.TEappPayorDto;
import hk.com.aia.ws.eapp.model.request.ipos.TVomeetingDto;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

@Mapper
public interface TVomeetingMapper {

    TVomeetingMapper MAPPER = Mappers.getMapper(TVomeetingMapper.class);

    TVomeeting mapToTVomeeting(TVomeetingDto tVomeetingDto);
}
