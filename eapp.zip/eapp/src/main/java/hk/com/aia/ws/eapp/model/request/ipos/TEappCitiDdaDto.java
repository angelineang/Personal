package hk.com.aia.ws.eapp.model.request.ipos;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.Conversion;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.util.Date;

import static hk.com.aia.ws.eapp.constant.Constants.TIMEZONE;


@ApiModel(value = "T_EAPPCITIDDA Model")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TEappCitiDdaDto {

    @ApiModelProperty(value = "citi Dda Id", required = true)
    @JsonProperty("citi_dda_id")
    @Size(max = 60)
    @NotBlank
    private String citiDdaId;

    @JsonProperty("eapp_id")
    @Size(max = 60)
    private String eappId;

    @JsonProperty("payment_mode")
    @Size(max = 10)
    private String paymentMode;

    @JsonProperty("payment_instruction")
    @Size(max = 10)
    private String paymentInstruction;

    @JsonProperty("account_holder_name")
    @Size(max = 60)
    private String accountHolderName;

    @JsonProperty("account_no")
    @Size(max = 20)
    private String accountNo;

    @JsonProperty("bank_code")
    @Size(max = 3)
    private String bankCode;

    @JsonProperty("bank_branch_no")
    @Size(max = 20)
    private String bankBranchNo;

    @JsonProperty("bank_account_type")
    @Size(max = 10)
    private String bankAccountType;

    @ApiModelProperty(value = "credit card expiry date")
    @JsonProperty("credit_card_expiry_date")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", timezone = TIMEZONE)
    private Date creditCardExpiryDate;

    @JsonProperty("credit_card_authorisation_code")
    @Size(max = 20)
    private String creditCardAuthorisationCode;

    @ApiModelProperty(value = "credit card authorisation date")
    @JsonProperty("credit_card_authorisation_date")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", timezone = TIMEZONE)
    private Date creditCardAuthorisationDate;

    @JsonProperty("credit_card_merchant_number")
    private String creditCardMerchantNumber;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TEappCitiDdaDto{");
        sb.append("citiDdaId='").append(citiDdaId).append('\'');
        sb.append(", eappId='").append(eappId).append('\'');
        sb.append(", paymentMode='").append(paymentMode).append('\'');
        sb.append(", paymentInstruction='").append(paymentInstruction).append('\'');
        sb.append(", accountHolderName='").append(ConversionHandler.mask(accountHolderName)).append('\'');
        sb.append(", accountNo='").append(ConversionHandler.mask(accountNo)).append('\'');
        sb.append(", bankCode='").append(bankCode).append('\'');
        sb.append(", bankBranchNo='").append(bankBranchNo).append('\'');
        sb.append(", bankAccountType='").append(bankAccountType).append('\'');
        sb.append(", creditCardExpiryDate=").append(creditCardExpiryDate);
        sb.append(", creditCardAuthorisationCode='").append(ConversionHandler.mask(creditCardAuthorisationCode)).append('\'');
        sb.append(", creditCardAuthorisationDate=").append(creditCardAuthorisationDate);
        sb.append(", creditCardMerchantNumber='").append(ConversionHandler.mask(creditCardMerchantNumber)).append('\'');
        sb.append('}');
        return sb.toString();
    }
}

