package hk.com.aia.ws.eapp.model.request.batch;

import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.model.base.Payload;
import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@ApiModel(value = "Generate BatchId Model")
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class GenBatchRequest extends Payload {

    @JsonProperty("policy_no")
    @NotBlank
    @Size(max = 10)
    String policyNo;

    @JsonProperty("type")
    @NotBlank
    @Size(max = 1)
    String type;

    @JsonProperty("doc_code")
    @NotBlank
    @Size(max = 1)
    String docCode;

    @JsonProperty("func_code")
    @NotBlank
    @Size(max = 3)
    String funcCode;

}
