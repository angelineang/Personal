package hk.com.aia.ws.eapp.model.request.calculator;

import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.model.base.Payload;
import hk.com.aia.ws.eapp.model.base.calculator.LoginUser;
import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

@ApiModel(value = "Sio Gio Request Model")
@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class SioGioRequest extends Payload {

    @JsonProperty("id_no")
    private String idNo;

    @JsonProperty("client_name")
    private String clientName;

    @JsonProperty("dob")
    private String dob;

    @JsonProperty("sex")
    private String sex;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("SioGioRequest{");
        sb.append(", idNo='").append(idNo).append('\'');
        sb.append(", clientName='").append(clientName).append('\'');
        sb.append(", dob='").append(dob).append('\'');
        sb.append(", sex='").append(sex).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
