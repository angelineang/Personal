package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Base64File {

    @JsonProperty("content")
    private String content;

    @JsonProperty("name")
    private String name;

    @JsonProperty("mine_type")
    private String mineType;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Base64File{");
        sb.append("content='").append(content).append('\'');
        sb.append(", name='").append(ConversionHandler.mask(name)).append('\'');
        sb.append(", mineType='").append(mineType).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
