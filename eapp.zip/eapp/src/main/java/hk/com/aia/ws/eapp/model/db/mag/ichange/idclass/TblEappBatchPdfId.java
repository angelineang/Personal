package hk.com.aia.ws.eapp.model.db.mag.ichange.idclass;

import java.io.Serializable;

public class TblEappBatchPdfId implements Serializable {

    private static final long serialVersionUID = 4000258928784591220L;
    private String batchId;
    private Integer sequence;
    private String docId;
    private String contentType;
}
