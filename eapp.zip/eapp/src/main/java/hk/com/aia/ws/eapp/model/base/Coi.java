package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.validation.Valid;

@ApiModel(value = "Coi Model")
@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class Coi extends Payload {

    @ApiModelProperty(value = "submission details")
    @JsonProperty("submission_detail")
    @Valid
    private SubmissionDetail submissionDetail;

    @ApiModelProperty(value = "coi details")
    @JsonProperty("coi_detail")
    private CoiDetail coiDetail;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Coi{");
        sb.append("submissionDetail=").append(submissionDetail);
        sb.append(", coiDetail=").append(coiDetail);
        sb.append('}');
        return sb.toString();
    }
}
