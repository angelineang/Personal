package hk.com.aia.ws.eapp.model.request.ipos;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@ApiModel(value = "T_EAPPMAGNUM Model")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TEappMagnumDto {

    @ApiModelProperty(value = "eapp Magnum Id", required = true)
    @JsonProperty("eapp_magnum_id")
    @Size(max = 60)
    @NotBlank
    private String eappMagnumId;

    @JsonProperty("eapp_id")
    @Size(max = 60)
    private String eappId;

    @JsonProperty("contact_id")
    @Size(max = 60)
    private String contactId;

    @JsonProperty("m_block_a")
    private String mBlockA;

    @JsonProperty("m_block_b")
    private String mBlockB;

    @JsonProperty("m_block_d")
    private String mBlockD;

    @JsonProperty("rule_base_version")
    @Size(max = 20)
    private String ruleBaseVersion;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TEappMagnumDto{");
        sb.append("eappMagnumId='").append(eappMagnumId).append('\'');
        sb.append(", eappId='").append(eappId).append('\'');
        sb.append(", contactId='").append(contactId).append('\'');
        sb.append(", mBlockA='").append(mBlockA).append('\'');
        sb.append(", mBlockB='").append(mBlockB).append('\'');
        sb.append(", mBlockD='").append(mBlockD).append('\'');
        sb.append(", ruleBaseVersion='").append(ruleBaseVersion).append('\'');
        sb.append('}');
        return sb.toString();
    }
}