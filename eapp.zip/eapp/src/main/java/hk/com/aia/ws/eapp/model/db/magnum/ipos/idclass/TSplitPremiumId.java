package hk.com.aia.ws.eapp.model.db.magnum.ipos.idclass;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TSplitPremiumId implements Serializable {

    private static final long serialVersionUID = 7482984530383052609L;
    private String splitPremiumId;
    private String basicPlanSelectionId;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TSplitPremiumId{");
        sb.append("splitPremiumId='").append(splitPremiumId).append('\'');
        sb.append(", basicPlanSelectionId='").append(basicPlanSelectionId).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
