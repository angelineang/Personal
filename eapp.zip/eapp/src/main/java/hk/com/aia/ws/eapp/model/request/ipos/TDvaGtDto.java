package hk.com.aia.ws.eapp.model.request.ipos;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.annotation.AllowedValuesIntValidation;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.util.Date;

import static hk.com.aia.ws.eapp.constant.Constants.TIMEZONE;

@ApiModel(value = "T_DVAGT Model")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TDvaGtDto {

    @ApiModelProperty(value = "dva Gt Id", required = true)
    @JsonProperty("dva_gt_id")
    @Size(max = 60)
    @NotBlank
    private String dvaGtId;

    @JsonProperty("eapp_id")
    @Size(max = 60)
    private String eappId;

    @JsonProperty("agent_code")
    @Size(max = 10)
    private String agentCode;

    @JsonProperty("access_code")
    @Size(max = 30)
    private String accessCode;

    @ApiModelProperty(value = "agent visit date, format = yyyy-MM-dd", example = "2020-12-31")
    @JsonProperty("agent_visit_date")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = TIMEZONE)
    private Date agentVisitDate;

    @JsonProperty("document_id")
    @Size(max = 60)
    private String documentId;

    @JsonProperty("is_confirm")
    @AllowedValuesIntValidation(values = {0, 1})
    @ApiModelProperty(value = "integer accepts 0 and 1 only", example = "0")
    private Integer isConfirm;

    @JsonProperty("address_type")
    @Size(max = 20)
    private String addressType;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TDvaGtDto{");
        sb.append("dvaGtId='").append(dvaGtId).append('\'');
        sb.append(", eappId='").append(eappId).append('\'');
        sb.append(", agentCode='").append(agentCode).append('\'');
        sb.append(", accessCode='").append(accessCode).append('\'');
        sb.append(", agentVisitDate=").append(agentVisitDate);
        sb.append(", documentId='").append(documentId).append('\'');
        sb.append(", isConfirm=").append(isConfirm);
        sb.append(", addressType='").append(addressType).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
