package hk.com.aia.ws.eapp.model.db.magnum;

import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.annotation.Nullable;
import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Data
@Entity
@Table(name = "tbl_eapp_lock_record")
@EntityListeners(AuditingEntityListener.class)
public class EappLockRecord implements Serializable {

    @Id
    @Column(name = "key_lock")
    private String keyLock;

    @Id
    @Column(name = "lock_type")
    private String lockType;

    @Column(name = "lock_user")
    @Nullable
    private String lockUser;

    @Column(name = "created_date")
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDate;

    @Column(name = "last_modified_date")
    @Temporal(TemporalType.TIMESTAMP)
    @LastModifiedDate
    private Date lastModifiedDate;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("XgfeSubmissionErr{");
        sb.append("key_lock=").append(keyLock);
        sb.append(", lock_type='").append(lockType);
        sb.append(", lock_user=").append(lockUser);
        sb.append(", createdDate=").append(createdDate);
        sb.append(", lastModifiedDate=").append(lastModifiedDate);
        sb.append('}');
        return sb.toString();
    }
}