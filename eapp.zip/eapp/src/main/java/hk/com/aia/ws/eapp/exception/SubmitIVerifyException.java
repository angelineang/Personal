package hk.com.aia.ws.eapp.exception;

import hk.com.aia.ws.eapp.model.base.ResultMessage;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class SubmitIVerifyException extends RuntimeException {

    private static final long serialVersionUID = 1L;
    private List<ResultMessage> exceptionMessages = new ArrayList<>();

    public SubmitIVerifyException(String exceptionMessage) {
        ResultMessage resultMessage = new ResultMessage();
        resultMessage.setCode("-99");
        resultMessage.setMessage(exceptionMessage);
        exceptionMessages.add(resultMessage);
    }

    public SubmitIVerifyException(List<ResultMessage> exMessages) {
        ResultMessage resultMessage = new ResultMessage();
        resultMessage.setCode("-99");
        exceptionMessages = exMessages;
    }


    @Override
    public String getMessage() {
        return "";
    }


}
