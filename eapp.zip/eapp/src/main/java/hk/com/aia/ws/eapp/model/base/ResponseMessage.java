package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class ResponseMessage {

    @JsonProperty("severity")
    private String severity;

    @JsonProperty("description")
    private String description;

    @JsonProperty("code")
    private String code;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("ResponseMessage{");
        sb.append("code='").append(code).append('\'');
        sb.append(", severity='").append(severity).append('\'');
        sb.append(", description='").append(description).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
