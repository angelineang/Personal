package hk.com.aia.ws.eapp.mapper;

import hk.com.aia.ws.eapp.model.db.magnum.ipos.TContactCitiExtra;
import hk.com.aia.ws.eapp.model.request.ipos.TContactCitiExtraDto;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper
public interface TContactCitiExtraMapper {

    TContactCitiExtraMapper MAPPER = Mappers.getMapper(TContactCitiExtraMapper.class);

    List<TContactCitiExtra> mapToTContactCitiExtraList(List<TContactCitiExtraDto> tContactCitiExtraDto);
}
