package hk.com.aia.ws.eapp.constant;

public class Constants {

    private Constants(){

    }

    public static final class ExceptionMsg {

        private ExceptionMsg(){ }
        public static final String EXCEPTION_CAUGHT = "exception caught : {} - cause : {}";
        public static final String RUNTIME_ROLLBACK = "Throwing runtime exception to rollback transaction";
        public static final String SQL_EXCEPTION_DBMAGNUM = "SQLException: JZ0R2: No result set for this query.";
        public static final String SQL_EXCEPTION_NO_RESULT_SET = "SQLServerException: The statement did not return a result set.";
        public static final String CLOUD_POLICY_ERROR = "Cannot lock the policy number %s to cloud environment";
        public static final String XGFE_EXCEPTION = "Error occurred during call to XGFE";
    }

    public static final class RequestHeader {

        private RequestHeader(){ }

        public static final String AIA_ENV = "x-aia-env";
        public static final String REQUEST_ID = "x-aia-request-id";
        public static final String AIA_LBU =  "x-aia-lbu";
        public static final String TOKEN_AGENT = "x-aiahk-token-agent";
        public static final String TRACE_ID = "x-AIAHK-Trace-ID";
        public static final String CONTEXT_ID = "x-AIAHK-Context-ID";
        public static final String FORWARDED_FOR = "X-Forwarded-For";
        public static final String AIAACESSTOKEN = "Authorization";
        public static final String ORIGINATING_USER = "X-AIAHK-Originating-User-Id";
        public static final String SOURCE_APP = "x-source-app";
        public static final String EAPP_APP_NAME = "EAPP";
        public static final String ORIGINAL_IP = "x-original-forwarded-for";
    }

    public static final class CalculatorConstants {
        public static final String USAGE_LIMIT = "Usage Limit reached for today";
        public static final String AML_CAL = "AML";
        public static final String AFF_CAL = "AFF";
        public static final String NON_MED_CAL = "NML";

        //Alpha Search
        public static final String NB = "NB";
        public static final String EAPP = "EAPP";
        public static final String NB_CREATOR = "NB_Creator";
        public static final String CALCULATOR = "NB_Calculator";
        public static final String CALL_ALPHA_BY_ID_1 = "Calling Alpha Search by IdNo1: {} - {}";
        public static final String CALL_ALPHA_BY_ID_2 = "Calling Alpha Search by IdNo2: {} - {}";

        //PerLife
        public static final String PER_LIFE_CDC_REQUEST_TYPE = "3";

        public static final String PL_GROUP_NAME_SUMMARY = "SUMMARY";
        public static final String PL_GROUP_CAT_SUM_TOTAL = "PER-LIF-SUMMARY_TOTAL";
        public static final String PL_GROUP_CAT_BY_MONTH = "PER-LIF-NONMED_IN_X_MONTH";
        public static final String PL_GROUP_CAT_REG_PREM_TOTAL = "PER-LIF-REGULAR_PREMIUM_TOTAL";
        public static final String PL_GROUP_CAT_SIN_PREM_TOTAL = "PER-LIF-SINGLE_PREMIUM_TOTAL";
        public static final String PP_GROUP_CAT_REG_PREM_TOTAL = "PER-POL-REGULAR_PREMIUM_TOTAL";
        public static final String PP_GROUP_CAT_SIN_PREM_TOTAL = "PER-POL-SINGLE_PREMIUM_TOTAL";
        public static final String PL_GROUP_CAT_TOTAL_ANP_BF_FNA = "TOTAL_ANP_BF_FNA";
        public static final String PL_GROUP_CAT_ANP_BF_FNA = "ANP_BF_FNA";

        public static final int SUM_ASSURED_LIMIT_FOR_NON_MED = 3000000;
        public static final String EXCEEDED_PL_MAX_E = "Exceeded Perlife Total Sum Assured USD 3,000,000, Non-Medical Limits are not applicable";
        public static final String EXCEEDED_PL_MAX_C = "\u500b\u4eba\u7e3d\u6295\u4fdd\u984d\u8d85\u904e3,000,000\u7f8e\u5143, \u514d\u9ad4\u6aa2\u9650\u984d\u4e26\u4e0d\u9069\u7528";
        public static final String EXCEEDED_PL_MAX_S = "\u4e2a\u4eba\u603b\u6295\u4fdd\u989d\u8d85\u8fc73,000,000\u7f8e\u5143, \u514d\u4f53\u68c0\u9650\u989d\u5e76\u4e0d\u9002\u7528";

        public static final String FAILED_RETRIEVE_CLIENT_INFO_ERROR_MSG_E = "Unable to retrieve client information, please contact agency hotline 2232-8999";
        public static final String FAILED_RETRIEVE_CLIENT_INFO_ERROR_MSG_C = "\u7121\u6cd5\u5c0b\u627e\u76f8\u95dc\u5ba2\u6236\u8a18\u9304\uff0c\u7169\u8acb\u81f4\u96fb\u71df\u904b\u90e8\u71b1\u7dda 2232-8999";
        public static final String FAILED_RETRIEVE_CLIENT_INFO_ERROR_MSG_S = "\u65e0\u6cd5\u5bfb\u627e\u76f8\u5173\u5ba2\u6237\u8bb0\u5f55\uff0c\u70e6\u8bf7\u81f4\u7535\u8425\u8fd0\u90e8\u70ed\u7ebf 2232-8999";

        public static final String EXISTING_RISK_MSG_E = "There are similar client records, please contact ";
        public static final String EXISTING_RISK_MSG_C = "\u7531\u65BC\u76F8\u985E\u4F3C\u7684\u5BA2\u6236\u8A18\u9304\u773E\u591A\uFF0C\u7169\u8ACB\u81F4\u96FB\u71DF\u904B\u90E8\u71B1\u7DDA 2232-8999";
        public static final String EXISTING_RISK_MSG_S = "\u7531\u4E8E\u76F8\u7C7B\u4F3C\u7684\u5BA2\u6237\u8BB0\u5F55\u4F17\u591A\uFF0C\u70E6\u8BF7\u81F4\u7535\u8425\u8FD0\u90E8\u70ED\u7EBF 2232-8999";

        public static final String NEW_CLIENT_RISK_MSG_E = "This is a new client\r\n";
        public static final String NEW_CLIENT_RISK_MSG_C = "\u6B64\u70BA\u65B0\u7684\u5BA2\u6236\r\n";
        public static final String NEW_CLIENT_RISK_MSG_S = "\u6B64\u4E3A\u65B0\u7684\u5BA2\u6237\r\n";

        public static final String SYSTEM_ERROR_MSG_E = "System under maintenance, please try again later.";
        public static final String SYSTEM_ERROR_MSG_C = "\u7cfb\u7d71\u6b63\u5728\u7dad\u8b77\u4e2d, \u8acb\u7a0d\u5f8c\u518d\u8a66";
        public static final String SYSTEM_ERROR_MSG_S = "\u7cfb\u7edf\u6b63\u5728\u7ef4\u62a4\u4e2d, \u8bf7\u7a0d\u540e\u518d\u8bd5";

        public static final String SEM = "SEM"; // System Error Msg
        public static final String FRC = "FRC"; // Failed to Retrieve Client
        public static final String EPM = "EPM"; // Exceeded PL Max

        public static final int DECIMAL_MODE = 0;
        public static final int MONEY_MODE = 1;

        public static final String AFFORD_CALCULATOR_RESULT_PASSED_EN = "Affordability Checking \u2013 Passed";
        public static final String AFFORD_CALCULATOR_RESULT_FAILED_EN = "Affordability Checking \u2013 Failed";
        public static final String AFFORD_CALCULATOR_RESULT_ANP_EN = "The Monthly Average Expenses before retirement is than the premium of existing policies in AIA. Please confirm.";

        public static final String AFFORD_CALCULATOR_RESULT_PASSED_ZH = "\u7E73\u4ED8\u4FDD\u8CBB\u7684\u8CA0\u64D4\u80FD\u529B \u2013 \u901A\u904E";
        public static final String AFFORD_CALCULATOR_RESULT_FAILED_ZH = "\u7E73\u4ED8\u4FDD\u8CBB\u7684\u8CA0\u64D4\u80FD\u529B \u2013 \u4E0D\u901A\u904E";
        public static final String AFFORD_CALCULATOR_RESULT_ANP_ZH = "\u9000\u4F11\u524D\u7684\u6BCF\u6708\u5E73\u5747\u958B\u652F\u5C11\u65BC\u73FE\u6709\u4FDD\u55AE\u7684\u4FDD\u8CBB\u3002\u8ACB\u78BA\u5B9A\u3002";

        public static final String AFFORD_CALCULATOR_COMMON_ERROR_EN = "Error";
        public static final String AFFORD_CALCULATOR_COMMON_ERROR_ZH = "\u932F\u8AA4";

        public static final String REQ_TYPE = "reqType";
        public static final String REQ_MSG = "reqMsg";
        public static final String LUM_SUMP = "L";
        public static final String REGULAR = "R";
        public static final double MAX_RATIO = 1.3;
        public static final double RATIO = 1.0;
        public static final double MIN_RATIO = 0.7;

    }

    public static final class DocumentSubmit {

        private DocumentSubmit(){ }

        public static final String CC = "CC";

        public static final String WS_ACTION_ADD_DOC = "eSub_add_doc";
        public static final String WS_ACTION_POL = "pol";

        public static final String EMAIL_JOB_ID_FIRESTORM = "MS-FS";
        public static final String EMAIL_APP_NAME = "MS";
    }

    public static final class PolicyProcessConstants {
        public static final String BEWS_SUB_PATH_1 = "/cases/UNI-";
        public static final String BEWS_SUB_PATH_2 = "-/comments/0/pendings?pendStatus=";

        public static final String RTN_CODE = "rtn_code";
        public static final String DEL_XGFE = "del_xgfe";
    }

    public static final class XGFEConstants {

        private XGFEConstants(){ }

        // MODE - F = Save and Underwriting, S = Save
        public static final String MODE = "F";

        // STAGE TO EUS
        public static final String UI_WS_AUG = "UI_WS_AUG"; // Version 2 - as of SIT - 2020/11/13
        public static final String EAPP = "EAPP";
        public static final String NBC = "NBC";
        public static final String NBSUBPATH = "/nb/submission";

        // STAGE TO EUS DOC
        public static final String UI_WS_HL = "UI_WS_HL"; //stageToEusDoc XGFE-endpoint

        public static final String POLICIESPATH = "/policies/";
        public static final String ENDORSEUWPATH = "/endorse-underwriting";

        // Channel Indicator
        public static final String HL = "HL";

        public static final String UU647 = "UU647";
        public static final String UU621 = "UU621";

    }

    public static final class SubmitMsConstants {
        // Constants used by SubmitMsService
        private SubmitMsConstants(){ }

        public static final int NORMAL_QUERY_TIMEOUT = 60;
        //    public static final int   LONG_QUERY_TIMEOUT = 120; currently unused
        //   public static final int   VERY_LONG_QUERY_TIMEOUT = 180; currently unused

        //    public static final String  SUBMIT_SUCCESS_MS = "Success to Submit - MS"; currently unused
        public static final String WS_ACTION_ESUB = " eSub";
        public static final String WS_ACTION_GET_SUBMIT_MS_STATUS = "getSubmitMsStatus";

        public static final String SUBMIT_SUCCESS_STAGING_MASTER = "Success to Submit - Staging Master";
        public static final String SUBMIT_FAIL_STAGING_MASTER = "Fail to Submit - Staging Master";

        public static final String SUBMIT_SUCCESS_STAGING_PROMOTION = "Success to Submit - Staging Promotion";
        public static final String SUBMIT_FAIL_STAGING_PROMOTION = "Fail to Submit - Staging Promotion";

        public static final String SUBMIT_SUCCESS_STAGING_COVERAGE = "Success to Submit - Staging Coverage";
        public static final String SUBMIT_FAIL_STAGING_COVERAGE = "Fail to Submit - Staging Coverage";

        public static final String SUBMIT_SUCCESS_STAGING_CUSTOMER = "Success to Submit - Staging Customer";
        public static final String SUBMIT_FAIL_STAGING_CUSTOMER = "Fail to Submit - Staging Customer";

        public static final String SUBMIT_SUCCESS_STAGING_ADDRESS = "Success to Submit - Staging Address";
        public static final String SUBMIT_FAIL_STAGING_ADDRESS = "Fail to Submit - Staging Address";

        public static final String SUBMIT_SUCCESS_STAGING_DOCUMENT = "Success to Submit - Staging Document";
        public static final String SUBMIT_FAIL_STAGING_DOCUMENT = "Fail to Submit - Staging Document";

        public static final String DELETE_SUCCESS_STAGING_DOCUMENT_PDF = "Success to Delete - Staging Document PDF";
        public static final String DELETE_FAIL_STAGING_DOCUMENT_PDF = "Fail to Delete - Staging Document PDF";

        public static final String SUBMIT_SUCCESS_STAGING_DOCUMENT_PDF = "Success to Submit - Staging Document PDF";
        public static final String SUBMIT_FAIL_STAGING_DOCUMENT_PDF = "Fail to Submit - Staging Document PDF";

        public static final String SUBMIT_SUCCESS_QUESTION = "Success to Submit - Question";
        public static final String SUBMIT_FAIL_QUESTION = "Fail to Submit - Question";

        public static final String SUBMIT_SUCCESS_DDUW = "Success to Submit - Dduw";
        public static final String SUBMIT_FAIL_DDUW = "Fail to Submit - Dduw";

        public static final String SUBMIT_SUCCESS_STAGING_BENEFIT = "Success to Submit - Staging Benefit";
        public static final String SUBMIT_FAIL_STAGING_BENEFIT = "Fail to Submit - Staging Benefit";

        public static final String SUBMIT_SUCCESS_AUTOPAY = "Success to Submit - Autopay";
        public static final String SUBMIT_FAIL_AUTOPAY = "Fail to Submit - Autopay";

        public static final String SUBMIT_SUCCESS_IFSPR = "Success to Submit - IFS PR";
        public static final String SUBMIT_FAIL_IFSPR = "Fail to Submit - IFS PR";

        public static final String SUBMIT_SUCCESS_IMPAIRMENT = "Success to Submit - Impairment";
        public static final String SUBMIT_FAIL_IMPAIRMENT = "Fail to Submit - Impairment";

        public static final String SUBMIT_SUCCESS_POLFNA = "Success to Submit - PolFna";
        public static final String SUBMIT_FAIL_POLFNA = "Fail to Submit - PolFna";

        public static final String SUBMIT_SUCCESS_EUS = "Success to Submit - EUS";
        public static final String SUBMIT_FAIL_EUS = "Fail to Submit - EUS";

        public static final String LOG_RESULT_FAIL_MESSAGE = "Fail to log";
        public static final String LOG_RESULT_SUCCESSFUL_MESSAGE = "Log Successful";

        public static final String SEND_RESULT_FAIL_EMAIL_SEND_MESSAGE = "Fail to send email";
        public static final String SEND_RESULT_SUCCESSFUL_EMAIL_MESSAGE = "Success to send email";

        public static final String SUCCESS_TO_SUBMIT_EUS_DOCUMENT = "Success to Submit - EUS Document";
        public static final String FAIL_TO_SUBMIT_EUS_DOCUMENT = "Fail to Submit - EUS Document";

        public static final String UNEXPECTED_ERROR = "Unexpected Error";

        public static final String WS_ACTION_POL_CLOUD = "checkPolCloud";

        public static final String WS_ACTION_ESUB_COI = "eSub_coi";
        public static final String MINI_SUBMISSION = "Mini-submission";
        public static final String COI_URL = "COI_URL";

        public static final String STAGE_TO_EUS_SUCCESS = "Stage to Eus Successfully";
        public static final String APP_ERROR = "Application Error:";
        public static final String XGFE_PAYLOAD = "XGFE Payload:";

    }

    public static final class EFKLogging {

        private EFKLogging(){}

        public static final String TRACE_ID = "trace_id";

        public static final String CALLER_CONTEXT_ID = "caller_context_id";

        public static final String APP_CONTEXT_ID = "context_id";

        public static final String APP_ID = "app_id";

        public static final String APP_VERSION = "app_version";

        public static final String MESSAGE_TYPE = "message_type";

        public static final String AIA_ENV = "x-aia-env";
         
        public static final String TRAN_KEYS = "tran_keys";
        public static final String SUB_TYPE = "sub_type";
        public static final String EAPP_ID = "eapp_id";
        
        public static final String MESSAGE_TYPE_MONITOR = "Monitor";
        public static final String MESSAGE_TYPE_INTEGRATION = "Integration";

        
        public static final String SOURCE_USER_ID = "source_user_id";
        public static final String SOURCE_USER_IP = "source_user_ip";
        public static final String SOURCE_APP = "source_app";
        
        public static final String APP_FUNCTION = "function_code";
        
    }
    
	public static final class APIPath {

		private APIPath() {
		}

		public static final String EAPP_D_GEN_BATCH_ID = "/documents/gen-batch-id";
		public static final String EAPP_D_SUBMIT_BATCH = "/documents/submit-batch";

		public static final String EAPP_CAL_AML = "/calculators/calculate-risk-aml";
		public static final String EAPP_CAL_NON_MED = "/calculators/calculate-risk-non-med";
		public static final String EAPP_CAL_SIO_GIO = "/calculators/calculate-risk-sio-gio";
		public static final String EAPP_CAL_SUIT = "/calculators/cal-suitability";
		public static final String EAPP_CAL_AFF = "/calculators/cal-afford";
		public static final String EAPP_D_GET_LETTER_DOC = "/documents/get-letter-doc";

		public static final String EAPP_P_SUBMIT = "/policies/submit";
		public static final String EAPP_P_SUBMIT_COI = "/policies/submit-coi";

		public static final String EAPP_P_RESERVE = "/policies/reserve";
		public static final String EAPP_P_SUBMIT_IPOS = "/policies/submit-ipos";
		public static final String EAPP_P_UPD_PROC_STS = "/policies/updateProcessStatus";
		public static final String EAPP_P_ENQ_IPOS = "/policies/enquire-ipos";

		public static final String EAPP_SUBMIT_IVERIFY = "/submit-iverify";
		public static final String EAPP_SUBMIT_MATCH_IVERIFY = "/match-iverify";
		public static final String EAPP_SUBMIT_REMATCH_IVERIFY = "/rematch-iverify";
		public static final String EAPP_SUBMIT_CHECK_IVERIFY = "/check-iverify";

	}

	public static final class APIFunction {

		private APIFunction() {
		}
		//online function
		public static final String EAPP_SUBMIT_IVERIFY = "SUBMIT_IVER";
		public static final String EAPP_SUBMIT_MATCH_IVERIFY = "MATCH_IVER";
		public static final String EAPP_SUBMIT_REMATCH_IVERIFY = "REMATCH_IVER";
		public static final String EAPP_SUBMIT_CHECK_IVERIFY = "CHK_IVER";
		
		public static final String EAPP_GEN_BATCH_ID= "GEN_BATCH_ID";
		public static final String EAPP_SUBMIT_BATCH = "SUBMIT_BATCH";
		public static final String EAPP_RESERVE_POL = "RSV_POL";
		public static final String EAPP_SUBMIT_POL_IPOS = "SUBMIT_POL_IPOS";
		public static final String EAPP_SUBMIT_POL_MINI = "SUBMIT_POL_MINI";
		public static final String EAPP_SUBMIT_POL_COI = "SUBMIT_POL_COI";
		public static final String EAPP_UPD_POL_PENDING = "UPD_POL_PENDING";
		public static final String EAPP_ENQ_PENDING_IPOS = "ENQ_PENDING_IPOS";
		
		//batch function
		public static final String EAPP_RELEASE_DOC = "RELEASE_DOC";

		//kafka
		public static final String EAPP_KAFKA_SYNC_DOC = "KAFKA_SYNC_DOC";
		public static final String EAPP_KAFKA_LISTEN_PGS_RATE_UP = "KAFKA_LISTEN_PGS_RATE_UP";
		public static final String EAPP_KAFKA_UPD_RB_STS = "KAFKA_UPD_RB_STS ";
		
	}
	
	public static final class KafkaPath {

		private KafkaPath() {
		}

		public static final String EAPP_KAFKA_RELEASE_STS = "hk.aia.il.new-business.policy.release-status.changed";

		public static final String EAPP_KAFKA_DOC_STS_CHG = "hk.aia.eapp.digital.sub.document.status.change";

		public static final String EAPP_KAFKA_PROPOSAL_REGEN = "hk.aia.pgs.digital.agency.proposal.regenerate";


	}
		
	public static final class APIAction {

		private APIAction() {
		}

		public static final String START_CALL = "START_CALL";
		public static final String START_CALL_LOG = "start call API {}";

		public static final String END_CALL_SUCESS = "END_CALL_SUCESS";
		public static final String END_CALL_SUCESS_LOG = "end call API {} http-code {}, time {}(ms)";

		public static final String END_CALL_FAILED = "END_CALL_FAILED";
		public static final String END_CALL_FAILED_LOG = "end call API {} exception {}, time {}(ms)";

		public static final String START_WORK = "START_WORK";
		public static final String START_WORK_LOG = "start working API {}";

		public static final String END_WORK_SUCESS = "END_WORK_SUCESS";
		public static final String END_WORK_SUCESS_LOG = "end working API {} success, time {}(ms)";

		public static final String END_WORK_FAILED = "END_WORK_FAILED";
		public static final String END_WORK_FAILED_LOG = "end working API {} exception {}, time {}(ms)";

	}
	
	public static final class ProcessAction {


		private ProcessAction() {
		}

		 
		public static final String START_SP = "START_SP";
		public static final String START_SP_LOG = "start Process {}";

		public static final String END_SP = "END_SP";
		public static final String END_SP_LOG = "end Process {} success, time {}(ms)";
		public static final String END_SP_ERROR_LOG = "end Process {} exception {}, time {}(ms)";
		
	}

    public static final class CitiSftpConstants {
        private CitiSftpConstants(){}

        public static final String ZIP_PHRASE_PREFIX = "CitiAIA_";

        public static final String ZIP_PHRASE_SUFFIX = "*";
    }

    // CommonConstants - would be used by multiple different services
    public static final String TIMEZONE = "Asia/Hong_Kong";
    public static final String SUCCESS = "Success";
    public static final String FAIL = "Fail";
    public static final String OK = "OK";

    public static final String LOG_ERROR_CAUSE_MESSAGE = "Error caused - {} | message - {}";

    public static final String RETURN_CODE_0 = "0"; // Fail
    public static final String RETURN_CODE_N1 = "N1"; // Non-Normalized Success Return Code - Calls for additional action - example : trigger XGFE
    public static final String RETURN_CODE_1 = "1"; // Success
    public static final String RETURN_CODE_2 = "2"; // Exception Fail
    public static final String RETURN_CODE_3 = "3";
    public static final String RETURN_CODE_4 = "4";
    public static final String RETURN_FAIL_CODE = "-1";
    public static final String RETURN_FAIL_CODE_2 = "-2";
    public static final String RETURN_FAIL_CODE_9 = "-9";
    public static final String RETURN_CODE_98 = "-98"; //authentication fail
    public static final String RETURN_CODE_99 = "-99"; // Common Fail Code

    public static final String IND_YES = "Y";
    public static final String IND_NO = "N";

    public static final String TIME_OUT_EXPRESSION = "javax.persistence.query.timeout";
    public static final int TIME_OUT = 60 * 1000;

    public static final String DDMMYYYY = "%1$td%1$tm%1$tY";

    public static final String PARAMSET10 = "?,?,?,?,?,?,?,?,?,?,";
    public static final String PARAMSET50 = PARAMSET10 + PARAMSET10 + PARAMSET10 + PARAMSET10 + PARAMSET10;

    public static final String PARAMLOG10 = "'{}','{}','{}','{}','{}','{}','{}','{}','{}','{}',";

    public static final String BMP_TYPE = "image/bmp";
    public static final String GIF_TYPE = "image/gif";
    public static final String JPEG_TYPE = "image/jpeg";
    public static final String PJPEG_TYPE = "image/pjpeg";
    public static final String PNG_TYPE = "image/png";
    public static final String XPNG_TYPE = "image/x-png";
    public static final String TIFF_TYPE = "image/tiff";
    public static final String ATIFF_TYPE = "application/tif";
    public static final String PDF_TYPE = "application/pdf";

    public static final String BMP = "bmp";
    public static final String GIF = "gif";
    public static final String JPEG = "jpg";
    public static final String PNG = "png";
    public static final String TIFF = "tif";
    public static final String PDF = "pdf";

    public static final String STATUS = "status";

    public static final String MESSAGE_TYPE_KAFKA_RECEIVE_SM = "KAFKA1-S-R";
    public static final String MESSAGE_TYPE_KAFKA_RECEIVE_PGS = "KAFKA-P-R";
    public static final String MESSAGE_TYPE_KAFKA_RECEIVE_EAPP = "KAFKA-E-R";
    public static final String MESSAGE_TYPE_KAFKA_SEND = "KAFKA-S";
    public static final String MESSAGE_TYPE_PATCH = "PATCH";
}
