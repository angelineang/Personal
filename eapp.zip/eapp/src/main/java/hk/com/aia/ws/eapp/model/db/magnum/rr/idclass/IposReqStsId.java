package hk.com.aia.ws.eapp.model.db.magnum.rr.idclass;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class IposReqStsId implements Serializable {
    private static final long serialVersionUID = -7653031515756596985L;
    private String eappId;
    private String policyNo;
    private Date lastSignDate;
    private String submitType;


}
