package hk.com.aia.ws.eapp.model.db.mag.iverify.idclass;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TPrcDoc4Id implements Serializable {
    private static final long serialVersionUID = 5150243638170859813L;
    private String iverifyId;
    private String docId;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TPrcDoc4Id{");
        sb.append("iverifyId='").append(iverifyId).append('\'');
        sb.append(", docId='").append(docId).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
