package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@ApiModel(value = "Gi Life Front Model")
@Data
public class GiLifeFront {

    @ApiModelProperty(value = "Date of Birth", example = "2000-12-31", notes = "format:yyyy-MM-dd")
    @JsonProperty("dob")
    private String dob;

    @ApiModelProperty(value = "E-mail")
    @JsonProperty("email")
    private String email;

    @ApiModelProperty(value = "First Name")
    @JsonProperty("first_name")
    private String firstName;

    @ApiModelProperty(value = "First Name - Chinese")
    @JsonProperty("first_name_chinese")
    private String firstNameChinese;

    @ApiModelProperty(value = "Gi Life")
    @JsonProperty("gi_life")
    private Integer giLife;

    @ApiModelProperty(value = "Gi Life - Status")
    @JsonProperty("gi_life_status")
    private String giLifeStatus;

    @ApiModelProperty(value = "Id Expiry", example = "2000-12-31", notes = "format:yyyy-MM-dd")
    @JsonProperty("id_expiry")
    private String idExpiry;

    @ApiModelProperty(value = "Id Number")
    @JsonProperty("id_number")
    private String idNumber;

    @ApiModelProperty(value = "Id Type")
    @JsonProperty("id_type")
    private String idType;

    @ApiModelProperty(value = "Last Name")
    @JsonProperty("last_name")
    private String lastName;

    @ApiModelProperty(value = "Last Name - Chinese")
    @JsonProperty("last_name_chinese")
    private String lastNameChinese;

    @ApiModelProperty(value = "Nationality")
    @JsonProperty("nationality")
    private String nationality;

    @ApiModelProperty(value = "Reject Code")
    @JsonProperty("reject_code")
    private String rejectCode;

    @ApiModelProperty(value = "Reject Reason")
    @JsonProperty("reject_reason")
    private String rejectReason;

    @ApiModelProperty(value = "Relationship")
    @JsonProperty("relationship")
    private String relationship;

    @ApiModelProperty(value = "Sex")
    @JsonProperty("sex")
    private String sex;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("GiLifeFront{");
        sb.append("dob='").append(ConversionHandler.mask(dob)).append('\'');
        sb.append(", email='").append(ConversionHandler.mask(email)).append('\'');
        sb.append(", firstName='").append(ConversionHandler.mask(firstName)).append('\'');
        sb.append(", firstNameChinese='").append(ConversionHandler.mask(firstNameChinese)).append('\'');
        sb.append(", giLife=").append(giLife);
        sb.append(", giLifeStatus='").append(giLifeStatus).append('\'');
        sb.append(", idExpiry='").append(idExpiry).append('\'');
        sb.append(", idNumber='").append(idNumber).append('\'');
        sb.append(", idType='").append(idType).append('\'');
        sb.append(", lastName='").append(ConversionHandler.mask(lastName)).append('\'');
        sb.append(", lastNameChinese='").append(ConversionHandler.mask(lastNameChinese)).append('\'');
        sb.append(", nationality='").append(nationality).append('\'');
        sb.append(", rejectCode='").append(rejectCode).append('\'');
        sb.append(", rejectReason='").append(rejectReason).append('\'');
        sb.append(", relationship='").append(relationship).append('\'');
        sb.append(", sex='").append(sex).append('\'');
        sb.append('}');
        return sb.toString();
    }
}

