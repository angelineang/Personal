package hk.com.aia.ws.eapp.model.request.ipos;

import java.math.BigDecimal;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@ApiModel(value = "T_ADHOCTOPUP Model")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TAdhocTopUpDto {

	@ApiModelProperty(value = "ad Hoc Topup Id", required = true) 
    @JsonProperty("adhoc_topup_id")
	@Size(max = 60)
    @NotBlank
    private String adhocTopUpId;

    @JsonProperty("agent_code")
    @Size(max = 10)
    private String agentCode;

    @JsonProperty("access_code")
    @Size(max = 30)
    private String accessCode;

	@ApiModelProperty(value = "sqs Quotation Id", required = true)
    @JsonProperty("sqs_quotation_id")
	@Size(max = 60)
    @NotBlank
    private String sqsQuotationId;

    @JsonProperty("policy_year")
    private Integer policyYear;

    @JsonProperty("amount")
    private BigDecimal amount;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TAdhocTopUpDto{");
        sb.append("adhocTopUpId='").append(adhocTopUpId).append('\'');
        sb.append(", agentCode='").append(agentCode).append('\'');
        sb.append(", accessCode='").append(accessCode).append('\'');
        sb.append(", sqsQuotationId='").append(sqsQuotationId).append('\'');
        sb.append(", policyYear=").append(policyYear);
        sb.append(", amount=").append(amount);
        sb.append('}');
        return sb.toString();
    }
}



