package hk.com.aia.ws.eapp.model.db.magnum.ipos.idclass;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TblHousekeepHisId implements Serializable {

    private static final long serialVersionUID = 1L;
    private String table_name;
    private String housekeep_date;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TblHousekeepHisId{");
        sb.append("table_name='").append(table_name).append('\'');
        sb.append(", housekeep_date='").append(housekeep_date).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
