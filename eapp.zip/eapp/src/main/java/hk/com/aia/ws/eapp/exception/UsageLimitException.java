package hk.com.aia.ws.eapp.exception;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class UsageLimitException extends RuntimeException {
    private static final long serialVersionUID = 1L;
    private String code;
    private String message;
    private String counter;
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public void setCounter(String counter) {
		this.counter = counter;
	}
	public String getCode() {
		return code;
	}
	
	@Override
	public String getMessage() {
		return message;
	}
	public String getCounter() {
		return counter;
	}

}

