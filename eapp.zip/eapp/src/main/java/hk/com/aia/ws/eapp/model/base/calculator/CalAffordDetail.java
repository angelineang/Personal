package hk.com.aia.ws.eapp.model.base.calculator;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class CalAffordDetail {

    @JsonProperty("current_age")
    private int currentAge;

    @JsonProperty("retire_age")
    private int retireAge;

    @JsonProperty("monthly_income_br")
    private BigDecimal monthlyIncomeBr;

    @JsonProperty("monthly_expense_br")
    private BigDecimal monthlyExpenseBr;

    @JsonProperty("monthly_d_income_ar")
    private BigDecimal monthlyDIncomeAr;

    @JsonProperty("annual_d_income_br")
    private BigDecimal annualDIncomeBr;

    @JsonProperty("annual_d_income_ar")
    private BigDecimal annualDIncomeAr;

    @JsonProperty("liquid_asset_br")
    private BigDecimal liquidAssetBr;

    @JsonProperty("liquid_asset_ar")
    private BigDecimal liquidAssetAr;

    @JsonProperty("income_contrib")
    private int incomeContrib;

    @JsonProperty("asset_contrib")
    private int assetContrib;

    @JsonProperty("anp")
    private BigDecimal anp;

    @JsonProperty("single_premium_1")
    private BigDecimal singlePremium1;

    @JsonProperty("annual_premium_1")
    private BigDecimal annualPremium1;

    @JsonProperty("sp_curr_1")
    private String spCurr1;

    @JsonProperty("ann_curr_1")
    private String annCurr1;

    @JsonProperty("payment_term_1")
    private int paymentTerm1;

    @JsonProperty("single_premium_2")
    private BigDecimal singlePremium2;

    @JsonProperty("annual_premium_2")
    private BigDecimal annualPremium2;

    @JsonProperty("sp_curr_2")
    private String spCurr2;

    @JsonProperty("ann_curr_2")
    private String annCurr2;

    @JsonProperty("payment_term_2")
    private int paymentTerm2;

    @JsonProperty("single_premium_3")
    private BigDecimal singlePremium3;

    @JsonProperty("annual_premium_3")
    private BigDecimal annualPremium3;

    @JsonProperty("sp_curr_3")
    private String spCurr3;

    @JsonProperty("ann_curr_3")
    private String annCurr3;

    @JsonProperty("payment_term_3")
    private int paymentTerm3;

    @JsonProperty("single_premium_4")
    private BigDecimal singlePremium4;

    @JsonProperty("annual_premium_4")
    private BigDecimal annualPremium4;

    @JsonProperty("sp_curr_4")
    private String spCurr4;

    @JsonProperty("ann_curr_4")
    private String annCurr4;

    @JsonProperty("payment_term_4")
    private int paymentTerm4;

    @JsonProperty("single_premium_5")
    private BigDecimal singlePremium5;

    @JsonProperty("annual_premium_5")
    private BigDecimal annualPremium5;

    @JsonProperty("sp_curr_5")
    private String spCurr5;

    @JsonProperty("ann_curr_5")
    private String annCurr5;

    @JsonProperty("payment_term_5")
    private int paymentTerm5;

    @JsonProperty("loanAmt")
    private BigDecimal loanAmt;
    
    @JsonProperty("loanInterestRate")
    private BigDecimal loanInterestRate;
    
    @JsonProperty("repaymentAmt")
    private BigDecimal repaymentAmt;
    
    @JsonProperty("loanTenors")
    private BigDecimal loanTenors;

}
