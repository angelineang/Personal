package hk.com.aia.ws.eapp.controller;

import java.io.IOException;
import java.net.URISyntaxException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.microsoft.azure.storage.StorageException;
import com.nimbusds.jose.util.StandardCharset;

import hk.com.aia.ws.eapp.aes.util.AES;
import hk.com.aia.ws.eapp.exception.BlobNotFoundException;
import hk.com.aia.ws.eapp.model.base.Payload;
import hk.com.aia.ws.eapp.model.request.AzureRequest;
import hk.com.aia.ws.eapp.model.response.AzureList;
import hk.com.aia.ws.eapp.model.response.AzureResponse;
import hk.com.aia.ws.eapp.service.AzureBlobService;
import hk.com.aia.ws.eapp.service.key.KeyService;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/azure")
@Slf4j
public class AzureDocumentController {

    @Qualifier("documentAzureBlobService")
    @Autowired
    private AzureBlobService documentBlobService;

    @Qualifier("eFormAzureBlobService")
    @Autowired
    private AzureBlobService eFormAzureBlobService;
    
    @Qualifier("egressAzureBlobService")
    @Autowired
    private AzureBlobService egressAzureBlobService;
    
    @Qualifier("pgsAzureBlobService")
    @Autowired
    private AzureBlobService pgsAzureBlobService;
    
    @Qualifier("eappDocumentAzureBlobService")
    @Autowired
    private AzureBlobService eappDocumentBlobService;
    
    
    @Autowired
    KeyService keyService;
    
    byte[] ivbyte = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
    
	private AzureBlobService getBlobService(String storage) {
		switch (storage) {
		case "document":
			return documentBlobService;
		case "eForm":
			return eFormAzureBlobService;
		case "egress":
			return egressAzureBlobService;
		case "pgs":
			return pgsAzureBlobService;
		case "edocument":
			return eappDocumentBlobService;
		default:
			return documentBlobService;
		}
	}

    @PostMapping("/uploadtoblob")
    public AzureResponse<Payload> uploadFileToBlob(@RequestBody AzureRequest<Payload> request)
            throws IOException, StorageException, URISyntaxException, InvalidKeyException {

        String encodedString = request.getDoc_file();
        String targetFileName = request.getBlob_name();
        byte[] decodedBytes = Base64.getDecoder().decode(encodedString);
        AzureBlobService azureBlobService= getBlobService(request.getStorage());
        azureBlobService.uploadFileToBlob(decodedBytes, targetFileName);

        AzureResponse<Payload> payload = new AzureResponse<>();
        payload.setDoc_file(request.getDoc_file());
        payload.setBlob_name(request.getBlob_name());

        return payload;
    }

    @PostMapping("/encrypttoblob")
    public AzureResponse<Payload> encryptFileToBlob(@RequestBody AzureRequest<Payload> request)
            throws IOException, StorageException, URISyntaxException, InvalidKeyException, InvalidKeySpecException, NoSuchAlgorithmException {

        String encodedString = request.getDoc_file();
        String targetFileName = request.getBlob_name();
        byte[] decodedBytes = Base64.getDecoder().decode(encodedString);
        AzureBlobService azureBlobService= getBlobService(request.getStorage());
        azureBlobService.uploadEncryptedByKey(decodedBytes, targetFileName);

        AzureResponse<Payload> payload = new AzureResponse<>();
        payload.setDoc_file(request.getDoc_file());
        payload.setBlob_name(request.getBlob_name());

        return payload;
    }

    @PostMapping("/downloadfromblob")
    public AzureResponse<Payload> downloadFileFromBlob(@RequestBody AzureRequest<Payload> request)
            throws IOException, NoSuchAlgorithmException, StorageException, URISyntaxException, InvalidKeyException, BlobNotFoundException, BlobNotFoundException {
    	  AzureBlobService azureBlobService= getBlobService(request.getStorage());
           
        byte[] bytes = azureBlobService.downloadBlob(request.getBlob_name());
        
         
		if (request.getStorage()!=null&&request.getStorage().equals("pgs")) {
			String encodedString2 = Base64.getEncoder().encodeToString(bytes);
			log.info("start decode2 ");
			byte[] encrytedBlobFile = hk.com.aia.ws.eapp.aes.util.Base64.decode2(encodedString2);
			log.info("start getPGSKey");
			String pgsSecretId = keyService.getPGSKey();
			log.info("start decrypt");
			byte[] decryptedFile = AES.decrypt(encrytedBlobFile, pgsSecretId, ivbyte);
			String base64String = new String(decryptedFile, StandardCharset.UTF_8);
			log.info("start second decode2 ");
			bytes = hk.com.aia.ws.eapp.aes.util.Base64.decode2(base64String);

		}
        
        
        String encodedString = Base64.getEncoder().encodeToString(bytes);


        AzureResponse<Payload> payload = new AzureResponse<>();
        payload.setDoc_file(encodedString);
        payload.setBlob_name(request.getBlob_name());

        return payload;
    }

    @PostMapping("/decryptfromblob")
    public AzureResponse<Payload> decryptFileFromBlob(@RequestBody AzureRequest<Payload> request)
            throws IOException, NoSuchAlgorithmException, StorageException, URISyntaxException, InvalidKeyException, BlobNotFoundException, BlobNotFoundException {
    	  AzureBlobService azureBlobService= getBlobService(request.getStorage());
        byte[] bytes = azureBlobService.downloadEncryptedBlob(request.getBlob_name());
        
        String encodedString = Base64.getEncoder().encodeToString(bytes);


        AzureResponse<Payload> payload = new AzureResponse<>();
        payload.setDoc_file(encodedString);
        payload.setBlob_name(request.getBlob_name());

        return payload;
    }

    @PostMapping("/listblob")
    public AzureList<Payload> listBlob (@RequestBody AzureRequest<Payload> request) {
        AzureList<Payload> payload = new AzureList<>();
        List<String> blobList = new ArrayList<>();
        AzureBlobService azureBlobService= getBlobService(request.getStorage());
        blobList = azureBlobService.listBlob(request.getPrefix());

        payload.setBlobList(blobList);

        return payload;

    }



}
