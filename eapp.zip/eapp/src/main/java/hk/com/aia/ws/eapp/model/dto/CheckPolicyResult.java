package hk.com.aia.ws.eapp.model.dto;

import hk.com.aia.ws.eapp.util.ConversionHandler;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class CheckPolicyResult {

    private String callPNA;
    private String CitiCase;
    private String policyNo;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("CheckPolicyResult{");
        sb.append("callPNA='").append(callPNA).append('\'');
        sb.append(", CitiCase='").append(CitiCase).append('\'');
        sb.append(", policyNo='").append(ConversionHandler.mask(policyNo)).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
