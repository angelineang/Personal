package hk.com.aia.ws.eapp.model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class SubmissionDto extends ResultDto{

    private SubmissionActivity submissionActivity;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("SubmissionDto{");
        sb.append("submissionActivity=").append(submissionActivity);
        sb.append('}');
        return sb.toString();
    }
}
