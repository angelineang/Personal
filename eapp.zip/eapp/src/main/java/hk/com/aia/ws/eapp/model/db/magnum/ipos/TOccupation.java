package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import hk.com.aia.ws.eapp.annotation.DataTruncation;
import lombok.Data;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "T_OCCUPATION")
public class TOccupation {

    @Column(name = "OCCUPATIONID", length = 60)
    @Id
    private String occupationId;

    @Column(name = "CONTACTID", length = 60)
    private String contactId;

    @Column(name = "OCCUPATIONCODE", length = 60)
    private String occupationCode;

    @Column(name = "OCCUPATIONNAME")
    @DataTruncation(max = 100, validateByte = true, log = true)
    private String occupationName;

    @Column(name = "INDUSTRYCODE", length = 60)
    private String industryCode;

    @Column(name = "INDUSTRYNAME", length = 100)
    private String industryName;

    @Column(name = "OTHERS")
    @DataTruncation(max = 500, validateByte = true, log = true)
    private String others;

    @Column(name = "MONTHLYINCOMECURRENCY", length = 3)
    private String monthlyIncomeCurrency;

    @Column(name = "MONTHLYINCOME", length = 60)
    private String monthlyIncome;

    @Column(name = "CREATEDBY", length = 10, updatable = false)
    @CreatedBy
    private String createdBy;

    @Column(name = "UPDATEDBY", length = 10)
    @LastModifiedBy
    private String updatedBy;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "LASTUPDATEDATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    @LastModifiedDate
    private Date lastUpdateDateTime;

    @Column(name = "MONTHLYEXPENSE", length = 60)
    private String monthlyExpense;

    @Column(name = "Occ_question1")
    private Integer occQuestion1;

    @Column(name = "Occ_question2")
    private Integer occQuestion2;

    @Column(name = "isNotAnswer")
    private Integer isNotAnswer;

    @Column(name = "jobNature")
    private Integer jobNature;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TOccupation{");
        sb.append("occupationId='").append(occupationId).append('\'');
        sb.append(", contactId='").append(contactId).append('\'');
        sb.append(", occupationCode='").append(occupationCode).append('\'');
        sb.append(", occupationName='").append(occupationName).append('\'');
        sb.append(", industryCode='").append(industryCode).append('\'');
        sb.append(", industryName='").append(industryName).append('\'');
        sb.append(", others='").append(others).append('\'');
        sb.append(", monthlyIncomeCurrency='").append(monthlyIncomeCurrency).append('\'');
        sb.append(", monthlyIncome='").append(monthlyIncome).append('\'');
        sb.append(", createdBy='").append(createdBy).append('\'');
        sb.append(", updatedBy='").append(updatedBy).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", lastUpdateDateTime=").append(lastUpdateDateTime);
        sb.append(", monthlyExpense='").append(monthlyExpense).append('\'');
        sb.append(", occQuestion1=").append(occQuestion1);
        sb.append(", occQuestion2=").append(occQuestion2);
        sb.append(", isNotAnswer=").append(isNotAnswer);
        sb.append(", jobNature=").append(jobNature);
        sb.append('}');
        return sb.toString();
    }
}
