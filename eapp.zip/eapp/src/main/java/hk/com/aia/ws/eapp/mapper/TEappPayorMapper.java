package hk.com.aia.ws.eapp.mapper;

import hk.com.aia.ws.eapp.model.db.magnum.ipos.TCitiFna;
import hk.com.aia.ws.eapp.model.db.magnum.ipos.TEappPayor;
import hk.com.aia.ws.eapp.model.request.ipos.TCitiFnaDto;
import hk.com.aia.ws.eapp.model.request.ipos.TEappPayorDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

@Mapper
public interface TEappPayorMapper {

    TEappPayorMapper MAPPER = Mappers.getMapper(TEappPayorMapper.class);

    TEappPayor mapToTEappPayor(TEappPayorDto tEappPayorDto);
}
