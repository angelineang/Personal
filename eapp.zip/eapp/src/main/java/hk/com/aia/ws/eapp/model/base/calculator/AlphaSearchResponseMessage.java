package hk.com.aia.ws.eapp.model.base.calculator;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class AlphaSearchResponseMessage {

	@JsonProperty("code")
	private String code;

	@JsonProperty("description")
	private String description;

	@JsonProperty("severity")
	private String severity;

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder("ResponseMessage{");
		sb.append("code='").append(code).append('\'');
		sb.append(", severity='").append(severity).append('\'');
		sb.append(", description='").append(description).append('\'');
		sb.append('}');
		return sb.toString();
	}
}
