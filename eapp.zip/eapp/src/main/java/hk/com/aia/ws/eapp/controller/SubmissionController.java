package hk.com.aia.ws.eapp.controller;

import static hk.com.aia.ws.eapp.constant.Constants.RETURN_CODE_1;
import static hk.com.aia.ws.eapp.constant.Constants.RETURN_CODE_99;
import static hk.com.aia.ws.eapp.constant.Constants.SUCCESS;
import static hk.com.aia.ws.eapp.constant.Constants.EFKLogging.APP_CONTEXT_ID;
import static hk.com.aia.ws.eapp.constant.Constants.EFKLogging.CALLER_CONTEXT_ID;
import static hk.com.aia.ws.eapp.constant.Constants.EFKLogging.TRACE_ID;
import static hk.com.aia.ws.eapp.constant.Constants.ExceptionMsg.CLOUD_POLICY_ERROR;
import static hk.com.aia.ws.eapp.constant.Constants.SubmitMsConstants.WS_ACTION_ESUB;
import static hk.com.aia.ws.eapp.constant.Constants.SubmitMsConstants.WS_ACTION_GET_SUBMIT_MS_STATUS;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;

import javax.validation.Valid;

import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import hk.com.aia.ws.eapp.constant.Constants;
import hk.com.aia.ws.eapp.constant.Constants.APIFunction;
import hk.com.aia.ws.eapp.constant.Constants.APIPath;
import hk.com.aia.ws.eapp.exception.ErrorResultException;
import hk.com.aia.ws.eapp.model.base.CheckPolicy;
import hk.com.aia.ws.eapp.model.base.Coi;
import hk.com.aia.ws.eapp.model.base.CustomResponseStatus;
import hk.com.aia.ws.eapp.model.base.EappDocument;
import hk.com.aia.ws.eapp.model.base.Flow;
import hk.com.aia.ws.eapp.model.base.FlowResult;
import hk.com.aia.ws.eapp.model.base.PolicyCheckResult;
import hk.com.aia.ws.eapp.model.base.PolicyCheckResults;
import hk.com.aia.ws.eapp.model.base.ReservePolicy;
import hk.com.aia.ws.eapp.model.base.ResultMessage;
import hk.com.aia.ws.eapp.model.base.ReturnPolicy;
import hk.com.aia.ws.eapp.model.base.SubmissionDetail;
import hk.com.aia.ws.eapp.model.base.SubmitMsStatus;
import hk.com.aia.ws.eapp.model.db.magnum.PolCloud;
import hk.com.aia.ws.eapp.model.dto.ResultDto;
import hk.com.aia.ws.eapp.model.dto.ReturnPolicyDto;
import hk.com.aia.ws.eapp.model.log.TranKeys;
import hk.com.aia.ws.eapp.model.request.Request;
import hk.com.aia.ws.eapp.model.request.ipos.EnquirePolicyIpos;
import hk.com.aia.ws.eapp.model.request.ipos.SubmitPolicyIpos;
import hk.com.aia.ws.eapp.model.response.Response;
import hk.com.aia.ws.eapp.model.response.SubmitMsStatusResponse;
import hk.com.aia.ws.eapp.model.response.error.GatewayError400;
import hk.com.aia.ws.eapp.model.response.error.GatewayError401;
import hk.com.aia.ws.eapp.model.response.error.InternalError500;
import hk.com.aia.ws.eapp.model.response.ipos.FilResult;
import hk.com.aia.ws.eapp.service.EappPolicyService;
import hk.com.aia.ws.eapp.service.FlowIndicatorService;
import hk.com.aia.ws.eapp.service.IposService;
import hk.com.aia.ws.eapp.service.LogService;
import hk.com.aia.ws.eapp.service.PayloadRequestService;
import hk.com.aia.ws.eapp.service.PolCloudService;
import hk.com.aia.ws.eapp.service.SubmissionService;
import hk.com.aia.ws.eapp.service.SubmitMsService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;


@Slf4j
@AllArgsConstructor
@RestController
@RequestMapping("/policies")
@Api(value = "Proposal Submission", tags = {"API(s) for proposal submission"})
@Validated
public class SubmissionController {

    @Autowired
    private final SubmissionService submissionService;

    @Autowired
    private final EappPolicyService eappPolicyService;

    @Autowired
    private final SubmitMsService submitMsService;

    @Autowired
    private final FlowIndicatorService flowIndicatorService;

    @Autowired
    private final IposService iposService;

    @Autowired
    private final PolCloudService polCloudService;

    @Autowired
    private PayloadRequestService payloadRequestService;
    
    @Autowired
    private LogService logService;
    
    /**
     * To submit ipos proposal
     *
     * @return Response FilResult
     */
    @ApiOperation("To submit ipos proposal - ipos submission")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "proposal submission successfully."),
            @ApiResponse(code = 400, message = "Bad Request", response = GatewayError400.class),
            @ApiResponse(code = 401, message = "Unauthorized", response = GatewayError401.class),
            @ApiResponse(code = 404, message = "Invalid request.", response = Response.class),
            @ApiResponse(code = 500, message = "Internal Server Error", response = InternalError500.class)
    })
    @PostMapping(value = "/submit-ipos", produces = "application/json")
    public Response<FilResult> submitIPos(
            @ApiParam(value = "Local business unit.    | Valid Values |   | ----------   |   | HK, TH, SG   | ", required = true)
            @RequestHeader(value = Constants.RequestHeader.AIA_LBU, required = true) String xAiaLbu,
            @ApiParam(value = "Unique id for the request for tracking purposes.        ", required = true)
            @RequestHeader(value = Constants.RequestHeader.REQUEST_ID, required = true) String xAiaRequestId,
            @ApiParam(value = "Target environment of the request. Note that this header is required only when accessing non-production environments.    | Valid Values       |   | ------------------ |   | qa1, qa2, qa3, qa4 |        ")
            @RequestHeader(value = Constants.RequestHeader.AIA_ENV, required = false) String xAiaEnv,
            @ApiParam(value = "JWT Token for the request to verify Agent Authorization")
            @RequestHeader(value = Constants.RequestHeader.TOKEN_AGENT, required = false) String xAiaTokenAgent,
            @ApiParam(value = "Trace Id for EFK Logging")
            @RequestHeader(value = Constants.RequestHeader.TRACE_ID, required = false) String xAiaHkTraceId,
            @ApiParam(value = "An access token issued by an AIA Authorization server. This will have the format Bearer + {space} + {accessToken}.")
            @RequestHeader(value = Constants.RequestHeader.AIAACESSTOKEN, required = false) String Authorization,
            @ApiParam(value = "Context Id for EFK Logging")
            @RequestHeader(value = Constants.RequestHeader.CONTEXT_ID) String xAiaHkContextId,            
            @ApiParam(value = "Originating IP for EFK Logging")
            @RequestHeader(value = Constants.RequestHeader.FORWARDED_FOR, required = false) String xForwardedFor,
            @ApiParam(value = "Originating User for EFK Logging")
            @RequestHeader(value = Constants.RequestHeader.ORIGINATING_USER, required = false) String xAiahkOriginatingUserId,  
            @ApiParam(value = "Source App info for EFK Logging")
            @RequestHeader(value = Constants.RequestHeader.SOURCE_APP, required = false) String xSourceApp,
            @ApiParam(value = "Policy details to be submitted", required = true)
            @Valid @RequestBody Request<SubmitPolicyIpos> submitPolicyIpos) {

    	String polNo = submitPolicyIpos.getData().getPolicyNo();
		String submitType = submitPolicyIpos.getData().getSubmitType();
		String eappId = submitPolicyIpos.getData().getEappId();
		logService.logTranKey(new TranKeys(polNo, submitType, eappId,"",submitPolicyIpos.getAppId(),APIFunction.EAPP_SUBMIT_POL_IPOS));
		
    	logService.logStartWorkingIntegration( APIPath.EAPP_P_SUBMIT_IPOS );
    	LocalDateTime start = LocalDateTime.now();
    	
   	 
		if(("S").equals(submitPolicyIpos.getData().getSubmitType())){
			payloadRequestService.saveRequestPreJson(polNo, "IPOS-C", submitPolicyIpos, eappId);
		}else {
			payloadRequestService.saveRequestJson(polNo, "IPOS-C", submitPolicyIpos);
		}
		
		  
        if (!("S").equals(submitPolicyIpos.getData().getSubmitType())) {
            final PolCloud polCloud = polCloudService.savePolicyNoIntoCloudFlow(submitPolicyIpos.getAppId(), submitPolicyIpos.getData().getPolicyNo(), MDC.get(TRACE_ID), MDC.get(CALLER_CONTEXT_ID), MDC.get(APP_CONTEXT_ID), MDC.get(Constants.EFKLogging.SOURCE_USER_ID), MDC.get(Constants.EFKLogging.SOURCE_USER_IP));

            if (polCloud.getId() == null) {
                throw new ErrorResultException("-99", String.format(CLOUD_POLICY_ERROR, submitPolicyIpos.getData().getPolicyNo()));
            }
        }







        
        Response<FilResult> res=iposService.submitIpos(submitPolicyIpos);

      
    	if(("S").equals(submitType)){
			payloadRequestService.saveRequestPreJson(polNo, "IPOS-R", res, eappId);
		}else {
			payloadRequestService.saveRequestJson(polNo, "IPOS-R", res);
		}
        
    	LocalDateTime end =LocalDateTime.now() ;
    	Duration duration = Duration.between( start,end );
    	logService.logEndWorkingSuccessIntegration( APIPath.EAPP_P_SUBMIT_IPOS,  duration.toMillis());
        
        return res;
    }

    /**
     * To enquire pending ipos message
     *
     * @return ipos enquire
     */
    @ApiOperation("To enquire pending ipos message")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successful request."),
            @ApiResponse(code = 400, message = "Bad Request", response = GatewayError400.class),
            @ApiResponse(code = 401, message = "Unauthorized", response = GatewayError401.class),
            @ApiResponse(code = 404, message = "Invalid request.", response = Response.class),
            @ApiResponse(code = 500, message = "Internal Server Error", response = InternalError500.class)
    })
    @PostMapping(value = "/enquire-ipos", produces = MediaType.APPLICATION_JSON_VALUE)
    public Response<FilResult> enquireIPos(
            @ApiParam(value = "Local business unit.    | Valid Values |   | ----------   |   | HK, TH, SG   | ", required = true)
            @RequestHeader(value = Constants.RequestHeader.AIA_LBU, required = true) String xAiaLbu,
            @ApiParam(value = "Unique id for the request for tracking purposes.        ", required = true)
            @RequestHeader(value = Constants.RequestHeader.REQUEST_ID, required = true) String xAiaRequestId,
            @ApiParam(value = "Target environment of the request. Note that this header is required only when accessing non-production environments.    | Valid Values       |   | ------------------ |   | qa1, qa2, qa3, qa4 |        ")
            @RequestHeader(value = Constants.RequestHeader.AIA_ENV, required = false) String xAiaEnv,
            @ApiParam(value = "JWT Token for the request to verify Agent Authorization")
            @RequestHeader(value = Constants.RequestHeader.TOKEN_AGENT, required = false) String xAiaTokenAgent,
            @ApiParam(value = "Trace Id for EFK Logging")
            @RequestHeader(value = Constants.RequestHeader.TRACE_ID, required = false) String xAiaHkTraceId,
            @ApiParam(value = "An access token issued by an AIA Authorization server. This will have the format Bearer + {space} + {accessToken}.")
            @RequestHeader(value = Constants.RequestHeader.AIAACESSTOKEN, required = false) String Authorization,
            @ApiParam(value = "Context Id for EFK Logging")
            @RequestHeader(value = Constants.RequestHeader.CONTEXT_ID, required = true) String xAiaHkContextId,
            @ApiParam(value = "Policy details to be submitted", required = true)
            @Valid @RequestBody Request<EnquirePolicyIpos> enquirePolicyIposRequest) {
    	
    	
    	Response<FilResult> res=null;
    	LocalDateTime start = LocalDateTime.now();
    	String submitType=enquirePolicyIposRequest.getData().getSubmitType();
    	String eappId=enquirePolicyIposRequest.getData().getEappId();
    	String polNo= enquirePolicyIposRequest.getData().getPolicyNo();
    	
    	logService.logTranKey(new TranKeys(polNo, submitType, eappId,"",enquirePolicyIposRequest.getAppId(),APIFunction.EAPP_ENQ_PENDING_IPOS));
    	logService.logStartWorkingIntegration( APIPath.EAPP_P_ENQ_IPOS  );

    	
    	logService.logTranKey(new TranKeys(polNo, submitType, eappId,"",enquirePolicyIposRequest.getAppId(),APIFunction.EAPP_ENQ_PENDING_IPOS));
      	if(("S").equals(submitType)){
  			payloadRequestService.saveRequestPreJson(polNo, "POL_ENQ-C", enquirePolicyIposRequest, eappId);
  		}else {
  			payloadRequestService.saveRequestJson(polNo, "POL_ENQ-C", enquirePolicyIposRequest);
  		}
    	
    	res=iposService.getIposPendMessage(enquirePolicyIposRequest);
    	   
      	if(("S").equals(submitType)){
  			payloadRequestService.saveRequestPreJson(polNo, "POL_ENQ-R", res, eappId);
  		}else {
  			payloadRequestService.saveRequestJson(polNo, "POL_ENQ-R", res);
  		}
          
      	LocalDateTime end =LocalDateTime.now() ;
		Duration duration = Duration.between(start, end);
		logService.logEndWorkingSuccessIntegration(APIPath.EAPP_P_ENQ_IPOS, duration.toMillis());
          
      	
        return res;
    }


    /**
     * To reserve and policy number using reference no
     *
     * @param
     * @return
     */

    @ApiOperation(value = "To reserve policy number for the proposal submission using reference number.")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Policy number reserved successfully by reference number."),
            @ApiResponse(code = 400, message = "Bad Request", response = GatewayError400.class),
            @ApiResponse(code = 401, message = "Unauthorized", response = GatewayError401.class),
            @ApiResponse(code = 404, message = "Invalid request.", response = Response.class),
            @ApiResponse(code = 500, message = "Internal Server Error", response = InternalError500.class)
    })
    @PostMapping(value = "/reserve", produces = MediaType.APPLICATION_JSON_VALUE)
    public Response<ReturnPolicy> reserve(
            @ApiParam(value = "Local business unit.    | Valid Values |   | ----------   |   | HK, TH, SG   | ", required = true)
            @RequestHeader(value = Constants.RequestHeader.AIA_LBU, required = true) String xAiaLbu,
            @ApiParam(value = "Unique id for the request for tracking purposes.        ", required = true)
            @RequestHeader(value = Constants.RequestHeader.REQUEST_ID, required = true) String xAiaRequestId,
            @ApiParam(value = "Target environment of the request. Note that this header is required only when accessing non-production environments.    | Valid Values       |   | ------------------ |   | qa1, qa2, qa3, qa4 |        ")
            @RequestHeader(value = Constants.RequestHeader.AIA_ENV, required = false) String xAiaEnv,
            @ApiParam(value = "JWT Token for the request to verify Agent Authorization")
            @RequestHeader(value = Constants.RequestHeader.TOKEN_AGENT, required = false) String xAiaTokenAgent,
            @ApiParam(value = "Trace Id for EFK Logging")
            @RequestHeader(value = Constants.RequestHeader.TRACE_ID, required = false) String xAiaHkTraceId,
            @ApiParam(value = "Context Id for EFK Logging")
            @RequestHeader(value = Constants.RequestHeader.CONTEXT_ID, required = true) String xAiaHkContextId,
            @ApiParam(value = "Policy number to reserve", required = true)
            @Valid @RequestBody Request<ReservePolicy> reservePolicy) {

    	LocalDateTime start = LocalDateTime.now();
    	String polNo="";
    	String submitType="E";
    	
     	if ("S".equals(reservePolicy.getData().getPolicyNo()))
    	{
     		submitType="S";
    	} 
     	
     	logService.logTranKey(new TranKeys("", submitType,reservePolicy.getData().getRefNo(),"",reservePolicy.getAppId(),APIFunction.EAPP_RESERVE_POL));
     	logService.logStartWorkingIntegration( APIPath.EAPP_P_RESERVE );
    	
    	if ("S".equals(submitType))
    	{
    		payloadRequestService.saveRequestPreJson("", "RSV-C", reservePolicy, reservePolicy.getData().getRefNo());
        	
    	}else {
    		payloadRequestService.saveRequestJson("", "RSV-C", reservePolicy, reservePolicy.getData().getRefNo());
        	
    	}
    	
        final ResultDto<ReturnPolicyDto> result = submissionService.checkPolicyAndRetry(reservePolicy);

        final Response<ReturnPolicy> payload = new Response<>();

        
        payload.setTransId(reservePolicy.getTransId());
        payload.setStatus(CustomResponseStatus.SUCCESS.getDescription());
        payload.getResultMessages().add(new ResultMessage(result.getReturnCode(),
                result.getReturnMessage()));

        ReturnPolicy returnPolicy = new ReturnPolicy();
        if (Objects.nonNull(result.getData())) {
            returnPolicy.setPolicyNo(result.getData().getPolicyNo());
            //return 'type' would be null as not required for user to send submit_type
            polNo=result.getData().getPolicyNo();
        }

        payload.setData(returnPolicy);

    	if ("S".equals(submitType))
    	{
    		payloadRequestService.saveRequestPreJson(returnPolicy.getPolicyNo(), "RSV-R", payload, reservePolicy.getData().getRefNo());
        	
    	}else {
    		payloadRequestService.saveRequestJson(returnPolicy.getPolicyNo(), "RSV-R", payload, reservePolicy.getData().getRefNo());
        	
    	}
    	
    	
    	logService.logTranKey(new TranKeys(polNo, submitType,null,"",reservePolicy.getAppId(),APIFunction.EAPP_RESERVE_POL));
    	LocalDateTime end =LocalDateTime.now() ;
    	Duration duration = Duration.between( start,end );
		logService.logEndWorkingSuccessIntegration(APIPath.EAPP_P_RESERVE, duration.toMillis());

        return payload;

    }

    @ApiOperation("To enquiry and get policy details based on given information.")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Return policy number verification status."),
            @ApiResponse(code = 400, message = "Bad Request", response = GatewayError400.class),
            @ApiResponse(code = 401, message = "Unauthorized", response = GatewayError401.class),
            @ApiResponse(code = 404, message = "Invalid request.", response = Response.class),
            @ApiResponse(code = 500, message = "Internal Server Error", response = InternalError500.class)
    })
    @PostMapping(value = "/enquire", produces = MediaType.APPLICATION_JSON_VALUE)
    public Response<PolicyCheckResults> enquire(
            @ApiParam(value = "Local business unit.    | Valid Values |   | ----------   |   | HK, TH, SG   | ", required = true)
            @RequestHeader(value = Constants.RequestHeader.AIA_LBU, required = true) String xAiaLbu,
            @ApiParam(value = "Unique id for the request for tracking purposes.        ", required = true)
            @RequestHeader(value = Constants.RequestHeader.REQUEST_ID, required = true) String xAiaRequestId,
            @ApiParam(value = "Target environment of the request. Note that this header is required only when accessing non-production environments.    | Valid Values       |   | ------------------ |   | qa1, qa2, qa3, qa4 |        ")
            @RequestHeader(value = Constants.RequestHeader.AIA_ENV, required = false) String xAiaEnv,
            @ApiParam(value = "JWT Token for the request to verify Agent Authorization")
            @RequestHeader(value = Constants.RequestHeader.TOKEN_AGENT, required = false) String xAiaTokenAgent,
            @ApiParam(value = "Trace Id for EFK Logging")
            @RequestHeader(value = Constants.RequestHeader.TRACE_ID, required = false) String xAiaHkTraceId,
            @ApiParam(value = "Context Id for EFK Logging")
            @RequestHeader(value = Constants.RequestHeader.CONTEXT_ID) String xAiaHkContextId,
            @ApiParam(value = "Policy details", required = true)
            @Valid @RequestBody Request<CheckPolicy> checkPolicy) {

        final PolicyCheckResults policyCheckResultObj = new PolicyCheckResults();

        final List<PolicyCheckResult> policyCheckResultList
                = eappPolicyService.getPolicyCheck(checkPolicy.getData(), checkPolicy.getAppId());

        policyCheckResultObj.setPolicyCheckResult(policyCheckResultList);

        final Response<PolicyCheckResults> payload = new Response<>();

        payload.setTransId(checkPolicy.getTransId());
        payload.setStatus(CustomResponseStatus.SUCCESS.getDescription());
        payload.setData(policyCheckResultObj);

        return payload;
    }

    @ApiOperation("To submit certificate of insurance(COI) policy.")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Coi policy successfully submitted."),
            @ApiResponse(code = 400, message = "Bad Request", response = GatewayError400.class),
            @ApiResponse(code = 401, message = "Unauthorized", response = GatewayError401.class),
            @ApiResponse(code = 404, message = "Invalid request.", response = Response.class),
            @ApiResponse(code = 500, message = "Internal Server Error", response = InternalError500.class)
    })
    @PostMapping(value = "/submit-coi", produces = MediaType.APPLICATION_JSON_VALUE)
    public Response<ReturnPolicy> submitCoi(
            @ApiParam(value = "Local business unit.    | Valid Values |   | ----------   |   | HK, TH, SG   | ", required = true)
            @RequestHeader(value = Constants.RequestHeader.AIA_LBU, required = true) String xAiaLbu,
            @ApiParam(value = "Unique id for the request for tracking purposes.        ", required = true)
            @RequestHeader(value = Constants.RequestHeader.REQUEST_ID, required = true) String xAiaRequestId,
            @ApiParam(value = "Target environment of the request. Note that this header is required only when accessing non-production environments.    | Valid Values       |   | ------------------ |   | qa1, qa2, qa3, qa4 |        ")
            @RequestHeader(value = Constants.RequestHeader.AIA_ENV, required = false) String xAiaEnv,
            @ApiParam(value = "JWT Token for the request to verify Agent Authorization")
            @RequestHeader(value = Constants.RequestHeader.TOKEN_AGENT, required = false) String xAiaTokenAgent,
            @ApiParam(value = "Trace Id for EFK Logging")
            @RequestHeader(value = Constants.RequestHeader.TRACE_ID, required = false) String xAiaHkTraceId,
            @ApiParam(value = "Context Id for EFK Logging")
            @RequestHeader(value = Constants.RequestHeader.CONTEXT_ID) String xAiaHkContextId,
            @ApiParam(value = "Coi object", required = true)
            @Valid @RequestBody Request<Coi> request) {

        final Coi data = request.getData();
        ReturnPolicy returnPolicy = new ReturnPolicy();

        
    	String polNo = data.getSubmissionDetail().getPolicyNo();
		String submitType = data.getSubmissionDetail().getCsSubmission().getSubmitChannel();
		String refNo = data.getSubmissionDetail().getRefNo();
		logService.logTranKey(new TranKeys(polNo, submitType, refNo,"",request.getAppId(),APIFunction.EAPP_SUBMIT_POL_COI));
		
    	logService.logStartWorkingIntegration( APIPath.EAPP_P_SUBMIT_COI );
    	LocalDateTime start = LocalDateTime.now();
        
        final PolCloud polCloud = polCloudService.savePolicyNoIntoCloudFlow(request.getAppId(), data.getSubmissionDetail().getPolicyNo(), MDC.get(TRACE_ID), MDC.get(CALLER_CONTEXT_ID), MDC.get(APP_CONTEXT_ID), MDC.get(Constants.EFKLogging.SOURCE_USER_ID), MDC.get(Constants.EFKLogging.SOURCE_USER_IP));

        if (polCloud.getId() == null) {
            throw new ErrorResultException("-99", String.format(CLOUD_POLICY_ERROR, data.getSubmissionDetail().getPolicyNo()));
        }

        final ResultDto<ReturnPolicyDto> result = submitMsService.submitMiniSubmissionWithCoi(data, WS_ACTION_ESUB);

        Response<ReturnPolicy> payload = constructPayload(request.getTransId(),
                result.getReturnCode(), result.getReturnMessage());

        if (Objects.nonNull(result.getData())) {
            returnPolicy.setPolicyNo(result.getData().getPolicyNo());
            returnPolicy.setType(result.getData().getType());
        }
        payload.setData(returnPolicy);
        try {
            submitMsService.prepareToSaveCoi(request.getData().getSubmissionDetail().getPolicyNo(), request);
        } catch (Exception e) {
            log.error("Error code {}", e.getMessage());
        }
        

    	LocalDateTime end =LocalDateTime.now() ;
    	Duration duration = Duration.between( start,end );
    	logService.logEndWorkingSuccessIntegration( APIPath.EAPP_P_SUBMIT_COI,  duration.toMillis());
        
        
        return payload;
    }

    @ApiOperation("To submit policy proposal.")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Policy/Proposal successfully submitted."),
            @ApiResponse(code = 400, message = "Bad Request", response = GatewayError400.class),
            @ApiResponse(code = 401, message = "Unauthorized", response = GatewayError401.class),
            @ApiResponse(code = 404, message = "Invalid request.", response = Response.class),
            @ApiResponse(code = 500, message = "Internal Server Error", response = InternalError500.class)
    })
    @PostMapping(value = "/submit", produces = MediaType.APPLICATION_JSON_VALUE)
    public Response<ReturnPolicy> submit(
            @ApiParam(value = "Local business unit.    | Valid Values |   | ----------   |   | HK, TH, SG   | ", required = true)
            @RequestHeader(value = Constants.RequestHeader.AIA_LBU, required = true) String xAiaLbu,
            @ApiParam(value = "Unique id for the request for tracking purposes.        ", required = true)
            @RequestHeader(value = Constants.RequestHeader.REQUEST_ID, required = true) String xAiaRequestId,
            @ApiParam(value = "Target environment of the request. Note that this header is required only when accessing non-production environments.    | Valid Values       |   | ------------------ |   | qa1, qa2, qa3, qa4 |        ")
            @RequestHeader(value = Constants.RequestHeader.AIA_ENV, required = false) String xAiaEnv,
            @ApiParam(value = "JWT Token for the request to verify Agent Authorization")
            @RequestHeader(value = Constants.RequestHeader.TOKEN_AGENT, required = false) String xAiaTokenAgent,
            @ApiParam(value = "Trace Id for EFK Logging")
            @RequestHeader(value = Constants.RequestHeader.TRACE_ID, required = false) String xAiaHkTraceId,
            @ApiParam(value = "Context Id for EFK Logging")
            @RequestHeader(value = Constants.RequestHeader.CONTEXT_ID, required = true) String xAiaHkContextId,
            @ApiParam(value = "submission details", required = true)
            @Valid @RequestBody Request<SubmissionDetail> request) {

    	
    	String polNo = request.getData().getPolicyNo();
		String submitType = request.getData().getCsSubmission().getSubmitChannel();
		String refNo = request.getData().getRefNo();
		logService.logTranKey(new TranKeys(polNo, submitType, refNo,"",request.getAppId(),APIFunction.EAPP_SUBMIT_POL_MINI));
		
    	logService.logStartWorkingIntegration( APIPath.EAPP_P_SUBMIT );
    	LocalDateTime start = LocalDateTime.now();
    	
    	 
		Request<SubmissionDetail> reqWithDoc = copyAndRemoveDoc(request);
		payloadRequestService.saveRequestJson(polNo, "MINI-C", reqWithDoc); 
    	
    	
        final SubmissionDetail data = request.getData();
        ReturnPolicy returnPolicy = new ReturnPolicy();

        final PolCloud polCloud = polCloudService.savePolicyNoIntoCloudFlow(request.getAppId(), data.getPolicyNo(), MDC.get(TRACE_ID), MDC.get(CALLER_CONTEXT_ID), MDC.get(APP_CONTEXT_ID), MDC.get(Constants.EFKLogging.SOURCE_USER_ID), MDC.get(Constants.EFKLogging.SOURCE_USER_IP));

        if (polCloud.getId() == null) {
            throw new ErrorResultException("-99", String.format(CLOUD_POLICY_ERROR, data.getPolicyNo()));
        }

        final ResultDto<ReturnPolicyDto> result = submitMsService.submitMiniSubmission(data, WS_ACTION_ESUB);

        
        Response<ReturnPolicy> payload = constructPayload(request.getTransId(),
                result.getReturnCode(), result.getReturnMessage());

        if (Objects.nonNull(result.getData())) {
            returnPolicy.setPolicyNo(result.getData().getPolicyNo());
            returnPolicy.setType(result.getData().getType());
        }

        payload.setData(returnPolicy);
        
		payloadRequestService.saveRequestJson(polNo, "MINI-R", payload); 
    	
		

    	LocalDateTime end =LocalDateTime.now() ;
    	Duration duration = Duration.between( start,end );
    	logService.logEndWorkingSuccessIntegration( APIPath.EAPP_P_SUBMIT,  duration.toMillis());
        
        
        return payload;
    }

	private Request<SubmissionDetail> copyAndRemoveDoc(Request<SubmissionDetail> request) {
		
		ObjectMapper objectMapper = new ObjectMapper();
		SubmissionDetail sd2;
		try {
			String csString = objectMapper.writeValueAsString(request.getData());

			sd2 = objectMapper.readValue(csString, SubmissionDetail.class);
		} catch (JsonMappingException e) {
			return null;
		} catch (JsonProcessingException e) {
			return null;
		}

		nullifyDocFile(sd2);
		
		Request<SubmissionDetail> req2 = new Request<SubmissionDetail>();
		req2.setAppId(request.getAppId());
		req2.setData(sd2);
		req2.setTransId(request.getTransId());
		return req2;
	}

	private void nullifyDocFile(SubmissionDetail submissionDetail) {
		EappDocument[] documentArr = submissionDetail.getCsSubmission().getDocuments();
		for (EappDocument eappDocument : documentArr) {
			eappDocument.setDocFile("Document Removed by code");
		}

	}
    
    
    private Response<ReturnPolicy> constructPayload(String transactionId, String returnCode, String returnMessage) {

        Response<ReturnPolicy> payload = new Response<>();
        payload.setTransId(transactionId);
        if (RETURN_CODE_1.equals(returnCode)) {
            payload.setStatus(CustomResponseStatus.SUCCESS.getDescription());
        } else {
            payload.setStatus(CustomResponseStatus.ERROR.getDescription());
        }
        
        if (RETURN_CODE_99.equals(returnCode)) {
        	returnMessage="Application Error";
            
        } 
        payload.getResultMessages().add(new ResultMessage(returnCode, returnMessage));

        return payload;
    }

    @ApiOperation("To get proposal status by policy number.")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Return policy submission status."),
            @ApiResponse(code = 400, message = "Bad Request", response = GatewayError400.class),
            @ApiResponse(code = 401, message = "Unauthorized", response = GatewayError401.class),
            @ApiResponse(code = 404, message = "Invalid request.", response = Response.class),
            @ApiResponse(code = 500, message = "Internal Server Error", response = InternalError500.class)
    })
    @PostMapping(value = "/enquire-status", produces = MediaType.APPLICATION_JSON_VALUE)
    public Response<SubmitMsStatusResponse> enquireStatus(
            @ApiParam(value = "Local business unit.    | Valid Values |   | ----------   |   | HK, TH, SG   | ", required = true)
            @RequestHeader(value = Constants.RequestHeader.AIA_LBU, required = true) String xAiaLbu,
            @ApiParam(value = "Unique id for the request for tracking purposes.        ", required = true)
            @RequestHeader(value = Constants.RequestHeader.REQUEST_ID, required = true) String xAiaRequestId,
            @ApiParam(value = "Target environment of the request. Note that this header is required only when accessing non-production environments.    | Valid Values       |   | ------------------ |   | qa1, qa2, qa3, qa4 |        ")
            @RequestHeader(value = Constants.RequestHeader.AIA_ENV, required = false) String xAiaEnv,
            @ApiParam(value = "JWT Token for the request to verify Agent Authorization")
            @RequestHeader(value = Constants.RequestHeader.TOKEN_AGENT, required = false) String xAiaTokenAgent,
            @ApiParam(value = "Trace Id for EFK Logging")
            @RequestHeader(value = Constants.RequestHeader.TRACE_ID, required = false) String xAiaHkTraceId,
            @ApiParam(value = "Context Id for EFK Logging")
            @RequestHeader(value = Constants.RequestHeader.CONTEXT_ID, required = true) String xAiaHkContextId,
            @ApiParam(value = "submission status", required = true)
            @Valid @RequestBody Request<SubmitMsStatus> submitMsStatus) {
        Response<SubmitMsStatusResponse> payload = new Response<>();
        payload.setTransId(submitMsStatus.getTransId());
        payload.setData(submitMsService.getSubmitMsStatus(submitMsStatus.getData(), WS_ACTION_GET_SUBMIT_MS_STATUS));
        payload.setStatus(SUCCESS);
        return payload;
    }

    @ApiOperation("To check if policy flow is to cloud.")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Return cloud indicator."),
            @ApiResponse(code = 400, message = "Bad Request", response = GatewayError400.class),
            @ApiResponse(code = 401, message = "Unauthorized", response = GatewayError401.class),
            @ApiResponse(code = 404, message = "Invalid request.", response = Response.class),
            @ApiResponse(code = 500, message = "Internal Server Error", response = InternalError500.class)
    })
    @PostMapping(value = "/flow", produces = MediaType.APPLICATION_JSON_VALUE)
    public Response<FlowResult> flow(
            @ApiParam(value = "Local business unit.    | Valid Values |   | ----------   |   | HK, TH, SG   | ", required = true)
            @RequestHeader(value = Constants.RequestHeader.AIA_LBU, required = true) String xAiaLbu,
            @ApiParam(value = "Unique id for the request for tracking purposes.        ", required = true)
            @RequestHeader(value = Constants.RequestHeader.REQUEST_ID, required = true) String xAiaRequestId,
            @ApiParam(value = "Target environment of the request. Note that this header is required only when accessing non-production environments.    | Valid Values       |   | ------------------ |   | qa1, qa2, qa3, qa4 |        ")
            @RequestHeader(value = Constants.RequestHeader.AIA_ENV, required = false) String xAiaEnv,
            @ApiParam(value = "JWT Token for the request to verify Agent Authorization")
            @RequestHeader(value = Constants.RequestHeader.TOKEN_AGENT, required = false) String xAiaTokenAgent,
            @ApiParam(value = "Trace Id for EFK Logging")
            @RequestHeader(value = Constants.RequestHeader.TRACE_ID, required = false) String xAiaHkTraceId,
            @ApiParam(value = "Context Id for EFK Logging")
            @RequestHeader(value = Constants.RequestHeader.CONTEXT_ID, required = true) String xAiaHkContextId,
            @ApiParam(value = "flow object", required = true)
            @Valid @RequestBody Request<Flow> flowRequest) {


    	
        return new Response<FlowResult> ();
    }

}

