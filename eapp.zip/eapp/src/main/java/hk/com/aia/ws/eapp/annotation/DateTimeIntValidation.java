package hk.com.aia.ws.eapp.annotation;

import hk.com.aia.ws.eapp.validation.DateTimeIntValidator;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.*;

@Documented
@Target({ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = DateTimeIntValidator.class)
public @interface DateTimeIntValidation {

    String message() default "Invalid Date";

    String format() default "yyyy-MM-dd HH:mm:ss";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

}
