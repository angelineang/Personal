package hk.com.aia.ws.eapp.model.db.magnum;

import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Data
@Entity
@Table(name = "tbl_payload_request")
@EntityListeners(AuditingEntityListener.class)
public class PayloadRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "payload")
    private String payload;

    @Column(name = "trace_id")
    private String traceId;

    @Column(name = "request_type")
    private String requestType;

    @Column(name = "policy_no")
    private String policyNo;

    @Column(name = "submission_date")
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date submissionDate;

    @Column(name = "field2")
    private String field2;

    @Column(name = "field3")
    private String field3;

    @Column(name = "context_id")
    private String context_id;
    
    @Column(name = "batch_id")
    private String batchId;

    @Column(name = "field1")
    private String field1;

    @Column(name = "caller_context_id")
    private String callerContextId;
    
    @Column(name = "create_date")
    private Date createDate;
        
}



