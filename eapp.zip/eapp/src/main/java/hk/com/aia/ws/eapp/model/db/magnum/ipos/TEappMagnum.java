package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import lombok.Data;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "T_EAPPMAGNUM")
public class TEappMagnum {

    @Column(name = "EAPPMAGNUMID", length = 60)
    @Id
    private String eappMagnumId;

    @Column(name = "EAPPID", length = 60)
    private String eappId;

    @Column(name = "CONTACTID", length = 60)
    private String contactId;

    @Column(name = "M_BLOCKA")
    private String mBlockA;

    @Column(name = "M_BLOCKB")
    private String mBlockB;

    @Column(name = "M_BLOCKD")
    private String mBlockD;

    @Column(name = "CREATEDBY", length = 10, updatable = false)
    @CreatedBy
    private String createdBy;

    @Column(name = "UPDATEDBY", length = 10)
    @LastModifiedBy
    private String updatedBy;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "LASTUPDATEDATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    @LastModifiedDate
    private Date lastUpdateDateTime;

    @Column(name = "RULEBASEVERSION", length = 20)
    private String ruleBaseVersion;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TEappMagnum{");
        sb.append("eappMagnumId='").append(eappMagnumId).append('\'');
        sb.append(", eappId='").append(eappId).append('\'');
        sb.append(", contactId='").append(contactId).append('\'');
        sb.append(", mBlockA='").append(mBlockA).append('\'');
        sb.append(", mBlockB='").append(mBlockB).append('\'');
        sb.append(", mBlockD='").append(mBlockD).append('\'');
        sb.append(", createdBy='").append(createdBy).append('\'');
        sb.append(", updatedBy='").append(updatedBy).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", lastUpdateDateTime=").append(lastUpdateDateTime);
        sb.append(", ruleBaseVersion='").append(ruleBaseVersion).append('\'');
        sb.append('}');
        return sb.toString();
    }
}