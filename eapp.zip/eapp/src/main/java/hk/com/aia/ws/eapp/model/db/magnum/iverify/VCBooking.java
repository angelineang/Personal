package hk.com.aia.ws.eapp.model.db.magnum.iverify;

import hk.com.aia.ws.eapp.util.ConversionHandler;
import lombok.Data;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.util.Date;

@Entity
@Data
@Table(name = "VCBOOKING")
public class VCBooking {

    @Column(name = "IVERIFYIND", length = 150)
    private String iverifyInd;

    @Column(name = "BookingID", length = 60)
    @Id
    private String bookingID;

    @Column(name ="centerId", length = 60)
    private String centerID;

    @Column(name = "roomID", length = 60)
    private String roomID;

    @Column(name = "statusPreset", length = 1)
    private String statusPreset;

    @Column(name = "agentNo", length = 40)
    private String agentNo;

    @Column (name = "startDateTime")
    @Temporal(TemporalType.TIMESTAMP)
    private Date startDateTime;

    @Column (name = "endDateTime")
    @Temporal(TemporalType.TIMESTAMP)
    private Date endDateTime;

    @Column(name = "CHINESENAME")
    private String chineseName;

    @Column(name = "LASTNAME", length = 100)
    private String lastName;

    @Column(name = "FIRSTNAME", length = 45)
    private String firstName;

    @Column(name = "currentStatusCode", length = 1)
    private String currentStatusCode;

    @Column(name = "docSubmitStatus", length = 1)
    private String docSubmitStatus;

    @Column(name = "pickedBy", length = 60)
    private String pickedBy;

    @Column(name = "docCheckStatus", length = 1)
    private String docCheckStatus;

    @Column(name = "VCCompleteStatus", length = 1)
    private String vcCompleteStatus;

    @Column(name = "agentNoSec", length = 40)
    private String agentNoSec;

    @Column(name = "LASTNAMESEC", length = 100)
    private String lastNameSec;

    @Column(name = "FIRSTNAMESEC", length = 100)
    private String firstNameSec;

    @Column(name = "agent_submission_success", length = 2)
    private String agentSubmissionSuccess;

    @Column(name = "FIRSTCLIENT", length = 150)
    private String firstClient;

    @Column(name = "CLIENTDOB", length = 50)
    private String clientDob;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("VCBooking{");
        sb.append("iverifyInd='").append(iverifyInd).append('\'');
        sb.append(", bookingID='").append(bookingID).append('\'');
        sb.append(", centerID='").append(centerID).append('\'');
        sb.append(", roomID='").append(roomID).append('\'');
        sb.append(", statusPreset='").append(statusPreset).append('\'');
        sb.append(", agentNo='").append(agentNo).append('\'');
        sb.append(", startDateTime=").append(startDateTime);
        sb.append(", endDateTime=").append(endDateTime);
        sb.append(", chineseName='").append(ConversionHandler.mask(chineseName)).append('\'');
        sb.append(", lastName='").append(ConversionHandler.mask(lastName)).append('\'');
        sb.append(", firstName='").append(ConversionHandler.mask(firstName)).append('\'');
        sb.append(", currentStatusCode='").append(currentStatusCode).append('\'');
        sb.append(", docSubmitStatus='").append(docSubmitStatus).append('\'');
        sb.append(", pickedBy='").append(pickedBy).append('\'');
        sb.append(", docCheckStatus='").append(docCheckStatus).append('\'');
        sb.append(", vcCompleteStatus='").append(vcCompleteStatus).append('\'');
        sb.append(", agentNoSec='").append(agentNoSec).append('\'');
        sb.append(", lastNameSec='").append(ConversionHandler.mask(lastNameSec)).append('\'');
        sb.append(", firstNameSec='").append(ConversionHandler.mask(firstNameSec)).append('\'');
        sb.append(", agentSubmissionSuccess='").append(agentSubmissionSuccess).append('\'');
        sb.append(", firstClient='").append(firstClient).append('\'');
        sb.append(", clientDob='").append(ConversionHandler.mask(clientDob)).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
