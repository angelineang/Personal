package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@ApiModel(value = "GI Coverage Front Model")
@Data
public class GiCoverageFront {

    @ApiModelProperty(value = "Commission Amount")
    @JsonProperty("commission_amount")
    private Double commissionAmount;

    @ApiModelProperty(value = "Component Code")
    @JsonProperty("component_code")
    private String componentCode;

    @ApiModelProperty(value = "Coverage Number")
    @JsonProperty("covr_no")
    private String covrNo;

    @ApiModelProperty(value = "Coverage Plan")
    @JsonProperty("covr_plan")
    private String covrPlan;

    @ApiModelProperty(value = "Coverage Premium")
    @JsonProperty("covr_prem")
    private Double covrPrem;

    @ApiModelProperty(value = "Sum Assured")
    @JsonProperty("sum_assured")
    private Double sumAssured;

    @ApiModelProperty(value = "Plan Short Name")
    @JsonProperty("plan_short_name")
    private String planShortName;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("GiCoverageFront{");
        sb.append("commissionAmount=").append(commissionAmount);
        sb.append(", componentCode='").append(componentCode).append('\'');
        sb.append(", covrNo='").append(covrNo).append('\'');
        sb.append(", covrPlan='").append(covrPlan).append('\'');
        sb.append(", covrPrem=").append(covrPrem);
        sb.append(", sumAssured=").append(sumAssured);
        sb.append(", planShortName='").append(planShortName).append('\'');
        sb.append('}');
        return sb.toString();
    }
}


