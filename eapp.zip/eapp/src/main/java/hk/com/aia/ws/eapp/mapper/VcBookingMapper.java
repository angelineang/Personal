package hk.com.aia.ws.eapp.mapper;

import hk.com.aia.ws.eapp.model.db.magnum.iverify.VCBooking;
import hk.com.aia.ws.eapp.model.request.iverify.VcBookingDto;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface VcBookingMapper {
    VcBookingMapper MAPPER = Mappers.getMapper(VcBookingMapper.class);

    VCBooking mapToVcBooking(VcBookingDto vcBookingDto);

}
