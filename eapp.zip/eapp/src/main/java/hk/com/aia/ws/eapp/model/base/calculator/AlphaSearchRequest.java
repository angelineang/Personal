package hk.com.aia.ws.eapp.model.base.calculator;

import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.model.base.RestEntity;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class AlphaSearchRequest extends RestEntity {

    @JsonProperty("reqType")
    private String requestType;

    @JsonProperty("firstName")
    private String firstName;

    @JsonProperty("lastName")
    private String lastName;

    @JsonProperty("dob")
    private String dob;

    @JsonProperty("sex")
    private String sex;

    @JsonProperty("idnr")
    private String idnr;

    @JsonProperty("groupName")
    private String groupName;

    public String generateParameter() {
    	StringBuilder sb = new StringBuilder("?");
        sb.append("reqType=").append(requestType).append("&");
        sb.append("firstName=").append(firstName).append("&");
        sb.append("lastName=").append(lastName).append("&");
        sb.append("dob=").append(dob).append("&");
        sb.append("sex=").append(sex).append("&");
        sb.append("idnr=").append(idnr).append("&");
        sb.append("groupName=").append(groupName);
        return sb.toString();
    }

	 
    public String generateMaskedParameter() {
    	StringBuilder sb = new StringBuilder("?");
        sb.append("reqType=").append(requestType).append("&");
        sb.append("firstName=").append(ConversionHandler.mask( firstName)).append("&");
        sb.append("lastName=").append(lastName).append("&");
        sb.append("dob=").append(ConversionHandler.mask(dob)).append("&");
        sb.append("sex=").append(sex).append("&");
        sb.append("idnr=").append(ConversionHandler.mask(idnr)).append("&");
        sb.append("groupName=").append(groupName);
        return sb.toString();
    }

    
}
