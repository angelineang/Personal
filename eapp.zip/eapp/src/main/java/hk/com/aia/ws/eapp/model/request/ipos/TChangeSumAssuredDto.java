package hk.com.aia.ws.eapp.model.request.ipos;


import java.math.BigDecimal;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@ApiModel(value = "T_CHANGESUMASSURED Model")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TChangeSumAssuredDto {

    @ApiModelProperty(value = "change Sum Assured Id", required = true) 
    @JsonProperty("change_sum_assured_id")
	@Size(max = 60)
    @NotBlank
    private String changeSumAssuredId;

    @JsonProperty("agent_code")
	@Size(max = 10)
    private String agentCode;

    @JsonProperty("access_code")
	@Size(max = 30)
    private String accessCode;

    @ApiModelProperty(value = "sqs Quotation Id", required = true)
    @JsonProperty("sqs_quotation_id")
	@Size(max = 60)
    @NotBlank
    private String sqsQuotationId;

    @JsonProperty("policy_year")
    private Integer policyYear;

    @JsonProperty("amount")
    private BigDecimal amount;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TChangeSumAssuredDto{");
        sb.append("changeSumAssuredId='").append(changeSumAssuredId).append('\'');
        sb.append(", agentCode='").append(agentCode).append('\'');
        sb.append(", accessCode='").append(accessCode).append('\'');
        sb.append(", sqsQuotationId='").append(sqsQuotationId).append('\'');
        sb.append(", policyYear=").append(policyYear);
        sb.append(", amount=").append(amount);
        sb.append('}');
        return sb.toString();
    }
}
