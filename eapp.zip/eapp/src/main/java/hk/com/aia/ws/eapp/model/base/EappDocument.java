package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.annotation.AllowedValuesValidation;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.ToString;
import org.apache.commons.lang3.StringUtils;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@ApiModel(value = "Supporting Document Model")
@Data
public class EappDocument {

    @ApiModelProperty(value = "Document Sequence number - 01,02,and so on (tbl_ms_pol_doc.doc_seq_no)", example = "01", required = true)
    @JsonProperty("doc_seq_no")
    @Size(max = 2)
    @NotBlank
    private String docSeqNo;

    @ApiModelProperty(value = "Client Type - I = Insured, O = Owner, IO = Insured / Owner  (tbl_ms_pol_doc.client_type)", example = "O", allowableValues = "I,O,IO", required = true)
    @JsonProperty("client_type")
    @Size(max = 2)
    @NotBlank
    private String clientType;

    @ApiModelProperty(value = "Based on pre-defined document ID (tbl_ms_pol_doc.doc_id)", example = "O9960138")
    @JsonProperty("doc_id")
    @Size(max = 10)
    private String docId;

    @ApiModelProperty(value = "Document Type - PDF = PDF format, IMAGE = Jpeg image (tbl_ms_pol_doc.doc_type)", example = "PDF", allowableValues = "PDF,IMAGE")
    @JsonProperty("doc_type")
    @Size(max = 10)
    @AllowedValuesValidation(values = {"PDF", "IMAGE"})
    private String docType;

    @ApiModelProperty(value = "Document File - File (Binary) (store to MSSQL db_mag..tbl_ms_pol_doc.doc_file )")
    @JsonProperty("doc_file")
    @ToString.Exclude
    private String docFile;

    @ApiModelProperty(value = "Document Name  (tbl_ms_pol_doc.doc_name)", example = "Application Summary")
    @JsonProperty("doc_name")
    @Size(max = 255)
    private String docName;

    //Import from old code, the custom getters

    public String getClientType() {
        return  StringUtils.isBlank(clientType) ? "O" : clientType;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("EappDocument{");
        sb.append("docSeqNo='").append(docSeqNo).append('\'');
        sb.append(", clientType='").append(clientType).append('\'');
        sb.append(", docId='").append(docId).append('\'');
        sb.append(", docType='").append(docType).append('\'');
        sb.append(", docFile='").append(docFile).append('\'');
        sb.append(", docName='").append(docName).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
