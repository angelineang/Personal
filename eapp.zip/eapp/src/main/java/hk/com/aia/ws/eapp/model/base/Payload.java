package hk.com.aia.ws.eapp.model.base;


public class Payload {

}
