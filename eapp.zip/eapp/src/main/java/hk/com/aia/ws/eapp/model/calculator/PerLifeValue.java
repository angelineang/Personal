package hk.com.aia.ws.eapp.model.calculator;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
public class PerLifeValue {

    private Double anp=0d;
    private Double totalAnp=0d;
    
	public Double getAnp() {
		return anp;
	}
	public void setAnp(Double anp) {
		this.anp = anp;
	}
	public Double getTotalAnp() {
		return totalAnp;
	}
	public void setTotalAnp(Double totalAnp) {
		this.totalAnp = totalAnp;
	}
 
}
