package hk.com.aia.ws.eapp.annotation;

import hk.com.aia.ws.eapp.validation.AllowedValuesIntValidator;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.*;

@Documented
@Target({ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = AllowedValuesIntValidator.class)
public @interface AllowedValuesIntValidation {

    String message() default "Value not allowed";

    /**
     * Match the values given
     */
    int[] values() default {};

    /**
     * use the values from property file using the specified property key
     * multiple values is separated by comma ( , )
     * Takes precedence over values (above)
     */
    String propertyKey() default "";

    boolean caseSensitive() default false;

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

}