package hk.com.aia.ws.eapp.model.request.ipos;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@ApiModel(value = "T_EAPPINSURANCEPURPOSE Model")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TEappInsurancePurposeDto {

	@ApiModelProperty(value = "eapp Insurance Purpose Id", required = true)
    @JsonProperty("eapp_insurance_purpose_id")
	@Size(max = 60)
	@NotBlank
    private String eappInsurancePurposeId;

    @JsonProperty("eapp_id")
	@Size(max = 60)
    private String eappId;

    @JsonProperty("purpose_code")
	@Size(max = 50)
    private String purposeCode;

    @JsonProperty("purpose_name")
	@Size(max = 50)
    private String purposeName;

    @JsonProperty("others")
	@Size(max = 100)
    private String others;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TEappInsurancePurposeDto{");
        sb.append("eappInsurancePurposeId='").append(eappInsurancePurposeId).append('\'');
        sb.append(", eappId='").append(eappId).append('\'');
        sb.append(", purposeCode='").append(purposeCode).append('\'');
        sb.append(", purposeName='").append(purposeName).append('\'');
        sb.append(", others='").append(others).append('\'');
        sb.append('}');
        return sb.toString();
    }
}


