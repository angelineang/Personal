package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import hk.com.aia.ws.eapp.annotation.DataTruncation;
import lombok.Data;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "T_DOC")
public class TDoc {

    @Column(name = "DOCUMENTSID", length = 60)
    @Id
    private String documentsId;

    @Column(name = "CONTACTID", length = 60)
    private String contactId;

    @Column(name = "DOCTYPE", length = 10)
    private String docType;

    @Column(name = "FILENAME")
    @DataTruncation(max = 200, validateByte = true, log = true)
    private String fileName;

    @Column(name = "MODULE", length = 10)
    private String module;

    @Column(name = "MODULEID", length = 60)
    private String moduleId;

    @Column(name = "SUBMITTEDSTATUS")
    private Integer submittedStatus;

    @Column(name = "SIGNSTATUS")
    private Integer signStatus;

    @Column(name = "PAGENO")
    private Integer pageNo;

    @Column(name = "EREFERENCENO", length = 60)
    private String eReferenceNo;

    @Column(name = "SIGNAT", length = 20)
    private String signAt;

    @Column(name = "SIGNDATE")
    @Temporal(TemporalType.DATE)
    private Date signDate;

    @Column(name = "AGENTCODE", length = 10)
    private String agentCode;

    @Column(name = "ACCESSCODE", length = 30)
    private String accessCode;

    @Column(name = "CREATEDBY", length = 10, updatable = false)
    @CreatedBy
    private String createdBy;

    @Column(name = "UPDATEDBY", length = 10)
    @LastModifiedBy
    private String updatedBy;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "LASTUPDATEDATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    @LastModifiedDate
    private Date lastUpdateDateTime;

    @Column(name = "isOcrPassToIverify", length = 10)
    private String isOcrPassToIverify;

    @Column(name = "SEQUENCE")
    private Integer sequence;

    @Column(name = "SIGNNO")
    private Integer signNo;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TDoc{");
        sb.append("documentsId='").append(documentsId).append('\'');
        sb.append(", contactId='").append(contactId).append('\'');
        sb.append(", docType='").append(docType).append('\'');
        sb.append(", fileName='").append(fileName).append('\'');
        sb.append(", module='").append(module).append('\'');
        sb.append(", moduleId='").append(moduleId).append('\'');
        sb.append(", submittedStatus=").append(submittedStatus);
        sb.append(", signStatus=").append(signStatus);
        sb.append(", pageNo=").append(pageNo);
        sb.append(", eReferenceNo='").append(eReferenceNo).append('\'');
        sb.append(", signAt='").append(signAt).append('\'');
        sb.append(", signDate=").append(signDate);
        sb.append(", agentCode='").append(agentCode).append('\'');
        sb.append(", accessCode='").append(accessCode).append('\'');
        sb.append(", createdBy='").append(createdBy).append('\'');
        sb.append(", updatedBy='").append(updatedBy).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", lastUpdateDateTime=").append(lastUpdateDateTime);
        sb.append(", isOcrPassToIverify='").append(isOcrPassToIverify).append('\'');
        sb.append(", sequence=").append(sequence);
        sb.append(", signNo=").append(signNo);
        sb.append('}');
        return sb.toString();
    }
}
