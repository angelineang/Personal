package hk.com.aia.ws.eapp.controller.advice;

import com.fasterxml.jackson.databind.ObjectMapper;
import hk.com.aia.ws.eapp.exception.*;
import hk.com.aia.ws.eapp.model.base.CustomResponseStatus;
import hk.com.aia.ws.eapp.model.base.Payload;
import hk.com.aia.ws.eapp.model.base.PolicyProcessUpdateResult;
import hk.com.aia.ws.eapp.model.base.ResultMessage;
import hk.com.aia.ws.eapp.model.response.Response;
import hk.com.aia.ws.eapp.service.NotificationService;
import hk.com.aia.ws.eapp.service.jwt.JwtVerificationException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.jboss.jandex.TypeTarget;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.transaction.HeuristicCompletionException;
import org.springframework.validation.FieldError;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.util.ContentCachingRequestWrapper;

import javax.persistence.NoResultException;
import javax.persistence.PersistenceException;
import javax.servlet.http.HttpServletRequest;
import javax.validation.ConstraintViolationException;
import java.nio.charset.Charset;
import java.util.*;

import static hk.com.aia.ws.eapp.constant.Constants.RETURN_CODE_0;
import static hk.com.aia.ws.eapp.constant.Constants.RETURN_FAIL_CODE_2;

@Slf4j
@RestControllerAdvice
public class ExceptionControllerAdvice {

    private static final String TRANS_ID = "trans_id";

    @Autowired
    NotificationService notificationService;

    @ExceptionHandler({Exception.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    Response<Payload> handleAll(Exception ex, HttpServletRequest request) {
    	log.error("handleAll",ex);
        log.error(ExceptionUtils.getStackTrace(ex));
        Map<String, Object> r = processRequestContent(request);
        Response<Payload> errorsPayload = new Response<>();
        errorsPayload.setTransId((String) r.get(TRANS_ID));
        errorsPayload.setStatus(CustomResponseStatus.ERROR.getDescription());
        errorsPayload.getResultMessages().add(new ResultMessage("-99", "Application Error"));

        return errorsPayload;
    }

    @ExceptionHandler({HeuristicCompletionException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    Response<Payload> handleHeuristic(HeuristicCompletionException ex, HttpServletRequest request) {
    	log.error("handleHeuristic",ex);
        log.error(ExceptionUtils.getStackTrace(ex));
        Map<String, Object> r = processRequestContent(request);
        Response<Payload> errorsPayload = new Response<>();
        errorsPayload.setTransId((String) r.get(TRANS_ID));
        errorsPayload.setStatus(CustomResponseStatus.ERROR.getDescription());
        errorsPayload.getResultMessages().add(new ResultMessage("-99", "An error occurred while processing the request. Please try again."));

        return errorsPayload;
    }

    @ExceptionHandler({ErrorResultException.class})
    @ResponseStatus(HttpStatus.OK)
    Response<Payload> handleErrorResult(RuntimeException ex, HttpServletRequest request) {
    	log.error("handleErrorResult",ex);
        log.error(ExceptionUtils.getStackTrace(ex));
        Map<String, Object> r = processRequestContent(request);
        Response<Payload> errorsPayload = new Response<>();
        errorsPayload.setTransId((String) r.get(TRANS_ID));
        errorsPayload.setStatus(CustomResponseStatus.ERROR.getDescription());
        errorsPayload.getResultMessages().add(new ResultMessage("-99", ex.getMessage()));

        return errorsPayload;
    }

    @ExceptionHandler({NoResultException.class, PersistenceException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    Response<Payload> handlePersistenceException(RuntimeException ex, HttpServletRequest request) {
    	log.error("handlePersistenceException",ex);
        log.error(ExceptionUtils.getStackTrace(ex));
        Map<String, Object> r = processRequestContent(request);
        Response<Payload> errorsPayload = new Response<>();
        errorsPayload.setTransId((String) r.get(TRANS_ID));
        errorsPayload.setStatus(CustomResponseStatus.ERROR.getDescription());
        errorsPayload.getResultMessages().add(new ResultMessage("-99", ex.getMessage()));

        return errorsPayload;
    }

    @ExceptionHandler({HttpClientErrorException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    Response<Payload> handleClientError(Exception ex, HttpServletRequest request) {
    	log.error("handleClientError",ex);
        log.error(ExceptionUtils.getStackTrace(ex));
        Map<String, Object> r = processRequestContent(request);
        Response<Payload> errorsPayload = new Response<>();
        errorsPayload.setTransId((String) r.get(TRANS_ID));
        errorsPayload.setStatus(CustomResponseStatus.ERROR.getDescription());
        errorsPayload.getResultMessages().add(new ResultMessage("-99", ex.getMessage()));

        return errorsPayload;
    }

    @ExceptionHandler({ConstraintViolationException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    Response<Payload> handleConstraintViolation(
            MethodArgumentNotValidException ex, HttpServletRequest request) {
    	log.error("handleConstraintViolation",ex);
        log.error(ExceptionUtils.getStackTrace(ex));
        Map<String, Object> r = processRequestContent(request);
        Response<Payload> errorsPayload = new Response<>();
        errorsPayload.setTransId((String) r.get(TRANS_ID));
        errorsPayload.setStatus(CustomResponseStatus.ERROR.getDescription());

        final List<ResultMessage> errors = new ArrayList<>();
        ex.getBindingResult().getAllErrors().forEach((error) -> {
            String fieldName = ((FieldError) error).getField();
            String errorMessage = error.getDefaultMessage();
            ResultMessage resultMessage = new ResultMessage();
            resultMessage.setCode("-99");
            resultMessage.setMessage(fieldName + " : " + errorMessage);
            errors.add(resultMessage);
        });

        errorsPayload.setResultMessages(errors);

        return errorsPayload;
    }

    @ExceptionHandler({MethodArgumentNotValidException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    Response<Payload> handleMethodArgumentNotValidException(
            MethodArgumentNotValidException ex, HttpServletRequest request) {

        log.error(ExceptionUtils.getStackTrace(ex));
        log.error("handleMethodArgumentNotValidException ", ex);
        ContentCachingRequestWrapper wrapper = (ContentCachingRequestWrapper) request;
        Map<String, Object> r = processRequestContent(wrapper);
        Response<Payload> errorsPayload = new Response<>();
        errorsPayload.setTransId((String) r.get(TRANS_ID));
        errorsPayload.setStatus(CustomResponseStatus.ERROR.getDescription());

        final List<ResultMessage> errors = new ArrayList<>();
        ex.getBindingResult().getAllErrors().forEach((error) -> {
            String fieldName = ((FieldError) error).getField();
            String errorMessage = error.getDefaultMessage();
            ResultMessage resultMessage = new ResultMessage();
            resultMessage.setCode("-99");
            resultMessage.setMessage(fieldName + " : " + errorMessage);
            errors.add(resultMessage);
        });

        errorsPayload.setResultMessages(errors);

        return errorsPayload;
    }

    @ExceptionHandler({JwtVerificationException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    Response<Payload> handleJwtVerificationException(JwtVerificationException ex, HttpServletRequest request) {
    	log.error("handleJwtVerificationException",ex);
    	Response<Payload> errorsPayload = new Response<>();
        Map<String, Object> r = processRequestContent(request);
        errorsPayload.setTransId((String) r.get(TRANS_ID));
        errorsPayload.setStatus(CustomResponseStatus.ERROR.getDescription());
        errorsPayload.setResultMessages(ex.getExceptionMessages());

        return errorsPayload;
    }

    @ExceptionHandler({SubmissionErrorResultException.class})
    @ResponseStatus(HttpStatus.OK)
    Response<Payload> handleSubmissionException(SubmissionErrorResultException ex, HttpServletRequest request) {
    	log.error("handleSubmissionException",ex);
        log.error(ExceptionUtils.getStackTrace(ex));
        Map<String, Object> r = processRequestContent(request);
        Response<Payload> errorsPayload = new Response<>();
        errorsPayload.setTransId((String) r.get(TRANS_ID));
        errorsPayload.setStatus(CustomResponseStatus.ERROR.getDescription());
        final List<ResultMessage> errors = new ArrayList<>();
        errorsPayload.setResultMessages(errors);
        ResultMessage msg = new ResultMessage();
        msg.setMessage(ex.getMessage());
        msg.setCode(ex.getCode());
        errors.add(msg);
        return errorsPayload;
    }

    @ExceptionHandler({SubmitIposException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    Response<Payload> handleSubmitIposException(SubmitIposException ex, HttpServletRequest request) {
    	log.error("handleSubmitIposException",ex);
        log.error(ExceptionUtils.getStackTrace(ex));
        Map<String, Object> r = processRequestContent(request);
        Response<Payload> errorsPayload = new Response<>();
        errorsPayload.setTransId((String) r.get(TRANS_ID));
        errorsPayload.setStatus(CustomResponseStatus.ERROR.getDescription());
        errorsPayload.setResultMessages(ex.getExceptionMessages());

        return errorsPayload;
    }

    @ExceptionHandler({SubmitIVerifyException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    Response<Payload> handleSubmitIVerifyException(SubmitIVerifyException ex, HttpServletRequest request) {
    	log.error("handleSubmitIVerifyException",ex);
        log.error(ExceptionUtils.getStackTrace(ex));
        Map<String, Object> r = processRequestContent(request);
        Response<Payload> errorsPayload = new Response<>();
        errorsPayload.setTransId((String) r.get(TRANS_ID));
        errorsPayload.setStatus(CustomResponseStatus.ERROR.getDescription());
        errorsPayload.setResultMessages(ex.getExceptionMessages());

        return errorsPayload;
    }

    @ExceptionHandler({SubmitBatchException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    Response<Payload> handleSubmitBatchException(SubmitBatchException ex, HttpServletRequest request) {
    	log.error("handleSubmitBatchException",ex);
    	log.error(ExceptionUtils.getStackTrace(ex));
        Map<String, Object> r = processRequestContent(request);
        Response<Payload> errorsPayload = new Response<>();
        errorsPayload.setTransId((String) r.get(TRANS_ID));
        errorsPayload.setStatus(CustomResponseStatus.ERROR.getDescription());
        errorsPayload.setResultMessages(ex.getExceptionMessages());

        return errorsPayload;
    }

    @ExceptionHandler({HttpMessageNotReadableException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    Response<Payload> handleHttpMessageNotReadable(HttpMessageNotReadableException ex) {
    	log.error("handleHttpMessageNotReadable",ex);
        log.error(ExceptionUtils.getStackTrace(ex));
        Response<Payload> errorPayload = new Response<>();
        errorPayload.setStatus(CustomResponseStatus.ERROR.getDescription());

        ResultMessage message = new ResultMessage();
        message.setMessage("Invalid Request");
        errorPayload.setResultMessages(Arrays.asList(message));
        return errorPayload;
    }

    @ExceptionHandler({HttpRequestMethodNotSupportedException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    Response handleHttpRequestMethodNotSupportedException(HttpRequestMethodNotSupportedException ex) {
    	log.error("handleHttpRequestMethodNotSupportedException",ex);
        log.error(ExceptionUtils.getStackTrace(ex));
        Response<Payload> errorPayload = new Response<>();
        errorPayload.setStatus(CustomResponseStatus.ERROR.getDescription());

        ResultMessage message = new ResultMessage();
        message.setMessage("Http Method Not Supported");
        errorPayload.setResultMessages(Arrays.asList(message));
        return errorPayload;
    }

    private Map<String, Object> processRequestContent(
            HttpServletRequest request) {

        ContentCachingRequestWrapper wrapper = (ContentCachingRequestWrapper) request;
        Map<String, Object> result = new HashMap<>();
        final String content = StringUtils.toEncodedString(wrapper.getContentAsByteArray(),
                Charset.forName(wrapper.getCharacterEncoding()));
        try {
            ObjectMapper om = new ObjectMapper();
            result = om.readValue(content, Map.class);

        } catch (Exception e) {
            log.error("exception while parsing string to json", e);
        }
        return result;
    }

    @ExceptionHandler({PolicyProcessException.class})
    @ResponseStatus(HttpStatus.OK)
    Response<PolicyProcessUpdateResult> handlePolicyProcessError(PolicyProcessException ex, HttpServletRequest request) {
    	log.error("handlePolicyProcessError",ex);
    	log.error(ExceptionUtils.getStackTrace(ex));
        Map<String, Object> r = processRequestContent(request);
        Response<PolicyProcessUpdateResult> errorsPayload = new Response<>();
        PolicyProcessUpdateResult data = new PolicyProcessUpdateResult();
        data.getFailedCases().add(ex.getPolicyNo());
        errorsPayload.setData(data);
        errorsPayload.setTransId((String) r.get(TRANS_ID));
        errorsPayload.setStatus(CustomResponseStatus.ERROR.getDescription());
        errorsPayload.getResultMessages().add(new ResultMessage("-99", ex.getMessage()));
        return errorsPayload;
    }
    @ExceptionHandler({UsageLimitException.class})
    @ResponseStatus(HttpStatus.OK)
    Response<Payload> handleCalculatorUsageLimit(UsageLimitException ex, HttpServletRequest request) {
    	log.error("handleCalculatorUsageLimit",ex);
        log.error(ExceptionUtils.getStackTrace(ex));
        Map<String, Object> r = processRequestContent(request);
        Response<Payload> errorsPayload = new Response<>();
        errorsPayload.setTransId((String) r.get(TRANS_ID));
        errorsPayload.setStatus(CustomResponseStatus.ERROR.getDescription());
        errorsPayload.getResultMessages().add(new ResultMessage(RETURN_CODE_0, "Over the daily limit"));

        return errorsPayload;
    }

}
