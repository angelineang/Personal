package hk.com.aia.ws.eapp.model.request.ipos;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@ApiModel(value = "T_EAppCPD Model")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TEappCpdDto {

	@ApiModelProperty(value = "eapp CPD Id", required = true)
    @JsonProperty("eapp_cpd_id")
	@Size(max = 60)
	@NotBlank
    private String eappCPDId;

    @JsonProperty("eapp_id")
    @Size(max = 60)
    private String eappId;

    @JsonProperty("q2_a_loss")
    private BigDecimal q2aLoss;

    @JsonProperty("q2_a_reason")
    private String q2aReason;

    @JsonProperty("q2_b_option")
    @Size(max = 1)
    private String q2bOption;

    @JsonProperty("q2_b_reason")
    private String q2bReason;

    @JsonProperty("q2_c_year")
    @Size(max = 80)
    private String q2cYear;

    @JsonProperty("q2_c_exist_currency")
    @Size(max = 5)
    private String q2cExistCurrency;

    @JsonProperty("q2_c_new_currency")
    @Size(max = 5)
    private String q2cNewCurrency;

    @JsonProperty("q2_c_new_value")
    private BigDecimal q2cNewValue;

    @JsonProperty("q2_c_exist_value")
    private BigDecimal q2cExistValue;

	@JsonProperty("q3_a_option")
	@Size(max = 1)
    private String q3aOption;

    @JsonProperty("q3_b_option")
    @Size(max = 1)
    private String q3bOption;

    @JsonProperty("q3_c_option")
    @Size(max = 1)
    private String q3cOption;

    @JsonProperty("q3_d_option")
    @Size(max = 1)
    private String q3dOption;

    @JsonProperty("q5_a_reason")
    private String q5aReason;

    @JsonProperty("q5_b_reason")
    private String q5bReason;

    @JsonProperty("q5_c_option")
    private String q5cOption;

    @JsonProperty("macau_q2_reason")
    @Size(max = 800)
    private String macauq2Reason;

    @JsonProperty("macau_q3_reason")
    @Size(max = 800)
    private String macauq3Reason;

    @JsonProperty("macau_q4_reason")
    @Size(max = 800)
    private String macauq4Reason;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TEappCpdDto{");
        sb.append("eappCPDId='").append(eappCPDId).append('\'');
        sb.append(", eappId='").append(eappId).append('\'');
        sb.append(", q2aLoss=").append(q2aLoss);
        sb.append(", q2aReason='").append(q2aReason).append('\'');
        sb.append(", q2bOption='").append(q2bOption).append('\'');
        sb.append(", q2bReason='").append(q2bReason).append('\'');
        sb.append(", q2cYear='").append(q2cYear).append('\'');
        sb.append(", q2cExistCurrency='").append(q2cExistCurrency).append('\'');
        sb.append(", q2cNewCurrency='").append(q2cNewCurrency).append('\'');
        sb.append(", q2cNewValue=").append(q2cNewValue);
        sb.append(", q2cExistValue=").append(q2cExistValue);
        sb.append(", q3aOption='").append(q3aOption).append('\'');
        sb.append(", q3bOption='").append(q3bOption).append('\'');
        sb.append(", q3cOption='").append(q3cOption).append('\'');
        sb.append(", q3dOption='").append(q3dOption).append('\'');
        sb.append(", q5aReason='").append(q5aReason).append('\'');
        sb.append(", q5bReason='").append(q5bReason).append('\'');
        sb.append(", q5cOption='").append(q5cOption).append('\'');
        sb.append(", macauq2Reason='").append(macauq2Reason).append('\'');
        sb.append(", macauq3Reason='").append(macauq3Reason).append('\'');
        sb.append(", macauq4Reason='").append(macauq4Reason).append('\'');
        sb.append('}');
        return sb.toString();
    }
}


