package hk.com.aia.ws.eapp.controller;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import hk.com.aia.ws.eapp.constant.Constants;
import hk.com.aia.ws.eapp.constant.Constants.APIAction;
import hk.com.aia.ws.eapp.constant.Constants.APIPath;
import hk.com.aia.ws.eapp.exception.BlobFileException;
import hk.com.aia.ws.eapp.model.base.CustomResponseStatus;
import hk.com.aia.ws.eapp.model.base.ResultMessage;
import hk.com.aia.ws.eapp.model.request.Request;
import hk.com.aia.ws.eapp.model.request.batch.GenBatchRequest;
import hk.com.aia.ws.eapp.model.request.batch.SubmitBatch;
import hk.com.aia.ws.eapp.model.response.GenBatchResponse;
import hk.com.aia.ws.eapp.model.response.Response;
import hk.com.aia.ws.eapp.model.response.ipos.FilResult;
import hk.com.aia.ws.eapp.service.BatchSubmissionService;
import hk.com.aia.ws.eapp.service.LogService;
import hk.com.aia.ws.eapp.service.PayloadRequestService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/documents")
@Api(value = "Batch Submission", tags = {"API(s) related to batch submission ."})
@Validated
public class BatchSubmissionController {

    @Autowired
    private BatchSubmissionService batchSubmissionService;

    @Autowired
    PayloadRequestService payloadRequestService;
    
    @Autowired
    LogService logService;
    
    
    @ApiOperation("To generate batch ID")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Requested document sent successfully."),
            @ApiResponse(code = 400, message = "Bad request.", response = Response.class),
            @ApiResponse(code = 404, message = "Invalid request.", response = Response.class)
    })
    @PostMapping(value = "/gen-batch-id", produces = MediaType.APPLICATION_JSON_VALUE)
    public Response<GenBatchResponse> generateBatchId(
            @ApiParam(value = "Local business unit.    | Valid Values |   | ----------   |   | HK, TH, SG   | ", required = true)
            @RequestHeader(value = Constants.RequestHeader.AIA_LBU, required = true) String xAiaLbu,
            @ApiParam(value = "Unique id for the request for tracking purposes.        ", required = true)
            @RequestHeader(value = Constants.RequestHeader.REQUEST_ID, required = true) String xAiaRequestId,
            @ApiParam(value = "Target environment of the request. Note that this header is required only when accessing non-production environments.    | Valid Values       |   | ------------------ |   | qa1, qa2, qa3, qa4 |        ")
            @RequestHeader(value = Constants.RequestHeader.AIA_ENV, required = false) String xAiaEnv,
            @ApiParam(value = "JWT Token for the request to verify Agent Authorization")
            @RequestHeader(value = Constants.RequestHeader.TOKEN_AGENT, required = false) String xAiaTokenAgent,
            @ApiParam(value = "Trace Id for EFK Logging")
            @RequestHeader(value = Constants.RequestHeader.TRACE_ID, required = false) String xAiaHkTraceId,
            @ApiParam(value = "Context Id for EFK Logging")
            @RequestHeader(value = Constants.RequestHeader.CONTEXT_ID, required = true) String xAiaHkContextId,
            @ApiParam(value = "Document to be sent", required = true)
            @Valid @RequestBody Request<GenBatchRequest> genBatchRequest) {
    	
    	logService.logStartWorkingIntegration( APIPath.EAPP_D_GEN_BATCH_ID );
    	LocalDateTime start = LocalDateTime.now();
    	
    	String polNo=genBatchRequest.getData().getPolicyNo();
		payloadRequestService.saveRequestJson(polNo, "GenIdReq", genBatchRequest);

    	Response<GenBatchResponse> response= batchSubmissionService.generateBatchId(genBatchRequest);
    	 
		payloadRequestService.saveRequestJson(polNo, "GenIdResp", response);
    	
    	LocalDateTime end =LocalDateTime.now() ;
    	Duration duration = Duration.between( start,end );

    	logService.logEndWorkingSuccessIntegration( APIPath.EAPP_D_GEN_BATCH_ID,  duration.toMillis());
        return response;
    }
 

    @ApiOperation("To submit batch")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Requested document sent successfully."),
            @ApiResponse(code = 400, message = "Bad request.", response = Response.class),
            @ApiResponse(code = 404, message = "Invalid request.", response = Response.class)
    })
    @PostMapping(value = "/submit-batch", produces = MediaType.APPLICATION_JSON_VALUE)
    public Response<hk.com.aia.ws.eapp.model.response.ipos.FilResult> submitBatch(
            @ApiParam(value = "Local business unit.    | Valid Values |   | ----------   |   | HK, TH, SG   | ", required = true)
            @RequestHeader(value = Constants.RequestHeader.AIA_LBU, required = true) String xAiaLbu,
            @ApiParam(value = "Unique id for the request for tracking purposes.        ", required = true)
            @RequestHeader(value = Constants.RequestHeader.REQUEST_ID, required = true) String xAiaRequestId,
            @ApiParam(value = "Target environment of the request. Note that this header is required only when accessing non-production environments.    | Valid Values       |   | ------------------ |   | qa1, qa2, qa3, qa4 |        ")
            @RequestHeader(value = Constants.RequestHeader.AIA_ENV, required = false) String xAiaEnv,
            @ApiParam(value = "JWT Token for the request to verify Agent Authorization")
            @RequestHeader(value = Constants.RequestHeader.TOKEN_AGENT, required = false) String xAiaTokenAgent,
            @ApiParam(value = "Trace Id for EFK Logging")
            @RequestHeader(value = Constants.RequestHeader.TRACE_ID, required = false) String xAiaHkTraceId,
            @ApiParam(value = "Context Id for EFK Logging")
            @RequestHeader(value = Constants.RequestHeader.CONTEXT_ID, required = true) String xAiaHkContextId,
            @ApiParam(value = "Document to be sent", required = true)
            @Valid @RequestBody Request<SubmitBatch> submitBatchRequest) {
    	
    	
     	logService.logStartWorkingIntegration( APIPath.EAPP_D_SUBMIT_BATCH);
    	LocalDateTime start = LocalDateTime.now();
    	
    	
		// Step 1 - Log Request
		Response<FilResult> response = new Response<>();
		String polNo = submitBatchRequest.getData().getPolicyNo();
		String batchId = submitBatchRequest.getData().getBatchId();
	 
		payloadRequestService.saveRequestJson(polNo, "BatchReq", submitBatchRequest, batchId);

		boolean duplicatedSubmission = batchSubmissionService.isDuplicated(submitBatchRequest);
		if (duplicatedSubmission) {
			FilResult filResult = new FilResult();
			filResult.setStatus("success - is a duplicated submission");
			filResult.setReturnCode("1");
			response.setData(filResult);
			response.setStatus(CustomResponseStatus.SUCCESS.getDescription());
			response.setTransId(submitBatchRequest.getTransId());
			
			 
			payloadRequestService.saveRequestJson(polNo, "BatchResp", response, batchId);
			
			LocalDateTime end =LocalDateTime.now() ;
	    	Duration duration = Duration.between( start,end );

	    	logService.logIntegration( APIPath.EAPP_D_SUBMIT_BATCH, APIAction.END_WORK_FAILED, duration.toMillis(),0,"Duplicated Batch Id");
	        return response;
		}

		try {
			response = batchSubmissionService.submitBatchJob(submitBatchRequest);
		} catch (BlobFileException e) {
			log.error("Error on submitBatch {}", e);
			response.setStatus(CustomResponseStatus.ERROR.getDescription());
			ResultMessage resultMessage = new ResultMessage();
			resultMessage.setCode("-99");
			resultMessage.setMessage(e.getMessage());
			response.setResultMessages(e.getExceptionMessages());

		} catch (Exception e) {
			// TODO Auto-generated catch block
			log.error("Error on submitBatch {}", e);
			List<ResultMessage> exceptionMessages = new ArrayList<>();
			response.setStatus(CustomResponseStatus.ERROR.getDescription());
			ResultMessage resultMessage = new ResultMessage();
			resultMessage.setCode("-99");
			resultMessage.setMessage(e.getMessage());
			exceptionMessages.add(resultMessage);
			response.setResultMessages(exceptionMessages);

		}
		
		payloadRequestService.saveRequestJson(polNo, "BatchResp", response, batchId);

		LocalDateTime end =LocalDateTime.now() ;
    	Duration duration = Duration.between( start,end );

    	logService.logEndWorkingSuccessIntegration( APIPath.EAPP_D_SUBMIT_BATCH,  duration.toMillis());
        return response;
    }

}
