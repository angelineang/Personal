package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import hk.com.aia.ws.eapp.annotation.DataTruncation;
import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "T_ILASIFSANSWER")
public class TIlasIfsAnswer {

    @Column(name = "IFSANSWERID", length = 60)
    @Id
    private String ifsAnswerId;

    @Column(name = "EAPPID", length = 60)
    private String eAppId;

    @Column(name = "PRODUCTKEY", length = 10)
    private String productkey;

    @Column(name = "SECTION", length = 60)
    private String section;

    @Column(name = "ANSWER", length = 150)
    private String answer;

    @Column(name = "ORDERID")
    private Integer orderid;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "DETAILS")
    @DataTruncation(max = 500, validateByte = true, log = true)
    private String details;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TIlasIfsAnswer{");
        sb.append("ifsAnswerId='").append(ifsAnswerId).append('\'');
        sb.append(", eAppId='").append(eAppId).append('\'');
        sb.append(", productkey='").append(productkey).append('\'');
        sb.append(", section='").append(section).append('\'');
        sb.append(", answer='").append(answer).append('\'');
        sb.append(", orderid=").append(orderid);
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", details='").append(details).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
