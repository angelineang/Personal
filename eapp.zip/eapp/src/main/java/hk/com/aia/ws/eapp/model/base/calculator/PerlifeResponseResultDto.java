
package hk.com.aia.ws.eapp.model.base.calculator;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * Response data, will be null if HTTP.STATUS is not 1XX or 2XX
 */
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@EqualsAndHashCode(callSuper = false)
public class PerlifeResponseResultDto {
	private PerLifeResultDto data = null;
	private PerLifeResponseMetaInfo meta = null;
	public PerLifeResultDto getData() {
		return data;
	}
	public void setData(PerLifeResultDto data) {
		this.data = data;
	}
	public PerLifeResponseMetaInfo getMeta() {
		return meta;
	}
	public void setMeta(PerLifeResponseMetaInfo meta) {
		this.meta = meta;
	}

}
