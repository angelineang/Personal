package hk.com.aia.ws.eapp.mapper;

import hk.com.aia.ws.eapp.model.db.magnum.ipos.TCitiFna;
import hk.com.aia.ws.eapp.model.db.magnum.ipos.TEappPayor;
import hk.com.aia.ws.eapp.model.db.magnum.ipos.TEappPf;
import hk.com.aia.ws.eapp.model.request.ipos.TCitiFnaDto;
import hk.com.aia.ws.eapp.model.request.ipos.TEappPayorDto;
import hk.com.aia.ws.eapp.model.request.ipos.TEappPfDto;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

@Mapper
public interface TEappPfMapper {

    TEappPfMapper MAPPER = Mappers.getMapper(TEappPfMapper.class);

    TEappPf mapToTEappPf(TEappPfDto tEappPfDto);
}
