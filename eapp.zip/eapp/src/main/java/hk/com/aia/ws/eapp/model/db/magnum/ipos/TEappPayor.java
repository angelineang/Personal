package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import hk.com.aia.ws.eapp.util.ConversionHandler;
import lombok.Data;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@Table(name = "T_EAPPPAYOR")
@EntityListeners(AuditingEntityListener.class)
public class TEappPayor {

    @Column(name = "EAPPID")
    @Id
    private String eappId;

    @Column(name = "SAMEAS")
    private Integer sameAs;

    @Column(name = "RELATIONSHIPCODE")
    private String relationshipCode;

    @Column(name = "LASTNAME")
    private String lastName;

    @Column(name = "FIRSTNAME")
    private String firstName;

    @Column(name = "COMPANYNAME")
    private String companyName;

    @Column(name = "CHNNAME")
    private String chnName;

    @Column(name = "COMPANYNAMECN")
    private String companyNameCn;

    @Column(name = "GENDER")
    private String gender;

    @Column(name = "DOB")
    private Date dob;

    @Column(name = "NATIONALITYCODE")
    private String nationalityCode;

    @Column(name = "IDTYPE")
    private String idType;

    @Column(name = "IDNUMBER")
    private String idnumber;

    @Column(name = "BUSINESSCERNO")
    private String businessCerNo;


    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TEappExpand{");
        sb.append("EAPPID='").append(eappId).append('\'');
        sb.append(", SAMEAS='").append(sameAs).append('\'');
        sb.append(", RELATIONSHIPCODE='").append(relationshipCode).append('\'');
        sb.append(", LASTNAME='").append(lastName).append('\'');
        sb.append(", FIRSTNAME='").append(firstName).append('\'');
        sb.append(", COMPANYNAME='").append(companyName).append('\'');
        sb.append(", CHNNAME='").append(chnName).append('\'');
        sb.append(", COMPANYNAMECN='").append(companyNameCn).append('\'');
        sb.append(", GENDER='").append(gender).append('\'');
        sb.append(", DOB='").append(dob).append('\'');
        sb.append(", NATIONALITYCODE='").append(nationalityCode).append('\'');
        sb.append(", IDTYPE='").append(idType).append('\'');
        sb.append(", IDNUMBER='").append(idnumber).append('\'');
        sb.append(", BUSINESSCERNO='").append(businessCerNo).append('\'');
        sb.append('}');
        return sb.toString();
    }



}


