package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "T_ILASFNAEVALUATION")
public class TIlasFnaEvaluation {

    @Column(name = "FNAEVALUATIONID", length = 60)
    @Id
    private String fnaEvaluationId;

    @Column(name = "FNAID", length = 60)
    private String fnaId;

    @Column(name = "Q1", length = 5)
    private String q1;

    @Column(name = "Q2", length = 5)
    private String q2;

    @Column(name = "OTHERS", length = 200)
    private String others;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TIlasFnaEvaluation{");
        sb.append("fnaEvaluationId='").append(fnaEvaluationId).append('\'');
        sb.append(", fnaId='").append(fnaId).append('\'');
        sb.append(", q1='").append(q1).append('\'');
        sb.append(", q2='").append(q2).append('\'');
        sb.append(", others='").append(others).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append('}');
        return sb.toString();
    }
}