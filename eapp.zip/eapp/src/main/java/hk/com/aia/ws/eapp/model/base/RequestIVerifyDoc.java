package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.annotation.AllowedValuesValidation;
import hk.com.aia.ws.eapp.model.request.IVerifyRequest;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@ApiModel(value = "Request")
@Data
@NoArgsConstructor
public class RequestIVerifyDoc<T extends IVerifyRequest> {

	@ApiModelProperty(value = "transaction id of the request", notes = "transaction id is combination of timestamp + 5 digit random number."
			+ "e.g. yyyyMMddHHmmssSSS-10010", example = "20201010101010000-10100", required = true, position = 1)
	@JsonProperty("trans_id")
	@NotBlank
	@Size(min = 23, max = 23)
	protected String transId;

	@ApiModelProperty(value = "application id/channel id of caller "
			+ "who consume eApp API.", example = "AGIPOS", required = true, position = 2)
	@JsonProperty("app_id")
	@NotBlank
	@AllowedValuesValidation(propertyKey = "app.allowed.request-ids")
	protected String appId;

	@ApiModelProperty(value = "Request details.", position = 3)
	@NotNull
	@JsonProperty("data")
	@Valid
	private T data;

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder("RequestIVerifyDoc{");
		sb.append("transId='").append(transId).append('\'');
		sb.append(", appId='").append(appId).append('\'');
		sb.append(", data=").append(data);
		sb.append('}');
		return sb.toString();
	}
}
