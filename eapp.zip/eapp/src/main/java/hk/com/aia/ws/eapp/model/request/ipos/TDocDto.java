package hk.com.aia.ws.eapp.model.request.ipos;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.annotation.AllowedValuesValidation;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.util.Date;

import static hk.com.aia.ws.eapp.constant.Constants.TIMEZONE;

@ApiModel(value = "T_DOC Model")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TDocDto {

    @ApiModelProperty(value = "documents Id", required = true)
    @JsonProperty("documents_id")
    @Size(max = 60)
    @NotBlank
    private String documentsId;

    @JsonProperty("contact_id")
    @Size(max = 60)
    private String contactId;

    @JsonProperty("doc_type")
    @Size(max = 10)
    private String docType;

    @JsonProperty("file_name")
    private String fileName;

    @JsonProperty("module")
    @Size(max = 10)
    private String module;

    @JsonProperty("module_id")
    @Size(max = 60)
    private String moduleId;

    @JsonProperty("submitted_status")
    private Integer submittedStatus;

    @JsonProperty("sign_status")
    private Integer signStatus;

    @JsonProperty("page_no")
    private Integer pageNo;

    @JsonProperty("e_reference_no")
    @Size(max = 60)
    private String eReferenceNo;

    @JsonProperty("sign_at")
    @Size(max = 20)
    private String signAt;

    @ApiModelProperty(value = "sign date,format = yyyy-MM-dd", example = "2020-12-31")
    @JsonProperty("sign_date")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = TIMEZONE)
    private Date signDate;

    @JsonProperty("agent_code")
    @Size(max = 10)
    private String agentCode;

    @JsonProperty("access_code")
    @Size(max = 30)
    private String accessCode;

    @JsonProperty("is_ocr_pass_to_iverify")
    @AllowedValuesValidation(values = {"", "Y", "N"})
    @Size(max = 10)
    @ApiModelProperty(value = "string accepts Y or N or blank only", example = "Y")
    private String isOcrPassToIverify;

    @JsonProperty("sequence")
    private Integer sequence;

    @JsonProperty("sign_no")
    private Integer signNo;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TDocDto{");
        sb.append("documentsId='").append(documentsId).append('\'');
        sb.append(", contactId='").append(contactId).append('\'');
        sb.append(", docType='").append(docType).append('\'');
        sb.append(", fileName='").append(fileName).append('\'');
        sb.append(", module='").append(module).append('\'');
        sb.append(", moduleId='").append(moduleId).append('\'');
        sb.append(", submittedStatus=").append(submittedStatus);
        sb.append(", signStatus=").append(signStatus);
        sb.append(", pageNo=").append(pageNo);
        sb.append(", eReferenceNo='").append(eReferenceNo).append('\'');
        sb.append(", signAt='").append(signAt).append('\'');
        sb.append(", signDate=").append(signDate);
        sb.append(", agentCode='").append(agentCode).append('\'');
        sb.append(", accessCode='").append(accessCode).append('\'');
        sb.append(", isOcrPassToIverify='").append(isOcrPassToIverify).append('\'');
        sb.append(", sequence=").append(sequence);
        sb.append(", signNo=").append(signNo);
        sb.append('}');
        return sb.toString();
    }
}
