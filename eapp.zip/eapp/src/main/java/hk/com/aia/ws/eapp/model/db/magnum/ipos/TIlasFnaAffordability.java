package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import hk.com.aia.ws.eapp.annotation.DataTruncation;
import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "T_ILASFNAAFFORDABILITY")
public class TIlasFnaAffordability {

    @Column(name = "FNAAFFORDABILITYID", length = 60)
    @Id
    private String fnaAffordabilityId;

    @Column(name = "FNAID", length = 60)
    private String fnaId;

    @Column(name = "FNAQNO", length = 10)
    private String fnaQNo;

    @Column(name = "ANSWER")
    @DataTruncation(max = 50, validateByte = true, log = true)
    private String answer;

    @Column(name = "MONEY")
    private Integer money;

    @Column(name = "RETIREMENTAGE")
    private Integer retirementAge;

    @Column(name = "OTHERS")
    @DataTruncation(max = 1000, validateByte = true, log = true)
    private String others;

    @Column(name = "OTHERSCONTENT", length = 200)
    private String othersContent;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "SEQUENCE", length = 2)
    private String sequence;

    @Column(name = "AMOUNT")
    private BigDecimal amount;

    @Column(name = "CONTENTA", length = 50)
    private String contentA;

    @Column(name = "CONTENTB", length = 50)
    private String contentB;

    @Column(name = "CONTENTC", length = 50)
    private String contentC;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TIlasFnaAffordability{");
        sb.append("fnaAffordabilityId='").append(fnaAffordabilityId).append('\'');
        sb.append(", fnaId='").append(fnaId).append('\'');
        sb.append(", fnaQNo='").append(fnaQNo).append('\'');
        sb.append(", answer='").append(answer).append('\'');
        sb.append(", money=").append(money);
        sb.append(", retirementAge=").append(retirementAge);
        sb.append(", others='").append(others).append('\'');
        sb.append(", othersContent='").append(othersContent).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", sequence='").append(sequence).append('\'');
        sb.append(", amount=").append(amount);
        sb.append(", contentA='").append(contentA).append('\'');
        sb.append(", contentB='").append(contentB).append('\'');
        sb.append(", contentC='").append(contentC).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
