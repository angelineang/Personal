package hk.com.aia.ws.eapp.model.request.calculator;

import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.model.base.Payload;
import hk.com.aia.ws.eapp.model.base.calculator.LoginUser;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.Conversion;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@ApiModel(value = "AML Request Model")
@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class AMLRequest extends Payload {

    @JsonProperty("agt_code")
    private String agtCode;

    @JsonProperty("id_no")
    private String idNo;

    @JsonProperty("client_name")
    private String clientName;

    @JsonProperty("dob")
    private String dob;

    @JsonProperty("sex")
    private String sex;

    @JsonProperty("aml_flag")
    private String amlFlag;

    @JsonProperty("single_prem")
    private String singlePrem;

    @JsonProperty("regular_prem")
    private String regularPrem;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("AMLRequest{");
        sb.append(", idNo='").append(idNo).append('\'');
        sb.append(", clientName='").append(clientName).append('\'');
        sb.append(", dob='").append(dob).append('\'');
        sb.append(", sex='").append(sex).append('\'');
        sb.append(", amlFlag='").append(amlFlag).append('\'');
        sb.append(", singlePrem='").append(singlePrem).append('\'');
        sb.append(", regularPrem='").append(regularPrem).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
