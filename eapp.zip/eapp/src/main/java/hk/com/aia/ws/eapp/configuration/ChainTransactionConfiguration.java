package hk.com.aia.ws.eapp.configuration;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.transaction.ChainedTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
public class ChainTransactionConfiguration {

    @Bean(name = "chainedTransactionManager")
    public ChainedTransactionManager transactionManager(
            @Qualifier("magnumTransactionManager")
                    PlatformTransactionManager sybaseTransactionManager,
            @Qualifier("magTransactionManager")
                    PlatformTransactionManager sqlTransactionManager
    ) {

        return new ChainedTransactionManager(sybaseTransactionManager,
                sqlTransactionManager);
    }
}
