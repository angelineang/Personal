package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.annotation.AllowedValuesValidation;
import hk.com.aia.ws.eapp.annotation.DateTimeValidation;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;

import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;

@ApiModel(value = "Submission Model")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PolPromotion {

    @ApiModelProperty(value = "policy_no")
    @JsonProperty("policy_no")
    @NotBlank
    private String policyNo;

    @ApiModelProperty(value = "fsa_paid_amount")
    @JsonProperty("fsa_paid_amount")
    private String fsaPaidAmount;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("PolPromotion{");
        sb.append(", policyNo='").append(policyNo).append('\'');
        sb.append(", fsaPaidAmount='").append(fsaPaidAmount).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
