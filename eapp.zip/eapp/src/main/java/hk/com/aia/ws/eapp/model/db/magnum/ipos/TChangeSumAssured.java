package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import hk.com.aia.ws.eapp.model.db.magnum.ipos.idclass.TChangeSumAssuredId;
import lombok.Data;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Data
@Table(name = "T_CHANGESUMASSURED")
@IdClass(TChangeSumAssuredId.class)
@EntityListeners(AuditingEntityListener.class)
public class TChangeSumAssured {

    @Column(name = "CHANGESUMASSUREDID", length = 60)
    @Id
    private String changeSumAssuredId;

    @Column(name = "AGENTCODE", length = 10)
    private String agentCode;

    @Column(name = "ACCESSCODE", length = 30)
    private String accessCode;

    @Column(name = "SQSQUOTATIONID", length = 60)
    @Id
    private String sqsQuotationId;

    @Column(name = "POLICYYEAR")
    private Integer policyYear;

    @Column(name = "AMOUNT")
    private BigDecimal amount;

    @Column(name = "CREATEDBY", length = 10, updatable = false)
    @CreatedBy
    private String createdBy;

    @Column(name = "UPDATEDBY", length = 10)
    @LastModifiedBy
    private String updatedBy;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "LASTUPDATEDATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    @LastModifiedDate
    private Date lastUpdateDateTime;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TChangeSumAssured{");
        sb.append("changeSumAssuredId='").append(changeSumAssuredId).append('\'');
        sb.append(", agentCode='").append(agentCode).append('\'');
        sb.append(", accessCode='").append(accessCode).append('\'');
        sb.append(", sqsQuotationId='").append(sqsQuotationId).append('\'');
        sb.append(", policyYear=").append(policyYear);
        sb.append(", amount=").append(amount);
        sb.append(", createdBy='").append(createdBy).append('\'');
        sb.append(", updatedBy='").append(updatedBy).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", lastUpdateDateTime=").append(lastUpdateDateTime);
        sb.append('}');
        return sb.toString();
    }
}
