package hk.com.aia.ws.eapp.interceptor;

import hk.com.aia.ws.eapp.constant.Constants;
import hk.com.aia.ws.eapp.model.log.TranKeys;
import hk.com.aia.ws.eapp.service.PayloadRequestService;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.security.SecureRandom;
import java.util.Enumeration;

@Component
@Slf4j
public class LogInterceptor implements HandlerInterceptor {

    @Value("${app.id.eim}")
    private String eimAppId;

    @Value("${app.version}")
    private String appVersion;

    @Autowired
    private PayloadRequestService payloadRequestService;

    private static final String AB = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";

    private static SecureRandom rnd = new SecureRandom();

    private String generateRandomString(int len) {
        StringBuilder sb = new StringBuilder(len);
        for (int i = 0; i < len; i++)
            sb.append(AB.charAt(rnd.nextInt(AB.length())));
        return sb.toString();
    }

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
            throws Exception {

        String traceId = request.getHeader(Constants.RequestHeader.TRACE_ID);
        final String callerContextId = request.getHeader(Constants.RequestHeader.CONTEXT_ID);
        String aiaEnv = request.getHeader(Constants.RequestHeader.AIA_ENV);
        final String sourceUserId = request.getHeader(Constants.RequestHeader.ORIGINATING_USER);
        final String sourceApp = request.getHeader(Constants.RequestHeader.SOURCE_APP);
        final String originalIp = request.getHeader(Constants.RequestHeader.ORIGINAL_IP);
        
      

        // Generate a trance id if empty
        if (StringUtils.isEmpty(traceId)) {
            traceId = generateRandomString(10);
            log.warn("request header trace_id is empty. Generated random trace_id : {} ", traceId);
        }

        // Generate a context id for each request
        final String appContextId = generateRandomString(5);

        MDC.put(Constants.EFKLogging.TRACE_ID, trim(traceId,10));
        MDC.put(Constants.EFKLogging.CALLER_CONTEXT_ID, trim(callerContextId,5));
        MDC.put(Constants.EFKLogging.APP_CONTEXT_ID, trim(appContextId,5));
        MDC.put(Constants.EFKLogging.APP_ID, eimAppId);
        MDC.put(Constants.EFKLogging.APP_VERSION, appVersion);
        MDC.put(Constants.EFKLogging.AIA_ENV, aiaEnv);     
        
        MDC.put(Constants.EFKLogging.SOURCE_USER_ID, trim(sourceUserId,50));
        MDC.put(Constants.EFKLogging.SOURCE_USER_IP, trim(originalIp,50));

        MDC.put(Constants.EFKLogging.SOURCE_APP, sourceApp);

        MDC.put(Constants.EFKLogging.MESSAGE_TYPE, "Application");
          
        MDC.put(Constants.EFKLogging.TRAN_KEYS, "");
        //log.info("request.getRequestURI {}", request.getRequestURI());
        
        StringBuilder sb=new StringBuilder();
        final Enumeration<String> parameterNames = request.getHeaderNames() ;
        while (parameterNames.hasMoreElements()) {
        	String parameter = parameterNames.nextElement();
        	sb.append(parameter).append(":").append(request.getHeader(parameter)).append("  ");
        	
        	}
        log.info("Header Parameter {} ", ConversionHandler.encode(sb.toString()));

        return true;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView)
            throws Exception {

        MDC.clear();

    }
    
	private String trim(String contextId,int length) {
		if (contextId == null)
			return null;
		if (contextId.length() > length) {
			return contextId.substring(0, length);
		} else {
			return contextId;
		}

	}
}
