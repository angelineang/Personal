package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import lombok.Data;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Data
@Table(name = "T_CITIFNA")
@EntityListeners(AuditingEntityListener.class)
public class TCitiFna {

    @Column(name = "FNAID", length = 60)
    @Id
    private String fnaId;

    @Column(name = "FNAEXPECTEDRATE")
    private BigDecimal fnaExpectedRate;

    @Column(name = "FNAINFLATIONRATE")
    private BigDecimal fnaInflationRate;

    @Column(name = "IARR")
    private BigDecimal iarr;

    @Column(name = "FNASIGNSTATUS")
    private Integer fnaSignStatus;

    @Column(name = "SIGNEDDATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date signedDate;

    @Column(name = "FNAQAINFOCONFIRMED", length = 60)
    private String fnaQAInfoConfirmed;

    @Column(name = "FNAQAFINDINGREPORTRECEIPT", length = 60)
    private String fnaQAFindingReportReceipt;

    @Column(name = "CONTACTID", length = 60)
    private String contactId;

    @Column(name = "EAPPID", length = 60)
    private String eappId;

    @Column(name = "CREATEBY", length = 10, updatable = false)
    @CreatedBy
    private String createBy;

    @Column(name = "UPDATEBY", length = 10)
    @LastModifiedBy
    private String updateBy;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "LASTUPDATEDATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    @LastModifiedDate
    private Date lastUpdateDateTime;

    @Column(name = "FNAFLAG", length = 1)
    private String fnaFlag;

    @Column(name = "MismatchQID", length = 50)
    private String mismatchQId;

    @Column(name = "LowerQID", length = 50)
    private String lowerQId;

    @Column(name = "HigherQID", length = 50)
    private String higherQId;

    @Column(name = "LowerReason", length = 50)
    private String lowerReason;

    @Column(name = "CA1LowerReasonRemark", length = 200)
    private String ca1LowerReasonRemark;

    @Column(name = "CA2LowerReasonRemark", length = 200)
    private String ca2LowerReasonRemark;

    @Column(name = "CA3LowerReasonRemark", length = 200)
    private String ca3LowerReasonRemark;

    @Column(name = "fnaAudioStatus", length = 5)
    private String fnaAudioStatus;

    @Column(name = "CA1LowerReason", length = 50)
    private String ca1LowerReason;

    @Column(name = "CA2LowerReason", length = 50)
    private String ca2LowerReason;

    @Column(name = "CA3LowerReason", length = 50)
    private String ca3LowerReason;


    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TCitiFna{");
        sb.append("fnaId='").append(fnaId).append('\'');
        sb.append(", fnaExpectedRate=").append(fnaExpectedRate);
        sb.append(", fnaInflationRate=").append(fnaInflationRate);
        sb.append(", iarr=").append(iarr);
        sb.append(", fnaSignStatus=").append(fnaSignStatus);
        sb.append(", signedDate=").append(signedDate);
        sb.append(", fnaQAInfoConfirmed='").append(fnaQAInfoConfirmed).append('\'');
        sb.append(", fnaQAFindingReportReceipt='").append(fnaQAFindingReportReceipt).append('\'');
        sb.append(", contactId='").append(contactId).append('\'');
        sb.append(", eappId='").append(eappId).append('\'');
        sb.append(", createBy='").append(createBy).append('\'');
        sb.append(", updateBy='").append(updateBy).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", lastUpdateDateTime=").append(lastUpdateDateTime);
        sb.append(", fnaFlag='").append(fnaFlag).append('\'');
        sb.append(", mismatchQId='").append(mismatchQId).append('\'');
        sb.append(", lowerQId='").append(lowerQId).append('\'');
        sb.append(", higherQId='").append(higherQId).append('\'');
        sb.append(", lowerReason='").append(lowerReason).append('\'');
        sb.append(", ca1LowerReasonRemark='").append(ca1LowerReasonRemark).append('\'');
        sb.append(", ca2LowerReasonRemark='").append(ca2LowerReasonRemark).append('\'');
        sb.append(", ca3LowerReasonRemark='").append(ca3LowerReasonRemark).append('\'');
        sb.append(", fnaAudioStatus='").append(fnaAudioStatus).append('\'');
        sb.append(", CA1LowerReason='").append(ca1LowerReason).append('\'');
        sb.append(", CA2LowerReason='").append(ca2LowerReason).append('\'');
        sb.append(", CA3LowerReason='").append(ca3LowerReason).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
