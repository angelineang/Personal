package hk.com.aia.ws.eapp.model.properties;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class PnaProperties {

    private Boolean indicator;
    private String planRegion;
    private String policyCurrency;
    private String paymentMode;
    private String ignoreQuota;
    private String url;
    private String successCode;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("PnaProperties{");
        sb.append("indicator=").append(indicator);
        sb.append(", planRegion='").append(planRegion).append('\'');
        sb.append(", policyCurrency='").append(policyCurrency).append('\'');
        sb.append(", paymentMode='").append(paymentMode).append('\'');
        sb.append(", ignoreQuota='").append(ignoreQuota).append('\'');
        sb.append(", url='").append(url).append('\'');
        sb.append(", successCode='").append(successCode).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
