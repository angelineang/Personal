package hk.com.aia.ws.eapp.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import hk.com.aia.ws.eapp.model.db.magnum.ipos.TSowdAddress;
import hk.com.aia.ws.eapp.model.request.ipos.TSowdAddressDto;

import java.util.List;

@Mapper
public interface TSowdAddressMapper {

    TSowdAddressMapper MAPPER = Mappers.getMapper(TSowdAddressMapper.class);

    @Mapping(target = "createdDateTime", ignore = true)
    List<TSowdAddress> mapToTSowdAddressList(List<TSowdAddressDto> tSowdAddressDto);
}
