package hk.com.aia.ws.eapp.model.properties;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class StorageProperties {

    private String accountName;
    private String accountKey;
    private String containerName;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("StorageProperties{");
        sb.append("accountName='").append(accountName).append('\'');
        sb.append(", accountKey='").append(accountKey).append('\'');
        sb.append(", containerName='").append(containerName).append('\'');
        sb.append('}');
        return sb.toString();
    }
}