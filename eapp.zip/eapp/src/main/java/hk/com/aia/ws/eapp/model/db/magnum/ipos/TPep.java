package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "T_PEP")
public class TPep {

    @Column(name = "PEPID", length = 60)
    @Id
    private String pepId;

    @Column(name = "CONTACTID", length = 60)
    private String contactId;

    @Column(name = "EAPPID", length = 60)
    private String eappId;

    @Column(name = "PEPANSWERID", length = 10)
    private String pepAnswerId;

    @Column(name = "PEPANSWER", length = 1)
    private String pepAnswer;

    @Column(name = "PEPANSWEROTHER")
    private String pepAnswerOther;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TPep{");
        sb.append("pepId='").append(pepId).append('\'');
        sb.append(", contactId='").append(contactId).append('\'');
        sb.append(", eappId='").append(eappId).append('\'');
        sb.append(", pepAnswerId='").append(pepAnswerId).append('\'');
        sb.append(", pepAnswer='").append(pepAnswer).append('\'');
        sb.append(", pepAnswerOther='").append(pepAnswerOther).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append('}');
        return sb.toString();
    }
}


