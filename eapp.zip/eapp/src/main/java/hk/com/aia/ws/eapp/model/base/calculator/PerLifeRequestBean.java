package hk.com.aia.ws.eapp.model.base.calculator;

import javax.xml.datatype.XMLGregorianCalendar;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class PerLifeRequestBean {

    protected String alphaID;
    protected long apiDs;
    protected String calcType;
    protected long cdcDs;
    protected String cdcPolicyNo;
    protected String dob;
    protected XMLGregorianCalendar endDate;
    protected String firstName;
    protected String groupName;
    protected String idnr;
    protected String keyID;
    protected String lastName;
    protected String middleName;
    protected String policyNo;
    protected String reqType;
    protected String requestWs;
    protected String responseWs;
    protected String selectedRole;
    protected String sex;
    protected XMLGregorianCalendar startDate;
    protected String wsKeyString;
    protected long wsdlDs;
}
