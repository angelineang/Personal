package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.annotation.AllowedValuesValidation;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@ApiModel(value = "Get Proposal Status ")
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class SubmitMsStatus extends Payload {

	@ApiModelProperty(value = "Policy number", required = true)
	@JsonProperty("policy_no")
	@NotBlank
	@Size(max = 10)
	private String policyNo;

	@ApiModelProperty(value = "Agent code")
	@JsonProperty("agent_code")
	@Size(max = 5)
	private String agentCode;

	@ApiModelProperty(value = "Agency Code")
	@JsonProperty("agency_code")
	@Size(max = 5)
	private String agencyCode;

	@ApiModelProperty(value = "Leader")
	@JsonProperty("leader")
	@Size(max = 1)
	@AllowedValuesValidation(values = {"1", "0"})
	private String leader;

	@ApiModelProperty(value = "View Mode - A = Agent View, C = Customer View, S = Staff View", allowableValues = "A,C,S")
	@JsonProperty("view_mode")
	@AllowedValuesValidation(values = {"A", "C", "S"})
	private String viewMode;

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder("SubmitMsStatus{");
		sb.append("policyNo='").append(ConversionHandler.mask(policyNo)).append('\'');
		sb.append(", agentCode='").append(agentCode).append('\'');
		sb.append(", agencyCode='").append(agencyCode).append('\'');
		sb.append(", leader='").append(leader).append('\'');
		sb.append(", viewMode='").append(viewMode).append('\'');
		sb.append('}');
		return sb.toString();
	}
}
