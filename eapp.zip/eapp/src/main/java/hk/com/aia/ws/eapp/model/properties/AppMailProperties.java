package hk.com.aia.ws.eapp.model.properties;

import lombok.Data;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

@Data
public class AppMailProperties {

    private static final Charset DEFAULT_CHARSET;
    private String host;
    private Integer port;
    private String username;
    private String password;
    private String protocol = "smtp";
    private Charset defaultEncoding;
    private Boolean testConnection = false;
    private String sendmail;
    private Map<String, String> properties;


    static {
        DEFAULT_CHARSET = StandardCharsets.UTF_8;
    }

    public AppMailProperties() {
        this.defaultEncoding = DEFAULT_CHARSET;
        this.properties = new HashMap<>();
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("AppMailProperties{");
        sb.append("host='").append(host).append('\'');
        sb.append(", port=").append(port);
        sb.append(", username='").append(username).append('\'');
        sb.append(", password='").append(password).append('\'');
        sb.append(", protocol='").append(protocol).append('\'');
        sb.append(", defaultEncoding=").append(defaultEncoding);
        sb.append(", testConnection=").append(testConnection);
        sb.append(", sendmail='").append(sendmail).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
