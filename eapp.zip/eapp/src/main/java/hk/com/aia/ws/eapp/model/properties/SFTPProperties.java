package hk.com.aia.ws.eapp.model.properties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class SFTPProperties {

    private String server;
    private String username;
    private Integer port;
    private String proxyHost;
    private Integer proxyPort = 0;
    private String privateKey;
    private String passPhrase;
    private Integer sessionTimeout;
    private Integer channelTimeout;
    private String folderDestination;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("SFTPProperties{");
        sb.append("server='").append(server).append('\'');
        sb.append(", username='").append(username).append('\'');
        sb.append(", port=").append(port);
        sb.append(", proxyHost='").append(proxyHost).append('\'');
        sb.append(", proxyPort=").append(proxyPort);
        sb.append(", privateKey='").append(privateKey).append('\'');
        sb.append(", passPhrase='").append(passPhrase).append('\'');
        sb.append(", sessionTimeout=").append(sessionTimeout);
        sb.append(", channelTimeout=").append(channelTimeout);
        sb.append(", folderDestination='").append(folderDestination).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
