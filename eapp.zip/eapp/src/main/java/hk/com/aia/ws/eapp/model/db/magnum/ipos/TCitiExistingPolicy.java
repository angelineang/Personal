package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.math.BigDecimal;

@Entity
@Data
@Table(name = "T_CITIEXISTINGPOLICY")
@EntityListeners(AuditingEntityListener.class)
public class TCitiExistingPolicy {

    @Column(name = "EXISTINGPOLID", length = 60)
    @Id
    private String existingPolId;

    @Column(name = "FNAID", length = 60)
    private String fnaId;

    @Column(name = "INSURANCECOMPANY", length = 200)
    private String insuranceCompany;

    @Column(name = "POLICYTYPE", length = 60)
    private String policyType;

    @Column(name = "PREMIUMMODE")
    private Integer premiumMode;

    @Column(name = "SUMASSURED")
    private BigDecimal sumAssured;

    @Column(name = "MODALPREMIUMAMOUNT")
    private BigDecimal modalPremiumAmount;

    @Column(name = "YEARDUE")
    private Integer yearDue;

    @Column(name = "REMAININGPAYMENTTERM")
    private Integer remainingPaymentTerm;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TCitiExistingPolicy{");
        sb.append("existingPolId='").append(existingPolId).append('\'');
        sb.append(", fnaId='").append(fnaId).append('\'');
        sb.append(", insuranceCompany='").append(insuranceCompany).append('\'');
        sb.append(", policyType='").append(policyType).append('\'');
        sb.append(", premiumMode=").append(premiumMode);
        sb.append(", sumAssured=").append(sumAssured);
        sb.append(", modalPremiumAmount=").append(modalPremiumAmount);
        sb.append(", yearDue=").append(yearDue);
        sb.append(", remainingPaymentTerm=").append(remainingPaymentTerm);
        sb.append('}');
        return sb.toString();
    }
}
