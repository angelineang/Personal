package hk.com.aia.ws.eapp.model.request.ipos;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.math.BigDecimal;
import java.util.Date;

import static hk.com.aia.ws.eapp.constant.Constants.TIMEZONE;

@ApiModel(value = "T_CITIFNA Model")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TCitiFnaDto {

    @ApiModelProperty(value = "fna Id", required = true)
    @JsonProperty("fna_id")
    @Size(max = 60)
    @NotBlank
    private String fnaId;

    @JsonProperty("fna_expected_rate")
    private BigDecimal fnaExpectedRate;

    @JsonProperty("fna_inflation_rate")
    private BigDecimal fnaInflationRate;

    @JsonProperty("iarr")
    private BigDecimal iarr;

    @JsonProperty("fna_sign_status")
    private Integer fnaSignStatus;

    @ApiModelProperty(value = "signed date")
    @JsonProperty("signed_date")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", timezone = TIMEZONE)
    private Date signedDate;

    @JsonProperty("fna_qa_info_confirmed")
    @Size(max = 60)
    private String fnaQAInfoConfirmed;

    @JsonProperty("fna_qa_finding_report_receipt")
    @Size(max = 60)
    private String fnaQAFindingReportReceipt;

    @JsonProperty("contact_id")
    @Size(max = 60)
    private String contactId;

    @JsonProperty("eapp_id")
    @Size(max = 60)
    private String eappId;

    @JsonProperty("fna_flag")
    @Size(max = 1)
    private String fnaFlag;

    @JsonProperty("mismatch_q_id")
    @Size(max = 50)
    private String mismatchQId;

    @JsonProperty("lower_q_id")
    @Size(max = 50)
    private String lowerQId;

    @JsonProperty("higher_q_id")
    @Size(max = 50)
    private String higherQId;

    @JsonProperty("lower_reason")
    @Size(max = 50)
    private String lowerReason;

    @JsonProperty("ca_1_lower_reason_remark")
    @Size(max = 200)
    private String ca1LowerReasonRemark;

    @JsonProperty("ca_2_lower_reason_remark")
    @Size(max = 200)
    private String ca2LowerReasonRemark;

    @JsonProperty("ca_3_lower_reason_remark")
    @Size(max = 200)
    private String ca3LowerReasonRemark;

    @JsonProperty("fna_audio_status")
    @Size(max = 5)
    private String fnaAudioStatus;

    @JsonProperty("ca1_lower_reason")
    @Size(max = 50)
    private String ca1LowerReason;

    @JsonProperty("ca2_lower_reason")
    @Size(max = 50)
    private String ca2LowerReason;

    @JsonProperty("ca3_lower_reason")
    @Size(max = 50)
    private String ca3LowerReason;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TCitiFnaDto{");
        sb.append("fnaId='").append(fnaId).append('\'');
        sb.append(", fnaExpectedRate=").append(fnaExpectedRate);
        sb.append(", fnaInflationRate=").append(fnaInflationRate);
        sb.append(", iarr=").append(iarr);
        sb.append(", fnaSignStatus=").append(fnaSignStatus);
        sb.append(", signedDate=").append(signedDate);
        sb.append(", fnaQAInfoConfirmed='").append(fnaQAInfoConfirmed).append('\'');
        sb.append(", fnaQAFindingReportReceipt='").append(fnaQAFindingReportReceipt).append('\'');
        sb.append(", contactId='").append(contactId).append('\'');
        sb.append(", eappId='").append(eappId).append('\'');
        sb.append(", fnaFlag='").append(fnaFlag).append('\'');
        sb.append(", mismatchQId='").append(mismatchQId).append('\'');
        sb.append(", lowerQId='").append(lowerQId).append('\'');
        sb.append(", higherQId='").append(higherQId).append('\'');
        sb.append(", lowerReason='").append(lowerReason).append('\'');
        sb.append(", ca1LowerReasonRemark='").append(ca1LowerReasonRemark).append('\'');
        sb.append(", ca2LowerReasonRemark='").append(ca2LowerReasonRemark).append('\'');
        sb.append(", ca3LowerReasonRemark='").append(ca3LowerReasonRemark).append('\'');
        sb.append(", fnaAudioStatus='").append(fnaAudioStatus).append('\'');
        sb.append(", ca1_lower_reason='").append(ca1LowerReason).append('\'');
        sb.append(", ca2_lower_reason='").append(ca2LowerReason).append('\'');
        sb.append(", ca3_lower_reason='").append(ca3LowerReason).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
