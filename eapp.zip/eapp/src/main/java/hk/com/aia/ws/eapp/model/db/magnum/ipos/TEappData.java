package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import lombok.Data;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "T_EAPP_DATA")
public class TEappData {
    @Column(name = "EAPPDATAID", length = 60)
    @Id
    private String eappDataId;
    
    @Column(name = "EAPPID", length = 60)
    private String eappId;
    
    @Column(name = "PREOPTION", length = 10)
    private String preOption;
    
    @Column(name = "PREAMOUNT")
    private BigDecimal preAmount;
    
    @Column(name = "PREPAY_GP2_BPV")
    private String prepayGp2Bpv;
    
    @Column(name = "emailApplicantReg")
    private String emailApplicantReg;
    
    @Column(name = "emailShareReason")
    private String emailShareReason;
    
    @Column(name = "NOCHINESENAME")
    private String noChineseName;
    
    @Override
    public String toString() {
    	final StringBuilder sb = new StringBuilder("TEappData{");
        sb.append(", eappDataId=").append(eappDataId);
        sb.append(", eappId=").append(eappId);
        sb.append(", preOption='").append(preOption).append('\'');
        sb.append(", preAmount='").append(preAmount).append('\'');
        sb.append(", prepayGp2Bpv='").append(prepayGp2Bpv).append('\'');
        sb.append(", emailApplicantReg='").append(emailApplicantReg).append('\'');
        sb.append(", emailShareReason='").append(emailShareReason).append('\'');
        sb.append(", noChineseName='").append(noChineseName).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
