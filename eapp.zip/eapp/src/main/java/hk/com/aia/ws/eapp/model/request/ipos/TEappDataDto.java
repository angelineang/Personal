package hk.com.aia.ws.eapp.model.request.ipos;



import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@ApiModel(value = "T_EAPP_DATA Model")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TEappDataDto {
    @JsonProperty("eappDataId")
    private String eappDataId;

    @JsonProperty("eappId")
    private String eappId;

    @JsonProperty("preOption")
    private String preOption;

    @JsonProperty("preAmount")
    private BigDecimal preAmount;
    
    @JsonProperty("prepayGp2Bpv")
    private String prepayGp2Bpv;
    
    @JsonProperty("emailIsApplicantReg")
    private String emailApplicantReg;
    
    @JsonProperty("emailShareReason")
    private String emailShareReason;
    
    @JsonProperty("noChineseName")
    private String noChineseName;
    
    @Override
    public String toString() {
    	final StringBuilder sb = new StringBuilder("TEappData{");
        sb.append(", eappDataId=").append(eappDataId);
        sb.append(", eappId=").append(eappId);
        sb.append(", preOption='").append(preOption).append('\'');
        sb.append(", preAmount='").append(preAmount).append('\'');
        sb.append(", prepayGp2Bpv='").append(prepayGp2Bpv).append('\'');
        sb.append(", emailApplicantReg='").append(emailApplicantReg).append('\'');
        sb.append(", emailShareReason='").append(emailShareReason).append('\'');
        sb.append(", noChineseName='").append(noChineseName).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
