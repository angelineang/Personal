package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import hk.com.aia.ws.eapp.util.ConversionHandler;
import lombok.Data;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "T_EAPP_PROM_OFFER")
public class TEappPromOffer {

    @Column(name = "eappPromOfferID", length = 60)
    @Id
    private String eappPromOfferId;

    @Column(name = "eappID", length = 60)
    private String eappId;

    @Column(name = "isSelected_FMRP", length = 20)
    private String isSelectedFmrp;

    @Column(name = "roleCode", length = 20)
    private String roleCode;

    @Column(name = "referrerPolicyNo", length = 20)
    private String referrerPolicyNo;

    @Column(name = "lastName", length = 50)
    private String lastName;

    @Column(name = "firstName", length = 50)
    private String firstName;

    @Column(name = "relationShipCode", length = 20)
    private String relationShipCode;

    @Column(name = "createby", length = 10,updatable = false)
    @CreatedBy
    private String createBy;

    @Column(name = "createddatetime",updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "isSelected_AIAPT", length = 20)
    private String isSelectedAiaPt;

    @Column(name = "member_AIAPT",length = 20)
    private String memberAiaPt;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TEappPromOffer{");
        sb.append("eappPromOfferId='").append(eappPromOfferId).append('\'');
        sb.append(", eappId='").append(eappId).append('\'');
        sb.append(", isSelectedFmrp='").append(isSelectedFmrp).append('\'');
        sb.append(", roleCode='").append(roleCode).append('\'');
        sb.append(", referrerPolicyNo='").append(referrerPolicyNo).append('\'');
        sb.append(", lastName='").append(ConversionHandler.mask(lastName)).append('\'');
        sb.append(", firstName='").append(ConversionHandler.mask(firstName)).append('\'');
        sb.append(", relationShipCode='").append(relationShipCode).append('\'');
        sb.append(", createBy='").append(createBy).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", isSelectedAiaPt='").append(isSelectedAiaPt).append('\'');
        sb.append(", memberAiaPt='").append(memberAiaPt).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
