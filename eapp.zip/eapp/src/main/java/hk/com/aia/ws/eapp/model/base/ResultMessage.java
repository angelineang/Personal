package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class ResultMessage extends Payload implements Serializable {

    private static final long serialVersionUID = 1L;

    public ResultMessage(String code, String message) {
        this.code = code;
        this.message = message;
    }

    @JsonProperty("code")
    private String code;

    @JsonProperty("message")
    private String message;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("ResultMessage{");
        sb.append("code='").append(code).append('\'');
        sb.append(", message='").append(message).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
