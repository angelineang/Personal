package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import lombok.Data;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "T_ESUB")
public class TEsub {

    @Column(name = "ESUBID", length = 60)
    @Id
    private String esubId;

    @Column(name = "EAPPID", length = 60)
    private String eappId;

    @Column(name = "SUBMISSIONDATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date submissionDateTime;

    @Column(name = "STATUS", length = 20)
    private String status;

    @Column(name = "ISPGSCOMPLETED")
    private Integer isPGSCompleted;

    @Column(name = "ISEAPPCOMPLETED")
    private Integer isEappCompleted;

    @Column(name = "SQSQUOTATIONID", length = 60)
    private String sqsQuotationId;

    @Column(name = "CREATEDBY", length = 10, updatable = false)
    @CreatedBy
    private String createdBy;

    @Column(name = "UPDATEDBY", length = 10)
    @LastModifiedBy
    private String updatedBy;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "LASTUPDATEDATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    @LastModifiedDate
    private Date lastUpdateDateTime;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TEsub{");
        sb.append("esubId='").append(esubId).append('\'');
        sb.append(", eappId='").append(eappId).append('\'');
        sb.append(", submissionDateTime=").append(submissionDateTime);
        sb.append(", status='").append(status).append('\'');
        sb.append(", isPGSCompleted=").append(isPGSCompleted);
        sb.append(", isEappCompleted=").append(isEappCompleted);
        sb.append(", sqsQuotationId='").append(sqsQuotationId).append('\'');
        sb.append(", createdBy='").append(createdBy).append('\'');
        sb.append(", updatedBy='").append(updatedBy).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", lastUpdateDateTime=").append(lastUpdateDateTime);
        sb.append('}');
        return sb.toString();
    }
}
