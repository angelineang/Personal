package hk.com.aia.ws.eapp.model.db.magnum.ipos.idclass;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TPermanentRatingId implements Serializable {

    private static final long serialVersionUID = -5421863188813997113L;
    private String permanentRatingId;
    private String planSelectionId;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TPermanentRatingId{");
        sb.append("permanentRatingId='").append(permanentRatingId).append('\'');
        sb.append(", planSelectionId='").append(planSelectionId).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
