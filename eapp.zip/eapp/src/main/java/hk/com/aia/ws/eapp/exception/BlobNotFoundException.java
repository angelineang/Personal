package hk.com.aia.ws.eapp.exception;

import lombok.NoArgsConstructor;


@NoArgsConstructor
public class BlobNotFoundException extends BaseException {

}
