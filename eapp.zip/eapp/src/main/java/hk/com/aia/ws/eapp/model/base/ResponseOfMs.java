package hk.com.aia.ws.eapp.model.base;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ResponseOfMs {

    private String returnCode;
    private String message;
    private List<ResultMessage> resultMessageOuts;

    public ResponseOfMs(String returnCode, String message) {
        this.returnCode = returnCode;
        this.message = message;
    }

    public ResultMessage getMessage(int i) {
        return this.resultMessageOuts.get(i);
    }

    public void setMessage(int i, ResultMessage resultMessage) {
        this.resultMessageOuts.set(i, resultMessage);
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("ResponseOfMs{");
        sb.append("returnCode='").append(returnCode).append('\'');
        sb.append(", message='").append(message).append('\'');
        sb.append(", resultMessageOuts=").append(resultMessageOuts);
        sb.append('}');
        return sb.toString();
    }
}
