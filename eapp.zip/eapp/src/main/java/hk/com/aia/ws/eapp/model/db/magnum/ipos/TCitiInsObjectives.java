package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;

@Entity
@Data
@Table(name = "T_CITIINSOBJECTIVES")
@EntityListeners(AuditingEntityListener.class)
public class TCitiInsObjectives {

    @Column(name = "INSOBJID", length = 60)
    @Id
    private String insObjId;

    @Column(name = "FNAID", length = 60)
    private String fnaId;

    @Column(name = "NEEDS", length = 60)
    private String needs;

    @Column(name = "GROUPEDBY", length = 60)
    private String groupedBy;

    @Column(name = "LEVELS", length = 5)
    private String levels;

    @Column(name = "REMARK", length = 200)
    private String remark;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TCitiInsObjectives{");
        sb.append("insObjId='").append(insObjId).append('\'');
        sb.append(", fnaId='").append(fnaId).append('\'');
        sb.append(", needs='").append(needs).append('\'');
        sb.append(", groupedBy='").append(groupedBy).append('\'');
        sb.append(", levels='").append(levels).append('\'');
        sb.append(", remark='").append(remark).append('\'');
        sb.append('}');
        return sb.toString();
    }
}

