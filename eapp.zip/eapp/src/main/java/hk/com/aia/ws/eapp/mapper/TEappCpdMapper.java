package hk.com.aia.ws.eapp.mapper;

import hk.com.aia.ws.eapp.model.db.magnum.ipos.TEappCpd;
import hk.com.aia.ws.eapp.model.request.ipos.TEappCpdDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper
public interface TEappCpdMapper {

    TEappCpdMapper MAPPER = Mappers.getMapper(TEappCpdMapper.class);

    @Mappings({
            @Mapping(target = "createdDateTime", ignore = true),
            @Mapping(target = "lastUpdateDateTime", ignore = true)})
    List<TEappCpd> mapToTEappCpdList(List<TEappCpdDto> tEappCpdDto);
}
