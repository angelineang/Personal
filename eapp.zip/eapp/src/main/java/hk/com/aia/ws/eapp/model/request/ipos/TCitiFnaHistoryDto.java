package hk.com.aia.ws.eapp.model.request.ipos;

import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.annotation.DateTimeIntValidation;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@ApiModel(value = "T_CITIFNAHISTORY Model")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TCitiFnaHistoryDto {

    @ApiModelProperty(value = "fna History Id", required = true)
    @JsonProperty("fna_history_id")
    @Size(max = 60)
    @NotBlank
    private String fnaHistoryId;

    @JsonProperty("agent_code")
    @Size(max = 10)
    private String agentCode;

    @JsonProperty("access_code")
    @Size(max = 10)
    private String accessCode;

    @JsonProperty("alias")
    @Size(max = 30)
    private String alias;

    @JsonProperty("contact_id")
    @Size(max = 60)
    private String contactId;

    @JsonProperty("fna_id")
    @Size(max = 60)
    private String fnaId;

    @JsonProperty("last_name_en")
    @Size(max = 100)
    private String lastNameEn;

    @JsonProperty("first_name_en")
    @Size(max = 45)
    private String firstNameEn;

    @ApiModelProperty(value="dob yyyyMMdd",example="20201231")
    @DateTimeIntValidation(format = "yyyyMMdd")
    @JsonProperty("dob")
    private Integer dob;

    @JsonProperty("age")
    private Integer age;

    @JsonProperty("gender")
    @Size(max = 1)
    private String gender;

    @JsonProperty("smoker")
    private Integer smoker;

    @JsonProperty("nationality_code")
    @Size(max = 2)
    private String nationalityCode;

    @JsonProperty("other_nationality")
    @Size(max = 50)
    private String otherNationality;

    @JsonProperty("contact_type")
    @Size(max = 1)
    private String contactType;

    @JsonProperty("id_type")
    @Size(max = 18)
    private String idType;

    @JsonProperty("id_number")
    @Size(max = 20)
    private String idNumber;

    @ApiModelProperty(value="id expiry date yyyyMMdd",example="20201231")
    @JsonProperty("id_expiry_date")
    @DateTimeIntValidation(format = "yyyyMMdd")
    private Integer idExpiryDate;

    @JsonProperty("passport_number")
    @Size(max = 20)
    private String passportNumber;

    @ApiModelProperty(value="passport expiry date yyyyMMdd",example="20201231")
    @JsonProperty("passport_expiry_date")
    @DateTimeIntValidation(format = "yyyyMMdd")
    private Integer passportExpiryDate;

    @JsonProperty("occupation_code")
    @Size(max = 60)
    private String occupationCode;

    @JsonProperty("industry_code")
    @Size(max = 60)
    private String industryCode;

    @JsonProperty("marital_status")
    @Size(max = 8)
    private String maritalStatus;

    @JsonProperty("mobile")
    @Size(max = 20)
    private String mobile;

    @JsonProperty("office_tel")
    @Size(max = 20)
    private String officeTel;

    @JsonProperty("home_tel")
    @Size(max = 20)
    private String homeTel;

    @JsonProperty("email_address")
    @Size(max = 100)
    private String emailAddress;

    @JsonProperty("correspondence_address")
    @Size(max = 100)
    private String correspondenceAddress;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TCitiFnaHistoryDto{");
        sb.append("fnaHistoryId='").append(fnaHistoryId).append('\'');
        sb.append(", agentCode='").append(agentCode).append('\'');
        sb.append(", accessCode='").append(accessCode).append('\'');
        sb.append(", alias='").append(alias).append('\'');
        sb.append(", contactId='").append(contactId).append('\'');
        sb.append(", fnaId='").append(fnaId).append('\'');
        sb.append(", lastNameEn='").append(ConversionHandler.mask(lastNameEn)).append('\'');
        sb.append(", firstNameEn='").append(ConversionHandler.mask(firstNameEn)).append('\'');
        sb.append(", dob=").append(ConversionHandler.mask(dob));
        sb.append(", age=").append(age);
        sb.append(", gender='").append(gender).append('\'');
        sb.append(", smoker=").append(smoker);
        sb.append(", nationalityCode='").append(nationalityCode).append('\'');
        sb.append(", otherNationality='").append(otherNationality).append('\'');
        sb.append(", contactType='").append(contactType).append('\'');
        sb.append(", idType='").append(idType).append('\'');
        sb.append(", idNumber='").append(ConversionHandler.mask(idNumber)).append('\'');
        sb.append(", idExpiryDate=").append(idExpiryDate);
        sb.append(", passportNumber='").append(ConversionHandler.mask(passportNumber)).append('\'');
        sb.append(", passportExpiryDate=").append(passportExpiryDate);
        sb.append(", occupationCode='").append(occupationCode).append('\'');
        sb.append(", industryCode='").append(industryCode).append('\'');
        sb.append(", maritalStatus='").append(maritalStatus).append('\'');
        sb.append(", mobile='").append(ConversionHandler.mask(mobile)).append('\'');
        sb.append(", officeTel='").append(ConversionHandler.mask(officeTel)).append('\'');
        sb.append(", homeTel='").append(ConversionHandler.mask(homeTel)).append('\'');
        sb.append(", emailAddress='").append(ConversionHandler.mask(emailAddress)).append('\'');
        sb.append(", correspondenceAddress='").append(correspondenceAddress).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
