package hk.com.aia.ws.eapp.model.request.calculator;

import com.fasterxml.jackson.annotation.JsonProperty;

import hk.com.aia.ws.eapp.annotation.AllowedValuesValidation;
import hk.com.aia.ws.eapp.model.base.Payload;
import hk.com.aia.ws.eapp.model.base.calculator.LoginUser;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

@ApiModel(value = "Cal Suitability Request Model")
@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class CalSuitabilityRequest extends Payload {

    @JsonProperty("top_up_type_bn")
    @AllowedValuesValidation(values = {"R", "L" })
    private String topUpTypeBN;

    @JsonProperty("investment_amount_bn")
    @Pattern(regexp = "^([0-9]+\\.?[0-9]*|\\.[0-9]+)$")
    private String investmentAmountBN;

    @JsonProperty("payment_mode_bn")
    @AllowedValuesValidation(values = {"1", "2","4","12"})
    private String paymentModeBN;

    @JsonProperty("expected_timeframe_bn")
    @Pattern(regexp = "^[0-9]*$")
    private String expectedTimeFrameBN;

    @JsonProperty("upfront_charge_bn")
    @Pattern(regexp = "^([0-9]+\\.?[0-9]*|\\.[0-9]+)$")
    private String upfrontChargeBN;

    @JsonProperty("net_ror_bn")
    @Pattern(regexp = "^([0-9]+\\.?[0-9]*|\\.[0-9]+)$")
    private String netRorBN;

    @JsonProperty("top_up_type_bb")
    @AllowedValuesValidation(values = {"R", "L" })
    private String topUpTypeBB;

    @JsonProperty("investment_amount_bb")
    @Pattern(regexp = "^([0-9]+\\.?[0-9]*|\\.[0-9]+)$")
    private String investmentAmountBB;

    /*1 is annually
     * 2 is half year
     * 4 is quarterly
     * 12 is monthly
    */
    @JsonProperty("payment_mode_bb")
    @AllowedValuesValidation(values = {"1", "2","4","12"})
    private String paymentModeBB;

    @JsonProperty("expected_timeframe_bb")
    @Pattern(regexp = "^[0-9]*$")
    private String expectedTimeFrameBB;

    @JsonProperty("upfront_charge_bb")
    @Pattern(regexp = "^([0-9]+\\.?[0-9]*|\\.[0-9]+)$")
    private String upfrontChargeBB;

    @JsonProperty("net_ror_bb")
    @Pattern(regexp = "^([0-9]+\\.?[0-9]*|\\.[0-9]+)$")
    private String netRorBB;

    @JsonProperty("suit_type")
    @AllowedValuesValidation(values = {"BN", "BB"})
    private String suitType;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("CalSuitabilityRequest{");
        sb.append(", topUpTypeBN='").append(topUpTypeBN).append('\'');
        sb.append(", investmentAmountBN='").append(investmentAmountBN).append('\'');
        sb.append(", paymentModeBN='").append(paymentModeBN).append('\'');
        sb.append(", expectedTimeFrameBN='").append(expectedTimeFrameBN).append('\'');
        sb.append(", upfrontChargeBN='").append(upfrontChargeBN).append('\'');
        sb.append(", netRorBN='").append(netRorBN).append('\'');
        sb.append(", topUpTypeBB='").append(topUpTypeBB).append('\'');
        sb.append(", investmentAmountBB='").append(investmentAmountBB).append('\'');
        sb.append(", paymentModeBB='").append(paymentModeBB).append('\'');
        sb.append(", expectedTimeFrameBB='").append(expectedTimeFrameBB).append('\'');
        sb.append(", upfrontChargeBB='").append(upfrontChargeBB).append('\'');
        sb.append(", netRorBB='").append(netRorBB).append('\'');
        sb.append(", suitType='").append(suitType).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
