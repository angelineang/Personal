package hk.com.aia.ws.eapp.model.db.magnum.iverify;

import hk.com.aia.ws.eapp.model.db.magnum.ipos.idclass.TPrcDocId;
import lombok.Data;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@Table(name = "T_PRC_DOC")
@IdClass(TPrcDocId.class)
@EntityListeners(AuditingEntityListener.class)
public class TPrcDoc {

    @Column(name = "IVERIFYID", length = 60)
    @Id
    private String iverifyId;

    @Column(name = "CLIENTID", length = 20)
    @Id
    private String clientID;

    @Column(name = "DOCSEQ")
    @Id
    private Integer docSeq;

    @Column(name = "DOCID", length = 8)
    @Id
    private String docId;

    @Column(name = "DOCTYPE", length = 10)
    private String docType;

    @Column(name = "FILENAME", length = 100)
    private String filename;

    @Column(name = "PAGENO")
    private Integer pageNo;

    @Column(name = "SIGNSTATUS", length = 1)
    private String signStatus;

    @Column(name = "SIGNAT", length = 20)
    private String signAt;

    @Column(name = "SIGNDATE", length = 50)
    private String signDate;

    @Column(name = "CREATEDBY", length = 40, updatable = false)
    @CreatedBy
    private String createdBy;

    @Column(name = "UPDATEDBY", length = 40)
    @LastModifiedBy
    private String updatedBy;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "LASTUPDATEDATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    @LastModifiedDate
    private Date lastUpdateDateTime;

    @Column(name = "DOCCHECKSTATUS")
    private Integer docCheckStatus;

    @Column(name = "REJECTREASON", length = 1)
    private String rejectReason;

    @Column(name = "DOC_SRC_APP", length = 8)
    private String docSrcApp;

    @Column(name = "OCR_DONE", length = 4)
    private String ocrDone;

    @Column(name = "OCR_SUCCESS", length = 4)
    private String ocrSuccess;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TPrcDoc{");
        sb.append("iverifyId='").append(iverifyId).append('\'');
        sb.append(", clientID='").append(clientID).append('\'');
        sb.append(", docSeq=").append(docSeq);
        sb.append(", docId='").append(docId).append('\'');
        sb.append(", docType='").append(docType).append('\'');
        sb.append(", filename='").append(filename).append('\'');
        sb.append(", pageNo=").append(pageNo);
        sb.append(", signStatus='").append(signStatus).append('\'');
        sb.append(", signAt='").append(signAt).append('\'');
        sb.append(", signDate='").append(signDate).append('\'');
        sb.append(", createdBy='").append(createdBy).append('\'');
        sb.append(", updatedBy='").append(updatedBy).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", lastUpdateDateTime=").append(lastUpdateDateTime);
        sb.append(", docCheckStatus=").append(docCheckStatus);
        sb.append(", rejectReason='").append(rejectReason).append('\'');
        sb.append(", docSrcApp='").append(docSrcApp).append('\'');
        sb.append(", ocrDone='").append(ocrDone).append('\'');
        sb.append(", ocrSuccess='").append(ocrSuccess).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
