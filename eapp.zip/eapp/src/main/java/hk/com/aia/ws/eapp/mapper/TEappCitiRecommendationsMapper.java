package hk.com.aia.ws.eapp.mapper;

import hk.com.aia.ws.eapp.model.db.magnum.ipos.TEapp;
import hk.com.aia.ws.eapp.model.db.magnum.ipos.TEappCitiRecommendations;
import hk.com.aia.ws.eapp.model.request.ipos.TEappCitiRecommendationsDto;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper
public interface TEappCitiRecommendationsMapper {

    TEappCitiRecommendationsMapper MAPPER = Mappers.getMapper(TEappCitiRecommendationsMapper.class);

    List<TEappCitiRecommendations> mapToTEappCitiRecommendationsList(List<TEappCitiRecommendationsDto> tEappCitiRecommendationsDto);
}
