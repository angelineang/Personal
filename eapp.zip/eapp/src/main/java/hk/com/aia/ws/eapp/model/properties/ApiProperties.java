package hk.com.aia.ws.eapp.model.properties;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class ApiProperties {

    private String groupName;
    private String hostName;
    private String version;
    private String title;
    private String description;
    private String termsOfServiceUrl;
    private String license;
    private String licenseUrl;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("ApiProperties{");
        sb.append("groupName='").append(groupName).append('\'');
        sb.append(", hostName='").append(hostName).append('\'');
        sb.append(", version='").append(version).append('\'');
        sb.append(", title='").append(title).append('\'');
        sb.append(", description='").append(description).append('\'');
        sb.append(", termsOfServiceUrl='").append(termsOfServiceUrl).append('\'');
        sb.append(", license='").append(license).append('\'');
        sb.append(", licenseUrl='").append(licenseUrl).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
