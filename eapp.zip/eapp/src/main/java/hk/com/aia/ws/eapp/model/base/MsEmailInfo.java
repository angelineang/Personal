package hk.com.aia.ws.eapp.model.base;

/*
// Check if Updated
// Store proc and Table obtained on the 13th of October 2020 from 'husyb12' server,
// Store proc - po_ms_get_email_info
// Table - temail_list
 */

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MsEmailInfo {

    private String jobId;
    private String refNo;
    private String appName;
    private String scriptName;
    private String recipientTo1;
    private String recipientTo2;
    private String recipientTo3;
    private String recipientCc1;
    private String recipientCc2;
    private String subject;
    private String contextTxt1;
    private String contextTxt2;
    private String contentFile;
    private String backupFlag;
    private String remarks;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("MsEmailInfo{");
        sb.append("jobId='").append(jobId).append('\'');
        sb.append(", refNo='").append(refNo).append('\'');
        sb.append(", appName='").append(appName).append('\'');
        sb.append(", scriptName='").append(scriptName).append('\'');
        sb.append(", recipientTo1='").append(recipientTo1).append('\'');
        sb.append(", recipientTo2='").append(recipientTo2).append('\'');
        sb.append(", recipientTo3='").append(recipientTo3).append('\'');
        sb.append(", recipientCc1='").append(recipientCc1).append('\'');
        sb.append(", recipientCc2='").append(recipientCc2).append('\'');
        sb.append(", subject='").append(subject).append('\'');
        sb.append(", contextTxt1='").append(contextTxt1).append('\'');
        sb.append(", contextTxt2='").append(contextTxt2).append('\'');
        sb.append(", contentFile='").append(contentFile).append('\'');
        sb.append(", backupFlag='").append(backupFlag).append('\'');
        sb.append(", remarks='").append(remarks).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
