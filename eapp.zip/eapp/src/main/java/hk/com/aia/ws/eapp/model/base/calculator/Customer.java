package hk.com.aia.ws.eapp.model.base.calculator;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class Customer {

    @JsonProperty("last_name")
    private String lastName;
    @JsonProperty("first_name")
    private String firstName;
    @JsonProperty("chinese_name")
    private String chineseName;
    @JsonProperty("name_format")
    private String nameFormat;
    @JsonProperty("sex")
    private String sex;
    @JsonProperty("dob")
    private String dob;
    @JsonProperty("martial_sts")
    private String martialSts;
    @JsonProperty("occ_code")
    private String occCode;
    @JsonProperty("phone_mobile")
    private String phoneMobile;
    @JsonProperty("phone_office")
    private String phoneOffice;
    @JsonProperty("phone_home")
    private String phoneHome;
    @JsonProperty("nationality")
    private String nationality;
    @JsonProperty("email_address")
    private String emailAddress;
    @JsonProperty("fax_no")
    private String faxNo;
    @JsonProperty("ssn")
    private String ssn;
    @JsonProperty("user_id")
    private String userId;
    @JsonProperty("id_type_1")
    private String idType1;
    @JsonProperty("id_no_1")
    private String idNo1;
    @JsonProperty("id_exp_1")
    private String idExp1;
    @JsonProperty("id_copy_1")
    private String idCopy1;
    @JsonProperty("id_type_2")
    private String idType2;
    @JsonProperty("id_no_2")
    private String idNo2;
    @JsonProperty("id_exp_2")
    private String idExp2;
    @JsonProperty("id_copy_2")
    private String idCopy2;
    @JsonProperty("role")
    private String role;
    @JsonProperty("name_no")
    private String nameNo;
    @JsonProperty("corr_address_type")
    private String corrAddressType;
    @JsonProperty("corr_address_lang")
    private String corrAddressLang;
    @JsonProperty("corr_addr_1")
    private String corrAddr1;
    @JsonProperty("corr_addr_2")
    private String corrAddr2;
    @JsonProperty("corr_addr_3")
    private String corrAddr3;
    @JsonProperty("corr_addr_4")
    private String corrAddr4;
    @JsonProperty("corr_addr_5")
    private String corrAddr5;
    @JsonProperty("corr_zip")
    private String corrZip;
    @JsonProperty("corr_country_code")
    private String corrCountryCode;
    @JsonProperty("corr_country")
    private String corrCountry;
    @JsonProperty("bus_address_type")
    private String busAddressType;
    @JsonProperty("bus_address_lang")
    private String busAddressLang;
    @JsonProperty("bus_addr_1")
    private String busAddr1;
    @JsonProperty("bus_addr_2")
    private String busAddr2;
    @JsonProperty("bus_addr_3")
    private String busAddr3;
    @JsonProperty("bus_addr_4")
    private String busAddr4;
    @JsonProperty("bus_addr_5")
    private String busAddr5;
    @JsonProperty("bus_zip")
    private String busZip;
    @JsonProperty("bus_country_code")
    private String busCountryCode;
    @JsonProperty("bus_country")
    private String busCountry;
    @JsonProperty("res_address_type")
    private String resAddressType;
    @JsonProperty("res_address_lang")
    private String resAddressLang;
    @JsonProperty("res_addr_1")
    private String resAddr1;
    @JsonProperty("res_addr_2")
    private String resAddr2;
    @JsonProperty("res_addr_3")
    private String resAddr3;
    @JsonProperty("res_addr_4")
    private String resAddr4;
    @JsonProperty("res_addr_5")
    private String resAddr5;
    @JsonProperty("res_zip")
    private String resZip;
    @JsonProperty("res_country_code")
    private String resCountryCode;
    @JsonProperty("res_country")
    private String resCountry;
    @JsonProperty("perm_address_type")
    private String permAddressType;
    @JsonProperty("perm_address_lang")
    private String permAddressLang;
    @JsonProperty("perm_addr_1")
    private String permAddr1;
    @JsonProperty("perm_addr_2")
    private String permAddr2;
    @JsonProperty("perm_addr_3")
    private String permAddr3;
    @JsonProperty("perm_addr_4")
    private String permAddr4;
    @JsonProperty("perm_addr_5")
    private String permAddr5;
    @JsonProperty("perm_zip")
    private String permZip;
    @JsonProperty("perm_country_code")
    private String permCountryCode;
    @JsonProperty("perm_country")
    private String permCountry;

    //-> 002
    @JsonProperty("vital_ind")
    private String vitalInd;
    @JsonProperty("vital_agt_code_1")
    private String vitalAgtCode1;
    @JsonProperty("vital_agt_code_2")
    private String vitalAgtCode2;
    @JsonProperty("vital_agy_code_1")
    private String vitalAgyCode1;
    @JsonProperty("vital_agy_code_2")
    private String vitalAgyCode2;
    @JsonProperty("vital_id_type_1")
    private String vitalIdType1;
    @JsonProperty("vital_id_type_2")
    private String vitalIdType2;
    @JsonProperty("vital_opt_out")
    private String vitalOptOut;
    @JsonProperty("vital_app_date")
    private Date vitalAppDate;
    //<- 002

    //-> 003
    @JsonProperty("vital_display_country")
    private String vitalDisplayCountry;
    @JsonProperty("vital_disc_percent")
    private BigDecimal vitalDiscPercent;
    @JsonProperty("vital_disc_mth")
    private int vitalDiscMth;
    //<- 003

    //-> 004
    @JsonProperty("tel_oth_country_code")
    private String telOthCountryCode;
    @JsonProperty("tel_oth_area_code")
    private String telOthAreaCode;
    @JsonProperty("tel_oth_phone_other")
    private String telOthPhoneOther;
    @JsonProperty("corr_addr_country_name")
    private String corrAddrCountryName;
    @JsonProperty("bus_addr_country_name")
    private String busAddrCountryName;
    @JsonProperty("res_addr_country_name")
    private String resAddrCountryName;
    @JsonProperty("perm_addr_country_name")
    private String permAddrCountryName;
    //<- 004

    //-> 005
    @JsonProperty("v_tel")
    private String vTel;
    @JsonProperty("v_addr_1")
    private String vAddr1;
    @JsonProperty("v_addr_2")
    private String vAddr2;
    @JsonProperty("v_addr_3")
    private String vAddr3;
    @JsonProperty("v_addr_4")
    private String vAddr4;
    @JsonProperty("v_addr_5")
    private String vAddr5;
    @JsonProperty("v_country_code")
    private String vCountryCode;
    //<- 005

    //-> 006
    @JsonProperty("tel_oth_phone_type")
    private String telOthPhoneType;
    @JsonProperty("tel_oth_phone_type_2")
    private String telOthPhoneType2;
    @JsonProperty("tel_oth_country_code_2")
    private String telOthCountryCode2;
    @JsonProperty("tel_other_area_code_2")
    private String telOthAreaCode2;
    @JsonProperty("tel_oth_phone_other_2")
    private String telOthPhoneOther2;
    @JsonProperty("tel_oth_phone_type_3")
    private String telOthPhoneType3;
    @JsonProperty("tel_oth_country_code_3")
    private String telOthCountryCode3;
    @JsonProperty("tel_oth_area_code_3")
    private String telOthAreaCode3;
    @JsonProperty("tel_oth_phone_other_3")
    private String telOthPhoneOther3;
    @JsonProperty("tel_oth_phone_type_4")
    private String telOthPhoneType4;
    @JsonProperty("tel_oth_country_code_4")
    private String telOthCountryCode4;
    @JsonProperty("tel_oth_area_code_4")
    private String telOthAreaCode4;
    @JsonProperty("tel_oth_phone_other_4")
    private String telOthPhoneOther4;
    @JsonProperty("tel_oth_phone_type_5")
    private String telOthPhoneType5;
    @JsonProperty("tel_oth_country_code_5")
    private String telOthCountryCode5;
    @JsonProperty("tel_oth_area_code_5")
    private String telOthAreaCode5;
    @JsonProperty("tel_oth_phone_other_5")
    private String telOthPhoneOther5;
    //<- 006

    //-> 007
    @JsonProperty("v_crs_country")
    private String vCrsCountry;
    //<- 007

    // alphaSearch WS groupName
    @JsonProperty("group_name")
    private String groupName;
    @JsonProperty("score")
    private String score;

}
