package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import javax.validation.constraints.Size;
import java.util.Date;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "T_ILASFNADECLARATION")
public class TIlasFnaDeclaration {

    @Column(name = "FNADECLARATIONID", length = 60)
    @Id
    private String fnaDeclarationId;

    @Column(name = "EAPPID", length = 60)
    private String eappId;

    @Column(name = "ANSWERA", length = 1)
    private String answerA;

    @Column(name = "ANSWERB", length = 1)
    private String answerB;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "OTHERINFOA", length = 800)
    private String otherInfoA;

    @Column(name = "OTHERINFOB", length = 800)
    private String otherInfoB;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TIlasFnaDeclaration{");
        sb.append("fnaDeclarationId='").append(fnaDeclarationId).append('\'');
        sb.append(", eappId='").append(eappId).append('\'');
        sb.append(", answerA='").append(answerA).append('\'');
        sb.append(", answerB='").append(answerB).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", otherInfoA='").append(otherInfoA).append('\'');
        sb.append(", otherInfoB='").append(otherInfoB).append('\'');
        sb.append('}');
        return sb.toString();
    }
}