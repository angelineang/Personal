package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.annotation.AllowedValuesValidation;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.math.BigDecimal;

@ApiModel(value = "Dduw Model")
@Data
public class Dduw {

    @ApiModelProperty(value = "Score ID", example = "CTHKS01T01", required = true)
    @JsonProperty("score_id")
    @NotBlank
    @Size(max = 15)
    private String scoreId;

    @ApiModelProperty(value = "Numeric value only, up to a precision of 3 decimal places", example = "0.126", required = true)
    @JsonProperty("score_value")
    @Digits(integer = 3, fraction = 3)
    private BigDecimal scoreValue;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Dduw{");
        sb.append("scoreId='").append(scoreId).append('\'');
        sb.append(", scoreValue=").append(scoreValue);
        sb.append('}');
        return sb.toString();
    }
}
