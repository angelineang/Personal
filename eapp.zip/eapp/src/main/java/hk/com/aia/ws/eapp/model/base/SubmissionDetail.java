package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.math.BigDecimal;

@ApiModel(value = "Submission details Model")
@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class SubmissionDetail extends Payload {

    // Size max and regex pattern determined by Stored procedure - db_magnum..po_ipos_chk_pol

    @ApiModelProperty(value = "company code")
    @JsonProperty("comp_no")
    @NotBlank
    @Size(min = 3, max = 3)
    private String compNo;

    @ApiModelProperty(value = "agent code")
    @JsonProperty("agent_code")
    @NotBlank
    @Size(max = 5)
    private String agentCode;

    @ApiModelProperty(value = "reference number")
    @JsonProperty("ref_no")
    private String refNo;

    @ApiModelProperty(value = "plan short name")
    @JsonProperty("plan_short_name")
    @Size(max = 15)
    private String planShortName;

    @ApiModelProperty(value = "sum assured")
    @JsonProperty("sum_assured")
//    @Pattern(regexp = "^[0-9]{1,15}(?:\\.[0-9]{1,2})?$")
    @Digits(integer = 15, fraction = 2)
    private BigDecimal sumAssured;

    @ApiModelProperty(value = "policy number")
    @JsonProperty("policy_no")
    @NotBlank
    private String policyNo;

    @ApiModelProperty(value = "insured name")
    @JsonProperty("insured_name")
    private String insuredName;

    @ApiModelProperty(value = "submission details")
    @JsonProperty("cs_submission")
    @Valid
    private CsSubmission csSubmission;

    @ApiModelProperty(value = "promotion")
    @JsonProperty("ui_tui_pol_promotion")
    @Valid
    private PolPromotion polPromotion;


    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("SubmissionDetail{");
        sb.append("compNo='").append(compNo).append('\'');
        sb.append(", agentCode='").append(agentCode).append('\'');
        sb.append(", refNo='").append(refNo).append('\'');
        sb.append(", planShortName='").append(planShortName).append('\'');
        sb.append(", sumAssured=").append(sumAssured);
        sb.append(", policyNo='").append(ConversionHandler.mask(policyNo)).append('\'');
        sb.append(", insuredName='").append(ConversionHandler.mask(insuredName)).append('\'');
        sb.append(", csSubmission=").append(csSubmission);
        sb.append(", polPromotion=").append(polPromotion);
        sb.append('}');
        return sb.toString();
    }
}


