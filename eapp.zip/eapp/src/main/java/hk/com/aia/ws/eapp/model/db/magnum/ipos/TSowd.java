package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@Table(name = "T_SOWD")
@EntityListeners(AuditingEntityListener.class)
public class TSowd {

    @Column(name = "SOWDID", length = 60)
    @Id
    private String sowdId;

    @Column(name = "EAPPID", length = 60)
    private String eappId;

    @Column(name = "q1Answer", length = 5)
    private String q1Answer;

    @Column(name = "q1AnswerOther", length = 100)
    private String q1AnswerOther;

    @Column(name = "q2AIncome", length = 60)
    private String q2AIncome;

    @Column(name = "q2BIncome", length = 60)
    private String q2BIncome;

    @Column(name = "q2BSelect", length = 60)
    private String q2BSelect;

    @Column(name = "q2BSelectOther", length = 100)
    private String q2BSelectOther;

    @Column(name = "q3BLiquid", length = 60)
    private String q3BLiquid;

    @Column(name = "q3BSelect", length = 60)
    private String q3BSelect;

    @Column(name = "q3BSelectOther", length = 100)
    private String q3BSelectOther;

    @Column(name = "q4Average", length = 60)
    private String q4Average;

    @Column(name = "q4Approximate", length = 60)
    private String q4Approximate;

    @Column(name = "q4Percentage", length = 10)
    private String q4Percentage;

    @Column(name = "employerName", length = 300)
    private String employerName;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TSowd{");
        sb.append("sowdId='").append(sowdId).append('\'');
        sb.append(", eappId='").append(eappId).append('\'');
        sb.append(", q1Answer='").append(q1Answer).append('\'');
        sb.append(", q1AnswerOther='").append(q1AnswerOther).append('\'');
        sb.append(", q2AIncome='").append(q2AIncome).append('\'');
        sb.append(", q2BIncome='").append(q2BIncome).append('\'');
        sb.append(", q2BSelect='").append(q2BSelect).append('\'');
        sb.append(", q2BSelectOther='").append(q2BSelectOther).append('\'');
        sb.append(", q3BLiquid='").append(q3BLiquid).append('\'');
        sb.append(", q3BSelect='").append(q3BSelect).append('\'');
        sb.append(", q3BSelectOther='").append(q3BSelectOther).append('\'');
        sb.append(", q4Average='").append(q4Average).append('\'');
        sb.append(", q4Approximate='").append(q4Approximate).append('\'');
        sb.append(", q4Percentage='").append(q4Percentage).append('\'');
        sb.append(", employerName='").append(employerName).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append('}');
        return sb.toString();
    }
}
