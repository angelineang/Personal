package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import hk.com.aia.ws.eapp.model.db.magnum.ipos.idclass.UiUipendBewsId;
import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Data
@Entity
@Table(name = "ui_uipend_bews")
@IdClass(UiUipendBewsId.class)
@EntityListeners(AuditingEntityListener.class)
public class UiUipendBews {

    @Id
    @Column(name = "policy_no")
    private String policyNo;

    @Id
    @Column(name = "request_no")
    private String requestNo;

    @Id
    @Column(name = "lob")
    private String lob;

    @Id
    @Column(name = "pend_id")
    private String pendId;

    @Column(name = "pend_code")
    private String pend_code;

    @Column(name = "ref_pend_id")
    private String refPendId;

    @Column(name = "ref_comment_id")
    private String refCommentId;

    @Column(name = "status")
    private String status;

    @Column(name = "memo_id")
    private Integer memoId;

    @Column(name = "lang_code")
    private String langCode;

    @Column(name = "pend_msg")
    private String pendMsg;

    @Column(name = "pend_remarks")
    private String pend_remarks;

    @Column(name = "resolved_msg")
    private String resolvedMsg;

    @Column(name = "resolved_userid")
    private String resolvedUserid;

    @Column(name = "resolved_date")
    private Date resolvedDate;

    @Column(name = "create_userid")
    private String createUserid;

    @Column(name = "create_date")
    @CreatedDate
    private Date createDate;

    @Column(name = "update_userid")
    private String updateUserid;

    @Column(name = "update_date")
    private Date updateDate;

    @Column(name = "pend_type")
    private String pendType;

    @Column(name = "pend_source")
    private String pendSource;

    @Column(name = "pend_category")
    private String pendCategory;

    @Column(name = "output_type")
    private String outputType;

    @Column(name = "stp_ind")
    private String stpInd;

    @Column(name = "resolved_code")
    private String resolvedCode;

    @Column(name = "pend_date")
    private Date pendDate;

    @Column(name = "screen_id")
    private String screenId;

    @Column(name = "seq_no")
    private Integer seqNo;

    @Column(name = "pending_count")
    private Integer pendingCount;

    @Column(name = "group_indicator")
    private String groupIndicator;

    @Column(name = "ipos_ind")
    private String iposInd;

    @Column(name = "pend_msg_e")
    private String pendMsgE;

    @Column(name = "pend_msg_s")
    private String pendMsgS;

    @Column(name = "pend_msg_t")
    private String pendMsgT;

    @Column(name = "src_channel")
    private String srcChannel;

    @Column(name = "sort_val")
    private String sortValue;

    @Column(name = "request_date")
    private Date requestDate;

    @Column(name = "solved")
    private String solved;

    @Column(name = "draft_ind")
    private String draftInd;

    @Column(name = "deadline_date")
    private Date deadlineDate;

    @Column(name = "resolved_msg_t")
    private String resolvedMsgT;

    @Column(name = "resolved_msg_s")
    private String resolvedMsgS;

    @Column(name = "source")
    private String source;

    @Column(name = "first_issue_date")
    private Date firstIssueDate;

    @Column(name = "first_issue_flag")
    private String firstIssueFlag;

    @Column(name = "second_issue_date")
    private Date secondIssueDate;

    @Column(name="pend_info")
    private String pendInfo;

}
