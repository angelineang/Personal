package hk.com.aia.ws.eapp.configuration;

import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import com.microsoft.aad.adal4j.AuthenticationContext;
import com.microsoft.aad.adal4j.AuthenticationResult;
import com.microsoft.aad.adal4j.ClientCredential;
import com.microsoft.azure.keyvault.core.IKey;
import com.microsoft.azure.keyvault.extensions.CachingKeyResolver;
import com.microsoft.azure.storage.CloudStorageAccount;
import com.microsoft.azure.storage.StorageCredentialsToken;
import com.microsoft.azure.storage.StorageException;
import com.microsoft.azure.storage.blob.CloudBlobContainer;

import hk.com.aia.ws.eapp.adapter.AzureBlobAdapter;
import hk.com.aia.ws.eapp.adapter.AzureBlobAdapterNoKey;
import hk.com.aia.ws.eapp.model.properties.AzureStorageProperties;
import lombok.extern.slf4j.Slf4j;

@Configuration
@Slf4j
public class AzureBlobConfiguration {

	private static ExecutorService executorService= Executors.newFixedThreadPool(30);


    @ConfigurationProperties(prefix = "azure.storage.document")
    @Bean("documentBlobStorage")
    public AzureStorageProperties ingressStorageProperties() {
        return new AzureStorageProperties();
    }

    @Bean("documentClientCredential")
    public ClientCredential ingressClientCredential(@Qualifier("documentBlobStorage") AzureStorageProperties azureStorageProperties) {
        return new ClientCredential(azureStorageProperties.getClientId(), azureStorageProperties.getClientSecret());
    }


    @ConfigurationProperties(prefix = "azure.storage.egress")
    @Bean("egressBlobStorage")
    public AzureStorageProperties egressStorageProperties() {
        return new AzureStorageProperties();
    }


    @Bean("egressClientCredential")
    public ClientCredential egressClientCredential(@Qualifier("egressBlobStorage") AzureStorageProperties azureStorageProperties) {
        return new ClientCredential(azureStorageProperties.getClientId(), azureStorageProperties.getClientSecret());
    }

    @ConfigurationProperties(prefix = "azure.storage.eform")
    @Bean("eFormBlobStorage")
    public AzureStorageProperties eFormStorageProperties() {
        return new AzureStorageProperties();
    }


    @Bean("eFormClientCredential")
    public ClientCredential eFormClientCredential(@Qualifier("eFormBlobStorage") AzureStorageProperties azureStorageProperties) {
        return new ClientCredential(azureStorageProperties.getClientId(), azureStorageProperties.getClientSecret());
    }

    @ConfigurationProperties(prefix = "azure.storage.pgs")
    @Bean("pgsBlobStorage")
    public AzureStorageProperties pgsStorageProperties() {
        return new AzureStorageProperties();
    }


    @Bean("pgsClientCredential")
    public ClientCredential pgsClientCredential(@Qualifier("pgsBlobStorage") AzureStorageProperties azureStorageProperties) {
        return new ClientCredential(azureStorageProperties.getClientId(), azureStorageProperties.getClientSecret());
    }

    @ConfigurationProperties(prefix = "azure.storage.eappdocument")
    @Bean("eappDocumentBlobStorage")
    public AzureStorageProperties eappDocumentStorageProperties() {
        return new AzureStorageProperties();
    }


    @Bean("eappDocumentClientCredential")
    public ClientCredential eappDocumentClientCredential(@Qualifier("eappDocumentBlobStorage") AzureStorageProperties azureStorageProperties) {
        return new ClientCredential(azureStorageProperties.getClientId(), azureStorageProperties.getClientSecret());
    }

    @Bean("documentStorageAccount")
    @Scope("prototype")
    public CloudStorageAccount ingressStorageAccount(@Qualifier("documentBlobStorage") AzureStorageProperties azureStorageProperties,
                                                     @Qualifier("documentClientCredential") ClientCredential clientCredential)
            throws URISyntaxException, MalformedURLException, ExecutionException, InterruptedException {

        final String url = azureStorageProperties.getAdUri()
                + "/" + azureStorageProperties.getTenantId();

        AuthenticationContext context = new AuthenticationContext(url, false, executorService);
        Future<AuthenticationResult> tokenFuture = context.acquireToken(azureStorageProperties.getBlobResource(), clientCredential, null);
        String token = tokenFuture.get().getAccessToken();
        StorageCredentialsToken credentialsToken = new StorageCredentialsToken(azureStorageProperties.getBlobAccountName(), token);
        return new CloudStorageAccount(credentialsToken, true);
    }

    @Bean("egressStorageAccount")
    @Scope("prototype")
    public CloudStorageAccount egressStorageAccount(@Qualifier("egressBlobStorage") AzureStorageProperties azureStorageProperties,
                                                    @Qualifier("egressClientCredential") ClientCredential clientCredential)
            throws URISyntaxException, MalformedURLException, ExecutionException, InterruptedException {
        final String url = azureStorageProperties.getAdUri()
                + "/" + azureStorageProperties.getTenantId();

        AuthenticationContext context = new AuthenticationContext(url, false, executorService);
        Future<AuthenticationResult> tokenFuture = context.acquireToken(azureStorageProperties.getBlobResource(), clientCredential, null);
        String token = tokenFuture.get().getAccessToken();
        StorageCredentialsToken credentialsToken = new StorageCredentialsToken(azureStorageProperties.getBlobAccountName(), token);
        return new CloudStorageAccount(credentialsToken, true);
    }

    @Bean("eFormStorageAccount")
    @Scope("prototype")
    public CloudStorageAccount eFormStorageAccount(@Qualifier("eFormBlobStorage") AzureStorageProperties azureStorageProperties,
                                                    @Qualifier("eFormClientCredential") ClientCredential clientCredential)
            throws URISyntaxException, MalformedURLException, ExecutionException, InterruptedException {
        final String url = azureStorageProperties.getAdUri()
                + "/" + azureStorageProperties.getTenantId();

        AuthenticationContext context = new AuthenticationContext(url, false, executorService);
        Future<AuthenticationResult> tokenFuture = context.acquireToken(azureStorageProperties.getBlobResource(), clientCredential, null);
        String token = tokenFuture.get().getAccessToken();
        StorageCredentialsToken credentialsToken = new StorageCredentialsToken(azureStorageProperties.getBlobAccountName(), token);
        return new CloudStorageAccount(credentialsToken, true);
    }

    @Bean("pgsStorageAccount")
    @Scope("prototype")
    public CloudStorageAccount pgsStorageAccount(@Qualifier("pgsBlobStorage") AzureStorageProperties azureStorageProperties,
                                                    @Qualifier("pgsClientCredential") ClientCredential clientCredential)
            throws URISyntaxException, MalformedURLException, ExecutionException, InterruptedException {
        final String url = azureStorageProperties.getAdUri()
                + "/" + azureStorageProperties.getTenantId();

        AuthenticationContext context = new AuthenticationContext(url, false, executorService);
        Future<AuthenticationResult> tokenFuture = context.acquireToken(azureStorageProperties.getBlobResource(), clientCredential, null);
        String token = tokenFuture.get().getAccessToken();
        StorageCredentialsToken credentialsToken = new StorageCredentialsToken(azureStorageProperties.getBlobAccountName(), token);
        return new CloudStorageAccount(credentialsToken, true);
    }

    @Bean("eappDocumentStorageAccount")
    @Scope("prototype")
    public CloudStorageAccount eappDocumentStorageAccount(@Qualifier("eappDocumentBlobStorage") AzureStorageProperties azureStorageProperties,
                                                    @Qualifier("eappDocumentClientCredential") ClientCredential clientCredential)
            throws URISyntaxException, MalformedURLException, ExecutionException, InterruptedException {
        final String url = azureStorageProperties.getAdUri()
                + "/" + azureStorageProperties.getTenantId();

        AuthenticationContext context = new AuthenticationContext(url, false, executorService);
        Future<AuthenticationResult> tokenFuture = context.acquireToken(azureStorageProperties.getBlobResource(), clientCredential, null);
        String token = tokenFuture.get().getAccessToken();
        StorageCredentialsToken credentialsToken = new StorageCredentialsToken(azureStorageProperties.getBlobAccountName(), token);
        return new CloudStorageAccount(credentialsToken, true);
    }


    @Bean("documentBlobAdapter")
    @Scope("prototype")
    public AzureBlobAdapter documentBlobAdapter(@Qualifier("documentStorageAccount") CloudStorageAccount cloudStorageAccount,
                                                @Qualifier("documentRSAKey") IKey rsaKey,
                                                @Qualifier("documentKeyResolver") CachingKeyResolver cachingKeyResolver,
                                                @Qualifier("documentBlobStorage") AzureStorageProperties azureStorageProperties)
            throws URISyntaxException, StorageException {

        return getAzureBlobAdapter(cloudStorageAccount, rsaKey, cachingKeyResolver, azureStorageProperties);
    }

    @Bean("egressBlobAdapter")
    @Scope("prototype")
    public AzureBlobAdapter egressBlobAdapter(@Qualifier("egressStorageAccount") CloudStorageAccount cloudStorageAccount,
                                                @Qualifier("egressRSAKey") IKey rsaKey,
                                                @Qualifier("egressKeyResolver") CachingKeyResolver cachingKeyResolver,
                                                @Qualifier("egressBlobStorage") AzureStorageProperties azureStorageProperties)
            throws URISyntaxException, StorageException {

        return getAzureBlobAdapter(cloudStorageAccount, rsaKey, cachingKeyResolver, azureStorageProperties);

    }

    @Bean("eFormBlobAdapter")
    @Scope("prototype")
    public AzureBlobAdapterNoKey eFormBlobAdapter(@Qualifier("eFormStorageAccount") CloudStorageAccount cloudStorageAccount,
                                              @Qualifier("eFormBlobStorage") AzureStorageProperties azureStorageProperties)
            throws URISyntaxException, StorageException {

        return getAzureBlobAdapterNoKey(cloudStorageAccount, azureStorageProperties);

    }

    @Bean("eappDocumentBlobAdapter")
    @Scope("prototype")
    public AzureBlobAdapter eappDocumentBlobAdapter(@Qualifier("eappDocumentStorageAccount") CloudStorageAccount cloudStorageAccount,
                                                    @Qualifier("eappDocumentRSAKey") IKey rsaKey,
                                                    @Qualifier("eappDocumentKeyResolver") CachingKeyResolver cachingKeyResolver,
                                                    @Qualifier("eappDocumentBlobStorage") AzureStorageProperties azureStorageProperties)
            throws URISyntaxException, StorageException {

        return getAzureBlobAdapter(cloudStorageAccount, rsaKey, cachingKeyResolver, azureStorageProperties);

    }

    @Bean("pgsBlobAdapter")
    @Scope("prototype")
    public AzureBlobAdapter pgsBlobAdapter(@Qualifier("pgsStorageAccount") CloudStorageAccount cloudStorageAccount,
                                           @Qualifier("pgsRSAKey") IKey rsaKey,
                                           @Qualifier("pgsKeyResolver") CachingKeyResolver cachingKeyResolver,
                                           @Qualifier("pgsBlobStorage") AzureStorageProperties azureStorageProperties)
            throws URISyntaxException, StorageException {

        return getAzureBlobAdapter(cloudStorageAccount, rsaKey, cachingKeyResolver, azureStorageProperties);

    }


    private AzureBlobAdapter getAzureBlobAdapter(CloudStorageAccount cloudStorageAccount, IKey rsaKey, CachingKeyResolver cachingKeyResolver, AzureStorageProperties azureStorageProperties) throws URISyntaxException, StorageException {
        CloudBlobContainer cloudBlobContainer = cloudStorageAccount.createCloudBlobClient()
                .getContainerReference(azureStorageProperties.getBlobContainerName());

        return new AzureBlobAdapter(cloudBlobContainer, rsaKey, cachingKeyResolver);
    }

    private AzureBlobAdapterNoKey getAzureBlobAdapterNoKey(CloudStorageAccount cloudStorageAccount, AzureStorageProperties azureStorageProperties) throws URISyntaxException, StorageException {
        CloudBlobContainer cloudBlobContainer = cloudStorageAccount.createCloudBlobClient()
                .getContainerReference(azureStorageProperties.getBlobContainerName());

        return new AzureBlobAdapterNoKey(cloudBlobContainer);
    }
}
