package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "T_ILASFNA")
public class TIlasFna {

    @Column(name = "FNAID", length = 60)
    @Id
    private String fnaId;

    @Column(name = "CONTACTID", length = 60)
    private String contactId;

    @Column(name = "FNASTATUS")
    private Integer fnaStatus;

    @Column(name = "FNACOMPLETEDATE")
    @Temporal(TemporalType.DATE)
    private Date fnaCompleteDate;

    @Column(name = "FNAVERSION", length = 20)
    private String fnaVersion;

    @Column(name = "CREATEDDATETIME",updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "PremiumExcessReason")
    private String premiumExcessReason;

    @Column(name = "AgeExcessReason")
    private String ageExcessReason;

    @Column(name = "FNAType", length = 20)
    private String fnaType;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TIlasFna{");
        sb.append("fnaId='").append(fnaId).append('\'');
        sb.append(", contactId='").append(contactId).append('\'');
        sb.append(", fnaStatus=").append(fnaStatus);
        sb.append(", fnaCompleteDate=").append(fnaCompleteDate);
        sb.append(", fnaVersion='").append(fnaVersion).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", premiumExcessReason='").append(premiumExcessReason).append('\'');
        sb.append(", ageExcessReason='").append(ageExcessReason).append('\'');
        sb.append(", fnaType='").append(fnaType).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
