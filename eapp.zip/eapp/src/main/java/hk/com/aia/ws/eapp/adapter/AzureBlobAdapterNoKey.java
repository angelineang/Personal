package hk.com.aia.ws.eapp.adapter;

import com.microsoft.azure.storage.AccessCondition;
import com.microsoft.azure.storage.OperationContext;
import com.microsoft.azure.storage.StorageException;
import com.microsoft.azure.storage.blob.*;
import hk.com.aia.ws.eapp.exception.BlobNotFoundException;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Slf4j
@AllArgsConstructor
public class AzureBlobAdapterNoKey {

    private final CloudBlobContainer cloudBlobContainer;

    public CloudBlockBlob upload(byte[] buffer, String fileName)
            throws IOException, StorageException, URISyntaxException {

        return upload(buffer, fileName, null);
    }

    public CloudBlockBlob upload(byte[] buffer, String fileName, BlobRequestOptions uploadOptions)
            throws IOException, StorageException, URISyntaxException {
        return upload(buffer, fileName, null, null, uploadOptions, null);

    }

    public CloudBlockBlob upload(byte[] buffer, String fileName, StandardBlobTier standardBlobTier,
                                 AccessCondition accessCondition, BlobRequestOptions uploadOptions, OperationContext opContext)
            throws IOException, StorageException, URISyntaxException {

        CloudBlockBlob blob = cloudBlobContainer.getBlockBlobReference(fileName);
        blob.uploadFromByteArray(buffer, 0, buffer.length, standardBlobTier, accessCondition, uploadOptions, opContext);
        return blob;
    }

    public boolean blobExist(String blobName) throws StorageException, URISyntaxException {

        CloudBlockBlob blob = cloudBlobContainer.getBlockBlobReference(blobName);
        return blob.exists();
    }

    public byte[] downloadBlob(String blobName) throws StorageException,
            URISyntaxException, BlobNotFoundException {

        CloudBlockBlob blob = cloudBlobContainer.getBlockBlobReference(blobName);
        return download(blob);
    }

    public byte[] download(CloudBlockBlob blob) throws StorageException, BlobNotFoundException {

        if (!blob.exists()) {
            log.warn("blob record cannot be found {}", blob.getName());
            throw new BlobNotFoundException();
        }
        long length = blob.getProperties().getLength();
        byte[] data = new byte[(int) length];
        blob.downloadToByteArray(data, 0);

        return data;
    }

    public byte[] download(CloudBlockBlob blob, BlobRequestOptions downloadOptions)
            throws StorageException, BlobNotFoundException {

        if (!blob.exists()) {
            log.warn("blob record cannot be found with blob request options {}", blob.getName());
            throw new BlobNotFoundException();
        }
        long length = blob.getProperties().getLength();
        byte[] data = new byte[(int) length];
        blob.downloadToByteArray(data, 0, null, downloadOptions, null);

        return data;
    }

    public byte[] download(CloudBlockBlob blob, BlobRequestOptions downloadOptions, AccessCondition accessCondition, OperationContext operationContext)
            throws StorageException, BlobNotFoundException {

        if (!blob.exists()) {
            log.warn("blob record not found {}", blob.getName());
            throw new BlobNotFoundException();
        }
        long length = blob.getProperties().getLength();
        byte[] data = new byte[(int) length];
        blob.downloadToByteArray(data, 0, accessCondition, downloadOptions, operationContext);

        return data;
    }

    public List<String> listBlob(String prefix) {
        List<String> uriList = new ArrayList<>();
        cloudBlobContainer.listBlobs(prefix).forEach(l -> {
            String url = l.getUri().toString();
            uriList.add(url);
        });
        return uriList;
    }

    public Map<String, String> blobMetadata(String blobName) throws URISyntaxException, StorageException {
        CloudBlockBlob blob = cloudBlobContainer.getBlockBlobReference(blobName);
        blob.downloadAttributes();
        return blob.getMetadata();
    }
}
