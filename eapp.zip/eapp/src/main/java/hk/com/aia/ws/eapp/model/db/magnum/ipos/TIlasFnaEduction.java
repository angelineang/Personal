package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import hk.com.aia.ws.eapp.util.ConversionHandler;
import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "T_ILASFNAEDUCTION")
public class TIlasFnaEduction {

    @Column(name = "FNAEDUCTIONID", length = 60)
    @Id
    private String fnaEductionId;

    @Column(name = "FNAID", length = 60)
    private String fnaId;

    @Column(name = "CHILDNAME", length = 50)
    private String childName;

    @Column(name = "CHILDAGE")
    private Integer childAge;

    @Column(name = "EDUCATIONCOUTRY", length = 50)
    private String educationCoutry;

    @Column(name = "AVERAGELIVINGEXPENSE")
    private BigDecimal averageLivingExpense;

    @Column(name = "SAVING")
    private BigDecimal saving;

    @Column(name = "CREATEDDATETIME",updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TIlasFnaEduction{");
        sb.append("fnaEductionId='").append(fnaEductionId).append('\'');
        sb.append(", fnaId='").append(fnaId).append('\'');
        sb.append(", childName='").append(ConversionHandler.mask(childName)).append('\'');
        sb.append(", childAge=").append(childAge);
        sb.append(", educationCoutry='").append(educationCoutry).append('\'');
        sb.append(", averageLivingExpense=").append(averageLivingExpense);
        sb.append(", saving=").append(saving);
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append('}');
        return sb.toString();
    }
}