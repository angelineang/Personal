package hk.com.aia.ws.eapp.model.db.magnum.ipos.idclass;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TWithdrawalId implements Serializable {

    private static final long serialVersionUID = 2709490918889763340L;
    private String withdrawalId;
    private String sqsQuotationId;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TWithdrawalId{");
        sb.append("withdrawalId='").append(withdrawalId).append('\'');
        sb.append(", sqsQuotationId='").append(sqsQuotationId).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
