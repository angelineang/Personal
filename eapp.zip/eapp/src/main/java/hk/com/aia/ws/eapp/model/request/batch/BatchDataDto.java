package hk.com.aia.ws.eapp.model.request.batch;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;

@ApiModel(value = "BatchData Model")
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class BatchDataDto {

    @JsonProperty("request_no")
    private String requestNo;

    @JsonProperty("field_name")
    private String fieldName;

    @JsonProperty("field_value")
    private String fieldValue;

    @JsonProperty("seq")
    @NotNull
    private Integer seq;

    @JsonProperty("doc_id")
    private String docId;

}
