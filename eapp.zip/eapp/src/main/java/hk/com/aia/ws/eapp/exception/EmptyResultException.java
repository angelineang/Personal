package hk.com.aia.ws.eapp.exception;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class EmptyResultException extends RuntimeException {

    private static final long serialVersionUID = 1L;
    private String code;
    private String message;

}
