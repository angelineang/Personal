package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;


@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "T_OCR_RETAKE_COUNT")
public class TOcrRetakeCount {

    @Column(name = "RETAKECOUNTID", length = 50)
    @Id
    private String retakeCountId;

    @Column(name = "EAPPID", length = 50)
    private String eAppId;

    @Column(name = "CONTACTID", length = 50)
    private String contactId;

    @Column(name = "IMAGETYPE", length = 50)
    private String imageType;

    @Column(name = "ISOCR")
    private Integer isOcr;

    @Column(name = "SEQUENCE")
    private Integer sequence;

    @Column(name = "RETAKECOUNT")
    private Integer retakeCount;

    @Column(name = "FAILREASONS", length = 200)
    private String failReasons;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "LASTUPDATEDATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    @LastModifiedDate
    private Date lastUpdateDateTime;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TOcrRetakeCount{");
        sb.append("retakeCountId='").append(retakeCountId).append('\'');
        sb.append(", eAppId='").append(eAppId).append('\'');
        sb.append(", contactId='").append(contactId).append('\'');
        sb.append(", imageType='").append(imageType).append('\'');
        sb.append(", isOcr=").append(isOcr);
        sb.append(", sequence=").append(sequence);
        sb.append(", retakeCount=").append(retakeCount);
        sb.append(", failReasons='").append(failReasons).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", lastUpdateDateTime=").append(lastUpdateDateTime);
        sb.append('}');
        return sb.toString();
    }
}
