package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import lombok.Data;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@Table(name = "T_TermConversion")
@EntityListeners(AuditingEntityListener.class)
public class TTermConversion {

    @Column(name = "ConversionID", length = 60)
    @Id
    private String conversionId;

    @Column(name = "EAPPID", length = 60)
    private String eappId;

    @Column(name = "FromPolicyNo", length = 50)
    private String fromPolicyNo;

    @Column(name = "ConvertedPlan", length = 500)
    private String convertedPlan;

    @Column(name = "OldPolicyOwner", length = 200)
    private String oldPolicyOwner;

    @Column(name = "OldOwnerName", length = 200)
    private String oldOwnerName;

    @Column(name = "ConvertedAmt")
    private Integer convertedAmt;

    @Column(name = "RemainingAmt")
    private Integer remainingAmt;

    @Column(name = "CirconvertedAmt")
    private Integer cirConvertedAmt;

    @Column(name = "CirremainingAmt")
    private Integer cirRemainingAmt;

    @Column(name = "createby", length = 10, updatable = false)
    @CreatedBy
    private String createBy;

    @Column(name = "createddatetime", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TTermConversion{");
        sb.append("conversionId='").append(conversionId).append('\'');
        sb.append(", eappId='").append(eappId).append('\'');
        sb.append(", fromPolicyNo='").append(fromPolicyNo).append('\'');
        sb.append(", convertedPlan='").append(convertedPlan).append('\'');
        sb.append(", oldPolicyOwner='").append(oldPolicyOwner).append('\'');
        sb.append(", oldOwnerName='").append(oldOwnerName).append('\'');
        sb.append(", convertedAmt=").append(convertedAmt);
        sb.append(", remainingAmt=").append(remainingAmt);
        sb.append(", cirConvertedAmt=").append(cirConvertedAmt);
        sb.append(", cirRemainingAmt=").append(cirRemainingAmt);
        sb.append(", createBy='").append(createBy).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append('}');
        return sb.toString();
    }
}