package hk.com.aia.ws.eapp.model.db.mag.iverify;


import hk.com.aia.ws.eapp.model.db.mag.iverify.idclass.TPrcDoc7Id;
import hk.com.aia.ws.eapp.model.request.iverify.TPrcDocDetailsDto;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Arrays;
import java.util.Date;

@Entity
@Data
@Table(name = "T_PRC_DOC_7")
@NoArgsConstructor
@EntityListeners(AuditingEntityListener.class)
@IdClass(TPrcDoc7Id.class)
public class TPrcDoc7 {

    public TPrcDoc7(TPrcDocDetailsDto tPrcDocDetailsDto, byte[] fileByte) {
        this.iverifyId = tPrcDocDetailsDto.getIverifyId();
        this.clientId = tPrcDocDetailsDto.getClientId();
        this.docSeq = tPrcDocDetailsDto.getDocSeq();
        this.docId = tPrcDocDetailsDto.getDocId();
        this.binary = fileByte;
    }

    @Column(name = "IVERIFYID", length = 60)
    @Id
    private String iverifyId;

    @Column(name = "CLIENTID", length = 20)
    private String clientId;

    @Column(name = "DOCSEQ")
    private Integer docSeq;

    @Column(name = "DOCID", length = 8)
    private String docId;

    @Column(name = "BINARY")
    private byte[] binary;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TPrcDoc7{");
        sb.append("iverifyId='").append(iverifyId).append('\'');
        sb.append(", clientId='").append(clientId).append('\'');
        sb.append(", docSeq=").append(docSeq);
        sb.append(", docId='").append(docId).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append('}');
        return sb.toString();
    }
}
