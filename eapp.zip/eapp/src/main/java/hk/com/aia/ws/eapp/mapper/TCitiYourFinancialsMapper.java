package hk.com.aia.ws.eapp.mapper;

import hk.com.aia.ws.eapp.model.db.magnum.ipos.TCitiYourFinancials;
import hk.com.aia.ws.eapp.model.request.ipos.TCitiYourFinancialsDto;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper
public interface TCitiYourFinancialsMapper {

    TCitiYourFinancialsMapper MAPPER = Mappers.getMapper(TCitiYourFinancialsMapper.class);

    List<TCitiYourFinancials> mapToCitiYourFinancialsList(List<TCitiYourFinancialsDto> tCitiYourFinancialsDto);
}
