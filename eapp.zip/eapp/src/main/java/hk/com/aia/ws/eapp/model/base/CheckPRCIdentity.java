package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.annotation.DateTimeValidation;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@ApiModel(value = "People Republic China (PRC) identity validation Model")
@ToString
@Data
@EqualsAndHashCode(callSuper = false)
public class CheckPRCIdentity extends Payload {
    // Size max determined by maximum allowed by stored procedure - db_magnum..po_eapp_chk_src_ind

    @ApiModelProperty(value = "Booking", required = true)
    @JsonProperty("booking")
    @NotBlank
    @Size(max = 3)
    private String booking;

    @ApiModelProperty(value = "Agent Code 1", required = true)
    @JsonProperty("agt_code_1")
    @NotBlank
    @Size(max = 10)
    private String agentCode1;

    @ApiModelProperty(value = "Agent Code 2")
    @JsonProperty("agt_code_2")
    @Size(max = 10)
    private String agentCode2;

    @ApiModelProperty(value = "Policy No", required = true)
    @JsonProperty("pol_no")
    @NotBlank
    @Size(max = 10)
    private String polNo;

    @ApiModelProperty(value = "Owner Last Name", required = true)
    @JsonProperty("own_last_name")
    @NotBlank
    @Size(max = 100)
    private String ownLastName;

    @ApiModelProperty(value = "Owner First Name", required = true)
    @JsonProperty("own_first_name")
    @NotBlank
    @Size(max = 45)
    private String ownFirstName;

    @ApiModelProperty(value = "eApp sign date yyyy-MM-dd", example = "2021-12-31", required = true)
    @JsonProperty("eapp_sign_date")
    @NotBlank
    @Size(max = 10)
    @DateTimeValidation(format="yyyy-MM-dd")
    private String eappSignDate;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("CheckPRCIdentity{");
        sb.append("booking='").append(booking).append('\'');
        sb.append(", agentCode1='").append(agentCode1).append('\'');
        sb.append(", agentCode2='").append(agentCode2).append('\'');
        sb.append(", polNo='").append(ConversionHandler.mask(polNo)).append('\'');
        sb.append(", ownLastName='").append(ConversionHandler.mask(ownLastName)).append('\'');
        sb.append(", ownFirstName='").append(ConversionHandler.mask(ownFirstName)).append('\'');
        sb.append(", eappSignDate='").append(eappSignDate).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
