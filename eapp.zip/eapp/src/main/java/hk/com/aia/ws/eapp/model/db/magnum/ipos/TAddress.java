package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import lombok.Data;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@Table(name = "T_ADDRESS")
@EntityListeners(AuditingEntityListener.class)
public class TAddress {

    @Column(name = "ADDRESSID", length = 60)
    @Id
    private String addressId;

    @Column(name = "CONTACTID", length = 60)
    private String contactId;

    @Column(name = "POSTALCODE", length = 10)
    private String postalCode;

    @Column(name = "ROOMNO", length = 100)
    private String roomNo;

    @Column(name = "FLOOR", length = 60)
    private String floor;

    @Column(name = "BLOCK", length = 300)
    private String block;

    @Column(name = "BUILDING", length = 500)
    private String building;

    @Column(name = "STREETLINE1", length = 800)
    private String streetLine1;

    @Column(name = "STREETLINE2", length = 800)
    private String streetLine2;

    @Column(name = "CITY", length = 255)
    private String city;

    @Column(name = "PROVINCE", length = 255)
    private String province;

    @Column(name = "COUNTRYCODE", length = 100)
    private String countryCode;

    @Column(name = "COUNTRYNAME", length = 255)
    private String countryName;

    @Column(name = "SAMEAS", length = 20)
    private String sameAs;

    @Column(name = "ADDRESSTYPE", length = 20)
    private String addressType;

    @Column(name = "EMPLOYERNAME", length = 500)
    private String employerName;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "LASTUPDATEDATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    @LastModifiedDate
    private Date lastUpdateDateTime;

    @Column(name = "CREATEDBY", length = 8, updatable = false)
    @CreatedBy
    private String createdBy;

    @Column(name = "UPDATEDBY", length = 10)
    @LastModifiedBy
    private String updatedBy;

    @Column(name = "INPUTLANGUAGE", length = 10)
    private String inputLanguage;

    @Column(name = "district", length = 500)
    private String district;

    @Column(name = "streets", length = 255)
    private String streets;

    @Column(name = "streetLine3", length = 1000)
    private String streetLine3;

    @Column(name = "streetLine4", length = 1000)
    private String streetLine4;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TAddress{");
        sb.append("addressId='").append(addressId).append('\'');
        sb.append(", contactId='").append(contactId).append('\'');
        sb.append(", postalCode='").append(postalCode).append('\'');
        sb.append(", roomNo='").append(roomNo).append('\'');
        sb.append(", floor='").append(floor).append('\'');
        sb.append(", block='").append(block).append('\'');
        sb.append(", building='").append(building).append('\'');
        sb.append(", streetLine1='").append(streetLine1).append('\'');
        sb.append(", streetLine2='").append(streetLine2).append('\'');
        sb.append(", city='").append(city).append('\'');
        sb.append(", province='").append(province).append('\'');
        sb.append(", countryCode='").append(countryCode).append('\'');
        sb.append(", countryName='").append(countryName).append('\'');
        sb.append(", sameAs='").append(sameAs).append('\'');
        sb.append(", addressType='").append(addressType).append('\'');
        sb.append(", employerName='").append(employerName).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", lastUpdateDateTime=").append(lastUpdateDateTime);
        sb.append(", createdBy='").append(createdBy).append('\'');
        sb.append(", updatedBy='").append(updatedBy).append('\'');
        sb.append(", inputLanguage='").append(inputLanguage).append('\'');
        sb.append(", district='").append(district).append('\'');
        sb.append(", streets='").append(streets).append('\'');
        sb.append(", streetLine3='").append(streetLine3).append('\'');
        sb.append(", streetLine4='").append(streetLine4).append('\'');
        sb.append('}');
        return sb.toString();
    }
}