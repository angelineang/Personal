package hk.com.aia.ws.eapp.model.kafka.incoming;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class MessageModel {

    @JsonProperty("messageCreateTime")
    private String messageCreateTime;

    @JsonProperty("messageType")
    private String messageType;

    @JsonProperty("targetApplication")
    private String targetApplication;

    @JsonProperty("sourceApplication")
    private String sourceApplication;

    @JsonProperty("payLoad")
    private MessagePayload messagePayload;

    @JsonProperty("tranId")
    private String tranId;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("MessageModel{");
        sb.append("tranId='").append(tranId).append('\'');
        sb.append(", targetApplication='").append(targetApplication).append('\'');
        sb.append(", messageType='").append(messageType).append('\'');
        sb.append(", messagePayload=").append(messagePayload);
        sb.append(", messageCreateTime='").append(messageCreateTime).append('\'');
        sb.append(", sourceApplication='").append(sourceApplication).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
