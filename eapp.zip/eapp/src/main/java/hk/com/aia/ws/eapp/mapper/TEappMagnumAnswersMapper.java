package hk.com.aia.ws.eapp.mapper;

import hk.com.aia.ws.eapp.model.db.magnum.ipos.TEapp;
import hk.com.aia.ws.eapp.model.db.magnum.ipos.TEappMagnumAnswers;
import hk.com.aia.ws.eapp.model.request.ipos.TEappMagnumAnswersDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper
public interface TEappMagnumAnswersMapper {

    TEappMagnumAnswersMapper MAPPER = Mappers.getMapper(TEappMagnumAnswersMapper.class);

    @Mapping(target = "createdDateTime", ignore = true)
    List<TEappMagnumAnswers> mapToTEappMagnumAnswersList(List<TEappMagnumAnswersDto> tEappMagnumAnswersDto);
}
