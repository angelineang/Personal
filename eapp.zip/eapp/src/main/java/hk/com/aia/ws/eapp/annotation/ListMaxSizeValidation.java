package hk.com.aia.ws.eapp.annotation;

import hk.com.aia.ws.eapp.validation.ListMaxSizeValidator;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.*;

@Documented
@Target({ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = ListMaxSizeValidator.class)
public @interface ListMaxSizeValidation {

    String message() default "List of Policy No cannot exceed maximum";

    String propertyKey() default "";
    Class<?>[] groups() default {};
    Class<? extends Payload>[] payload() default {};
    /**
     * Set max size of a list
     */
    int max() default 1;

}
