package hk.com.aia.ws.eapp.exception;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
@AllArgsConstructor
public class BaseException extends Exception {

    private static final long serialVersionUID = 1L;
    private String code;
    private String message;

}
