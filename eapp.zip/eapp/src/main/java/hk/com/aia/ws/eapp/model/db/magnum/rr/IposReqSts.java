package hk.com.aia.ws.eapp.model.db.magnum.rr;

import hk.com.aia.ws.eapp.model.db.magnum.rr.idclass.IposReqStsId;
import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Data
@Entity
@Table(name = "tbl_ipos_req_sts")
@IdClass(IposReqStsId.class)
@EntityListeners(AuditingEntityListener.class)
public class IposReqSts {

    @Id
    @Column(name = "eapp_id")
    private String eappId;

    @Id
    @Column(name = "policy_no")
    private String policyNo;

    @Id
    @Column(name = "last_sign_date")
    private Date lastSignDate;

    @Id
    @Column(name = "submit_type")
    private String submitType;

    @Column(name = "submit_sts")
    private String submitSts;

    @Column(name = "create_by")
    private String createBy;

    @Column(name = "create_date")
    private Date createDate;

    @Column(name = "update_by")
    private String updateBy;

    @Column(name = "last_update")
    private Date lastUpdate;

}
