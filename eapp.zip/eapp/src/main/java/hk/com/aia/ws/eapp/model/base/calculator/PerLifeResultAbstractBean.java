package hk.com.aia.ws.eapp.model.base.calculator;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@EqualsAndHashCode(callSuper = false)
public class PerLifeResultAbstractBean {

    protected PerLifeRequestBean perLifeRequestBean;
    protected String resultCode;
    protected String resultMessage;

}
