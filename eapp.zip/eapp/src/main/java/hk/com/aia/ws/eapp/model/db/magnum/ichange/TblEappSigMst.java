package hk.com.aia.ws.eapp.model.db.magnum.ichange;

import hk.com.aia.ws.eapp.model.db.magnum.ichange.idclass.TblEappSigMstId;
import lombok.Data;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "tbl_eapp_sig_mst")
@IdClass(TblEappSigMstId.class)
public class TblEappSigMst {

    @Column(name = "batch_id", length = 19)
    @Id
    private String batchId;

    @Column(name = "seq")
    @Id
    private Integer sequence;

    @Column(name = "policy_no", length = 10)
    @Id
    private String policyNo;

    @Column(name = "doc_id", length = 8)
    @Id
    private String docId;

    @Column(name = "sig_role", length = 8)
    @Id
    private String sigRole;

    @Column(name = "sig_no")
    @Id
    private Integer sigNo;

    @Column(name = "sig_seq")
    private Integer sigSeq;

    @Column(name = "create_by", length = 15)
    @CreatedBy
    private String createBy;

    @Column(name = "create_date", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createDate;

    @Column(name = "update_by", length = 15, updatable = false)
    @LastModifiedBy
    private String updateBy;

    @Column(name = "last_update")
    @Temporal(TemporalType.TIMESTAMP)
    @LastModifiedDate
    private Date lastUpdate;

    @Column(name = "documents_id", length = 8)
    private String documentsId;

    @Column(name = "iverify_id", length = 8)
    private String iVerifyId;

    @Column(name = "iverify_client_id", length = 8)
    private String iVerifyClientId;

    @Column(name = "iverify_doc_seq")
    private Integer iVerifyDocSeq;

    @Column(name = "content_type", length = 30)
    @Id
    private String contentType;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TblEappSigMst{");
        sb.append("batchId='").append(batchId).append('\'');
        sb.append(", seq='").append(sequence).append('\'');
        sb.append(", policyNo='").append(policyNo).append('\'');
        sb.append(", docId='").append(docId).append('\'');
        sb.append(", sigRole='").append(sigRole).append('\'');
        sb.append(", sigNo=").append(sigNo);
        sb.append(", sigSeq=").append(sigSeq);
        sb.append(", createBy='").append(createBy).append('\'');
        sb.append(", createDate=").append(createDate);
        sb.append(", updateBy='").append(updateBy).append('\'');
        sb.append(", lastUpdate=").append(lastUpdate);
        sb.append(", documentsId='").append(documentsId).append('\'');
        sb.append(", iVerifyId='").append(iVerifyId).append('\'');
        sb.append(", iVerifyClientId='").append(iVerifyClientId).append('\'');
        sb.append(", iVerifyDocSeq=").append(iVerifyDocSeq);
        sb.append(", contentType='").append(contentType).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
