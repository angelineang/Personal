package hk.com.aia.ws.eapp.aes.util;

import java.io.UnsupportedEncodingException;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class AES {
	
	private static final String DECRYPT_FAIL = "decrypt fail!";
	

	
	private static RuntimeException newRuntimeException(String decryptFail, Exception e) {
		return new RuntimeException(decryptFail, e);
	}

	public static byte[] decrypt(byte[] data, byte[] key,byte[] ivbyte) {
		try {
			SecretKeySpec secretKey = new SecretKeySpec(key, "AES");
			byte[] enCodeFormat = secretKey.getEncoded();
			SecretKeySpec seckey = new SecretKeySpec(enCodeFormat, "AES");
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
			IvParameterSpec iv = new IvParameterSpec(ivbyte);
			cipher.init(Cipher.DECRYPT_MODE, seckey, iv);
			byte[] result = cipher.doFinal(data);
			return result; 
		} catch (Exception e) {
			e.printStackTrace();
			throw newRuntimeException(DECRYPT_FAIL, e);
		}
	}

	public static byte[] decrypt(byte[] data, String key,byte[] ivkey) {
		try {
			byte[] valueByte = decrypt(data, key.getBytes("UTF-8"), ivkey);
			return valueByte;
		} catch (UnsupportedEncodingException e) {
			throw newRuntimeException(DECRYPT_FAIL, e);
		}
	}


	public static String decryptFromBase64(String data, String key,byte[] ivkey) {
		try {
			byte[] originalData = Base64.decode(data.getBytes());
			byte[] valueByte = decrypt(originalData, key, ivkey);
			return new String(valueByte, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			throw newRuntimeException(DECRYPT_FAIL, e);
		}
	}



	public String selfconcatpassword(String str, int minLen) {
		if (str.length() >= minLen) {
			return str.substring(0, minLen);
		}
		StringBuilder sb = new StringBuilder(str);
		for (int i = 0; i < minLen; i++) {
			sb.append(str);
		}

		return sb.substring(0, minLen);
	}

}
