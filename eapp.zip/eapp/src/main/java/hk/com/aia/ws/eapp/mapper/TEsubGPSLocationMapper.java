package hk.com.aia.ws.eapp.mapper;

import hk.com.aia.ws.eapp.model.db.magnum.ipos.TEsubGPSLocation;
import hk.com.aia.ws.eapp.model.request.ipos.TEsubGPSLocationDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper
public interface TEsubGPSLocationMapper {

    TEsubGPSLocationMapper MAPPER = Mappers.getMapper(TEsubGPSLocationMapper.class);

    @Mapping(target = "createdDateTime", ignore = true)
    List<TEsubGPSLocation> mapToTEsubGPSLocationList(List<TEsubGPSLocationDto> tEsubGPSLocationDto);
}
