package hk.com.aia.ws.eapp.model.dto;

import hk.com.aia.ws.eapp.util.ConversionHandler;
import lombok.Data;

import java.util.Date;

import static hk.com.aia.ws.eapp.constant.Constants.IND_NO;

@Data
public class SubmissionActivity {

    private String name;
    private String submitChannel;
    private String submitType;
    private String polNo;
    private String wsAction;
    private String lastSignDate;
    private String additionalInd;
    private String polInd = IND_NO;
    private String mstInd = IND_NO;
    private String promoInd = IND_NO;
    private String covInd = IND_NO;
    private String custInd = IND_NO;
    private String addrInd = IND_NO;
    private String docInd = IND_NO;
    private String benefitInd = IND_NO;
    private String eSubInd = IND_NO;
    private String questInd = IND_NO;
    private String remarks;
    private Date logStartDate;
    private Date logEndDate;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("SubmissionActivity{");
        sb.append("name='").append(name).append('\'');
        sb.append(", submitChannel='").append(submitChannel).append('\'');
        sb.append(", submitType='").append(submitType).append('\'');
        sb.append(", polNo='").append(ConversionHandler.mask(polNo)).append('\'');
        sb.append(", wsAction='").append(wsAction).append('\'');
        sb.append(", lastSignDate='").append(lastSignDate).append('\'');
        sb.append(", additionalInd='").append(additionalInd).append('\'');
        sb.append(", polInd='").append(polInd).append('\'');
        sb.append(", mstInd='").append(mstInd).append('\'');
        sb.append(", covInd='").append(covInd).append('\'');
        sb.append(", custInd='").append(custInd).append('\'');
        sb.append(", addrInd='").append(addrInd).append('\'');
        sb.append(", docInd='").append(docInd).append('\'');
        sb.append(", benefitInd='").append(benefitInd).append('\'');
        sb.append(", eSubInd='").append(eSubInd).append('\'');
        sb.append(", questInd='").append(questInd).append('\'');
        sb.append(", remarks='").append(remarks).append('\'');
        sb.append(", logStartDate=").append(logStartDate);
        sb.append(", logEndDate=").append(logEndDate);
        sb.append('}');
        return sb.toString();
    }
}
