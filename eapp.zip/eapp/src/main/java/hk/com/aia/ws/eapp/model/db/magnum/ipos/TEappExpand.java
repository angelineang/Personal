package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import hk.com.aia.ws.eapp.util.ConversionHandler;
import lombok.Data;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "T_EAPP_EXPAND")
public class TEappExpand {

    @Column(name = "EAPPEXPANDID", length = 60)
    @Id
    private String eappExpandId;

    @Column(name = "EAPPID", length = 60)
    private String eappId;

    @Column(name = "SUBMITPRCTYPE", length = 10)
    private String submitPrcType;

    @Column(name = "CREATEDBY", length = 10, updatable = false)
    @CreatedBy
    private String createdBy;

    @Column(name = "UPDATEDBY", length = 10)
    @LastModifiedBy
    private String updatedBy;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "LASTUPDATEDATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    @LastModifiedDate
    private Date lastUpdateDateTime;

    @Column(name = "COLUMN1")
    private String column1;

    @Column(name = "COLUMN2")
    private String column2;

    @Column(name = "TRTelNo", length = 30)
    private String trTelNo;

    @Column(name = "TRMemberShipNo", length = 30)
    private String trMembershipNo;

    @Column(name = "eappCreateVersion", length = 20)
    private String eappCreateVersion;

    @Column(name = "eappConfirmVersion", length = 20)
    private String eappConfirmVersion;

    @Column(name = "eappSignedVersion", length = 20)
    private String eappSignedVersion;

    @Column(name = "bypassFinancialForm", length = 10)
    private String bypassFinancialForm;

    @Column(name = "tickedBirthdayCampaign", length = 10)
    private String tickedBirthdayCampaign;

    @Column(name = "noMobileReason", length = 60)
    private String noMobileReason;

    @Column(name = "fhc_answer", length = 5)
    private String fhcAnswer;

    @Column(name = "fhc_answer_NO_reason", length = 10)
    private String fhcAnswerNoReason;

    @Column(name = "fhc_answer_NO_details", length = 800)
    private String fhcAnswerNODetails;

    @Column(name = "addressSameReason", length = 20)
    private String addressSameReason;

    @Column(name = "addressSameOthersReason", length = 500)
    private String addressSameOthersReason;

    @Column(name = "nationalityNoSameReason", length = 20)
    private String nationalityNoSameReason;

    @Column(name = "nationalityNoSameOthersReason", length = 500)
    private String nationalityNoSameOthersReason;

    @Column(name = "EntryStartDate_A", length = 4)
    @Temporal(TemporalType.DATE)
    private Date entryStartDateA;

    @Column(name = "EntryEndDate_A", length = 4)
    @Temporal(TemporalType.DATE)
    private Date entryEndDateA;

    @Column(name = "EntryNumber_A", length = 30)
    private String entryNumberA;

    @Column(name = "EntryStartDate_I", length = 4)
    @Temporal(TemporalType.DATE)
    private Date entryStartDateI;

    @Column(name = "EntryEndDate_I", length = 4)
    @Temporal(TemporalType.DATE)
    private Date entryEndDateI;

    @Column(name = "EntryNumber_I", length = 30)
    private String entryNumberI;

    @Column(name = "isDirectRelative")
    private Integer isDirectRelative;

    @Column(name = "InsuredCopyFromPolNo", length = 20)
    private String insuredCopyFromPolNo;

    @Column(name = "AreaCode", length = 20)
    private String areaCode;

    @Column(name = "isVitalityPersonalData")
    private Integer isVitalityPersonalData;

    @Column(name = "ISRATEUP", length = 10)
    private String isRateUp;

    @Column(name = "CIVILEMPLOYCODE", length = 10)
    private String civilEmployCode;

    @Column(name = "groupConversionPolicyNo", length = 10)
    private String groupConversionPolicyNo;

    @Column(name = "lastEmailDateTime", length = 20)
    private String lastEmailDateTime;

    @Column(name = "isRemoteSign", length = 10)
    private String isRemoteSign;

    @Column(name = "VOOptin", length = 4)
    private String voOptin;

    @Column(name = "IANumber", length = 60)
    private String iaNumber;

    @Column(name = "medicalCISelections", length = 10)
    private String medicalCISelections;

    @Column(name = "transferToMPFFlag")
    private Integer transferToMPFFlag;

    @Column(name = "isChineseCitizen", length = 10)
    private String isChineseCitizen;

    @Column(name = "isPEPRole")
    private Integer isPEPRole;

    @Column(name = "isPayoutAcknowledge")
    private Integer isPayoutAcknowledge;

    @Column(name = "isEadviceAcknowledge")
    private Integer isEadviceAcknowledge;

    @Column(name = "MOBILEISAPPLICANTREG")
    private String mobileIsApplicantReg;

    @Column(name = "MOBILESHAREREASON")
    private String mobileShareReason;
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TEappExpand{");
        sb.append("eappExpandId='").append(eappExpandId).append('\'');
        sb.append(", eappId='").append(eappId).append('\'');
        sb.append(", submitPrcType='").append(submitPrcType).append('\'');
        sb.append(", createdBy='").append(createdBy).append('\'');
        sb.append(", updatedBy='").append(updatedBy).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", lastUpdateDateTime=").append(lastUpdateDateTime);
        sb.append(", column1='").append(column1).append('\'');
        sb.append(", column2='").append(column2).append('\'');
        sb.append(", trTelNo='").append(ConversionHandler.mask(trTelNo)).append('\'');
        sb.append(", trMembershipNo='").append(trMembershipNo).append('\'');
        sb.append(", eappCreateVersion='").append(eappCreateVersion).append('\'');
        sb.append(", eappConfirmVersion='").append(eappConfirmVersion).append('\'');
        sb.append(", eappSignedVersion='").append(eappSignedVersion).append('\'');
        sb.append(", bypassFinancialForm='").append(bypassFinancialForm).append('\'');
        sb.append(", tickedBirthdayCampaign='").append(tickedBirthdayCampaign).append('\'');
        sb.append(", noMobileReason='").append(noMobileReason).append('\'');
        sb.append(", fhcAnswer='").append(fhcAnswer).append('\'');
        sb.append(", fhcAnswerNoReason='").append(fhcAnswerNoReason).append('\'');
        sb.append(", fhcAnswerNODetails='").append(fhcAnswerNODetails).append('\'');
        sb.append(", addressSameReason='").append(addressSameReason).append('\'');
        sb.append(", addressSameOthersReason='").append(addressSameOthersReason).append('\'');
        sb.append(", nationalityNoSameReason='").append(nationalityNoSameReason).append('\'');
        sb.append(", nationalityNoSameOthersReason='").append(nationalityNoSameOthersReason).append('\'');
        sb.append(", entryStartDateA=").append(entryStartDateA);
        sb.append(", entryEndDateA=").append(entryEndDateA);
        sb.append(", entryNumberA='").append(entryNumberA).append('\'');
        sb.append(", entryStartDateI=").append(entryStartDateI);
        sb.append(", entryEndDateI=").append(entryEndDateI);
        sb.append(", entryNumberI='").append(entryNumberI).append('\'');
        sb.append(", isDirectRelative=").append(isDirectRelative);
        sb.append(", insuredCopyFromPolNo='").append(insuredCopyFromPolNo).append('\'');
        sb.append(", areaCode='").append(areaCode).append('\'');
        sb.append(", isVitalityPersonalData=").append(isVitalityPersonalData);
        sb.append(", isRateUp='").append(isRateUp).append('\'');
        sb.append(", civilEmployCode='").append(civilEmployCode).append('\'');
        sb.append(", groupConversionPolicyNo='").append(groupConversionPolicyNo).append('\'');
        sb.append(", lastEmailDateTime='").append(lastEmailDateTime).append('\'');
        sb.append(", isRemoteSign='").append(isRemoteSign).append('\'');
        sb.append(", voOptin='").append(voOptin).append('\'');
        sb.append(", iaNumber='").append(iaNumber).append('\'');
        sb.append(", medicalCISelections='").append(medicalCISelections).append('\'');
        sb.append(", transferToMPFFlag=").append(transferToMPFFlag);
        sb.append(", isChineseCitizen='").append(isChineseCitizen).append('\'');
        sb.append(", isPEPRole=").append(isPEPRole);
        sb.append(", isPayoutAcknowledge=").append(isPayoutAcknowledge);
        sb.append(", isEadviceAcknowledge=").append(isEadviceAcknowledge);
        sb.append(", mobileIsApplicantReg=").append(mobileIsApplicantReg);
        sb.append(", mobileShareReason=").append(mobileShareReason);
        sb.append('}');
        return sb.toString();
    }



}


