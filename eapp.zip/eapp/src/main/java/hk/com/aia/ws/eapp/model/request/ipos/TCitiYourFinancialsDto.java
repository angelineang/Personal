package hk.com.aia.ws.eapp.model.request.ipos;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.annotation.AllowedValuesIntValidation;
import hk.com.aia.ws.eapp.annotation.AllowedValuesValidation;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@ApiModel(value = "T_CITIYOURFINANCIALS Model")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TCitiYourFinancialsDto {

	@ApiModelProperty(value = "your Financials Id", required = true)
    @JsonProperty("your_financials_id")
	@Size(max = 60)
    @NotBlank
    private String yourFinancialsId;

    @JsonProperty("fna_id")
    @Size(max = 60)
    private String fnaId;

    @JsonProperty("client_income_amount")
    private BigDecimal clientIncomeAmount;

    @JsonProperty("other_income_amount")
    private BigDecimal otherIncomeAmount;

    @JsonProperty("other_income_source")
    @Size(max = 60)
    private String otherIncomeSource;

    @JsonProperty("loan_expenses_amount")
    private BigDecimal loanExpensesAmount;

    @JsonProperty("living_expenses_amount")
    private BigDecimal livingExpensesAmount;

    @JsonProperty("other_expenses_amount")
    private BigDecimal otherExpensesAmount;

    @JsonProperty("other_expenses_remark")
    private String otherExpensesRemark;

    @JsonProperty("liquid_assets_a")
    private BigDecimal liquidAssetSA;

    @JsonProperty("liquid_assets_b")
    private BigDecimal liquidAssetSB;

    @JsonProperty("residential")
    private BigDecimal residential;

    @JsonProperty("investment")
    private BigDecimal investment;

    @JsonProperty("other_amount")
    private BigDecimal otherAmount;

    @JsonProperty("source_of_other_a")
    @Size(max = 60)
    private String sourceOfOtherA;

    @JsonProperty("l_loans")
    private BigDecimal lLoans;

    @JsonProperty("l_person_loans")
    private BigDecimal lPersonLoans;

    @JsonProperty("l_mortgage")
    private BigDecimal lMortgage;

    @JsonProperty("l_car_loans")
    private BigDecimal lCarLoans;

    @JsonProperty("l_others_amount")
    private BigDecimal lOthersAmount;

    @JsonProperty("source_of_other_l")
    @Size(max = 60)
    private String sourceOfOtherL;

    @JsonProperty("liquid_asset_saving_check_flag")
    @Size(max = 30)
    private String liquidAssetSavingCheckFlag;

    @JsonProperty("liquid_asset_cash_amount")
    private BigDecimal liquidAssetCashAmount;

    @JsonProperty("liquid_asset_money_bank_amount")
    private BigDecimal liquidAssetMoneyBankAmount;

    @JsonProperty("liquid_asset_invest_check_flag")
    @Size(max = 30)
    private String liquidAssetInvestCheckFlag;

    @JsonProperty("liquid_asset_invest_amount")
    private BigDecimal liquidAssetInvestAmount;

    @JsonProperty("liquid_asset_invest_other")
    @Size(max = 200)
    private String liquidAssetInvestOther;

    @JsonProperty("salary")
    private BigDecimal salary;

    @JsonProperty("bonus")
    private BigDecimal bonus;

    @JsonProperty("dividends")
    private BigDecimal dividends;

    @JsonProperty("rent")
    private BigDecimal rent;

    @JsonProperty("annuity")
    private BigDecimal annuity;

    @JsonProperty("business_income")
    private BigDecimal businessIncome;

    @JsonProperty("miscellaneous_income")
    private BigDecimal miscellaneousIncome;

    @JsonProperty("miscellaneous_income_spec")
    @Size(max = 200)
    private String miscellaneousIncomeSpec;

    @JsonProperty("avg_mth_income")
    private BigDecimal avgMthIncome;

    @JsonProperty("avg_ann_income")
    private BigDecimal avgAnnIncome;

    @JsonProperty("avg_mth_expenses")
    private BigDecimal avgMthExpenses;

    @JsonProperty("disp_income")
    private BigDecimal dispIncome;

    @JsonProperty("liquid_asset")
    private BigDecimal liquidAsset;
    
    @JsonProperty("shortTermLiability")
    private BigDecimal shortTermLiability;
    
    @JsonProperty("longTermLiability")
    private BigDecimal longTermLiability;
    
    @JsonProperty("otherLiability")
    private BigDecimal otherLiability;

    @JsonProperty("is_selected_financial_range")
    @AllowedValuesValidation(values = {"0", "1"})
    @ApiModelProperty(value = "string accepts 0 and 1 only", example = "0")
    private String isSelectedFinancialRange;

    @JsonProperty("financial_range_value")
    private BigDecimal financialRangeValue;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TCitiYourFinancialsDto{");
        sb.append("yourFinancialsId='").append(yourFinancialsId).append('\'');
        sb.append(", fnaId='").append(fnaId).append('\'');
        sb.append(", clientIncomeAmount=").append(ConversionHandler.mask(clientIncomeAmount));
        sb.append(", otherIncomeAmount=").append(ConversionHandler.mask(otherIncomeAmount));
        sb.append(", otherIncomeSource='").append(otherIncomeSource).append('\'');
        sb.append(", loanExpensesAmount=").append(ConversionHandler.mask(loanExpensesAmount));
        sb.append(", livingExpensesAmount=").append(ConversionHandler.mask(livingExpensesAmount));
        sb.append(", otherExpensesAmount=").append(otherExpensesAmount);
        sb.append(", otherExpensesRemark='").append(otherExpensesRemark).append('\'');
        sb.append(", liquidAssetSA=").append(liquidAssetSA);
        sb.append(", liquidAssetSB=").append(liquidAssetSB);
        sb.append(", residential=").append(residential);
        sb.append(", investment=").append(investment);
        sb.append(", otherAmount=").append(otherAmount);
        sb.append(", sourceOfOtherA='").append(sourceOfOtherA).append('\'');
        sb.append(", lLoans=").append(ConversionHandler.mask(lLoans));
        sb.append(", lPersonLoans=").append(ConversionHandler.mask(lPersonLoans));
        sb.append(", lMortgage=").append(ConversionHandler.mask(lMortgage));
        sb.append(", lCarLoans=").append(ConversionHandler.mask(lCarLoans));
        sb.append(", lOthersAmount=").append(ConversionHandler.mask(lOthersAmount));
        sb.append(", sourceOfOtherL='").append(sourceOfOtherL).append('\'');
        sb.append(", liquidAssetSavingCheckFlag='").append(liquidAssetSavingCheckFlag).append('\'');
        sb.append(", liquidAssetCashAmount=").append(ConversionHandler.mask(liquidAssetCashAmount));
        sb.append(", liquidAssetMoneyBankAmount=").append(liquidAssetMoneyBankAmount);
        sb.append(", liquidAssetInvestCheckFlag='").append(liquidAssetInvestCheckFlag).append('\'');
        sb.append(", liquidAssetInvestAmount=").append(ConversionHandler.mask(liquidAssetInvestAmount));
        sb.append(", liquidAssetInvestOther='").append(liquidAssetInvestOther).append('\'');
        sb.append(", salary=").append(ConversionHandler.mask(salary));
        sb.append(", bonus=").append(ConversionHandler.mask(bonus));
        sb.append(", dividends=").append(dividends);
        sb.append(", rent=").append(rent);
        sb.append(", annuity=").append(annuity);
        sb.append(", businessIncome=").append(ConversionHandler.mask(businessIncome));
        sb.append(", miscellaneousIncome=").append(ConversionHandler.mask(miscellaneousIncome));
        sb.append(", miscellaneousIncomeSpec='").append(ConversionHandler.mask(miscellaneousIncomeSpec)).append('\'');
        sb.append(", avgMthIncome=").append(ConversionHandler.mask(avgMthIncome));
        sb.append(", avgAnnIncome=").append(ConversionHandler.mask(avgAnnIncome));
        sb.append(", avgMthExpenses=").append(ConversionHandler.mask(avgMthExpenses));
        sb.append(", dispIncome=").append(ConversionHandler.mask(dispIncome));
        sb.append(", liquidAsset=").append(liquidAsset);
        sb.append(", shortTermLiability=").append(shortTermLiability);
        sb.append(", longTermLiability=").append(longTermLiability);
        sb.append(", otherLiability=").append(otherLiability);
        sb.append(", isSelectedFinancialRange='").append(isSelectedFinancialRange).append('\'');
        sb.append(", financialRangeValue=").append(financialRangeValue);
        sb.append('}');
        return sb.toString();
    }
}

