package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import lombok.Data;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@Table(name = "T_RELATIONSHIP")
@EntityListeners(AuditingEntityListener.class)
public class TRelationship {

    @Column(name = "RELATIONSHIPID", length = 60)
    @Id
    private String relationshipId;

    @Column(name = "CONTACTID", length = 60)
    private String contactId;

    @Column(name = "CONTACTRELATIONSHIPID", length = 60)
    private String contactRelationshipId;

    @Column(name = "ISDEPENDENT")
    private Integer isDependent;

    @Column(name = "RELATIONSHIPCODE", length = 1)
    private String relationshipCode;

    @Column(name = "RELATIONSHIPNAME", length = 40)
    private String relationshipName;

    @Column(name = "CREATEDBY", length = 10, updatable = false)
    @CreatedBy
    private String createdBy;

    @Column(name = "UPDATEDBY", length = 10)
    @LastModifiedBy
    private String updatedBy;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "LASTUPDATEDATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    @LastModifiedDate
    private Date lastUpdateDateTime;

    @Column(name = "OTHERRELATIONSHIP", length = 255)
    private String otherRelationship;

    @Column(name = "reasonCode", length = 30)
    private String reasonCode;

    @Column(name = "otherReason", length = 500)
    private String otherReason;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TRelationship{");
        sb.append("relationshipId='").append(relationshipId).append('\'');
        sb.append(", contactId='").append(contactId).append('\'');
        sb.append(", contactRelationshipId='").append(contactRelationshipId).append('\'');
        sb.append(", isDependent=").append(isDependent);
        sb.append(", relationshipCode='").append(relationshipCode).append('\'');
        sb.append(", relationshipName='").append(relationshipName).append('\'');
        sb.append(", createdBy='").append(createdBy).append('\'');
        sb.append(", updatedBy='").append(updatedBy).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", lastUpdateDateTime=").append(lastUpdateDateTime);
        sb.append(", otherRelationship='").append(otherRelationship).append('\'');
        sb.append(", reasonCode='").append(reasonCode).append('\'');
        sb.append(", otherReason='").append(otherReason).append('\'');
        sb.append('}');
        return sb.toString();
    }
}


