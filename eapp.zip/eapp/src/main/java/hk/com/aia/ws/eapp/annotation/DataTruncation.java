package hk.com.aia.ws.eapp.annotation;


import java.lang.annotation.*;

@Documented
@Target({ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
public @interface DataTruncation {

    int max() default 1000;

    boolean validateByte() default false;

    boolean log() default false;

}
