package hk.com.aia.ws.eapp.model.db.magnum.ipos.idclass;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TPrcDocId implements Serializable {
    private static final long serialVersionUID = -3834522387881458809L;
    private String iverifyId;
    private String clientID;
    private Integer docSeq;
    private String docId;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TPrcDocId{");
        sb.append("iverifyId='").append(iverifyId).append('\'');
        sb.append(", clientID='").append(clientID).append('\'');
        sb.append(", docSeq=").append(docSeq);
        sb.append(", docId='").append(docId).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
