package hk.com.aia.ws.eapp.model.base;

import hk.com.aia.ws.eapp.util.ConversionHandler;
import lombok.Data;

@Data
public class TimeLog {
    private String policyNo;
    private String nbStartTime;
    private String nbEndTime;
    private String peStartTime;
    private String peEndTime;
    private String asStartTime;
    private String asEndTime;
    private String cmStartTime;
    private String cmEndTime;
    private String ehStartTime;
    private String ehEndTime;
    private String acStartTime;
    private String acEndTime;
    private String viStartTime;
    private String viEndTime;
    private String nbInd;
    private String peInd;
    private String asInd;
    private String cmInd;
    private String ehInd;
    private String acInd;
    private String viInd;
    private String user;
    private String nbErrorMsg;
    private String peErrorMsg;
    private String asErrorMsg;
    private String cmErrorMsg;
    private String ehErrorMsg;
    private String viErrorMsg;
    private String coiErrorMsg;
    private String coiInd;
    private String coiStartTime;
    private String coiEndTime;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TimeLog{");
        sb.append("policyNo='").append(ConversionHandler.mask(policyNo)).append('\'');
        sb.append(", nbStartTime='").append(nbStartTime).append('\'');
        sb.append(", nbEndTime='").append(nbEndTime).append('\'');
        sb.append(", peStartTime='").append(peStartTime).append('\'');
        sb.append(", peEndTime='").append(peEndTime).append('\'');
        sb.append(", asStartTime='").append(asStartTime).append('\'');
        sb.append(", asEndTime='").append(asEndTime).append('\'');
        sb.append(", cmStartTime='").append(cmStartTime).append('\'');
        sb.append(", cmEndTime='").append(cmEndTime).append('\'');
        sb.append(", ehStartTime='").append(ehStartTime).append('\'');
        sb.append(", ehEndTime='").append(ehEndTime).append('\'');
        sb.append(", acStartTime='").append(acStartTime).append('\'');
        sb.append(", acEndTime='").append(acEndTime).append('\'');
        sb.append(", viStartTime='").append(viStartTime).append('\'');
        sb.append(", viEndTime='").append(viEndTime).append('\'');
        sb.append(", nbInd='").append(nbInd).append('\'');
        sb.append(", peInd='").append(peInd).append('\'');
        sb.append(", asInd='").append(asInd).append('\'');
        sb.append(", cmInd='").append(cmInd).append('\'');
        sb.append(", ehInd='").append(ehInd).append('\'');
        sb.append(", acInd='").append(acInd).append('\'');
        sb.append(", viInd='").append(viInd).append('\'');
        sb.append(", user='").append(user).append('\'');
        sb.append(", nbErrorMsg='").append(nbErrorMsg).append('\'');
        sb.append(", peErrorMsg='").append(peErrorMsg).append('\'');
        sb.append(", asErrorMsg='").append(asErrorMsg).append('\'');
        sb.append(", cmErrorMsg='").append(cmErrorMsg).append('\'');
        sb.append(", ehErrorMsg='").append(ehErrorMsg).append('\'');
        sb.append(", viErrorMsg='").append(viErrorMsg).append('\'');
        sb.append(", coiErrorMsg='").append(coiErrorMsg).append('\'');
        sb.append(", coiInd='").append(coiInd).append('\'');
        sb.append(", coiStartTime='").append(coiStartTime).append('\'');
        sb.append(", coiEndTime='").append(coiEndTime).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
