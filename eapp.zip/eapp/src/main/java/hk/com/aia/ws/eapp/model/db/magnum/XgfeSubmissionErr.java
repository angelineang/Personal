package hk.com.aia.ws.eapp.model.db.magnum;

import hk.com.aia.ws.eapp.util.ConversionHandler;
import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Data
@Entity
@Table(name = "tbl_xgfe_submission_err")
@EntityListeners(AuditingEntityListener.class)
public class XgfeSubmissionErr {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "pol_no")
    private String polNo;

    @Column(name = "http_status_code")
    private int httpStatusCode;

    @Column(name = "description")
    private String description;

    @Column(name = "status")
    private String status;

    @Column(name = "type")
    private String type;

    @Column(name = "retry")
    private int retry = 0;

    @Column(name = "submission_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date submissionDate;

    @Column(name = "created_date")
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDate;

    @Column(name = "last_modified_date")
    @Temporal(TemporalType.TIMESTAMP)
    @LastModifiedDate
    private Date lastModifiedDate;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("XgfeSubmissionErr{");
        sb.append("id=").append(id);
        sb.append(", polNo='").append(ConversionHandler.mask(polNo)).append('\'');
        sb.append(", httpStatusCode=").append(httpStatusCode);
        sb.append(", description='").append(description).append('\'');
        sb.append(", status='").append(status).append('\'');
        sb.append(", type='").append(type).append('\'');
        sb.append(", retry=").append(retry);
        sb.append(", submissionDate=").append(submissionDate);
        sb.append(", createdDate=").append(createdDate);
        sb.append(", lastModifiedDate=").append(lastModifiedDate);
        sb.append('}');
        return sb.toString();
    }
}
