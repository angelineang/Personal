package hk.com.aia.ws.eapp.model.request.ipos;

import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.annotation.DateTimeValidation;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.util.Date;

@ApiModel(value = "T_EAPPAUDIOANSWER Model")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TEappAudioAnswerDto {
    @ApiModelProperty(value = "audio answer Id ", required = true)
    @JsonProperty("audio_answer_id")
    @Size(max = 60)
    @NotBlank
    private String audioAnswerId;

    @ApiModelProperty(value = "eapp Id")
    @JsonProperty("eapp_id")
    @Size(max = 60)
    private String eappId;

    @ApiModelProperty(value = "answer")
    @JsonProperty("answer")
    @Size(max = 50)
    private String answer;

    @ApiModelProperty(value = "audio date")
    @JsonProperty("audio_date")
    private Date audioDate;

    @ApiModelProperty(value = "start time ")
    @JsonProperty("start_time")
    @Size(max = 10)
    @DateTimeValidation(format = "HH:mm")
    private String startTime;

    @ApiModelProperty(value = "end time ")
    @JsonProperty("end_time")
    @Size(max = 10)
    @DateTimeValidation(format = "HH:mm")
    private String endTime;

    @ApiModelProperty(value = "opt in audio ")
    @JsonProperty("opt_in_audio")
    @Size(max = 4)
    private String optInAudio;

    @ApiModelProperty(value = "opt out audio ")
    @JsonProperty("opt_out_audio")
    @Size(max = 4)
    private String optOutAudio;

    @ApiModelProperty(value = "others content ")
    @JsonProperty("others_content")
    @Size(max = 1000)
    private String othersContent;

    @ApiModelProperty(value = "ifsdasigndate")
    @JsonProperty("ifsda_sign_date")
    private Date ifsdaSignDate;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TEappAudioAnswerDto{");
        sb.append("audioAnswerId='").append(audioAnswerId).append('\'');
        sb.append(", eappId='").append(eappId).append('\'');
        sb.append(", answer='").append(answer).append('\'');
        sb.append(", audioDate=").append(audioDate);
        sb.append(", startTime='").append(startTime).append('\'');
        sb.append(", endTime='").append(endTime).append('\'');
        sb.append(", optInAudio='").append(optInAudio).append('\'');
        sb.append(", optOutAudio='").append(optOutAudio).append('\'');
        sb.append(", othersContent='").append(othersContent).append('\'');
        sb.append(", ifsdaSignDate='").append(ifsdaSignDate).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
