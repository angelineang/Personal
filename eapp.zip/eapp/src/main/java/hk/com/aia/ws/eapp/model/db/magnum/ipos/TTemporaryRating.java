package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import hk.com.aia.ws.eapp.model.db.magnum.ipos.idclass.TTemporaryRatingId;
import lombok.Data;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@Table(name = "T_TEMPORARYRATING")
@IdClass(TTemporaryRatingId.class)
@EntityListeners(AuditingEntityListener.class)
public class TTemporaryRating {

    @Column(name = "TEMPORARYRATINGID", length = 60)
    @Id
    private String temporaryRatingId;

    @Column(name = "AGENTCODE", length = 10)
    private String agentCode;

    @Column(name = "ACCESSCODE", length = 30)
    private String accessCode;

    @Column(name = "PLANSELECTIONID", length = 60)
    @Id
    private String planSelectionId;

    @Column(name = "RATINGTYPE")
    private Integer ratingType;

    @Column(name = "RATING")
    private Double rating;

    @Column(name = "RATINGUNIT", length = 20)
    private String ratingUnit;

    @Column(name = "DURATION")
    private Integer duration;

    @Column(name = "CREATEDBY", length = 10, updatable = false)
    @CreatedBy
    private String createdBy;

    @Column(name = "UPDATEDBY", length = 10)
    @LastModifiedBy
    private String updatedBy;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "LASTUPDATEDATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    @LastModifiedDate
    private Date lastUpdateDateTime;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TTemporaryRating{");
        sb.append("temporaryRatingId='").append(temporaryRatingId).append('\'');
        sb.append(", agentCode='").append(agentCode).append('\'');
        sb.append(", accessCode='").append(accessCode).append('\'');
        sb.append(", planSelectionId='").append(planSelectionId).append('\'');
        sb.append(", ratingType=").append(ratingType);
        sb.append(", rating=").append(rating);
        sb.append(", ratingUnit='").append(ratingUnit).append('\'');
        sb.append(", duration=").append(duration);
        sb.append(", createdBy='").append(createdBy).append('\'');
        sb.append(", updatedBy='").append(updatedBy).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", lastUpdateDateTime=").append(lastUpdateDateTime);
        sb.append('}');
        return sb.toString();
    }
}