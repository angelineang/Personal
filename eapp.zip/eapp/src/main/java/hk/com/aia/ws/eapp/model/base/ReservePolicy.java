package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.model.request.Request;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.math.BigDecimal;

@ApiModel(value = "Reserve Policy Model", parent = Request.class)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class ReservePolicy extends Payload {

    //Size maxed determined by max allowed by stored procedures - db_magnum..po_ipos_chk_pna and db_magnum..po_ipos_mark_pna

    @ApiModelProperty(value = "Company Code", required = true)
    @JsonProperty("comp_no")
    @NotBlank(message = "company no is required.")
    @Size(min = 3, max = 3)
    private String compNo;

    @ApiModelProperty(value = "Agent Code", required = true)
    @JsonProperty("agent_code")
    @NotBlank(message = "agent code is required.")
    @Size(min = 5, max = 5)
    private String agentCode;

    @ApiModelProperty(value = "Reference Number", required = true)
    @JsonProperty("ref_no")
    @NotBlank(message = "Reference number is required.")
    private String refNo;

    @ApiModelProperty(value = "Plan short name")
    @JsonProperty("plan_short_name")
    @NotBlank(message = "Plan short name is required.")
    private String planShortName;

    @ApiModelProperty(value = "Plan sum assured")
    @JsonProperty("sum_assured")
    /*@Pattern(regexp = "^[0-9]{1,15}(?:\\.[0-9]{1,2})?$")*/
    @Digits(integer = 15, fraction = 2)
    private BigDecimal sumAssured;

    @ApiModelProperty(value = "Policy number")
    @JsonProperty("policy_no")
    private String policyNo;

    @ApiModelProperty(value = "Insured name")
    @JsonProperty("insured_name")
    private String insuredName;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("ReservePolicy{");
        sb.append("compNo='").append(compNo).append('\'');
        sb.append(", agentCode='").append(agentCode).append('\'');
        sb.append(", refNo='").append(refNo).append('\'');
        sb.append(", planShortName='").append(planShortName).append('\'');
        sb.append(", sumAssured=").append(sumAssured);
        sb.append(", policyNo='").append(ConversionHandler.mask(policyNo)).append('\'');
        sb.append(", insuredName='").append(ConversionHandler.mask(insuredName)).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
