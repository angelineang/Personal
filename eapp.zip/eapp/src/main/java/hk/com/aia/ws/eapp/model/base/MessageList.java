package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MessageList {

	 @JsonProperty("message_id")
	 private String MESSAGE_ID;
	 
	 @JsonProperty("message_en")
	 private String MESSAGE_EN;
	 
	 @JsonProperty("message_zn_cn")
	 private String MESSAGE_ZN_CN;
	 
	 @JsonProperty("message_zn_hk")
	 private String MESSAGE_ZN_HK;

	 @JsonProperty("pend_info")
	 private String pendInfo;

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder("MessageList{");
		sb.append("MESSAGE_ID='").append(MESSAGE_ID).append('\'');
		sb.append(", MESSAGE_EN='").append(MESSAGE_EN).append('\'');
		sb.append(", MESSAGE_ZN_CN='").append(MESSAGE_ZN_CN).append('\'');
		sb.append(", MESSAGE_ZN_HK='").append(MESSAGE_ZN_HK).append('\'');
		sb.append(", pendInfo='").append(pendInfo).append('\'');
		sb.append('}');
		return sb.toString();
	}
}
