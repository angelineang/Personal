package hk.com.aia.ws.eapp.model.db.magnum.ichange;

import hk.com.aia.ws.eapp.model.db.magnum.ichange.idclass.TblEappBatchDataId;
import lombok.Data;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "tbl_eapp_batch_data")
@IdClass(TblEappBatchDataId.class)
public class TblEappBatchData {

    @Column(name = "batch_id", length = 19)
    @Id
    private String batchId;

    @Column(name = "policy_no", length = 10)
    @Id
    private String policyNo;

    @Column(name = "request_no", length = 15)
    private String requestNo;

    @Column(name = "field_name", length = 60)
    @Id
    private String fieldName;

    @Column(name = "field_value", length = 2800)
    private String fieldValue;

    @Column(name = "last_update")
    @Temporal(TemporalType.TIMESTAMP)
    @LastModifiedDate
    private Date lastUpdate;

    @Column(name = "seq")
    @Id
    private Integer sequence;

    @Column(name = "doc_id")
    private String docId;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TblEappBatchData{");
        sb.append("batchId='").append(batchId).append('\'');
        sb.append(", policyNo='").append(policyNo).append('\'');
        sb.append(", requestNo='").append(requestNo).append('\'');
        sb.append(", fieldName='").append(fieldName).append('\'');
        sb.append(", fieldValue='").append(fieldValue).append('\'');
        sb.append(", lastUpdate=").append(lastUpdate);
        sb.append(", seq='").append(sequence).append('\'');
        sb.append(", docId='").append(docId).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
