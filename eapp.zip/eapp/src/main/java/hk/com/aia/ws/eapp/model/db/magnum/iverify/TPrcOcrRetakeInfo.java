package hk.com.aia.ws.eapp.model.db.magnum.iverify;

import lombok.Data;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@Table(name = "T_PRC_OCR_RETAKE_INFO")
@EntityListeners(AuditingEntityListener.class)
public class TPrcOcrRetakeInfo {

    @Column(name = "RETAKEINFOID", length = 50)
    @Id
    private String retakeInfoId;

    @Column(name = "IVERIFYID", length = 50)
    private String iverifyID;

    @Column(name = "IMAGETYPE", length = 100)
    private String imageType;

    @Column(name = "ISOCR")
    private Integer isOcr;

    @Column(name = "DOCSEQ")
    private Integer docSeq;

    @Column(name = "RETAKECOUNT")
    private Integer retakeCount;

    @Column(name = "FAILREASONS", length = 200)
    private String failReasons;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @LastModifiedDate
    private Date createdDateTime;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TPrcOcrRetakeInfo{");
        sb.append("retakeInfoId='").append(retakeInfoId).append('\'');
        sb.append(", iverifyID='").append(iverifyID).append('\'');
        sb.append(", imageType='").append(imageType).append('\'');
        sb.append(", isOcr=").append(isOcr);
        sb.append(", docSeq=").append(docSeq);
        sb.append(", retakeCount=").append(retakeCount);
        sb.append(", failReasons='").append(failReasons).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append('}');
        return sb.toString();
    }
}
