package hk.com.aia.ws.eapp.model.db.magnum.ipos.idclass;

import hk.com.aia.ws.eapp.model.db.magnum.ipos.UiUipendBews;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.IdClass;
import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UiUipendBewsId implements Serializable {
    private static final long serialVersionUID = 4000258928784591220L;
    private String policyNo;
    private String requestNo;
    private String lob;
    private String pendId;
}
