package hk.com.aia.ws.eapp.adapter;

import hk.com.aia.ws.eapp.model.db.magnum.SubTaskletUser;
import hk.com.aia.ws.eapp.model.properties.TaskProperties;
import hk.com.aia.ws.eapp.service.LogService;
import hk.com.aia.ws.eapp.service.SubTaskletUserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.concurrent.atomic.AtomicInteger;


@Slf4j
@RequiredArgsConstructor
@Component
public class ThreadSchedulerAdapter {

    public static final String BUSY_USER = "BUSY";
    public static final String NO_USER = "NO USER";
    private final AtomicInteger atomicInteger = new AtomicInteger();
    private final ConcurrentLinkedDeque<String> concurrentLinkedDeque = new ConcurrentLinkedDeque<>();
    private final List<SubTaskletUser> subTaskletUsers = new ArrayList<>();

    @Autowired
    private final TaskProperties taskProperties;

    @Autowired
    private final SubTaskletUserService subTaskletUserService;

    @Autowired
    LogService logService;
    
    @PostConstruct
    public void constructUserRandomList() {
    	logService.logEventIntegration("constructUserRandomList -Start Daemon");
        List<SubTaskletUser> users = subTaskletUserService.getAvailableUsers(taskProperties.getPoolSize());
        subTaskletUsers.addAll(users);
        
        String userListStr="";
        for (SubTaskletUser subTaskletUser : users) {
        	
        	userListStr=userListStr+subTaskletUser.getTaskUserName();
        	
		}
        logService.logEventIntegration("constructUserRandomList -userId assigned :" +userListStr);
    }

    private int index(int size) {
        int i = atomicInteger.getAndIncrement();
        if (i >= size) {
            atomicInteger.set(0);
            return index(size);
        }
        return i;
    }

    @PreDestroy
    public void releaseSubTaskletUsersDB() {
    	logService.logEventIntegration("End Daemon");
        subTaskletUsers.forEach(
                u -> {
                    u.setLock(false);
                    subTaskletUserService.releaseLockUsers(u);
                    log.info("releaseSubTaskletUsersDB -userId released " ,u.getTaskUserName());
                }
        );
       
        logService.logEventIntegration("userId released");
    }

	public String registerCurrentThreadWithUser() {

		int size = subTaskletUsers.size();

		if (size == 0) {
			log.info(
					"No user found or all users are locked. Kindly manually patch the lock status for the users in database.");
			constructUserRandomList();
			return NO_USER;
		}

		int i = index(size);
		String currentUser = subTaskletUsers.get(i).getTaskUserName();

		if (concurrentLinkedDeque.contains(currentUser)) {
			log.info("registerCurrentThreadWithUser - current user is busy. userid={} ,size={} , i= {} , ", currentUser, size, i);
			return BUSY_USER;
		} else {

			concurrentLinkedDeque.add(currentUser);
			log.info("registerCurrentThreadWithUser - added userid={} ,size={} , i= {}", currentUser, size, i);
		}
		return currentUser;
	}

	public void releaseCurrentUserFromThread(String currentUser) {

		concurrentLinkedDeque.remove(currentUser);
		log.info("releaseCurrentUserFromThread - user {}", currentUser);
	}
}
