package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@ApiModel(value = "Impairment model")
@Data
public class Impairment {

    // Size values comes from sp - po_ms_ins_staging_impairment

    @ApiModelProperty(value = "Name Number", example = "01")
    @JsonProperty(value = "name_no", required = true)
    @Size(max = 2)
    @NotBlank
    private String nameNo;

    @ApiModelProperty(value = "Impair Number", example = "01")
    @JsonProperty(value = "impair_no", required = true)
    @Size(max = 2)
    @NotBlank
    private String impairNo;

    @ApiModelProperty(value = "Impair Code", example = "IMORZ")
    @JsonProperty(value = "impair_code", required = true)
    @Size(max = 5)
    @NotBlank
    private String impairCode;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Impairment{");
        sb.append("nameNo='").append(nameNo).append('\'');
        sb.append(", impairNo='").append(impairNo).append('\'');
        sb.append(", impairCode='").append(impairCode).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
