package hk.com.aia.ws.eapp.model.request.ipos;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@ApiModel(value = "T_CITIINSPRODUCTTYPE Model")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TCitiInsProductTypeDto {

	@ApiModelProperty(value = "citi Ins Product Type Id", required = true)
    @JsonProperty("citi_ins_product_type_id")
	@Size(max = 60)
    @NotBlank
    private String citiInsProductTypeId;

    @JsonProperty("fna_id")
    @Size(max = 60)
    private String fnaId;

    @JsonProperty("product_type_check")
    @Size(max = 50)
    private String productTypeCheck;

    @JsonProperty("other_type_spec")
    @Size(max = 200)
    private String otherTypeSpec;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TCitiInsProductTypeDto{");
        sb.append("citiInsProductTypeId='").append(citiInsProductTypeId).append('\'');
        sb.append(", fnaId='").append(fnaId).append('\'');
        sb.append(", productTypeCheck='").append(productTypeCheck).append('\'');
        sb.append(", otherTypeSpec='").append(otherTypeSpec).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
