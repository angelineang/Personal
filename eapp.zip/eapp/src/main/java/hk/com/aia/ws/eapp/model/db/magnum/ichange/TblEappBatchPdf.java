package hk.com.aia.ws.eapp.model.db.magnum.ichange;

import hk.com.aia.ws.eapp.model.db.magnum.ichange.idclass.TblEappBatchPdfId;
import lombok.Data;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "tbl_eapp_batch_pdf")
@IdClass(TblEappBatchPdfId.class)
public class TblEappBatchPdf {

    @Column(name = "batch_id", length = 19)
    @Id
    private String batchId;

    @Column(name = "seq")
    @Id
    private Integer sequence;

    @Column(name = "doc_id", length = 8)
    @Id
    private String docId;

    @Column(name = "content_type", length = 30)
    @Id
    private String contentType;

    @Column(name = "last_update")
    @Temporal(TemporalType.TIMESTAMP)
    @LastModifiedDate
    private Date lastUpdate;

    @Column(name = "pdf_img")
    private byte[] pdfImage;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TblEappBatchPdf{");
        sb.append("batchId='").append(batchId).append('\'');
        sb.append(", seq='").append(sequence).append('\'');
        sb.append(", docId='").append(docId).append('\'');
        sb.append(", contentType='").append(contentType).append('\'');
        sb.append(", lastUpdate=").append(lastUpdate);
        sb.append('}');
        return sb.toString();
    }
}
