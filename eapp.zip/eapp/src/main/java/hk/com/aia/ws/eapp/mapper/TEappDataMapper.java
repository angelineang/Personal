package hk.com.aia.ws.eapp.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import hk.com.aia.ws.eapp.model.db.magnum.ipos.TEappData;
import hk.com.aia.ws.eapp.model.request.ipos.TEappDataDto;

@Mapper
public interface TEappDataMapper {
	TEappDataMapper MAPPER = Mappers.getMapper(TEappDataMapper.class);

    List<TEappData> mapToTEappDataList(List<TEappDataDto> tEappDataDto);

}
