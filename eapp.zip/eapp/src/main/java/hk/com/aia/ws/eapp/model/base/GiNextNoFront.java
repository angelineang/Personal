package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class GiNextNoFront {

    @JsonProperty("coi_master_next_no_front")
    private CoiMasterNextNoFront coiMasterNextNoFront;

    @JsonProperty("gi_credit_balance_front")
    private GiCreditBalanceFront giCreditBalanceFront;

    @JsonProperty("gi_tx_credit_balance_front")
    private GiTxCreditBalanceFront giTxCreditBalanceFront;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("GiNextNoFront{");
        sb.append("coiMasterNextNoFront=").append(coiMasterNextNoFront);
        sb.append(", giCreditBalanceFront=").append(giCreditBalanceFront);
        sb.append(", giTxCreditBalanceFront=").append(giTxCreditBalanceFront);
        sb.append('}');
        return sb.toString();
    }
}
