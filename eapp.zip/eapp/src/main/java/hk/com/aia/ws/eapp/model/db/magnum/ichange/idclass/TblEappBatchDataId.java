package hk.com.aia.ws.eapp.model.db.magnum.ichange.idclass;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TblEappBatchDataId implements Serializable {

    private static final long serialVersionUID = 4000258928784591220L;
    private String batchId;
    private String policyNo;
    private String fieldName;
    private Integer sequence;

}
