package hk.com.aia.ws.eapp.controller;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import hk.com.aia.ws.eapp.constant.Constants;
import hk.com.aia.ws.eapp.model.base.Payload;
import hk.com.aia.ws.eapp.model.response.Response;
import hk.com.aia.ws.eapp.model.response.error.GatewayError400;
import hk.com.aia.ws.eapp.model.response.error.GatewayError401;
import hk.com.aia.ws.eapp.model.response.error.InternalError500;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.AllArgsConstructor;

@AllArgsConstructor
@RestController
@Api(value = "ping", tags = { "API(s) for ping" })
public class PingController {
	@ApiOperation(value = "Server heartbeat operation.")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "OK"),
			@ApiResponse(code = 400, message = "Bad Request", response = GatewayError400.class),
			@ApiResponse(code = 401, message = "Unauthorized", response = GatewayError401.class),
			@ApiResponse(code = 404, message = "Invalid request.", response = Response.class),
			@ApiResponse(code = 500, message = "Internal Server Error", response = InternalError500.class) })

	@PostMapping(value = "/ping", produces = MediaType.APPLICATION_JSON_VALUE)
	public Response<Payload> ping() {
		Response<Payload> response = new Response();
		response.setStatus(Constants.OK);

		return response;
	}

	@GetMapping(value = "/ping", produces = MediaType.APPLICATION_JSON_VALUE)
	public Response<Payload> getPing() {

		return ping();
	}
}
