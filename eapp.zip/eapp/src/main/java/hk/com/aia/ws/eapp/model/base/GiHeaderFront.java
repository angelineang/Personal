package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@ApiModel(value = "GI Header Front Model")
@Data
public class GiHeaderFront {

    @ApiModelProperty(value = "Accumulated discount")
    @JsonProperty("accumulated_discount")
    private Double accumulatedDiscount;

    @ApiModelProperty(value = "Application date", example = "2000-12-31 12:59:59", notes = "format:yyyy-MM-dd HH:mm:ss")
    @JsonProperty("application_date")
    private String applicationDate;

    @ApiModelProperty(value = "Commission amount")
    @JsonProperty("commission_amount")
    private Double commissionAmount;

    @ApiModelProperty(value = "Contract Version")
    @JsonProperty("contract_version")
    private String contractVersion;

    @ApiModelProperty(value = "Credit used")
    @JsonProperty("credit_used")
    private Double creditUsed;

    @ApiModelProperty(value = "Customer type")
    @JsonProperty("customer_type")
    private String customerType;

    @ApiModelProperty(value = "Delta days")
    @JsonProperty("delta_days")
    private Integer deltaDays;

    @ApiModelProperty(value = "Discount amount")
    @JsonProperty("discount_amt")
    private Double discountAmt;

    @ApiModelProperty(value = "Gi from date", example = "2000-12-31", notes = "format:yyyy-MM-dd")
    @JsonProperty("gi_from_date")
    private String giFromDate;

    @ApiModelProperty(value = "Gi number")
    @JsonProperty("gi_no")
    private String giNo;

    @ApiModelProperty(value = "Gi to date", example = "2000-12-31", notes = "format:yyyy-MM-dd")
    @JsonProperty("gi_to_date")
    private String giToDate;

    //TODO - this is a presumption
    @ApiModelProperty(value = "Gi version")
    @JsonProperty("gi_ver")
    private Integer giVer;

    @ApiModelProperty(value = "Levy amount")
    @JsonProperty("levy_amt")
    private Double levyAmt;

    @ApiModelProperty(value = "Levy effective date", example = "2000-12-31", notes = "format:yyyy-MM-dd")
    @JsonProperty("levy_effective_date")
    private String levyEffectiveDate;

    @ApiModelProperty(value = "Pay mode")
    @JsonProperty("pay_mode")
    private String payMode;

    @ApiModelProperty(value = "Policy number")
    @JsonProperty("pol_no")
    private String polNo;

    @ApiModelProperty(value = "Premium amount")
    @JsonProperty("prem_amt")
    private Double premAmt;

    @ApiModelProperty(value = "Promotion Code")
    @JsonProperty("promotion_code")
    private String promotionCode;

    @ApiModelProperty(value = "Request type")
    @JsonProperty("request_type")
    private String requestType;

    @ApiModelProperty(value = "Rider contract version")
    @JsonProperty("rider_contract_version")
    private String riderContractVersion;

    @ApiModelProperty(value = "Status")
    @JsonProperty("status")
    private String status;

    //    @ApiModelProperty(value = "Coupon used")
    //    @JsonProperty("coupon_used")
    //    private Double couponUsed;

    //    @ApiModelProperty(value = "Plan code")
    //    @JsonProperty("plan_code")
    //    private String planCode;


    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("GiHeaderFront{");
        sb.append("accumulatedDiscount=").append(accumulatedDiscount);
        sb.append(", applicationDate='").append(applicationDate).append('\'');
        sb.append(", commissionAmount=").append(commissionAmount);
        sb.append(", contractVersion='").append(contractVersion).append('\'');
        sb.append(", creditUsed=").append(creditUsed);
        sb.append(", customerType='").append(customerType).append('\'');
        sb.append(", deltaDays=").append(deltaDays);
        sb.append(", discountAmt=").append(discountAmt);
        sb.append(", giFromDate='").append(giFromDate).append('\'');
        sb.append(", giNo='").append(giNo).append('\'');
        sb.append(", giToDate='").append(giToDate).append('\'');
        sb.append(", giVer=").append(giVer);
        sb.append(", levyAmt=").append(levyAmt);
        sb.append(", levyEffectiveDate='").append(levyEffectiveDate).append('\'');
        sb.append(", payMode='").append(payMode).append('\'');
        sb.append(", polNo='").append(polNo).append('\'');
        sb.append(", premAmt=").append(premAmt);
        sb.append(", promotionCode='").append(promotionCode).append('\'');
        sb.append(", requestType='").append(requestType).append('\'');
        sb.append(", riderContractVersion='").append(riderContractVersion).append('\'');
        sb.append(", status='").append(status).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
