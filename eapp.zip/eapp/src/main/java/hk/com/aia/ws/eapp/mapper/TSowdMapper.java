package hk.com.aia.ws.eapp.mapper;

import hk.com.aia.ws.eapp.model.db.magnum.ipos.TSowd;
import hk.com.aia.ws.eapp.model.request.ipos.TSowdDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper
public interface TSowdMapper {

    TSowdMapper MAPPER = Mappers.getMapper(TSowdMapper.class);

    @Mapping(target = "createdDateTime", ignore = true)
    List<TSowd> mapToTSowdList(List<TSowdDto> tSowdDto);
}
