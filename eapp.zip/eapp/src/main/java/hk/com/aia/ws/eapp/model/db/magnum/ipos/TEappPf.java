package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import hk.com.aia.ws.eapp.util.ConversionHandler;
import lombok.Data;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@Table(name = "T_EAPP_PF")
@EntityListeners(AuditingEntityListener.class)
public class TEappPf {

	@Column(name = "EAPPID")
	@Id
	private String eappId;

	@Column(name = "USEPF")
	private String usePf;

	@Column(name = "LIQUIDASSETS")
	private Double liquidAssets;

	@Column(name = "PFAMOUNT")
	private Double pfAmount;

	@Column(name = "LONGLIABILITY")
	private Double longLiability;

	@Column(name = "SHORTLIABILITY")
	private Double shortLiability;

	@Column(name = "NOPFREASON")
	private String noPfReason;

	@Column(name = "DISCLOSEPF")
	private String disclosePf;

	@Column(name = "IFSPFSELECTED")
	private String ifspfSelected;

	@Column(name = "PFOPTION")
	private String pfOption;

	@Column(name = "LENDERNAME")
	private String lenderName;

	@Column(name = "OTHERLENDER")
	private String otherLender;

	@Column(name = "PFLOANAMOUNT")
	private Double pfLoanAmount;

	@Column(name = "PFINTERESTRATE")
	private String pfInterestRate;

	@Column(name = "PFITENOR")
	private Integer pfItenor;

	@Column(name = "PFPITENOR")
	private Integer pfpItenor;
	
	@Column(name = "TENOROPTION")
	private String tenorReason;

	@Column(name = "PFREPAYMENTAMOUNT")
	private Double pfRepaymentAmount;

	@Column(name = "IFSPFRECEIVED")
	private String ifspfReceived;

	@Column(name = "IFSPFSIGNDATE")
	private String ifspfSignDate;

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder("TEappExpand{");
		sb.append('}');
		return sb.toString();
	}

}
