package hk.com.aia.ws.eapp.configuration;

import hk.com.aia.ws.eapp.model.base.Payload;
import hk.com.aia.ws.eapp.model.base.RestEntity;
import hk.com.aia.ws.eapp.model.properties.ApiProperties;
import hk.com.aia.ws.eapp.model.properties.CoiProperties;
import hk.com.aia.ws.eapp.model.properties.PnaProperties;
import hk.com.aia.ws.eapp.model.properties.SFTPProperties;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.data.domain.AuditorAware;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import springfox.bean.validators.configuration.BeanValidatorPluginsConfiguration;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Slf4j
@EnableSwagger2
@Configuration
@Import({BeanValidatorPluginsConfiguration.class, AzureBlobConfiguration.class})
@EnableJpaAuditing(auditorAwareRef = "auditorProvider")
public class BeanConfiguration {

    @Bean
    public Docket api() {

        final ApiProperties apiProperties = apiProperties();

        return new Docket(DocumentationType.SWAGGER_2)
                .host(apiProperties.getHostName())
                .ignoredParameterTypes(Payload.class, RestEntity.class)
                .select()
                .apis(RequestHandlerSelectors.basePackage("hk.com.aia.ws"))
                .paths(PathSelectors.ant("/**"))
                .build()
                .apiInfo(customAPI(apiProperties));
    }

    @Bean
    public ApiInfo customAPI(ApiProperties apiProperties) {

        return new ApiInfoBuilder()
                .title(apiProperties.getTitle())
                .description(apiProperties.getDescription())
                .license("")
                .licenseUrl("")
                .version(apiProperties.getVersion())
                .contact(new Contact("", "", ""))
                .build();
    }

    @Bean
    @ConfigurationProperties(prefix = "springdoc")
    public ApiProperties apiProperties() {
        return new ApiProperties();
    }

    @Bean(name = "pnaProperties")
    @ConfigurationProperties(prefix = "ws.pna")
    public PnaProperties pnaProperties() {
        return new PnaProperties();
    }

    @Bean(name = "coiProperties")
    @ConfigurationProperties(prefix = "ws.coi")
    public CoiProperties coiProperties() {
        return new CoiProperties();
    }

    @Bean
    AuditorAware<String> auditorProvider() {
        return new AuditorAwareImpl();
    }

    @Bean(name = "sftpProperties")
    @ConfigurationProperties(prefix = "citi.sftp")
    public SFTPProperties sftpProperties() {
        return new SFTPProperties();
    }

}
