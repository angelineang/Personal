package hk.com.aia.ws.eapp.model.base;

import lombok.Data;

@Data
public class ResponseMetaInfo {
    private Long completedTime;
    private ResponseMessage[] messages;
}
