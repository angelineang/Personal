package hk.com.aia.ws.eapp.exception;

import lombok.Getter;

@Getter
public class FileProcessorException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    private final String code;
    private final String message;

    public FileProcessorException(String code, String message) {
        super();
        this.code = code;
        this.message = message;
    }
}
