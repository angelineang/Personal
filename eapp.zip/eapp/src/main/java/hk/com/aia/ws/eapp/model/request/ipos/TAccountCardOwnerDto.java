package hk.com.aia.ws.eapp.model.request.ipos;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@ApiModel(value = "T_AccountCardOwner Model")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TAccountCardOwnerDto {

	@ApiModelProperty(value = "account Card Owner Id", required = true) 
    @JsonProperty("account_card_owner_id")
	@Size(max = 60)
    @NotBlank
    private String accountCardOwnerId;

    @JsonProperty("payment_detail_id")
	@Size(max = 60)
    private String paymentDetailId;

    @JsonProperty("owner_name")
	@Size(max = 100)
    private String ownerName;

    @JsonProperty("id_doc_sequence")
    private Integer idDocSequence;

    @JsonProperty("id_doc_type")
	@Size(max = 1)
    private String idDocType;

    @JsonProperty("id_doc_name")
	@Size(max = 30)
    private String idDocName;

    @JsonProperty("id_doc_no")
	@Size(max = 18)
    private String idDocNo;

    @JsonProperty("relationship")
	@Size(max = 60)
    private String relationship;

    @JsonProperty("relationship_other_text")
	@Size(max = 80)
    private String relationshipOtherText;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TAccountCardOwnerDto{");
        sb.append("accountCardOwnerId='").append(ConversionHandler.mask(accountCardOwnerId)).append('\'');
        sb.append(", paymentDetailId='").append(paymentDetailId).append('\'');
        sb.append(", ownerName='").append(ConversionHandler.mask(ownerName)).append('\'');
        sb.append(", idDocSequence=").append(idDocSequence);
        sb.append(", idDocType='").append(idDocType).append('\'');
        sb.append(", idDocName='").append(idDocName).append('\'');
        sb.append(", idDocNo='").append(ConversionHandler.mask(idDocNo)).append('\'');
        sb.append(", relationship='").append(relationship).append('\'');
        sb.append(", relationshipOtherText='").append(relationshipOtherText).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
