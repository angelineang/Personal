package hk.com.aia.ws.eapp.model.base.calculator;

import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.model.base.RestEntity;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class PerLifeRequest extends RestEntity {

    @JsonProperty("groupName")
    private String groupName;

    @JsonProperty("reqType")
    private String reqType;

    @JsonProperty("alphaID")
    private String alphaId;
    

    public String generateParameter() {
    	StringBuilder sb = new StringBuilder("?");
        sb.append("reqType=").append(reqType).append("&");
        sb.append("alphaID=").append(alphaId).append("&");
        sb.append("groupName=").append(groupName);
        return sb.toString();
    }

 
    
    
}
