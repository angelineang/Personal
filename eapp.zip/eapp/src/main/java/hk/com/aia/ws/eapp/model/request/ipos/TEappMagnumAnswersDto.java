package hk.com.aia.ws.eapp.model.request.ipos;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@ApiModel(value = "T_EAPPMAGNUMANSWERS Model")
@Data
@NoArgsConstructor
@AllArgsConstructor

public class TEappMagnumAnswersDto {

    @ApiModelProperty(value = "eapp Magnum Answer id", required = true)
    @JsonProperty("eapp_magnum_answer_id")
    @Size(max = 60)
    @NotBlank
    private String eappMagnumAnswerid;

    @JsonProperty("contact_id")
    @Size(max = 60)
    private String contactId;

    @JsonProperty("eapp_id")
    @Size(max = 60)
    private String eappId;

    @JsonProperty("friendly_name")
    @Size(max = 1000)
    private String friendlyName;

    @JsonProperty("question_id")
    @Size(max = 100)
    private String questionId;

    @JsonProperty("q_type")
    @Size(max = 50)
    private String qType;

    @JsonProperty("answers")
    private String answers;

    @JsonProperty("q_text")
    private String qText;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TEappMagnumAnswersDto{");
        sb.append("eappMagnumAnswerid='").append(eappMagnumAnswerid).append('\'');
        sb.append(", contactId='").append(contactId).append('\'');
        sb.append(", eappId='").append(eappId).append('\'');
        sb.append(", friendlyName='").append(friendlyName).append('\'');
        sb.append(", questionId='").append(questionId).append('\'');
        sb.append(", qType='").append(qType).append('\'');
        sb.append(", answers='").append(answers).append('\'');
        sb.append(", qText='").append(qText).append('\'');
        sb.append('}');
        return sb.toString();
    }
}