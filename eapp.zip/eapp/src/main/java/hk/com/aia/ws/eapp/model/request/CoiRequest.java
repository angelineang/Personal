package hk.com.aia.ws.eapp.model.request;

import hk.com.aia.ws.eapp.model.base.GiNextNoFront;
import hk.com.aia.ws.eapp.model.base.RestEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class CoiRequest extends RestEntity {

    private String encodeMethod;
    private String purchaseKey;
    private String resourceOwnerId;
    private String transactionId;
    private GiNextNoFront giNextNoFront;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("CoiRequest{");
        sb.append("encodeMethod='").append(encodeMethod).append('\'');
        sb.append(", purchaseKey='").append(purchaseKey).append('\'');
        sb.append(", resourceOwnerId='").append(resourceOwnerId).append('\'');
        sb.append(", transactionId='").append(transactionId).append('\'');
        sb.append(", giNextNoFront=").append(giNextNoFront);
        sb.append('}');
        return sb.toString();
    }
}
