package hk.com.aia.ws.eapp.model.db.mag.iverify.idclass;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TPrcDoc2Id implements Serializable {
    private static final long serialVersionUID = 2351178775622651607L;
    private String iverifyId;
    private String docId;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TPrcDoc2Id{");
        sb.append("iverifyId='").append(iverifyId).append('\'');
        sb.append(", docId='").append(docId).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
