package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.annotation.DateTimeValidation;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import java.util.Arrays;

@ApiModel(value = "Submit Document Model")
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@AllArgsConstructor
public class SubmitDocument extends Payload {

    @ApiModelProperty(value = "Channel", example = "IPOS")
    @NotBlank
    @JsonProperty("channel")
    private String channel;

    @ApiModelProperty(value = "Submission Type")
    @NotBlank
    @JsonProperty("submission_type")
    private String type;

    @ApiModelProperty(value = "Reference Number", example = "\"101010\"", required = true)
    @JsonProperty("ref_no")
    @NotBlank
    private String refNo;

    @ApiModelProperty(value = "Policy Number", required = true)
    @JsonProperty("policy_no")
    @NotBlank
    private String policyNo;

    @ApiModelProperty(value = "Current Date - MM/dd/yyyy", example = "10/27/2020")
    @JsonProperty("current_date")
    @DateTimeValidation(format = "MM/dd/yyyy")
    private String currentDate;

    @ApiModelProperty(value = "List of Documents")
    @JsonProperty("documents")
    private EappDocument[] documents;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("SubmitDocument{");
        sb.append("channel='").append(channel).append('\'');
        sb.append(", type='").append(type).append('\'');
        sb.append(", refNo='").append(refNo).append('\'');
        sb.append(", policyNo='").append(ConversionHandler.mask(policyNo)).append('\'');
        sb.append(", currentDate='").append(currentDate).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
