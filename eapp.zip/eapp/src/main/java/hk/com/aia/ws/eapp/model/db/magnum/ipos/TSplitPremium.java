package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import hk.com.aia.ws.eapp.model.db.magnum.ipos.idclass.TSplitPremiumId;
import lombok.Data;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Data
@Table(name = "T_SPLITPREMIUM")
@EntityListeners(AuditingEntityListener.class)
@IdClass(TSplitPremiumId.class)
public class TSplitPremium {

    @Column(name = "SPLITPREMIUMID", length = 60)
    @Id
    private String splitPremiumId;

    @Column(name = "AGENTCODE", length = 10)
    private String agentCode;

    @Column(name = "ACCESSCODE", length = 30)
    private String accessCode;

    @Column(name = "BASICPLANSELECTIONID", length = 60)
    @Id
    private String basicPlanSelectionId;

    @Column(name = "AMOUNT")
    private BigDecimal amount;

    @Column(name = "ATMONTH")
    private Integer atMonth;

    @Column(name = "MONTH")
    private Integer month;

    @Column(name = "CREATEDBY", length = 10, updatable = false)
    @CreatedBy
    private String createdBy;

    @Column(name = "UPDATEDBY", length = 10)
    @LastModifiedBy
    private String updatedBy;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "LASTUPDATEDATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    @LastModifiedDate
    private Date lastUpdateDateTime;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TSplitPremium{");
        sb.append("splitPremiumId='").append(splitPremiumId).append('\'');
        sb.append(", agentCode='").append(agentCode).append('\'');
        sb.append(", accessCode='").append(accessCode).append('\'');
        sb.append(", basicPlanSelectionId='").append(basicPlanSelectionId).append('\'');
        sb.append(", amount=").append(amount);
        sb.append(", atMonth=").append(atMonth);
        sb.append(", month=").append(month);
        sb.append(", createdBy='").append(createdBy).append('\'');
        sb.append(", updatedBy='").append(updatedBy).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", lastUpdateDateTime=").append(lastUpdateDateTime);
        sb.append('}');
        return sb.toString();
    }
}