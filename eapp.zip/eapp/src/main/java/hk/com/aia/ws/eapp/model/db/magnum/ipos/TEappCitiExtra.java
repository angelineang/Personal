package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "T_EAPPCITIEXTRA")
public class TEappCitiExtra {

    @Column(name = "CITIEXTRAID", length = 60)
    @Id
    private String citiExtraId;

    @Column(name = "EAPPID", length = 60)
    private String eappId;

    @Column(name = "FNAID", length = 60)
    private String fnaId;

    @Column(name = "FNADUPLICATEDID", length = 60)
    private String fnaDuplicatedId;

    @Column(name = "CITIGOLD")
    private Integer citiGold;

    @Column(name = "HNW")
    private Integer hnw;

    @Column(name = "IRRACCEPTDECLARATION")
    private Integer irrAcceptDeclaration;

    @Column(name = "IRRACCEPTRECEIPT")
    private Integer irrAcceptReceipt;

    @Column(name = "REFERRERNAME")
    private String referrerName;

    @Column(name = "SOEID", length = 60)
    private String soeId;

    @Column(name = "GEID", length = 60)
    private String geId;

    @Column(name = "PLANCONSULTANT")
    private Integer planConsultant;

    @Column(name = "BRANCHCODE", length = 60)
    private String branchCode;

    @Column(name = "BRANCHCODEOTHERS", length = 60)
    private String branchCodeOthers;

    @Column(name = "BUSINESSGROUP", length = 60)
    private String businessGroup;

    @Column(name = "GUARANTEEDPAYMENTOPTION", length = 10)
    private String guaranteedPaymentOption;

    @Column(name = "CCBCWA")
    private Integer ccbcwa;

    @Column(name = "isSpecialCustomer", length = 1)
    private String isSpecialCustomer;

    @Column(name = "optOutAudio", length = 1)
    private String optOutAudio;

    @Column(name = "audioRecordedDate")
    @Temporal(TemporalType.DATE)
    private Date audioRecordedDate;

    @Column(name = "audioRecordedTime", length = 10)
    private String audioRecordedTime;

    @Column(name = "audioRecordedExt", length = 10)
    private String audioRecordedExt;

    @Column(name = "isPregnancy22Weeks")
    private Integer isPregnancy22Weeks;

    @Column(name = "deferredAnnuityBoxStatus")
    private Integer deferredAnnuityBoxStatus;

    @Column(name = "deferredAnnuityOption")
    private Integer deferredAnnuityOption;

    @Column(name = "isSTT", length = 1)
    private String isStt;

    @Column(name = "SCTReason", length = 50)
    private String sctReason;

    @Column(name = "STTReason", length = 50)
    private String sttReason;

    @Column(name = "STTReasonOther", length = 1000)
    private String sttReasonOther;

    @Column(name = "applyPremiumFinancing", length = 1)
    private String applyPremiumFinancing;

    @Column(name = "eappAudioStatus", length = 5)
    private String eappAudioStatus;

    @Column(name = "eappTickHybridModel", length = 5)
    private String eappTickHybridModel;

    @Column(name = "prcHolder", length = 5)
    private String prcHolder;

    @Column(name = "isTWACus")
    private Integer isTwaCus;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TEappCitiExtra{");
        sb.append("citiExtraId='").append(citiExtraId).append('\'');
        sb.append(", eappId='").append(eappId).append('\'');
        sb.append(", fnaId='").append(fnaId).append('\'');
        sb.append(", fnaDuplicatedId='").append(fnaDuplicatedId).append('\'');
        sb.append(", citiGold=").append(citiGold);
        sb.append(", hnw=").append(hnw);
        sb.append(", irrAcceptDeclaration=").append(irrAcceptDeclaration);
        sb.append(", irrAcceptReceipt=").append(irrAcceptReceipt);
        sb.append(", referrerName='").append(referrerName).append('\'');
        sb.append(", soeId='").append(soeId).append('\'');
        sb.append(", geId='").append(geId).append('\'');
        sb.append(", planConsultant=").append(planConsultant);
        sb.append(", branchCode='").append(branchCode).append('\'');
        sb.append(", branchCodeOthers='").append(branchCodeOthers).append('\'');
        sb.append(", businessGroup='").append(businessGroup).append('\'');
        sb.append(", guaranteedPaymentOption='").append(guaranteedPaymentOption).append('\'');
        sb.append(", ccbcwa=").append(ccbcwa);
        sb.append(", isSpecialCustomer='").append(isSpecialCustomer).append('\'');
        sb.append(", optOutAudio='").append(optOutAudio).append('\'');
        sb.append(", audioRecordedDate=").append(audioRecordedDate);
        sb.append(", audioRecordedTime='").append(audioRecordedTime).append('\'');
        sb.append(", audioRecordedExt='").append(audioRecordedExt).append('\'');
        sb.append(", isPregnancy22Weeks=").append(isPregnancy22Weeks);
        sb.append(", deferredAnnuityBoxStatus=").append(deferredAnnuityBoxStatus);
        sb.append(", deferredAnnuityOption=").append(deferredAnnuityOption);
        sb.append(", isStt='").append(isStt).append('\'');
        sb.append(", sctReason='").append(sctReason).append('\'');
        sb.append(", sttReason='").append(sttReason).append('\'');
        sb.append(", sttReasonOther='").append(sttReasonOther).append('\'');
        sb.append(", applyPremiumFinancing='").append(applyPremiumFinancing).append('\'');
        sb.append(", eappAudioStatus='").append(eappAudioStatus).append('\'');
        sb.append(", eappTickHybridModel='").append(eappTickHybridModel).append('\'');
        sb.append(", prcHolder='").append(prcHolder).append('\'');
        sb.append(", isTwaCus=").append(isTwaCus);
        sb.append('}');
        return sb.toString();
    }
}
