package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "T_ILASFUNDSELECTION")
public class TIlasFundSelection {

    @Column(name = "FUNDSELECTIONID", length = 60)
    @Id
    private String fundSelectionId;

    @Column(name = "EAPPID", length = 60)
    private String eappId;

    @Column(name = "FUNDCODE", length = 5)
    private String fundCode;

    @Column(name = "FUNDNAME", length = 600)
    private String fundName;

    @Column(name = "FUNDGROUP", length = 50)
    private String fundGroup;

    @Column(name = "RICKLEVEL", length = 1)
    private String rickLevel;

    @Column(name = "TOTALALLOC", length = 20)
    private String totalAlloc;

    @Column(name = "SECTION", length = 3)
    private String section;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "EffectiveDate", length = 60)
    private String effectiveDate;

    @Column(name = "PortfolioMatch", length = 1)
    private String portfolioMatch;

    @Column(name = "PortfolioNo", length = 30)
    private String portfolioNo;

    @Column(name = "shownReference", length = 1)
    private String shownReference;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TIlasFundSelection{");
        sb.append("fundSelectionId='").append(fundSelectionId).append('\'');
        sb.append(", eappId='").append(eappId).append('\'');
        sb.append(", fundCode='").append(fundCode).append('\'');
        sb.append(", fundName='").append(fundName).append('\'');
        sb.append(", fundGroup='").append(fundGroup).append('\'');
        sb.append(", rickLevel='").append(rickLevel).append('\'');
        sb.append(", totalAlloc='").append(totalAlloc).append('\'');
        sb.append(", section='").append(section).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", effectiveDate='").append(effectiveDate).append('\'');
        sb.append(", portfolioMatch='").append(portfolioMatch).append('\'');
        sb.append(", portfolioNo='").append(portfolioNo).append('\'');
        sb.append(", shownReference='").append(shownReference).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
