package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Arrays;

@ApiModel(value = "Coi Master Next No Front Model")
@Data
public class CoiMasterNextNoFront {

    @ApiModelProperty(value = "Gi coverage front list")
    @JsonProperty("gi_coverage_front_list")
    private GiCoverageFront[] giCoverageFrontList;

    @ApiModelProperty(value = "Gi header front")
    @JsonProperty("gi_header_front")
    private GiHeaderFront giHeaderFront;

    @ApiModelProperty(value = "Gi life front list")
    @JsonProperty("gi_life_front_list")
    private GiLifeFront[] giLifeFrontList;

    @ApiModelProperty(value = "Gi tax coverage front list")
    @JsonProperty("gi_tx_coverage_front_list")
    private GiTxCoverageFront[] giTxCoverageFrontList;

    @ApiModelProperty(value = "Gi tax header front")
    @JsonProperty("gi_tx_header_front")
    private GiTxHeaderFront giTxHeaderFront;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("CoiMasterNextNoFront{");
        sb.append(", giHeaderFront=").append(giHeaderFront);
        sb.append(", giTxHeaderFront=").append(giTxHeaderFront);
        sb.append('}');
        return sb.toString();
    }
}
