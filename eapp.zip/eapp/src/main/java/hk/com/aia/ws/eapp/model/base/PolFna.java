package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.annotation.AllowedValuesValidation;
import hk.com.aia.ws.eapp.annotation.DateTimeValidation;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.math.BigDecimal;

@ApiModel(value = "PolFna model")
@Data
public class PolFna {

    // Size values comes from sp - po_ms_ins_staging_fna

    @ApiModelProperty(value = "form status R - Received, N - Not Received, F - Refer, W - Waived", example = "R", allowableValues = "R,N,F,W")
    @JsonProperty(value = "form_status", required = true)
    @Size(max = 1)
    @NotBlank
    @AllowedValuesValidation(values = {"R", "N", "F", "W"}, caseSensitive = true)
    private String formStatus;

    @ApiModelProperty(value = "refer policy number", example = "B021689989")
    @JsonProperty(value = "refer_policy_no")
    @Size(max = 10)
    private String referPolicyNo;

    @ApiModelProperty(value = "sign date (MM/DD/YYYY)", example = "12/31/1990")
    @JsonProperty(value = "sign_date")
    @DateTimeValidation(format = "MM/dd/yyyy")
    private String signDate;

    @ApiModelProperty(value = "education level", example = "P", allowableValues = "P,T,S,M,1,0")
    @JsonProperty("edu_level")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"P", "T", "S", "M", "1", "O"}, caseSensitive = true)
    private String eduLevel;

    @ApiModelProperty(value = "average annual income", example = "24000000")
    @JsonProperty("avg_ann_income")
    private BigDecimal avgAnnIncome;

    @ApiModelProperty(value = "average monthly outgoings", example = "777")
    @JsonProperty("avg_mth_outgoings")
    private BigDecimal avgMthOutgoings;

    @ApiModelProperty(value = "disposable income", example = "9525108")
    @JsonProperty("disp_income")
    private BigDecimal dispIncome;

    @ApiModelProperty(value = "liquid assets", example = "100")
    @JsonProperty("liquid_asset")
    private BigDecimal liquidAsset;

    @ApiModelProperty(value = "co fin protect", example = "Y", allowableValues = "Y,N")
    @JsonProperty("co_fin_protect")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y", "N"}, caseSensitive = true)
    private String coFinProtect;

    @ApiModelProperty(value = "co health care need", example = "Y", allowableValues = "Y,N")
    @JsonProperty("co_health_care_need")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y", "N"}, caseSensitive = true)
    private String coHealthCareNeed;

    @ApiModelProperty(value = "co future income", example = "Y", allowableValues = "Y,N")
    @JsonProperty("co_future_income")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y", "N"}, caseSensitive = true)
    private String coFutureIncome;

    @ApiModelProperty(value = "co save up future", example = "Y", allowableValues = "Y,N")
    @JsonProperty("co_save_up_future")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y", "N"}, caseSensitive = true)
    private String coSaveUpFuture;

    @ApiModelProperty(value = "co invest", example = "Y", allowableValues = "Y,N")
    @JsonProperty("co_invest")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y", "N"}, caseSensitive = true)
    private String coInvest;

    @ApiModelProperty(value = "co other", example = "Y", allowableValues = "Y,N")
    @JsonProperty("co_other")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y", "N"}, caseSensitive = true)
    private String coOther;

    @ApiModelProperty(value = "ip term", example = "Y", allowableValues = "Y,N")
    @JsonProperty("ip_term")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y", "N"}, caseSensitive = true)
    private String ipTerm;

    @ApiModelProperty(value = "ip non par ", example = "Y", allowableValues = "Y,N")
    @JsonProperty("ip_non_par")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y", "N"}, caseSensitive = true)
    private String ipNonPar;

    @ApiModelProperty(value = "ip par", example = "Y", allowableValues = "Y,N")
    @JsonProperty("ip_par")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y", "N"}, caseSensitive = true)
    private String ipPar;

    @ApiModelProperty(value = "ip il", example = "Y", allowableValues = "Y,N")
    @JsonProperty("ip_il")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y", "N"}, caseSensitive = true)
    private String ipIL;

    @ApiModelProperty(value = "ip other", example = "Y", allowableValues = "Y,N")
    @JsonProperty("ip_other")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y", "N"}, caseSensitive = true)
    private String ipOther;

    @ApiModelProperty(value = "benf period", example = "101-999", allowableValues = "0-1,1-5,6-10,11-15,16-20,21-100,101-999")
    @JsonProperty("benf_period")
    @Size(max = 7)
    @AllowedValuesValidation(values = {"0-1", "1-5", "6-10", "11-15", "16-20", "21-100", "101-999"}, caseSensitive = true)
    private String benfPeriod;

    @ApiModelProperty(value = "ctbn period", example = "6-11", allowableValues = "2-6,6-11,11-16,16-21,21-100,101-999,999")
    @JsonProperty("ctbn_period")
    @Size(max = 7)
    @AllowedValuesValidation(values = {"2-6", "6-11", "11-16", "16-21", "21-100", "101-999", "999"}, caseSensitive = true)
    private String ctbnPeriod;

    @ApiModelProperty(value = "sof salary", example = "Y", allowableValues = "Y,N")
    @JsonProperty("sof_salary")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y", "N"}, caseSensitive = true)
    private String sofSalary;

    @ApiModelProperty(value = "sof income", example = "Y", allowableValues = "Y,N")
    @JsonProperty("sof_income")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y", "N"}, caseSensitive = true)
    private String sofIncome;

    @ApiModelProperty(value = "sof savings", example = "Y", allowableValues = "Y,N")
    @JsonProperty("sof_savings")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y", "N"}, caseSensitive = true)
    private String sofSavings;

    @ApiModelProperty(value = "sof invest", example = "Y", allowableValues = "Y,N")
    @JsonProperty("sof_invest")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y", "N"}, caseSensitive = true)
    private String sofInvest;

    @ApiModelProperty(value = "sof other", example = "Y", allowableValues = "Y,N")
    @JsonProperty("sof_other")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y", "N"}, caseSensitive = true)
    private String sofOther;

    @ApiModelProperty(value = "income ctbn pct", example = "21-30", allowableValues = "0-9,10-20,21-30,31-40,41-50,50-100")
    @JsonProperty("income_ctbn_pct")
    @Size(max = 6)
    @AllowedValuesValidation(values = {"0-9", "10-20", "21-30", "31-40", "41-50", "50-100"}, caseSensitive = true)
    private String incomeCtbnPct;

    @ApiModelProperty(value = "average monthly income", example = "400000")
    @JsonProperty("avg_mth_income")
    private BigDecimal avgMthIncome;

    @ApiModelProperty(value = "applicant", example = "aaa bbb")
    @JsonProperty("applicant")
    @Size(max = 50)
    private String applicant;

    @ApiModelProperty(value = "average annual nett", example = "250000")
    @JsonProperty("average_annual_net")
    private BigDecimal avgAnnNet;

    @ApiModelProperty(value = "net asset", example = "150000")
    @JsonProperty("net_asset")

    private BigDecimal netAsset;

    @ApiModelProperty(value = "co legacy", example = "Y", allowableValues = "Y,N")
    @JsonProperty("co_legacy")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y", "N"}, caseSensitive = true)
    private String coLegacy;

    @ApiModelProperty(value = "life protection")
    @JsonProperty("life_protection")
    private BigDecimal lifeProtection;

    @ApiModelProperty(value = "pol cur")
    @JsonProperty("pol_cur")
    @Size(max = 3)
    private String polCur;

    @ApiModelProperty(value = "audio opt out")
    @JsonProperty("audio_opt_out")
    @Size(max = 1)
    private String audioOptOut;

    @ApiModelProperty(value = "retired age", example = "60")
    @Size(max = 10)
    @JsonProperty("retired_age")
    private String retiredAge;

    @ApiModelProperty(value = "monthly disposable income after retired", example = "80000")
    @JsonProperty("mth_disp_income_after_retired")
    private BigDecimal mthDispIncomeAfterRetired;

    @ApiModelProperty(value = "dispoable income after retired", example = "972000")
    @JsonProperty("disp_income_after_retired")
    private BigDecimal dispIncomeAfterRetired;

    @ApiModelProperty(value = "liquid asset after retired", example = "100")
    @JsonProperty("liquid_asset_after_retired")
    private BigDecimal liquidAssetAfterRetired;

    @ApiModelProperty(value = "co health care need hi", example = "Y", allowableValues = "Y")
    @JsonProperty("co_health_care_need_hi")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y"}, caseSensitive = true)
    private String coHealthCareNeedHi;

    @ApiModelProperty(value = "co health care_need_herb", example = "Y", allowableValues = "Y")
    @JsonProperty("co_health_care_need_herb")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y"}, caseSensitive = true)
    private String coHealthCareNeedHerb;

    @ApiModelProperty(value = "co health-care", example = "Y", allowableValues = "Y")
    @JsonProperty("co_health_care_need_hpci")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y"}, caseSensitive = true)
    private String coHealthCareNeedHpci;

    @ApiModelProperty(value = "co invest od wo adv", example = "Y", allowableValues = "Y")
    @JsonProperty("co_invest_od_wo_adv")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y"}, caseSensitive = true)
    private String coInvestOdWoAdv;

    @ApiModelProperty(value = "co invest od w adv", example = "Y", allowableValues = "Y")
    @JsonProperty("co_invest_od_w_adv")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y"}, caseSensitive = true)
    private String coInvestOdWAdv;

    @ApiModelProperty(value = "co invest dont option", example = "Y", allowableValues = "Y")
    @JsonProperty("co_invest_dont_option")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y"}, caseSensitive = true)
    private String coInvestDontOption;

    @ApiModelProperty(value = "co other pb", example = "Y", allowableValues = "Y")
    @JsonProperty("co_other_pb")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y"}, caseSensitive = true)
    private String coOtherPb;

    @ApiModelProperty(value = "co other cipb", example = "Y", allowableValues = "Y")
    @JsonProperty("co_other_cipb")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y"}, caseSensitive = true)
    private String coOtherCipb;

    @ApiModelProperty(value = "co other wp", example = "Y", allowableValues = "Y")
    @JsonProperty("co_other_wp")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y"}, caseSensitive = true)
    private String coOtherWp;

    @ApiModelProperty(value = "co other lp", example = "Y", allowableValues = "Y")
    @JsonProperty("co_other_lp")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y"}, caseSensitive = true)
    private String coOtherLp;

    @ApiModelProperty(value = "co other other", example = "Y", allowableValues = "Y")
    @JsonProperty("co_other_other")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y"}, caseSensitive = true)
    private String coOtherOther;

    @ApiModelProperty(value = "spmnt cur", example = "HKD")
    @JsonProperty("spmnt_cur")
    @Size(max = 3)
    private String spmntCur;

    @ApiModelProperty(value = "spmnt amount", example = "250000")
    @JsonProperty("spmnt_amount")
    private BigDecimal spmntAmount;

    @ApiModelProperty(value = "asset ctbn pct", example = "61-80", allowableValues = "0-10,11-20,21-40,41-60,61-80,81-100")
    @JsonProperty("asset_ctbn_pct")
    @Size(max = 6)
    @AllowedValuesValidation(values = {"0-10", "11-20", "21-40", "41-60", "61-80", "81-100"}, caseSensitive = true)
    private String assetCtbnPct;

    @ApiModelProperty(value = "ci protection cur", example = "USD")
    @JsonProperty("ci_protection_cur")
    @Size(max = 3)
    private String ciProtectionCur;

    @ApiModelProperty(value = "ci protection", example = "150000")
    @JsonProperty("ci_protection")
    private BigDecimal ciProtection;

    @ApiModelProperty(value = "expected time-frame", example = "10")
    @JsonProperty("expected_timeframe")
    private Integer expectedTimeframe;

    @ApiModelProperty(value = "tsa cur", example = "USD")
    @JsonProperty("tsa_cur")
    @Size(max = 3)
    private String tsaCur;

    @ApiModelProperty(value = "tsa protection", example = "1000")
    @JsonProperty("tsa_protection")
    private BigDecimal tsaProtection;

    @ApiModelProperty(value = "life within ind", example = "Y", allowableValues = "Y")
    @JsonProperty("life_within_ind")
    @Size(max = 20)
    @AllowedValuesValidation(values = {"Y"}, caseSensitive = true)
    private String lifeWithinInd;

    @ApiModelProperty(value = "ci within ind", example = "Y", allowableValues = "Y")
    @JsonProperty("ci_within_ind")
    @Size(max = 20)
    @AllowedValuesValidation(values = {"Y"}, caseSensitive = true)
    private String ciWithinInd;

    @ApiModelProperty(value = "tsa within ind", example = "Y", allowableValues = "Y")
    @JsonProperty("tsa_within_ind")
    @Size(max = 20)
    @AllowedValuesValidation(values = {"Y"}, caseSensitive = true)
    private String tsaWithinInd;

    @ApiModelProperty(value = "soi retire fund", example = "Y", allowableValues = "Y")
    @JsonProperty("soi_retire_fund")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y"}, caseSensitive = true)
    private String soiRetireFund;

    @ApiModelProperty(value = "soi saving", example = "Y", allowableValues = "Y")
    @JsonProperty("soi_saving")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y"}, caseSensitive = true)
    private String soiSaving;

    @ApiModelProperty(value = "soi interest", example = "Y", allowableValues = "Y")
    @JsonProperty("soi_interest")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y"}, caseSensitive = true)
    private String soiInterest;

    @ApiModelProperty(value = "soi rental", example = "Y", allowableValues = "Y")
    @JsonProperty("soi_rental")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y"}, caseSensitive = true)
    private String soiRental;

    @ApiModelProperty(value = "soi annuity", example = "Y", allowableValues = "Y")
    @JsonProperty("soi_annuity")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y"}, caseSensitive = true)
    private String soiAnnuity;

    @ApiModelProperty(value = "soi inheritance", example = "Y", allowableValues = "Y")
    @JsonProperty("soi_inheritance")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y"}, caseSensitive = true)
    private String soiInheritance;

    @ApiModelProperty(value = "soi family", example = "Y", allowableValues = "Y")
    @JsonProperty("soi_family")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y"}, caseSensitive = true)
    private String soiFamily;

    @ApiModelProperty(value = "soi other", example = "Y", allowableValues = "Y")
    @JsonProperty("soi_other")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y"}, caseSensitive = true)
    private String soiOther;

    @ApiModelProperty(value = "fna dec", example = "A", allowableValues = "A,B")
    @JsonProperty("fna_dec")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"A", "B"}, caseSensitive = true)
    private String fnaDec;

    @ApiModelProperty(value = "reason decl b a", example = "Y", allowableValues = "Y")
    @JsonProperty("reason_decl_b_a")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y"}, caseSensitive = true)
    private String reasonDeclBA;

    @ApiModelProperty(value = "reason decl b b", example = "Y", allowableValues = "Y")
    @JsonProperty("reason_decl_b_b")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y"}, caseSensitive = true)
    private String reasonDeclBB;

    @ApiModelProperty(value = "reason decl b c", example = "Y", allowableValues = "Y")
    @JsonProperty("reason_decl_b_c")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y"}, caseSensitive = true)
    private String reasonDeclBC;

    @ApiModelProperty(value = "reason decl b d", example = "Y", allowableValues = "Y")
    @JsonProperty("reason_decl_b_d")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y"}, caseSensitive = true)
    private String reasonDeclBD;

    @ApiModelProperty(value = "reason decl b e", example = "Y", allowableValues = "Y")
    @JsonProperty("reason_decl_b_e")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y"}, caseSensitive = true)
    private String reasonDeclBE;

    @ApiModelProperty(value = "med ci sa no", example = "Y", allowableValues = "Y")
    @JsonProperty("med_ci_sa_no")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y","N"}, caseSensitive = true)
    private String medCiSaNo;

    @ApiModelProperty(value = "med ci sa yes", example = "Y", allowableValues = "Y")
    @JsonProperty("med_ci_sa_yes")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y","N"}, caseSensitive = true)
    private String medCiSaYes;

    @ApiModelProperty(value = "med ci sa yes hi", example = "Y", allowableValues = "Y")
    @JsonProperty("med_ci_sa_yes_hi")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y","N"}, caseSensitive = true)
    private String medCiSaYesHi;

    @ApiModelProperty(value = "med ci sa yes herb", example = "Y", allowableValues = "Y")
    @JsonProperty("med_ci_sa_yes_herb")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y","N"}, caseSensitive = true)
    private String medCiSaYesHerb;

    @ApiModelProperty(value = "med ci sa yes lsp ci", example = "Y", allowableValues = "Y")
    @JsonProperty("med_ci_sa_yes_lsp_ci")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y","N"}, caseSensitive = true)
    private String medCiSaYesLspCi;

    @ApiModelProperty(value = "b1 reason suit mis a", example = "Y", allowableValues = "Y")
    @JsonProperty("b1_reason_suit_mis_a")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y"}, caseSensitive = true)
    private String b1ReasonSuitMisA;

    @ApiModelProperty(value = "b1 reason suit mis b", example = "Y", allowableValues = "Y")
    @JsonProperty("b1_reason_suit_mis_b")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y"}, caseSensitive = true)
    private String b1ReasonSuitMisB;

    @ApiModelProperty(value = "b1 reason suit mis c", example = "Y", allowableValues = "Y")
    @JsonProperty("b1_reason_suit_mis_c")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y"}, caseSensitive = true)
    private String b1ReasonSuitMisC;

    @ApiModelProperty(value = "b1 reason suit mis d", example = "Y", allowableValues = "Y")
    @JsonProperty("b1_reason_suit_mis_d")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y"}, caseSensitive = true)
    private String b1ReasonSuitMisD;

    @ApiModelProperty(value = "b1 reason suit mis e", example = "Y", allowableValues = "Y")
    @JsonProperty("b1_reason_suit_mis_e")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y"}, caseSensitive = true)
    private String b1ReasonSuitMisE;

    @ApiModelProperty(value = "b1 reason suit mis f", example = "Y", allowableValues = "Y")
    @JsonProperty("b1_reason_suit_mis_f")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y"}, caseSensitive = true)
    private String b1ReasonSuitMisF;

    @ApiModelProperty(value = "b1 reason suit mis g", example = "Y", allowableValues = "Y")
    @JsonProperty("b1_reason_suit_mis_g")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y"}, caseSensitive = true)
    private String b1ReasonSuitMisG;

    @ApiModelProperty(value = "b2 reason recm a", example = "Y", allowableValues = "Y")
    @JsonProperty("b2_reason_recm_a")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y"}, caseSensitive = true)
    private String b2ReasonRecmA;

    @ApiModelProperty(value = "b2 reason recm b", example = "Y", allowableValues = "Y")
    @JsonProperty("b2_reason_recm_b")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y"}, caseSensitive = true)
    private String b2ReasonRecmB;

    @ApiModelProperty(value = "b2 reason recm c", example = "Y", allowableValues = "Y")
    @JsonProperty("b2_reason_recm_c")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y"}, caseSensitive = true)
    private String b2ReasonRecmC;

    @ApiModelProperty(value = "b2 reason recm d", example = "Y", allowableValues = "Y")
    @JsonProperty("b2_reason_recm_d")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y"}, caseSensitive = true)
    private String b2ReasonRecmD;

    @ApiModelProperty(value = "b2 reason recm e", example = "Y", allowableValues = "Y")
    @JsonProperty("b2_reason_recm_e")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"Y"}, caseSensitive = true)
    private String b2ReasonRecmE;

    public String getFormStatus() {
        return StringUtils.isBlank(formStatus) ? "N" : formStatus;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("PolFna{");
        sb.append("formStatus='").append(formStatus).append('\'');
        sb.append(", referPolicyNo='").append(referPolicyNo).append('\'');
        sb.append(", signDate='").append(signDate).append('\'');
        sb.append(", eduLevel='").append(eduLevel).append('\'');
        sb.append(", avgAnnIncome=").append(avgAnnIncome);
        sb.append(", avgMthOutgoings=").append(avgMthOutgoings);
        sb.append(", dispIncome=").append(dispIncome);
        sb.append(", liquidAsset=").append(liquidAsset);
        sb.append(", coFinProtect='").append(coFinProtect).append('\'');
        sb.append(", coHealthCareNeed='").append(coHealthCareNeed).append('\'');
        sb.append(", coFutureIncome='").append(coFutureIncome).append('\'');
        sb.append(", coSaveUpFuture='").append(coSaveUpFuture).append('\'');
        sb.append(", coInvest='").append(coInvest).append('\'');
        sb.append(", coOther='").append(coOther).append('\'');
        sb.append(", ipTerm='").append(ipTerm).append('\'');
        sb.append(", ipNonPar='").append(ipNonPar).append('\'');
        sb.append(", ipPar='").append(ipPar).append('\'');
        sb.append(", ipIL='").append(ipIL).append('\'');
        sb.append(", ipOther='").append(ipOther).append('\'');
        sb.append(", benfPeriod='").append(benfPeriod).append('\'');
        sb.append(", ctbnPeriod='").append(ctbnPeriod).append('\'');
        sb.append(", sofSalary='").append(sofSalary).append('\'');
        sb.append(", sofIncome='").append(sofIncome).append('\'');
        sb.append(", sofSavings='").append(sofSavings).append('\'');
        sb.append(", sofInvest='").append(sofInvest).append('\'');
        sb.append(", sofOther='").append(sofOther).append('\'');
        sb.append(", incomeCtbnPct='").append(incomeCtbnPct).append('\'');
        sb.append(", avgMthIncome=").append(avgMthIncome);
        sb.append(", applicant='").append(applicant).append('\'');
        sb.append(", avgAnnNet=").append(avgAnnNet);
        sb.append(", netAsset=").append(netAsset);
        sb.append(", coLegacy='").append(coLegacy).append('\'');
        sb.append(", lifeProtection=").append(lifeProtection);
        sb.append(", polCur='").append(polCur).append('\'');
        sb.append(", audioOptOut='").append(audioOptOut).append('\'');
        sb.append(", retiredAge='").append(retiredAge).append('\'');
        sb.append(", mthDispIncomeAfterRetired=").append(mthDispIncomeAfterRetired);
        sb.append(", dispIncomeAfterRetired=").append(dispIncomeAfterRetired);
        sb.append(", liquidAssetAfterRetired=").append(liquidAssetAfterRetired);
        sb.append(", coHealthCareNeedHi='").append(coHealthCareNeedHi).append('\'');
        sb.append(", coHealthCareNeedHerb='").append(coHealthCareNeedHerb).append('\'');
        sb.append(", coHealthCareNeedHpci='").append(coHealthCareNeedHpci).append('\'');
        sb.append(", coInvestOdWoAdv='").append(coInvestOdWoAdv).append('\'');
        sb.append(", coInvestOdWAdv='").append(coInvestOdWAdv).append('\'');
        sb.append(", coInvestDontOption='").append(coInvestDontOption).append('\'');
        sb.append(", coOtherPb='").append(coOtherPb).append('\'');
        sb.append(", coOtherCipb='").append(coOtherCipb).append('\'');
        sb.append(", coOtherWp='").append(coOtherWp).append('\'');
        sb.append(", coOtherLp='").append(coOtherLp).append('\'');
        sb.append(", coOtherOther='").append(coOtherOther).append('\'');
        sb.append(", spmntCur='").append(spmntCur).append('\'');
        sb.append(", spmntAmount=").append(spmntAmount);
        sb.append(", assetCtbnPct='").append(assetCtbnPct).append('\'');
        sb.append(", ciProtectionCur='").append(ciProtectionCur).append('\'');
        sb.append(", ciProtection=").append(ciProtection);
        sb.append(", expectedTimeframe=").append(expectedTimeframe);
        sb.append(", tsaCur='").append(tsaCur).append('\'');
        sb.append(", tsaProtection=").append(tsaProtection);
        sb.append(", lifeWithinInd='").append(lifeWithinInd).append('\'');
        sb.append(", ciWithinInd='").append(ciWithinInd).append('\'');
        sb.append(", tsaWithinInd='").append(tsaWithinInd).append('\'');
        sb.append(", soiRetireFund='").append(soiRetireFund).append('\'');
        sb.append(", soiSaving='").append(soiSaving).append('\'');
        sb.append(", soiInterest='").append(soiInterest).append('\'');
        sb.append(", soiRental='").append(soiRental).append('\'');
        sb.append(", soiAnnuity='").append(soiAnnuity).append('\'');
        sb.append(", soiInheritance='").append(soiInheritance).append('\'');
        sb.append(", soiFamily='").append(soiFamily).append('\'');
        sb.append(", soiOther='").append(soiOther).append('\'');
        sb.append(", fnaDec='").append(fnaDec).append('\'');
        sb.append(", reasonDeclBA='").append(reasonDeclBA).append('\'');
        sb.append(", reasonDeclBB='").append(reasonDeclBB).append('\'');
        sb.append(", reasonDeclBC='").append(reasonDeclBC).append('\'');
        sb.append(", reasonDeclBD='").append(reasonDeclBD).append('\'');
        sb.append(", reasonDeclBE='").append(reasonDeclBE).append('\'');
        sb.append(", medCiSaNo='").append(medCiSaNo).append('\'');
        sb.append(", medCiSaYes='").append(medCiSaYes).append('\'');
        sb.append(", medCiSaYesHi='").append(medCiSaYesHi).append('\'');
        sb.append(", medCiSaYesHerb='").append(medCiSaYesHerb).append('\'');
        sb.append(", medCiSaYesLspCi='").append(medCiSaYesLspCi).append('\'');
        sb.append(", b1ReasonSuitMisA='").append(b1ReasonSuitMisA).append('\'');
        sb.append(", b1ReasonSuitMisB='").append(b1ReasonSuitMisB).append('\'');
        sb.append(", b1ReasonSuitMisC='").append(b1ReasonSuitMisC).append('\'');
        sb.append(", b1ReasonSuitMisD='").append(b1ReasonSuitMisD).append('\'');
        sb.append(", b1ReasonSuitMisE='").append(b1ReasonSuitMisE).append('\'');
        sb.append(", b1ReasonSuitMisF='").append(b1ReasonSuitMisF).append('\'');
        sb.append(", b1ReasonSuitMisG='").append(b1ReasonSuitMisG).append('\'');
        sb.append(", b2ReasonRecmA='").append(b2ReasonRecmA).append('\'');
        sb.append(", b2ReasonRecmB='").append(b2ReasonRecmB).append('\'');
        sb.append(", b2ReasonRecmC='").append(b2ReasonRecmC).append('\'');
        sb.append(", b2ReasonRecmD='").append(b2ReasonRecmD).append('\'');
        sb.append(", b2ReasonRecmE='").append(b2ReasonRecmE).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
