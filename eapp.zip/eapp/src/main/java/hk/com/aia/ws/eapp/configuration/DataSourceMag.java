package hk.com.aia.ws.eapp.configuration;

import com.microsoft.aad.adal4j.AuthenticationContext;
import com.microsoft.aad.adal4j.AuthenticationResult;
import com.microsoft.aad.adal4j.ClientCredential;
import com.microsoft.sqlserver.jdbc.SQLServerDataSource;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.jdbc.datasource.AbstractDataSource;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

@Slf4j
@Component("magDataSource")
@ConditionalOnExpression("!'${spring.profiles}'.equals('local') && !'${spring.profiles}'.equals('dev')")
public class DataSourceMag extends AbstractDataSource implements InitializingBean {

	private static ExecutorService executorService= Executors.newFixedThreadPool(30);
	
    @Value("${connection.mag.datasource.cloud.authority-url}")
    private String authorityUrl;

    @Value("${connection.mag.datasource.cloud.client-id}")
    private String clientId;

    @Value("${connection.mag.datasource.cloud.client-secret}")
    private String clientSecret;

    @Value("${connection.mag.datasource.cloud.server-name}")
    private String serverName;

    @Value("${connection.mag.datasource.cloud.database-name}")
    private String databaseName;

    @Value("${connection.mag.datasource.cloud.database-url}")
    private String databaseUrl;

    @Value("${connection.mag.datasource.cloud.spn-url}")
    private String spnUrl;

    private DataSource dataSource;

    private String accessToken;

    private void initializeDataSource() throws Exception {
        log.info("initializing DataSource magDataSourceCloud ...");
        log.info("#databaseconfig : {}|{}|{}|{}|{}", clientId, clientSecret,serverName,databaseName,databaseUrl);
        SQLServerDataSource ds = new SQLServerDataSource();
        ds.setURL(databaseUrl);
        ds.setServerName(serverName);
        ds.setDatabaseName(databaseName);
        ds.setAccessToken(accessToken);

        this.dataSource = ds;

    }

    @Scheduled(cron = "${connection.mag.datasource.cloud.token-refresh-cron-expr}")
    public void reInitializeToken() throws Exception {
        log.info("reInitializeToken DataSource magDataSource ...");
        AuthenticationContext context = new AuthenticationContext(authorityUrl, false,executorService);
        ClientCredential clientCredentials = new ClientCredential(clientId, clientSecret);

        Future<AuthenticationResult> future = context.acquireToken(spnUrl, clientCredentials, null);
        AuthenticationResult authenticationResult = future.get();
        this.accessToken = authenticationResult.getAccessToken();

        initializeDataSource();
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        reInitializeToken();
    }

    @Override
    public Connection getConnection() throws SQLException {
        return dataSource.getConnection();
    }

    @Override
    public Connection getConnection(String username, String password) throws SQLException {
        return dataSource.getConnection();
    }
}