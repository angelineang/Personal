package hk.com.aia.ws.eapp.model.request.ipos;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@ApiModel(value = "T_COMMUNICATION Model")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TCommunicationDto {

	@ApiModelProperty(value = "communication Id", required = true)
    @JsonProperty("communication_id")
	@Size(max = 60)
    @NotBlank
    private String communicationId;

    @JsonProperty("contact_id")
    @Size(max = 60)
    private String contactId;

    @JsonProperty("country_code")
    @Size(max = 4)
    private String countryCode;

    @JsonProperty("country_name")
    @Size(max = 60)
    private String countryName;

    @JsonProperty("area_code")
    @Size(max = 4)
    private String areaCode;

    @JsonProperty("area_name")
    @Size(max = 100)
    private String areaName;

    @JsonProperty("communication")
    @Size(max = 60)
    private String communication;

    @JsonProperty("e_advice")
    private Integer eAdvice;

    @JsonProperty("type")
    @Size(max = 10)
    private String type;

    @JsonProperty("sub_type")
    @Size(max = 20)
    private String subType;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TCommunicationDto{");
        sb.append("communicationId='").append(communicationId).append('\'');
        sb.append(", contactId='").append(contactId).append('\'');
        sb.append(", countryCode='").append(countryCode).append('\'');
        sb.append(", countryName='").append(countryName).append('\'');
        sb.append(", areaCode='").append(areaCode).append('\'');
        sb.append(", areaName='").append(areaName).append('\'');
        sb.append(", communication='").append(communication).append('\'');
        sb.append(", eAdvice=").append(eAdvice);
        sb.append(", type='").append(type).append('\'');
        sb.append(", subType='").append(subType).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
