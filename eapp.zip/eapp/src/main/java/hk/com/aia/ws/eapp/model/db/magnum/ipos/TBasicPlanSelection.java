package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import hk.com.aia.ws.eapp.model.db.magnum.ipos.idclass.TBasicPlanSelectionId;
import lombok.Data;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


@Entity
@Data
@Table(name = "T_BASICPLANSELECTION")
@IdClass(TBasicPlanSelectionId.class)
@EntityListeners(AuditingEntityListener.class)
public class TBasicPlanSelection {

    @Column(name = "BASICPLANSELECTIONID", length = 60)
    @Id
    private String basicPlanSelectionId;

    @Column(name = "AGENTCODE", length = 10)
    private String agentCode;

    @Column(name = "ACCESSCODE", length = 30)
    private String accessCode;

    @Column(name = "PLANSELECTIONID", length = 60)
    @Id
    private String planSelectionId;

    @Column(name = "ANNUALPREMIUM")
    private BigDecimal annualPremium;

    @Column(name = "MODALPREMIUM")
    private BigDecimal modalPremium;

    @Column(name = "REGULARTOPUPPREMIUM")
    private BigDecimal regularTopUpPremium;

    @Column(name = "WITHDRAWALDEDUCTSUMASSURED")
    private Integer withdrawalDeductSumAssured;

    @Column(name = "LIFESTYLEDISCOUNT")
    private Integer lifeStyleDiscount;

    @Column(name = "LEVELOFBENEFIT")
    private Integer levelOfBenefit;

    @Column(name = "PREMIUMOFFSETOPTION")
    private Integer premiumOffSetOption;

    @Column(name = "SINGLEDEPOSIT")
    private Integer singleDeposit;

    @Column(name = "RATING")
    private Double rating;

    @Column(name = "RISKCLASS")
    private Integer riskClass;

    @Column(name = "DEATHBENEFITOPTION", length = 255)
    private String deathBenefitOption;

    @Column(name = "COIOPTION", length = 255)
    private String coiOption;

    @Column(name = "SOLVEROPTION", length = 255)
    private String solverOption;

    @Column(name = "PREMIUMPAIDTOAGE")
    private Integer premiumPaidToAge;

    @Column(name = "INFORCETOAGE")
    private Integer inforceToAge;

    @Column(name = "INTERESTRATE1")
    private Double interestRate1;

    @Column(name = "INTERESTRATE2")
    private Double interestRate2;

    @Column(name = "SPLITPREMIUM")
    private Integer splitPremium;

    @Column(name = "TARGETAGE")
    private Integer targetage;

    @Column(name = "TARGETENDOWEDAMOUNT")
    private BigDecimal targetEndOwedAmount;

    @Column(name = "MINFIRSTYEARPREMIUM")
    private BigDecimal minFirstFearPremium;

    @Column(name = "MAXPREMIUM")
    private BigDecimal maxPremium;

    @Column(name = "NOLAPSEPREMIUM")
    private BigDecimal noLapsePremium;

    @Column(name = "CREATEDBY", length = 10, updatable = false)
    @CreatedBy
    private String createdBy;

    @Column(name = "UPDATEDBY", length = 10)
    @LastModifiedBy
    private String updatedBy;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "LASTUPDATEDATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    @LastModifiedDate
    private Date lastUpdateDateTime;

    @Column(name = "TARGETPREMIUM")
    private BigDecimal targetPremium;

    @Column(name = "PARTYPE", length = 255)
    private String parType;

    @Column(name = "INCOMEPERIOD")
    private Integer incomePeriod;
    
    @Column(name = "PRESCRIBEDPERCENTAGE")
    private BigDecimal prescribedPercentage;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TBasicPlanSelection{");
        sb.append("basicPlanSelectionId='").append(basicPlanSelectionId).append('\'');
        sb.append(", agentCode='").append(agentCode).append('\'');
        sb.append(", accessCode='").append(accessCode).append('\'');
        sb.append(", planSelectionId='").append(planSelectionId).append('\'');
        sb.append(", annualPremium=").append(annualPremium);
        sb.append(", modalPremium=").append(modalPremium);
        sb.append(", regularTopUpPremium=").append(regularTopUpPremium);
        sb.append(", withdrawalDeductSumAssured=").append(withdrawalDeductSumAssured);
        sb.append(", lifeStyleDiscount=").append(lifeStyleDiscount);
        sb.append(", levelOfBenefit=").append(levelOfBenefit);
        sb.append(", premiumOffSetOption=").append(premiumOffSetOption);
        sb.append(", singleDeposit=").append(singleDeposit);
        sb.append(", rating=").append(rating);
        sb.append(", riskClass=").append(riskClass);
        sb.append(", deathBenefitOption='").append(deathBenefitOption).append('\'');
        sb.append(", coiOption='").append(coiOption).append('\'');
        sb.append(", solverOption='").append(solverOption).append('\'');
        sb.append(", premiumPaidToAge=").append(premiumPaidToAge);
        sb.append(", inforceToAge=").append(inforceToAge);
        sb.append(", interestRate1=").append(interestRate1);
        sb.append(", interestRate2=").append(interestRate2);
        sb.append(", splitPremium=").append(splitPremium);
        sb.append(", targetage=").append(targetage);
        sb.append(", targetEndOwedAmount=").append(targetEndOwedAmount);
        sb.append(", minFirstFearPremium=").append(minFirstFearPremium);
        sb.append(", maxPremium=").append(maxPremium);
        sb.append(", noLapsePremium=").append(noLapsePremium);
        sb.append(", createdBy='").append(createdBy).append('\'');
        sb.append(", updatedBy='").append(updatedBy).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", lastUpdateDateTime=").append(lastUpdateDateTime);
        sb.append(", targetPremium=").append(targetPremium);
        sb.append(", parType='").append(parType).append('\'');
        sb.append(", incomePeriod=").append(incomePeriod);
        sb.append(", prescribedPercentage=").append(prescribedPercentage);
        sb.append('}');
        return sb.toString();
    }
}
