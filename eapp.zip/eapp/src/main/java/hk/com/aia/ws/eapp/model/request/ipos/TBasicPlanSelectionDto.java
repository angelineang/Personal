package hk.com.aia.ws.eapp.model.request.ipos;

import java.math.BigDecimal;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@ApiModel(value = "T_BASICPLANSELECTION Model")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TBasicPlanSelectionDto {

	@ApiModelProperty(value = "basic Plan Selection Id", required = true) 
    @JsonProperty("basic_plan_selection_id")
	@Size(max = 60)
    @NotBlank
    private String basicPlanSelectionId;

    @JsonProperty("agent_code")
    @Size(max = 10)
    private String agentCode;

    @JsonProperty("access_code")
    @Size(max = 30)
    private String accessCode;

    @ApiModelProperty(value = " plan Selection Id", required = true) 
    @JsonProperty("plan_selection_id")
    @Size(max = 60)
    @NotBlank
    private String planSelectionId;

    @JsonProperty("annual_premium")
    private BigDecimal annualPremium;

    @JsonProperty("modal_premium")
    private BigDecimal modalPremium;

    @JsonProperty("regular_topup_premium")
    private BigDecimal regularTopUpPremium;

    @JsonProperty("withdrawal_deduct_sum_assured")
    private Integer withdrawalDeductSumAssured;

    @JsonProperty("life_style_discount")
    private Integer lifeStyleDiscount;

    @JsonProperty("level_of_benefit")
    private Integer levelOfBenefit;

    @JsonProperty("premium_offset_option")
    private Integer premiumOffSetOption;

    @JsonProperty("single_deposit")
    private Integer singleDeposit;

    @JsonProperty("rating")
    private Double rating;

    @JsonProperty("risk_class")
    private Integer riskClass;

    @JsonProperty("death_benefit_option")
    @Size(max = 255)
    private String deathBenefitOption;

    @JsonProperty("coi_option")
    @Size(max = 255)
    private String coiOption;

    @JsonProperty("solver_option")
    @Size(max = 255)
    private String solverOption;

    @JsonProperty("premium_paid_to_age")
    private Integer premiumPaidToAge;

    @JsonProperty("inforce_to_age")
    private Integer inforceToAge;

    @JsonProperty("interest_rate_1")
    private Double interestRate1;

    @JsonProperty("interest_rate_2")
    private Double interestRate2;

    @JsonProperty("split_premium")
    private Integer splitPremium;

    @JsonProperty("target_age")
    private Integer targetage;

    @JsonProperty("target_endowed_amount")
    private BigDecimal targetEndOwedAmount;

    @JsonProperty("min_first_year_premium")
    private BigDecimal minFirstFearPremium;

    @JsonProperty("max_premium")
    private BigDecimal maxPremium;

    @JsonProperty("no_lapse_premium")
    private BigDecimal noLapsePremium;

    @JsonProperty("target_premium")
    private BigDecimal targetPremium;

    @JsonProperty("par_type")
    @Size(max = 255)
    private String parType;

    @JsonProperty("income_period")
    private Integer incomePeriod;
    
    @JsonProperty("prescribePercentage")
    private BigDecimal prescribedPercentage;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TBasicPlanSelectionDto{");
        sb.append("basicPlanSelectionId='").append(basicPlanSelectionId).append('\'');
        sb.append(", agentCode='").append(agentCode).append('\'');
        sb.append(", accessCode='").append(accessCode).append('\'');
        sb.append(", planSelectionId='").append(planSelectionId).append('\'');
        sb.append(", annualPremium=").append(annualPremium);
        sb.append(", modalPremium=").append(modalPremium);
        sb.append(", regularTopUpPremium=").append(regularTopUpPremium);
        sb.append(", withdrawalDeductSumAssured=").append(withdrawalDeductSumAssured);
        sb.append(", lifeStyleDiscount=").append(lifeStyleDiscount);
        sb.append(", levelOfBenefit=").append(levelOfBenefit);
        sb.append(", premiumOffSetOption=").append(premiumOffSetOption);
        sb.append(", singleDeposit=").append(singleDeposit);
        sb.append(", rating=").append(rating);
        sb.append(", riskClass=").append(riskClass);
        sb.append(", deathBenefitOption='").append(deathBenefitOption).append('\'');
        sb.append(", coiOption='").append(coiOption).append('\'');
        sb.append(", solverOption='").append(solverOption).append('\'');
        sb.append(", premiumPaidToAge=").append(premiumPaidToAge);
        sb.append(", inforceToAge=").append(inforceToAge);
        sb.append(", interestRate1=").append(interestRate1);
        sb.append(", interestRate2=").append(interestRate2);
        sb.append(", splitPremium=").append(splitPremium);
        sb.append(", targetage=").append(targetage);
        sb.append(", targetEndOwedAmount=").append(targetEndOwedAmount);
        sb.append(", minFirstFearPremium=").append(minFirstFearPremium);
        sb.append(", maxPremium=").append(maxPremium);
        sb.append(", noLapsePremium=").append(noLapsePremium);
        sb.append(", targetPremium=").append(targetPremium);
        sb.append(", parType='").append(parType).append('\'');
        sb.append(", incomePeriod=").append(incomePeriod);
        sb.append(", prescribedPercentage=").append(prescribedPercentage);
        sb.append('}');
        return sb.toString();
    }
}
