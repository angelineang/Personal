package hk.com.aia.ws.eapp.model.request.ipos;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.util.Date;

import static hk.com.aia.ws.eapp.constant.Constants.TIMEZONE;

@ApiModel(value = "T_EAPP_CONTINGENT_INSURE Model")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TEappContingentInsureDto {

    @ApiModelProperty(value = "eapp Contingent Insureid", required = true)
    @JsonProperty("eapp_contingent_insure_id")
    @Size(max = 60)
    @NotBlank
    private String eappContingentInsureId;

    @ApiModelProperty(value = "eapp Id", required = true)
    @JsonProperty("eapp_id")
    @Size(max = 60)
    private String eappId;

    @JsonProperty("fullname_en")
    @Size(max = 101)
    private String fullNameEn;

    @JsonProperty("name_chn")
    @Size(max = 550)
    private String nameChn;

    @JsonProperty("age")
    private Integer age;

    @JsonProperty("id_card_passport_no")
    @Size(max = 18)
    private String idCardPassportNo;

    @JsonProperty("relationship")
    @Size(max = 2)
    private String relationship;

    @JsonProperty("others")
    @Size(max = 255)
    private String others;

    @JsonProperty("agent_code")
    @Size(max = 10)
    private String agentCode;

    @JsonProperty("access_code")
    @Size(max = 10)
    private String accessCode;

    @ApiModelProperty(value = "date of birth, format = yyyy-MM-dd", example = "2020-12-31")
    @JsonProperty("dob")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = TIMEZONE)
    private Date dob;

    @JsonProperty("gender")
    @Size(max = 10)
    private String gender;

    @JsonProperty("id_type")
    @Size(max = 20)
    private String idType;

    @JsonProperty("adult_reason")
    @Size(max = 1)
    private String adultReason;

    @JsonProperty("adult_reason_other")
    @Size(max = 800)
    private String adultReasonOther;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TEappContingentInsureDto{");
        sb.append("eappContingentInsureId='").append(eappContingentInsureId).append('\'');
        sb.append(", eappId='").append(eappId).append('\'');
        sb.append(", fullNameEn='").append(ConversionHandler.mask(fullNameEn)).append('\'');
        sb.append(", nameChn='").append(ConversionHandler.mask(nameChn)).append('\'');
        sb.append(", age=").append(ConversionHandler.mask(age));
        sb.append(", idCardPassportNo='").append(ConversionHandler.mask(idCardPassportNo)).append('\'');
        sb.append(", relationship='").append(relationship).append('\'');
        sb.append(", others='").append(others).append('\'');
        sb.append(", agentCode='").append(agentCode).append('\'');
        sb.append(", accessCode='").append(accessCode).append('\'');
        sb.append(", dob=").append(ConversionHandler.mask(dob));
        sb.append(", gender='").append(gender).append('\'');
        sb.append(", idType='").append(idType).append('\'');
        sb.append(", adultReason='").append(adultReason).append('\'');
        sb.append(", adultReasonOther='").append(adultReasonOther).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
