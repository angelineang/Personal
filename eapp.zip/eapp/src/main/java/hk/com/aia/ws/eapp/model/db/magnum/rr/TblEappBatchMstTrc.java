package hk.com.aia.ws.eapp.model.db.magnum.rr;

import hk.com.aia.ws.eapp.model.db.magnum.ichange.idclass.TblEappBatchMstId;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "tbl_eapp_batch_mst_trc")
@IdClass(TblEappBatchMstId.class)
public class TblEappBatchMstTrc {

    @Column(name = "retry_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date retryDate;

    @Column(name = "batch_id", length = 19)
    @Id
    private String batchId;

    @Column(name = "policy_no", length = 10)
    @Id
    private String policyNo;

    @Column(name = "doc_id", length = 8)
    @Id
    private String docId;

    @Column(name = "status", length = 1)
    private String status;

    @Column(name = "agy_code", length = 5)
    private String agyCode;

    @Column(name = "agt_code", length = 5)
    private String agtCode;

    @Column(name = "team_code", length = 1)
    private String teamCode;

    @Column(name = "create_by", length = 15)
    private String createBy;

    @Column(name = "create_date", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date createDate;

    @Column(name = "update_by", length = 15, updatable = false)
    private String updateBy;

    @Column(name = "last_update")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdate;

    @Column(name = "seq")
    @Id
    private Integer sequence;

    @Column(name = "rb_status", length = 1)
    private String rbStatus;

    @Column(name = "agt_code2", length = 5)
    private String agtCode2;

    @Column(name = "sftp_status", length = 1)
    private String sftpStatus;

    @Column(name = "sftp_date")
    private Date sftpDate;

    @Column(name = "otp_ind", length = 1)
    private String otpInd;

    @Column(name = "fail_cnt")
    private Integer failCnt;

    @Column(name = "nb_complete_date")
    private Date nbCompleteDate;

    @Column(name = "rb_complete_date")
    private Date rbCompleteDate;

    @Column(name = "citi", length = 1)
    private String citi;

    @Column(name = "org_batch_id") // length of 255 is default value
    private String orgBatchId;

    @Column(name = "stp_ind", length = 1)
    private String stpInd;

    @Column(name = "parent_batch_id", length = 19)
    private String parentBatchId;

    @Column(name = "documents_id", length = 64)
    private String documentsId;

    @Column(name = "iverify_id", length = 60)
    private String iVerifyId;

    @Column(name = "iverify_client_id", length = 20)
    private String iVerifyClientId;

    @Column(name = "iverify_doc_seq", length = 4)
    private String iVerifyDocSeq;

    @Column(name = "content_type", length = 30)
    private String contentType;

    @Column(name = "access_id", length = 30)
    private String accessId;

    @Column(name = "tr_code", length = 20)
    private String trCode;

    @Column(name = "convert_tif", length = 1)
    private String convertTif;

    @Column(name = "otp_confirm_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date otpConfirmDate;

    @Transient
    private String rrRowId;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TblEappBatchMstTrc{");
        sb.append("batchId='").append(batchId).append('\'');
        sb.append(", policyNo='").append(ConversionHandler.mask(policyNo)).append('\'');
        sb.append(", docId='").append(docId).append('\'');
        sb.append(", status='").append(status).append('\'');
        sb.append(", agyCode='").append(agyCode).append('\'');
        sb.append(", agtCode='").append(agtCode).append('\'');
        sb.append(", teamCode='").append(teamCode).append('\'');
        sb.append(", createBy='").append(createBy).append('\'');
        sb.append(", createDate=").append(createDate);
        sb.append(", updateBy='").append(updateBy).append('\'');
        sb.append(", lastUpdate=").append(lastUpdate);
        sb.append(", seq=").append(sequence);
        sb.append(", rbStatus='").append(rbStatus).append('\'');
        sb.append(", agtCode2='").append(agtCode2).append('\'');
        sb.append(", sftpStatus='").append(sftpStatus).append('\'');
        sb.append(", sftpDate=").append(sftpDate);
        sb.append(", otpInd='").append(otpInd).append('\'');
        sb.append(", failCnt=").append(failCnt);
        sb.append(", nbCompleteDate=").append(nbCompleteDate);
        sb.append(", rbCompleteDate=").append(rbCompleteDate);
        sb.append(", citi='").append(citi).append('\'');
        sb.append(", orgBatchId='").append(orgBatchId).append('\'');
        sb.append(", stpInd='").append(stpInd).append('\'');
        sb.append(", parentBatchId='").append(parentBatchId).append('\'');
        sb.append(", documentsId='").append(documentsId).append('\'');
        sb.append(", iverifyId='").append(iVerifyId).append('\'');
        sb.append(", iverifyClientId='").append(iVerifyClientId).append('\'');
        sb.append(", iverifyDocSeq='").append(iVerifyDocSeq).append('\'');
        sb.append(", contentType='").append(contentType).append('\'');
        sb.append(", accessId='").append(accessId).append('\'');
        sb.append(", trCode='").append(trCode).append('\'');
        sb.append(", convertTif='").append(convertTif).append('\'');
        sb.append(", otpConfirmDate=").append(otpConfirmDate);
        sb.append(", rrRowId='").append(rrRowId).append('\'');
        sb.append('}');
        return sb.toString();
    }

}
