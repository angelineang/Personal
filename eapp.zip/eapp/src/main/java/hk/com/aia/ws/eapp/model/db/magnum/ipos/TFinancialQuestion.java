package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "T_FinancialQuestion")
public class TFinancialQuestion {

    @Column(name = "FinancialQuestionID", length = 60)
    @Id
    private String financialQuestionID;

    @Column(name = "EAPPID", length = 60)
    private String eappId;

    @Column(name = "isTick", length = 1)
    private String isTick;

    @Column(name = "isFirstTick", length = 20)
    private String isFirstTick;

    @Column(name = "isSecondTick", length = 20)
    private String isSecondTick;

    @Column(name = "field1Value", length = 50)
    private String field1Value;

    @Column(name = "field2Value", length = 50)
    private String field2Value;

    @Column(name = "field3Value", length = 50)
    private String field3Value;

    @Column(name = "field4Value", length = 50)
    private String field4Value;

    @Column(name = "field5Value", length = 50)
    private String field5Value;

    @Column(name = "field6Value", length = 50)
    private String field6Value;

    @Column(name = "field7Value", length = 50)
    private String field7Value;

    @Column(name = "field8Value", length = 50)
    private String field8Value;

    @Column(name = "field9Value", length = 50)
    private String field9Value;

    @Column(name = "field10Value", length = 50)
    private String field10Value;

    @Column(name = "field11Value")
    private String field11Value;

    @Column(name = "field12Value")
    private String field12Value;

    @Column(name = "field13Value")
    private String field13Value;

    @Column(name = "field14Value")
    private String field14Value;

    @Column(name = "field15Value")
    private String field15Value;

    @Column(name = "field16Value")
    private String field16Value;

    @Column(name = "field17Value")
    private String field17Value;

    @Column(name = "field18Value")
    private String field18Value;

    @Column(name = "field19Value")
    private String field19Value;

    @Column(name = "field20Value")
    private String field20Value;

    @Column(name = "sectionType", length = 20)
    private String sectionType;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "CONTACTID", length = 60)
    private String contactId;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TFinancialQuestion{");
        sb.append("financialQuestionID='").append(financialQuestionID).append('\'');
        sb.append(", eappId='").append(eappId).append('\'');
        sb.append(", isTick='").append(isTick).append('\'');
        sb.append(", isFirstTick='").append(isFirstTick).append('\'');
        sb.append(", isSecondTick='").append(isSecondTick).append('\'');
        sb.append(", field1Value='").append(field1Value).append('\'');
        sb.append(", field2Value='").append(field2Value).append('\'');
        sb.append(", field3Value='").append(field3Value).append('\'');
        sb.append(", field4Value='").append(field4Value).append('\'');
        sb.append(", field5Value='").append(field5Value).append('\'');
        sb.append(", field6Value='").append(field6Value).append('\'');
        sb.append(", field7Value='").append(field7Value).append('\'');
        sb.append(", field8Value='").append(field8Value).append('\'');
        sb.append(", field9Value='").append(field9Value).append('\'');
        sb.append(", field10Value='").append(field10Value).append('\'');
        sb.append(", field11Value='").append(field11Value).append('\'');
        sb.append(", field12Value='").append(field12Value).append('\'');
        sb.append(", field13Value='").append(field13Value).append('\'');
        sb.append(", field14Value='").append(field14Value).append('\'');
        sb.append(", field15Value='").append(field15Value).append('\'');
        sb.append(", field16Value='").append(field16Value).append('\'');
        sb.append(", field17Value='").append(field17Value).append('\'');
        sb.append(", field18Value='").append(field18Value).append('\'');
        sb.append(", field19Value='").append(field19Value).append('\'');
        sb.append(", field20Value='").append(field20Value).append('\'');
        sb.append(", sectionType='").append(sectionType).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", contactId='").append(contactId).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
