package hk.com.aia.ws.eapp.model.db.magnum.ipos.idclass;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TBasicPlanSelectionId implements Serializable {

    private static final long serialVersionUID = 6582340756205903747L;
    private String basicPlanSelectionId;
    private String planSelectionId;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TBasicPlanSelectionId{");
        sb.append("basicPlanSelectionId='").append(basicPlanSelectionId).append('\'');
        sb.append(", planSelectionId='").append(planSelectionId).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
