package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import hk.com.aia.ws.eapp.util.ConversionHandler;
import lombok.Data;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "T_CONTACT")
public class TContact {

    @Column(name = "CONTACTID", length = 60)
    @Id
    private String contactId;

    @Column(name = "TITLEID", length = 10)
    private String titleId;

    @Column(name = "LASTNAME_EN", length = 100)
    private String lastNameEn;

    @Column(name = "FIRSTNAME_EN", length = 50)
    private String firstNameEn;

    @Column(name = "ALIAS", length = 45)
    private String alias;

    @Column(name = "NAME_CHN", length = 500)
    private String nameChn;

    @Column(name = "GENDER", length = 1)
    private String gender;

    @Column(name = "AGENTCODE", length = 5)
    private String agentCode;

    @Column(name = "ACCESSCODE", length = 30)
    private String accesscode;

    @Column(name = "CITIZENSHIPCODE", length = 2)
    private String citizenshipCode;

    @Column(name = "CITIZENSHIPNAME", length = 255)
    private String citizenshipName;

    @Column(name = "OTHERCITIZENSHIP", length = 50)
    private String otherCitizenship;

    @Column(name = "NATIONALITYCODE", length = 2)
    private String nationalityCode;

    @Column(name = "NATIONALITYNAME", length = 255)
    private String nationalityName;

    @Column(name = "OTHERNATIONALITY", length = 50)
    private String otherNationality;

    @Column(name = "RESIDENTIALCODE", length = 2)
    private String residentialCode;

    @Column(name = "RESIDENTIALNAME", length = 255)
    private String residentialName;

    @Column(name = "OTHERRESIDENTIAL", length = 50)
    private String otherResidential;

    @Column(name = "DOB")
    @Temporal(TemporalType.DATE)
    private Date dob;

    @Column(name = "AGE")
    private Integer age;

    @Column(name = "MARITALSTATUS", length = 1)
    private String maritalStatus;

    @Column(name = "SSN", length = 20)
    private String ssn;

    @Column(name = "CONTACTTYPE", length = 1)
    private String contactType;

    @Column(name = "PROCESSSTATUS", length = 10)
    private String processStatus;

    @Column(name = "PRC")
    private Integer prc;

    @Column(name = "ORIGINALCONTACTID", length = 60)
    private String originalContactId;

    @Column(name = "BUSINESSCERTIFICATENO", length = 300)
    private String businessCertificateNo;

    @Column(name = "BUSINESSNATURECODE", length = 60)
    private String businessNatureCode;

    @Column(name = "REMARK", length = 500)
    private String remark;

    @Column(name = "SMOKER", length = 1)
    private String smoker;

    @Column(name = "IAMPCUSTOMERID", length = 60)
    private String iAmpCustomerId;

    @Column(name = "SERVERCONTACTID", length = 60)
    private String serverContactId;

    @Column(name = "MASTERCONTACTID", length = 60)
    private String masterContactId;

    @Column(name = "CITYCODE", length = 20)
    private String cityCode;

    @Column(name = "DUPLICATE")
    private Integer duplicate;

    @Column(name = "MERGED")
    private Integer merged;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "LASTUPDATEDATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    @LastModifiedDate
    private Date lastUpdateDateTime;

    @Column(name = "CREATEDBY", length = 10, updatable = false)
    @CreatedBy
    private String createdBy;

    @Column(name = "UPDATEDBY", length = 10)
    @LastModifiedBy
    private String updatedBy;

    @Column(name = "VITALITY")
    private Integer vitality;

    @Column(name = "CONTACTID_IPOS", length = 60)
    private String contactIdIpos;

    @Column(name = "PROVINCE", length = 50)
    private String province;

    @Column(name = "CITY", length = 50)
    private String city;

    @Column(name = "OTHERCITYDETAIL", length = 200)
    private String otherCityDetail;

    @Column(name = "ALPHAID", length = 60)
    private String alphaId;

    @Column(name = "PROSPECTID", length = 60)
    private String prospectId;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TContact{");
        sb.append("contactId='").append(contactId).append('\'');
        sb.append(", titleId='").append(titleId).append('\'');
        sb.append(", lastNameEn='").append(ConversionHandler.mask(lastNameEn)).append('\'');
        sb.append(", firstNameEn='").append(ConversionHandler.mask(firstNameEn)).append('\'');
        sb.append(", alias='").append(alias).append('\'');
        sb.append(", nameChn='").append(ConversionHandler.mask(nameChn)).append('\'');
        sb.append(", gender='").append(gender).append('\'');
        sb.append(", agentCode='").append(agentCode).append('\'');
        sb.append(", accesscode='").append(accesscode).append('\'');
        sb.append(", citizenshipCode='").append(citizenshipCode).append('\'');
        sb.append(", citizenshipName='").append(citizenshipName).append('\'');
        sb.append(", otherCitizenship='").append(otherCitizenship).append('\'');
        sb.append(", nationalityCode='").append(nationalityCode).append('\'');
        sb.append(", nationalityName='").append(nationalityName).append('\'');
        sb.append(", otherNationality='").append(otherNationality).append('\'');
        sb.append(", residentialCode='").append(residentialCode).append('\'');
        sb.append(", residentialName='").append(residentialName).append('\'');
        sb.append(", otherResidential='").append(otherResidential).append('\'');
        sb.append(", dob=").append(ConversionHandler.mask(dob));
        sb.append(", age=").append(age);
        sb.append(", maritalStatus='").append(maritalStatus).append('\'');
        sb.append(", ssn='").append(ConversionHandler.mask(ssn)).append('\'');
        sb.append(", contactType='").append(contactType).append('\'');
        sb.append(", processStatus='").append(processStatus).append('\'');
        sb.append(", prc=").append(prc);
        sb.append(", originalContactId='").append(originalContactId).append('\'');
        sb.append(", businessCertificateNo='").append(businessCertificateNo).append('\'');
        sb.append(", businessNatureCode='").append(businessNatureCode).append('\'');
        sb.append(", remark='").append(remark).append('\'');
        sb.append(", smoker='").append(smoker).append('\'');
        sb.append(", iAmpCustomerId='").append(iAmpCustomerId).append('\'');
        sb.append(", serverContactId='").append(serverContactId).append('\'');
        sb.append(", masterContactId='").append(masterContactId).append('\'');
        sb.append(", cityCode='").append(cityCode).append('\'');
        sb.append(", duplicate=").append(duplicate);
        sb.append(", merged=").append(merged);
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", lastUpdateDateTime=").append(lastUpdateDateTime);
        sb.append(", createdBy='").append(createdBy).append('\'');
        sb.append(", updatedBy='").append(updatedBy).append('\'');
        sb.append(", vitality=").append(vitality);
        sb.append(", contactIdIpos='").append(contactIdIpos).append('\'');
        sb.append(", province='").append(province).append('\'');
        sb.append(", city='").append(city).append('\'');
        sb.append(", otherCityDetail='").append(otherCityDetail).append('\'');
        sb.append(", alphaId='").append(alphaId).append('\'');
        sb.append(", prospectId='").append(prospectId).append('\'');
        sb.append('}');
        return sb.toString();
    }
}

