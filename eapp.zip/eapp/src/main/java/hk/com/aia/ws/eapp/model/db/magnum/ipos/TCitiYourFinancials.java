package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.math.BigDecimal;

@Entity
@Data
@Table(name = "T_CITIYOURFINANCIALS")
@EntityListeners(AuditingEntityListener.class)
public class TCitiYourFinancials {

    @Column(name = "YOURFINANCIALSID", length = 60)
    @Id
    private String yourFinancialsId;

    @Column(name = "FNAID", length = 60)
    private String fnaId;

    @Column(name = "CLIENTINCOMEAMOUNT")
    private BigDecimal clientIncomeAmount;

    @Column(name = "OTHERINCOMEAMOUNT")
    private BigDecimal otherIncomeAmount;

    @Column(name = "OTHERINCOMESOURCE", length = 60)
    private String otherIncomeSource;

    @Column(name = "LOANEXPENSESAMOUNT")
    private BigDecimal loanExpensesAmount;

    @Column(name = "LIVINGEXPENSESAMOUNT")
    private BigDecimal livingExpensesAmount;

    @Column(name = "OTHEREXPENSESAMOUNT")
    private BigDecimal otherExpensesAmount;

    @Column(name = "OTHEREXPENSESREMARK")
    private String otherExpensesRemark;

    @Column(name = "LIQUIDASSETSA")
    private BigDecimal liquidAssetSA;

    @Column(name = "LIQUIDASSETSB")
    private BigDecimal liquidAssetSB;

    @Column(name = "RESIDENTIAL")
    private BigDecimal residential;

    @Column(name = "INVESTMENT")
    private BigDecimal investment;

    @Column(name = "OTHERAMOUNT")
    private BigDecimal otherAmount;

    @Column(name = "SOURCEOFOTHER_A", length = 60)
    private String sourceOfOtherA;

    @Column(name = "LLOANS")
    private BigDecimal lLoans;

    @Column(name = "LPERSONLOANS")
    private BigDecimal lPersonLoans;

    @Column(name = "LMORTGAGE")
    private BigDecimal lMortgage;

    @Column(name = "LCARLOANS")
    private BigDecimal lCarLoans;

    @Column(name = "LOTHERSAMOUNT")
    private BigDecimal lOthersAmount;

    @Column(name = "SOURCEOFOTHER_L", length = 60)
    private String sourceOfOtherL;

    @Column(name = "LIQUIDASSETSAVINGCHECKFLAG", length = 30)
    private String liquidAssetSavingCheckFlag;

    @Column(name = "LIQUIDASSETCASHAMOUNT")
    private BigDecimal liquidAssetCashAmount;

    @Column(name = "LIQUIDASSETMONEYBANKAMOUNT")
    private BigDecimal liquidAssetMoneyBankAmount;

    @Column(name = "LIQUIDASSETINVESTCHECKFLAG", length = 30)
    private String liquidAssetInvestCheckFlag;

    @Column(name = "LIQUIDASSETINVESTAMOUNT")
    private BigDecimal liquidAssetInvestAmount;

    @Column(name = "LIQUIDASSETINVESTOTHER", length = 200)
    private String liquidAssetInvestOther;

    @Column(name = "SALARY")
    private BigDecimal salary;

    @Column(name = "BONUS")
    private BigDecimal bonus;

    @Column(name = "DIVIDENDS")
    private BigDecimal dividends;

    @Column(name = "RENT")
    private BigDecimal rent;

    @Column(name = "ANNUITY")
    private BigDecimal annuity;

    @Column(name = "BUSINESSINCOME")
    private BigDecimal businessIncome;

    @Column(name = "MISCELLANEOUSINCOME")
    private BigDecimal miscellaneousIncome;

    @Column(name = "MISCELLANEOUSINCOMESPEC", length = 200)
    private String miscellaneousIncomeSpec;

    @Column(name = "AVGMTHINCOME")
    private BigDecimal avgMthIncome;

    @Column(name = "AVGANNINCOME")
    private BigDecimal avgAnnIncome;

    @Column(name = "AVGMTHEXPENSES")
    private BigDecimal avgMthExpenses;

    @Column(name = "DISPINCOME")
    private BigDecimal dispIncome;

    @Column(name = "LIQUIDASSET")
    private BigDecimal liquidAsset;

    @Column(name = "shortTermLiability")
    private BigDecimal shortTermLiability;

    @Column(name = "longTermLiability")
    private BigDecimal longTermLiability;

    @Column(name = "otherLiability")
    private BigDecimal otherLiability;

    @Column(name = "ISSELECTEDFINANCIALRANGE", length = 1)
    private String isSelectedFinancialRange;

    @Column(name = "FINANCIALRANGEVALUE")
    private BigDecimal financialRangeValue;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TCitiYourFinancials{");
        sb.append("yourFinancialsId='").append(yourFinancialsId).append('\'');
        sb.append(", fnaId='").append(fnaId).append('\'');
        sb.append(", clientIncomeAmount=").append(clientIncomeAmount);
        sb.append(", otherIncomeAmount=").append(otherIncomeAmount);
        sb.append(", otherIncomeSource='").append(otherIncomeSource).append('\'');
        sb.append(", loanExpensesAmount=").append(loanExpensesAmount);
        sb.append(", livingExpensesAmount=").append(livingExpensesAmount);
        sb.append(", otherExpensesAmount=").append(otherExpensesAmount);
        sb.append(", otherExpensesRemark='").append(otherExpensesRemark).append('\'');
        sb.append(", liquidAssetSA=").append(liquidAssetSA);
        sb.append(", liquidAssetSB=").append(liquidAssetSB);
        sb.append(", residential=").append(residential);
        sb.append(", investment=").append(investment);
        sb.append(", otherAmount=").append(otherAmount);
        sb.append(", sourceOfOtherA='").append(sourceOfOtherA).append('\'');
        sb.append(", lLoans=").append(lLoans);
        sb.append(", lPersonLoans=").append(lPersonLoans);
        sb.append(", lMortgage=").append(lMortgage);
        sb.append(", lCarLoans=").append(lCarLoans);
        sb.append(", lOthersAmount=").append(lOthersAmount);
        sb.append(", sourceOfOtherL='").append(sourceOfOtherL).append('\'');
        sb.append(", liquidAssetSavingCheckFlag='").append(liquidAssetSavingCheckFlag).append('\'');
        sb.append(", liquidAssetCashAmount=").append(liquidAssetCashAmount);
        sb.append(", liquidAssetMoneyBankAmount=").append(liquidAssetMoneyBankAmount);
        sb.append(", liquidAssetInvestCheckFlag='").append(liquidAssetInvestCheckFlag).append('\'');
        sb.append(", liquidAssetInvestAmount=").append(liquidAssetInvestAmount);
        sb.append(", liquidAssetInvestOther='").append(liquidAssetInvestOther).append('\'');
        sb.append(", salary=").append(salary);
        sb.append(", bonus=").append(bonus);
        sb.append(", dividends=").append(dividends);
        sb.append(", rent=").append(rent);
        sb.append(", annuity=").append(annuity);
        sb.append(", businessIncome=").append(businessIncome);
        sb.append(", miscellaneousIncome=").append(miscellaneousIncome);
        sb.append(", miscellaneousIncomeSpec='").append(miscellaneousIncomeSpec).append('\'');
        sb.append(", avgMthIncome=").append(avgMthIncome);
        sb.append(", avgAnnIncome=").append(avgAnnIncome);
        sb.append(", avgMthExpenses=").append(avgMthExpenses);
        sb.append(", dispIncome=").append(dispIncome);
        sb.append(", liquidAsset=").append(liquidAsset);
        sb.append(", shortTermLiability=").append(shortTermLiability);
        sb.append(", longTermLiability=").append(longTermLiability);
        sb.append(", otherLiability=").append(otherLiability);
        sb.append(", isSelectedFinancialRange='").append(isSelectedFinancialRange).append('\'');
        sb.append(", financialRangeValue=").append(financialRangeValue);
        sb.append('}');
        return sb.toString();
    }
}

