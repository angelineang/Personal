package hk.com.aia.ws.eapp.model.properties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AzureKVProperties {

    private String clientId;
    private String clientSecret;
    private String tenantId;
    private String keyIdentifier;
    private String keyVaultUrl;
    private Boolean enabled;
    private Integer tokenAcquireTimeoutSeconds;
    private Integer refreshInterval;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("AzureKVProperties{");
        sb.append("clientId='").append(clientId).append('\'');
        sb.append(", clientSecret='").append(clientSecret).append('\'');
        sb.append(", tenantId='").append(tenantId).append('\'');
        sb.append(", keyIdentifier='").append(keyIdentifier).append('\'');
        sb.append(", keyVaultUrl='").append(keyVaultUrl).append('\'');
        sb.append(", enabled=").append(enabled);
        sb.append(", tokenAcquireTimeoutSeconds=").append(tokenAcquireTimeoutSeconds);
        sb.append(", refreshInterval=").append(refreshInterval);
        sb.append('}');
        return sb.toString();
    }
}
