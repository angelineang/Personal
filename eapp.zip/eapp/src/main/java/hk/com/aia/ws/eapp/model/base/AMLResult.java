package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonProperty;

public class AMLResult {

    @JsonProperty("risk_desc_c")
    private String riskDescC;

    @JsonProperty("risk_desc_e")
    private String riskDescE;

    @JsonProperty("risk_msg_c")
    private String riskMsgC;

    @JsonProperty("risk_msg_s")
    private String riskMsgS;
    
    @JsonProperty("risk_desc_s")
    private String riskDescS;

    @JsonProperty("risk_msg_e")
    private String riskMsgE;

    @JsonProperty("seq")
    private int seq;

    @JsonProperty("pend_code")
    private String pendCode;

    @JsonProperty("risk_level")
    private String riskLevel;


}
