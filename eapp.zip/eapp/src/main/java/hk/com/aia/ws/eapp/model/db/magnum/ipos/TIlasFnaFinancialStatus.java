package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "T_ILASFNAFINANCIALSTATUS")
public class TIlasFnaFinancialStatus {

    @Column(name = "FNAFINANCIALSTATUSID", length = 60)
    @Id
    private String fnaFinancialStatusId;

    @Column(name = "FNAID", length = 60)
    private String fnaId;

    @Column(name = "MONTHINCOME")
    private BigDecimal monthIncome;

    @Column(name = "YEARINCOME")
    private BigDecimal yearIncome;

    @Column(name = "MONTHBONUS")
    private BigDecimal monthBonus;

    @Column(name = "YEARBONUS")
    private BigDecimal yearBonus;

    @Column(name = "MONTHOTHERINCOME")
    private BigDecimal monthOtherIncome;

    @Column(name = "YEAROTHERINCOME")
    private BigDecimal yearOtherIncome;

    @Column(name = "AVERAGEINCOME")
    private BigDecimal averageIncome;

    @Column(name = "MONTHLIVINGEXPENSE")
    private BigDecimal monthLivingExpense;

    @Column(name = "YEARLIVINGEXPENSE")
    private BigDecimal yearLivingExpense;

    @Column(name = "MONTHPERSONALEXPENSE")
    private BigDecimal monthPersonalExpense;

    @Column(name = "YEARPERSONALEXPENSE")
    private BigDecimal yearPersonalExpense;

    @Column(name = "AVERAGEOUTGOING")
    private BigDecimal averageOutGoing;

    @Column(name = "DISPOSABLE")
    private BigDecimal disposable;

    @Column(name = "LIFEPROTECTION")
    private Integer lifeProtection;

    @Column(name = "LIVINGEXPEMSEYEARS")
    private Integer livingExpemseYears;

    @Column(name = "FAMILYCOMMITMENTS")
    private BigDecimal familyCommitments;

    @Column(name = "DEBT")
    private BigDecimal debt;

    @Column(name = "FUNERAL")
    private BigDecimal funeral;

    @Column(name = "ESTATE")
    private BigDecimal estate;

    @Column(name = "TOTALRESPONSIBILITYIES")
    private BigDecimal totalResponsibilityies;

    @Column(name = "LIFEPSAVINGS")
    private BigDecimal lifePSavings;

    @Column(name = "LIQUIDASSET")
    private BigDecimal liquidAsset;

    @Column(name = "LIFECOVERAGE")
    private BigDecimal lifeCoverage;

    @Column(name = "TOTALUSABLE")
    private BigDecimal totalUsable;

    @Column(name = "NETLIFENEEDS")
    private BigDecimal netLifeNeeds;

    @Column(name = "CI", length = 4)
    private Integer ci;

    @Column(name = "TWOYEAREXPENSE")
    private BigDecimal twoYearExpense;

    @Column(name = "THREEYEAREXPENSE")
    private Double threeYearExpense;

    @Column(name = "FIVEYEAREXPENSE")
    private BigDecimal fiveYearExpense;

    @Column(name = "CIPROTECTIONNEEDS")
    private BigDecimal ciProtectionNeeds;

    @Column(name = "EXISTINGCICOVERAGE")
    private BigDecimal existingCiCoverage;

    @Column(name = "NETCINEEDS")
    private BigDecimal netCiNeeds;

    @Column(name = "PA")
    private Integer pa;

    @Column(name = "ACCIDENTNEEDS")
    private BigDecimal accidentNeeds;

    @Column(name = "EXISTINGACCIDENTNEEDS")
    private BigDecimal existingAccidentNeeds;

    @Column(name = "NETACCIDENTNEEDS")
    private BigDecimal netAccidentNeeds;

    @Column(name = "HEALTHCOVERAGE")
    private BigDecimal healthCoverage;

    @Column(name = "INPATIENTLEVEL", length = 20)
    private String inPatientLevel;

    @Column(name = "HOSPITALCOVERAGE")
    private BigDecimal hospitalCoverage;

    @Column(name = "HEALTHNEEDS")
    private BigDecimal healthNeeds;

    @Column(name = "EDUCATION")
    private Integer education;

    @Column(name = "NETEDUCATIONNEEDS")
    private BigDecimal netEducationNeeds;

    @Column(name = "RETIREMENT")
    private Integer retirement;

    @Column(name = "RETIREMENTYEAR")
    private Integer retirementYear;

    @Column(name = "ANNUALSPENDING")
    private BigDecimal annualSpending;

    @Column(name = "RETIREMENTNEEDS")
    private BigDecimal retirementNeeds;

    @Column(name = "RETIREMENTSAVING")
    private BigDecimal retirementSaving;

    @Column(name = "NETRETIREMENTNEEDS")
    private BigDecimal netRetirementNeeds;

    @Column(name = "INVESTMENT")
    private BigDecimal investment;

    @Column(name = "TOTALGOAL")
    private BigDecimal totalGoal;

    @Column(name = "CURRENTINVESTMENT")
    private BigDecimal currentInvestment;

    @Column(name = "NETINVESTMENTNEEDS")
    private BigDecimal netInvestmentNeeds;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "LIABILITIESYEAR")
    private Integer liabilitiesYear;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TIlasFnaFinancialStatus{");
        sb.append("fnaFinancialStatusId='").append(fnaFinancialStatusId).append('\'');
        sb.append(", fnaId='").append(fnaId).append('\'');
        sb.append(", monthIncome=").append(monthIncome);
        sb.append(", yearIncome=").append(yearIncome);
        sb.append(", monthBonus=").append(monthBonus);
        sb.append(", yearBonus=").append(yearBonus);
        sb.append(", monthOtherIncome=").append(monthOtherIncome);
        sb.append(", yearOtherIncome=").append(yearOtherIncome);
        sb.append(", averageIncome=").append(averageIncome);
        sb.append(", monthLivingExpense=").append(monthLivingExpense);
        sb.append(", yearLivingExpense=").append(yearLivingExpense);
        sb.append(", monthPersonalExpense=").append(monthPersonalExpense);
        sb.append(", yearPersonalExpense=").append(yearPersonalExpense);
        sb.append(", averageOutGoing=").append(averageOutGoing);
        sb.append(", disposable=").append(disposable);
        sb.append(", lifeProtection=").append(lifeProtection);
        sb.append(", livingExpemseYears=").append(livingExpemseYears);
        sb.append(", familyCommitments=").append(familyCommitments);
        sb.append(", debt=").append(debt);
        sb.append(", funeral=").append(funeral);
        sb.append(", estate=").append(estate);
        sb.append(", totalResponsibilityies=").append(totalResponsibilityies);
        sb.append(", lifePSavings=").append(lifePSavings);
        sb.append(", liquidAsset=").append(liquidAsset);
        sb.append(", lifeCoverage=").append(lifeCoverage);
        sb.append(", totalUsable=").append(totalUsable);
        sb.append(", netLifeNeeds=").append(netLifeNeeds);
        sb.append(", ci=").append(ci);
        sb.append(", twoYearExpense=").append(twoYearExpense);
        sb.append(", threeYearExpense=").append(threeYearExpense);
        sb.append(", fiveYearExpense=").append(fiveYearExpense);
        sb.append(", ciProtectionNeeds=").append(ciProtectionNeeds);
        sb.append(", existingCiCoverage=").append(existingCiCoverage);
        sb.append(", netCiNeeds=").append(netCiNeeds);
        sb.append(", pa=").append(pa);
        sb.append(", accidentNeeds=").append(accidentNeeds);
        sb.append(", existingAccidentNeeds=").append(existingAccidentNeeds);
        sb.append(", netAccidentNeeds=").append(netAccidentNeeds);
        sb.append(", healthCoverage=").append(healthCoverage);
        sb.append(", inPatientLevel='").append(inPatientLevel).append('\'');
        sb.append(", hospitalCoverage=").append(hospitalCoverage);
        sb.append(", healthNeeds=").append(healthNeeds);
        sb.append(", education=").append(education);
        sb.append(", netEducationNeeds=").append(netEducationNeeds);
        sb.append(", retirement=").append(retirement);
        sb.append(", retirementYear=").append(retirementYear);
        sb.append(", annualSpending=").append(annualSpending);
        sb.append(", retirementNeeds=").append(retirementNeeds);
        sb.append(", retirementSaving=").append(retirementSaving);
        sb.append(", netRetirementNeeds=").append(netRetirementNeeds);
        sb.append(", investment=").append(investment);
        sb.append(", totalGoal=").append(totalGoal);
        sb.append(", currentInvestment=").append(currentInvestment);
        sb.append(", netInvestmentNeeds=").append(netInvestmentNeeds);
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", liabilitiesYear=").append(liabilitiesYear);
        sb.append('}');
        return sb.toString();
    }
}
