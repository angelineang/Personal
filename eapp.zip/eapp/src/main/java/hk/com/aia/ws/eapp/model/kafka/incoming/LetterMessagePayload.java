package hk.com.aia.ws.eapp.model.kafka.incoming;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import hk.com.aia.ws.eapp.util.ConversionHandler;
import lombok.Data;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class LetterMessagePayload {

    @JsonProperty("versionNo")
    private String versionNo;

    @JsonProperty("eSignDate")
    private Date eSignDate;

    @JsonProperty("docSeq")
    private Integer docSeq;

    @JsonProperty("cycleDate")
    private Date cycleDate;

    @JsonProperty("lang")
    private String lang;

    @JsonProperty("lastViewTime")
    private Date lastViewTime;

    @JsonProperty("md5")
    private String md5;

    @JsonProperty("lastModifiedTime")
    private Date lastModifiedTime;

    @JsonProperty("blobPathWithWatermark")
    private String blobPathWithWatermark;

    @JsonProperty("fileName")
    private String fileName;

    @JsonProperty("channel")
    private String channel;

    @JsonProperty("lastViewCount")
    private Integer lastViewCount;

    @JsonProperty("updateOn")
    private Date updateOn;

    @JsonProperty("createDate")
    private Date createDate;

    @JsonProperty("blobPath")
    private String blobPath;

    @JsonProperty("letterType")
    private String letterType;

    @JsonProperty("polNo")
    private String polNo;

    @JsonProperty("compNo")
    private String compNo;

    @JsonProperty("fileType")
    private String fileType;

    @JsonProperty("fileSize")
    private Integer fileSize;

    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("CounterOfferMessagePayload{");
        sb.append("compNo='").append(compNo).append('\'');
        sb.append(", md5='").append(md5).append('\'');
        sb.append(", updateOn='").append(updateOn).append('\'');
        sb.append(", channel='").append(channel).append('\'');
        sb.append(", fileType='").append(fileType).append('\'');
        sb.append(", fileSize='").append(fileSize).append('\'');
        sb.append(", lastModifiedTime='").append(lastModifiedTime).append('\'');
        sb.append(", eSignDate='").append(eSignDate).append('\'');
        sb.append(", createDate='").append(createDate).append('\'');
        sb.append(", blobPath='").append(blobPath);
        sb.append(", blobPathWithWatermark='").append(blobPathWithWatermark);
        sb.append(", polNo='").append(ConversionHandler.mask(polNo)).append('\'');
        sb.append(", letterType='").append(letterType).append('\'');
        sb.append(", lang='").append(lang).append('\'');
        sb.append(", lastViewCount='").append(lastViewCount).append('\'');
        sb.append(", lastViewTime='").append(lastViewTime).append('\'');
        sb.append(", cycleDate='").append(cycleDate).append('\'');
        sb.append(", docSeq=").append(docSeq).append('\'');
        sb.append(", fileName='").append(fileName).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
