package hk.com.aia.ws.eapp.model.db.magnum.ipos.idclass;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TChangeSumAssuredId implements Serializable {

    private String changeSumAssuredId;
    private String sqsQuotationId;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TChangeSumAssuredId{");
        sb.append("changeSumAssuredId='").append(changeSumAssuredId).append('\'');
        sb.append(", sqsQuotationId='").append(sqsQuotationId).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
