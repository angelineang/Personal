package hk.com.aia.ws.eapp.model.db.magnum.ipos;


import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "T_EAPPRECOMMENDLEVEL")
public class TEappRecommendLevel {
    @Column(name = "EAPPRLID", length = 60)
    @Id
    private String eappRlId;

    @Column(name = "EAPPID", length = 60)
    private String eappId;

    @Column(name = "LIFE")
    private BigDecimal life;

    @Column(name = "REGULARINCOME")
    private BigDecimal regularIncome;

    @Column(name = "SAVINGS")
    private BigDecimal savings;

    @Column(name = "INVESTMENTS")
    private BigDecimal investments;

    @Column(name = "CI")
    private BigDecimal ci;

    @Column(name = "AMOUNT")
    private BigDecimal amount;

    @Column(name = "CURRENCY_LIFE", length = 10)
    private String currencyLife;

    @Column(name = "CURRENCY_REGULARINCOME", length = 10)
    private String currencyRegularincome;

    @Column(name = "CURRENCY_SAVINGS", length = 10)
    private String currencySavings;

    @Column(name = "CURRENCY_INVESTMENTS", length = 10)
    private String currencyInvestments;

    @Column(name = "CURRENCY_CI", length = 10)
    private String currencyCi;

    @Column(name = "CURRENCY", length = 60)
    private String currency;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "LASTUPDATEDATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    @LastModifiedDate
    private Date lastUpdateDateTime;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TEappRecommendLevel{");
        sb.append("eappRlId='").append(eappRlId).append('\'');
        sb.append(", eappId='").append(eappId).append('\'');
        sb.append(", life=").append(life);
        sb.append(", regularIncome=").append(regularIncome);
        sb.append(", savings=").append(savings);
        sb.append(", investments=").append(investments);
        sb.append(", ci=").append(ci);
        sb.append(", amount=").append(amount);
        sb.append(", currencyLife='").append(currencyLife).append('\'');
        sb.append(", currencyRegularincome='").append(currencyRegularincome).append('\'');
        sb.append(", currencySavings='").append(currencySavings).append('\'');
        sb.append(", currencyInvestments='").append(currencyInvestments).append('\'');
        sb.append(", currencyCi='").append(currencyCi).append('\'');
        sb.append(", currency='").append(currency).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", lastUpdateDateTime=").append(lastUpdateDateTime);
        sb.append('}');
        return sb.toString();
    }
}
