package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;

@ApiModel(value = "Request Agent Profile")
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class AgentProfileRequest extends Payload {

    @JsonProperty("login_id")
    @NotBlank
    private String loginId;

    @JsonProperty("access_code")
    private String accessCode;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("AgentProfileRequest{");
        sb.append("loginId='").append(loginId).append('\'');
        sb.append(", accessCode='").append(accessCode).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
