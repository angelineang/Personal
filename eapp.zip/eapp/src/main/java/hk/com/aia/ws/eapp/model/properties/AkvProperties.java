package hk.com.aia.ws.eapp.model.properties;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class AkvProperties {

    private String clientId;
    private String clientKey;
    private String tenantId;
    private String keyIdentifier;
    private Boolean enabled;
    private String uri;
    private Integer tokenAcquireTimeoutSeconds;
    private Integer refreshInterval;
    private String rsaKey;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("AkvProperties{");
        sb.append("clientId='").append(clientId).append('\'');
        sb.append(", clientKey='").append(clientKey).append('\'');
        sb.append(", tenantId='").append(tenantId).append('\'');
        sb.append(", keyIdentifier='").append(keyIdentifier).append('\'');
        sb.append(", enabled=").append(enabled);
        sb.append(", uri='").append(uri).append('\'');
        sb.append(", tokenAcquireTimeoutSeconds=").append(tokenAcquireTimeoutSeconds);
        sb.append(", refreshInterval=").append(refreshInterval);
        sb.append(", rsaKey='").append(rsaKey).append('\'');
        sb.append('}');
        return sb.toString();
    }
}

