package hk.com.aia.ws.eapp.controller;

import hk.com.aia.ws.eapp.constant.Constants;
import hk.com.aia.ws.eapp.constant.Constants.APIAction;
import hk.com.aia.ws.eapp.constant.Constants.APIFunction;
import hk.com.aia.ws.eapp.constant.Constants.APIPath;
import hk.com.aia.ws.eapp.model.base.CustomResponseStatus;
import hk.com.aia.ws.eapp.model.base.PolicyProcessStatusList;
import hk.com.aia.ws.eapp.model.base.PolicyProcessUpdateResult;
import hk.com.aia.ws.eapp.model.base.ResultMessage;
import hk.com.aia.ws.eapp.model.db.magnum.rr.IposReqSts;
import hk.com.aia.ws.eapp.model.db.magnum.rr.IposReqStsPre;
import hk.com.aia.ws.eapp.model.log.TranKeys;
import hk.com.aia.ws.eapp.model.request.Request;
import hk.com.aia.ws.eapp.model.response.Response;
import hk.com.aia.ws.eapp.model.response.error.GatewayError400;
import hk.com.aia.ws.eapp.model.response.error.GatewayError401;
import hk.com.aia.ws.eapp.model.response.error.InternalError500;
import hk.com.aia.ws.eapp.service.LogService;
import hk.com.aia.ws.eapp.service.PayloadRequestService;
import hk.com.aia.ws.eapp.service.PolicyProcessService;
import io.swagger.annotations.*;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

import static hk.com.aia.ws.eapp.constant.Constants.OK;
import static hk.com.aia.ws.eapp.constant.Constants.RETURN_CODE_1;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;

@Slf4j
@AllArgsConstructor
@RestController
@RequestMapping("/policies")
@Api(value = "Policy Processing", tags = {"API(s) for policy processing"})
@Validated
public class PolicyProcessController {

    @Autowired
    private final PolicyProcessService policyProcessService;

    @Autowired
    private PayloadRequestService payloadRequestService;
    
    @Autowired
    private LogService logService;
    
    /**
     * For XGFE to Callback
     *
     * @return Response
     */
    @ApiOperation(value = "Update or Insert policy status to eSubLog table",
            notes = "Update or insert the UNI cases event handlers' state to eSubLog table by policy number. Maximum of 1 policy_no, reject item out-of-range request.")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK"),
            @ApiResponse(code = 201, message = "Created"),
            @ApiResponse(code = 400, message = "Bad Request", response = GatewayError400.class),
            @ApiResponse(code = 401, message = "Unauthorized", response = GatewayError401.class),
            @ApiResponse(code = 404, message = "Invalid request.", response = Response.class),
            @ApiResponse(code = 500, message = "Internal Server Error", response = InternalError500.class)
    })
    @PostMapping(value = "/updateProcessStatus", produces = "application/json")
    public Response<PolicyProcessUpdateResult> updateEsubLogInBatch(
            @ApiParam(value = "Local business unit.    | Valid Values |   | ----------   |   | HK, TH, SG   | ", required = true)
            @RequestHeader(value = Constants.RequestHeader.AIA_LBU, required = true) String xAiaLbu,
            @ApiParam(value = "Unique id for the request for tracking purposes.        ", required = true)
            @RequestHeader(value = Constants.RequestHeader.REQUEST_ID, required = true) String xAiaRequestId,
            @ApiParam(value = "Target environment of the request. Note that this header is required only when accessing non-production environments.    | Valid Values       |   | ------------------ |   | qa1, qa2, qa3, qa4 |        ")
            @RequestHeader(value = Constants.RequestHeader.AIA_ENV, required = false) String xAiaEnv,
            @ApiParam(value = "JWT Token for the request to verify Agent Authorization")
            @RequestHeader(value = Constants.RequestHeader.TOKEN_AGENT, required = false) String xAiaTokenAgent,
            @ApiParam(value = "Trace Id for EFK Logging")
            @RequestHeader(value = Constants.RequestHeader.TRACE_ID, required = false) String xAiaHkTraceId,
            @ApiParam(value = "Context Id for EFK Logging")
            @RequestHeader(value = Constants.RequestHeader.CONTEXT_ID) String xAiaHkContextId,
            @ApiParam(value = "Policy details to be submitted", required = true)
            @Valid @RequestBody Request<PolicyProcessStatusList> policyProcessRequest) {
    	
    	LocalDateTime start = LocalDateTime.now();
    	String submitType="E";
    	String eappId="";
    	String polNo= policyProcessRequest.getData().getPolicyProcessStatusList().get(0).getPolNo();
    	
    	logService.logTranKey(new TranKeys(polNo, "", "","",policyProcessRequest.getAppId(),APIFunction.EAPP_UPD_POL_PENDING));
    	logService.logStartWorkingIntegration( APIPath.EAPP_P_UPD_PROC_STS);

    	IposReqSts iposReqSts=null;
    	try {
			iposReqSts =policyProcessService.getPolReqSts(polNo);
			eappId = iposReqSts.getEappId();
			submitType = iposReqSts.getSubmitType();
		} catch (Exception e) {
			log.info("no record found in tbl_ipos_req_sts");
		}
		if (iposReqSts == null) {
			List<IposReqStsPre> IposReqStsPreList = policyProcessService.getPolReqStsPre(polNo);
			if (!IposReqStsPreList.isEmpty()) {
				eappId = IposReqStsPreList.get(0).getEappId();
				submitType = IposReqStsPreList.get(0).getSubmitType();
			}
		}
    	
    	logService.logTranKey(new TranKeys(polNo, submitType, eappId,"",policyProcessRequest.getAppId(),APIFunction.EAPP_UPD_POL_PENDING));
    	logService.logEappId(eappId);
    	logService.logSubmitType(submitType); 
    	
    	if(("S").equals(submitType)){
			payloadRequestService.saveRequestPreJson(polNo, "POL_UP-C", policyProcessRequest, eappId);
		}else {
			payloadRequestService.saveRequestJson(polNo, "POL_UP-C", policyProcessRequest);
		}
    	
        Response<PolicyProcessUpdateResult> payload = new Response<>();
        payload.setTransId(policyProcessRequest.getTransId());
        payload.setData(policyProcessService.policyProcess(policyProcessRequest.getData()));
        payload.setStatus(CustomResponseStatus.SUCCESS.getDescription());
        payload.getResultMessages().add(new ResultMessage(RETURN_CODE_1, OK));

        
        
      	if(("S").equals(submitType)){
  			payloadRequestService.saveRequestPreJson(polNo, "POL_UP-R", payload, eappId);
  		}else {
  			payloadRequestService.saveRequestJson(polNo, "POL_UP-R", payload);
  		}
          
      	LocalDateTime end =LocalDateTime.now() ;
      	Duration duration = Duration.between( start,end );
      	logService.logEndWorkingSuccessIntegration( APIPath.EAPP_P_UPD_PROC_STS, duration.toMillis());
          
        
        return payload;
    }

}
