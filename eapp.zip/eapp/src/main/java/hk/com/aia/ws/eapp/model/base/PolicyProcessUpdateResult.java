package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@ApiModel(value = "Policy Process Update Result - Batch Update Result")
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class PolicyProcessUpdateResult extends Payload {

	@ApiModelProperty(value = "Confidential Data - Policies that have been successfully updated to eSubLog table", example = "[\"B12345678\",\"B12345679\",\"B12345680\"]")
	@JsonProperty("success_cases")
	private List<String> successCases = new ArrayList<>();

	@ApiModelProperty(value = "Confidential Data - Policies that have failed to update to eSubLog table", example = "[\"B12345681\"]")
	@JsonProperty("failed_cases")
	private List<String> failedCases = new ArrayList<>();
}
