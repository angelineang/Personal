package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "T_EAPPAUDIOANSWER")
public class TEappAudioAnswer {
    @Column(name = "AUDIOANSWERID", length = 60)
    @Id
    private String audioAnswerId;

    @Column(name = "EAPPID", length = 60)
    private String eappId;

    @Column(name = "ANSWER", length = 50)
    private String answer;

    @Column(name = "AUDIODATE")
    @Temporal(TemporalType.DATE)
    private Date audioDate;

    @Column(name = "STARTTIME", length = 10)
    private String startTime;

    @Column(name = "ENDTIME", length = 10)
    private String endTime;

    @Column(name = "OPTINAUDIO", length = 4)
    private String optInAudio;

    @Column(name = "OPTOUTAUDIO", length = 4)
    private String optOutAudio;

    @Column(name = "OTHERSCONTENT", length = 1000)
    private String othersContent;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "LASTUPDATEDATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    @LastModifiedDate
    private Date lastUpdateDateTime;

    @Column(name = "IFSDASIGNDATE")
    @Temporal(TemporalType.DATE)
    private Date ifsdaSignDate;


    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TEappAudioAnswer{");
        sb.append("audioAnswerId='").append(audioAnswerId).append('\'');
        sb.append(", eappId='").append(eappId).append('\'');
        sb.append(", answer='").append(answer).append('\'');
        sb.append(", audioDate=").append(audioDate);
        sb.append(", startTime='").append(startTime).append('\'');
        sb.append(", endTime='").append(endTime).append('\'');
        sb.append(", optInAudio='").append(optInAudio).append('\'');
        sb.append(", optOutAudio='").append(optOutAudio).append('\'');
        sb.append(", othersContent='").append(othersContent).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", lastUpdateDateTime=").append(lastUpdateDateTime);
        sb.append(", ifsdaSignDate=").append(ifsdaSignDate);
        sb.append('}');
        return sb.toString();
    }
}
