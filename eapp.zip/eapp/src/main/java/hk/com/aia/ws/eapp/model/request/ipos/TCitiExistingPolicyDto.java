package hk.com.aia.ws.eapp.model.request.ipos;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;


@ApiModel(value = "T_CITIEXISTINGPOLICY Model")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TCitiExistingPolicyDto {

    @ApiModelProperty(value = "existing Pol Id", required = true)
    @JsonProperty("existing_pol_id")
    @Size(max = 60)
    @NotBlank
    private String existingPolId;

    @JsonProperty("fna_id")
    @Size(max = 60)
    private String fnaId;

    @JsonProperty("insurance_company")
    @Size(max = 200)
    private String insuranceCompany;

    @JsonProperty("policy_type")
    @Size(max = 60)
    private String policyType;

    @JsonProperty("premium_mode")
    private Integer premiumMode;

    @JsonProperty("sum_assured")
    private BigDecimal sumAssured;

    @JsonProperty("modal_premium_amount")
    private BigDecimal modalPremiumAmount;

    @JsonProperty("year_due")
    private Integer yearDue;

    @JsonProperty("remaining_payment_term")
    private Integer remainingPaymentTerm;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TCitiExistingPolicyDto{");
        sb.append("existingPolId='").append(existingPolId).append('\'');
        sb.append(", fnaId='").append(fnaId).append('\'');
        sb.append(", insuranceCompany='").append(insuranceCompany).append('\'');
        sb.append(", policyType='").append(policyType).append('\'');
        sb.append(", premiumMode=").append(premiumMode);
        sb.append(", sumAssured=").append(sumAssured);
        sb.append(", modalPremiumAmount=").append(modalPremiumAmount);
        sb.append(", yearDue=").append(yearDue);
        sb.append(", remainingPaymentTerm=").append(remainingPaymentTerm);
        sb.append('}');
        return sb.toString();
    }
}
