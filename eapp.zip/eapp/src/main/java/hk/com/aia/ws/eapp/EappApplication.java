package hk.com.aia.ws.eapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class EappApplication {

	public static void main(String[] args) {
		SpringApplication.run(EappApplication.class);
	}

}
