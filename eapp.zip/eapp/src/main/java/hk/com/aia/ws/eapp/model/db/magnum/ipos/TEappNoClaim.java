package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@Table(name = "T_EAPPNOCLAIM")
@EntityListeners(AuditingEntityListener.class)
public class TEappNoClaim {
    @Column(name = "EAPPNOCLAIMID", length = 60)
    @Id
    private String eappNoClaimId;

    @Column(name = "EAPPID", length = 60)
    private String eappId;

    @Column(name = "INSURECOMPANY", length = 50)
    private String insureCompany;

    @Column(name = "PRODUCTNAME", length = 512)
    private String productName;

    @Column(name = "LASTDATE")
    private Date lastDate;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "LASTUPDATEDATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    @LastModifiedDate
    private Date lastUpdateDateTime;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TEappNoClaim{");
        sb.append("eappNoClaimId='").append(eappNoClaimId).append('\'');
        sb.append(", eappId='").append(eappId).append('\'');
        sb.append(", insureCompany='").append(insureCompany).append('\'');
        sb.append(", productName='").append(productName).append('\'');
        sb.append(", lastDate=").append(lastDate);
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", lastUpdateDateTime=").append(lastUpdateDateTime);
        sb.append('}');
        return sb.toString();
    }
}
