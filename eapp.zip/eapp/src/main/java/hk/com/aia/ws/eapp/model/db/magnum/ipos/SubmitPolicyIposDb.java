package hk.com.aia.ws.eapp.model.db.magnum.ipos;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import hk.com.aia.ws.eapp.model.base.Payload;
import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.util.List;

@ApiModel(value = "Submit Policy - IPOS - Model ")
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class SubmitPolicyIposDb extends Payload {

    private List<TRelationship> tRelationship;
    private List<TCommunication> tCommunication;
    private List<TEappContact> tEappContact;
    private List<TOccupation> tOccupation;
    private TEapp tEapp;
    private List<TContact> tContact;
    private List<TAddress> tAddress;
    private List<TPaymentDetail> tPaymentDetail;
    private List<TEappInsurancePurpose> tEappInsurancePurpose;
    private List<TEappPremiumPaymentSource> tEappPremiumPaymentSource;
    private List<TEappSpecialReq> tEappSpecialReq;
    private List<TIdCard> tIdCard;
    private List<TSimulation> tSimulation;
    private List<TEappBeneficiary> tEappBeneficiary;
    private List<TDoc> tDoc;
    private List<TDvaGt> tDvaGt;
    private List<TAccountCardOwner> tAccountCardOwner;
    private TEsub tESub;
    private List<TAdhocTopUp> tAdhocTopUp;
    private List<TBasicPlanSelection> tBasicPlanSelection;
    private List<TChangeSumAssured> tChangeSumAssured;
    private List<TEappQAnswer> tEappQAnswer;
    private List<TEappQInsuranceHis> tEappQInsuranceHis;
    private TSqsQuotation tSqsQuotation;
    private List<TPremiumHoliday> tPremiumHoliday;
    private List<TPlanSelection> tPlanSelection;
    private List<TSplitPremium> tSplitPremium;
    private List<TTemporaryRating> tTemporaryRating;
    private List<TPermanentRating> tPermanentRating;
    private List<TPermanentFlatRating> tPermanentFlatRating;
    private List<TWithdrawal> tWithdrawal;
    private List<TContactHistory> tContactHistory;
    private List<TSqsDocument> tSqsDocument;
    private List<TTermConversionList> tTermConversionList;
    private List<TEappTrustee> tEappTrustee;
    private TCitiFna tCitiFna;
    private List<TCitiYourFinancials> tCitiYourFinancials;
    private List<TCitiExistingPolicy> tCitiExistingPolicy;
    private List<TCitiInsObjectives> tCitiInsObjectives;
    private List<TCitiAnswer> tCitiAnswer;
    private List<TContactCitiExtra> tContactCitiExtra;
    private List<TEappCitiDda> tEappCitiDda;
    private TEappCitiExtra tEappCitiExtra;
    private TEappPayor tEappPayor;
    private TVomeeting tVomeeting;
    private TEappPf tEappPf;
    private List<TEappCitiRecommendations> tEappCitiRecommendations;
    private List<TEappCitiReviewer> tEappCitiReviewer;
    private List<TCitiFnaHistory> tCitiFnaHistory;
    private List<TIlasContactFNA> tIlasContactFNA;
    private List<TIlasFna> tIlasFNA;
    private List<TIlasFnaAffordability> tIlasFnaAffordability;
    private List<TIlasFnaEduction> tIlasFnaEduction;
    private List<TIlasFnaEvaluation> tIlasFnaEvaluation;
    private List<TIlasFnaFinancialStatus> tIlasFnaFinancialStatus;
    private List<TIlasFundSelection> tIlasFundSelection;
    private List<TIlasIfsAnswer> tIlasIfsAnswer;
    private List<TIlasRpqAnswer> tIlasRpqAnswer;
    private List<TCitiInsProductType> tCitiInsProductType;
    private List<TIlasFnaDeclaration> tIlasFnaDeclaration;
    private List<TPep> tPep;
    private List<TEappMagnum> tEappMagnum;
    private List<TEappMagnumAnswers> tEappMagnumAnswers;
    private List<TTax> tTax;
    private List<TEappExpand> tEappExpand;
    private List<TSowd> tSowd;
    private List<TSowdAddress> tSowdAddress;
    private List<TFnaOtherEr> tFnaOtherEr;
    private List<TFinancialQuestion> tFinancialQuestion;
    private List<TEappStepUp> tEappStepUp;
    private List<TLevy> tLevy;
    private List<TEappPromOffer> tEappPromOffer;
    private List<TOcrContact> tOcrContact;
    private List<TOcrContactCount> tOcrContactCount;
    private List<TTermConversion> tTermConversion;
    private List<TEsubGPSLocation> teSubGPSLocation;
    private List<TEFnaMapping> tEFnaMapping;
    private List<TEappCpd> tEappCpd;
    private List<TCpdSub> tCpdSub;
    private List<TOcrRetakeCount> tOcrRetakeCount;
    private List<TEappContingentInsure> tEappContigentInsure;
    private List<TIrrAnswer> tIrrAnswer;
    private List<TEappAudioAnswer> tEappAudioAnswer;
    private List<TEappReviewer> tEappReviewer;
    private List<TEappRecommendLevel> tEappRecommendLevel;
    private List<TEappNoClaim> tEappNoClaim;
    private List<TEappData> tEappData;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("SubmitPolicyIposDb{");
        sb.append(", tEapp=").append(tEapp);
        sb.append(", tESub=").append(tESub);
        sb.append(", tSqsQuotation=").append(tSqsQuotation);
        sb.append(", tCitiFna=").append(tCitiFna);
        sb.append(", tEappCitiExtra=").append(tEappCitiExtra);
        sb.append(", tVomeeting=").append(tVomeeting);
        sb.append(", tEappPf=").append(tEappPf);
        sb.append('}');
        return sb.toString();
    }
}
