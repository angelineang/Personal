package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@ApiModel(value = "Gi Credit Balance Front Model")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class GiCreditBalanceFront {

    @ApiModelProperty(value = "Coupon Balance")
    @JsonProperty("coupon_balance")
    private Double couponBalance;

    @ApiModelProperty(value = "Credit Balance")
    @JsonProperty("credit_balance")
    private Double creditBalance;

    @ApiModelProperty(value = "Previous credit balance")
    @JsonProperty("previous_credit_balance")
    private Double previousCreditBalance;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("GiCreditBalanceFront{");
        sb.append("couponBalance=").append(couponBalance);
        sb.append(", creditBalance=").append(creditBalance);
        sb.append(", previousCreditBalance=").append(previousCreditBalance);
        sb.append('}');
        return sb.toString();
    }
}
