package hk.com.aia.ws.eapp.exception;

import hk.com.aia.ws.eapp.model.base.ResultMessage;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

@Data
@EqualsAndHashCode(callSuper = false)
public class BlobFileException extends Exception {

    private static final long serialVersionUID = 1L;
    private List<ResultMessage> exceptionMessages;
    private String message;

    public BlobFileException(String message){
        this.message = message;
    }

    public BlobFileException(List<ResultMessage> exceptionMessages){
        this.exceptionMessages = exceptionMessages;
    }

    public BlobFileException(String message, List<ResultMessage> exceptionMessages){
        this.message = message;
        this.exceptionMessages = exceptionMessages;
    }
}
