package hk.com.aia.ws.eapp.model.base.calculator;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AlphaSearchResponseMetaInfo {
	private Long completedTime;
	private AlphaSearchResponseMessage[] messages;
	public Long getCompletedTime() {
		return completedTime;
	}
	public void setCompletedTime(Long completedTime) {
		this.completedTime = completedTime;
	}
	public AlphaSearchResponseMessage[] getMessages() {
		return messages;
	}
	public void setMessages(AlphaSearchResponseMessage[] messages) {
		this.messages = messages;
	}
}
