package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@ApiModel(value = "Coi Details Model")
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class CoiDetail {

    @ApiModelProperty(value = "encoded method")
    @JsonProperty("encode_method")
    private String encodeMethod;

    // No validation for this object
    // Mediation object, content to be mapped and passed to XGFE - /nb/submission
    @ApiModelProperty(value = "gi next no front")
    @JsonProperty("gi_next_no_front")
    private GiNextNoFront ginextnofront;

    @ApiModelProperty(value = "purchase key")
    @JsonProperty("purchase_key")
    private String purchaseKey;

    @ApiModelProperty(value = "resource owner id")
    @JsonProperty("resource_owner_id")
    private String resourceOwnerId;

    @ApiModelProperty(value = "transaction id")
    @JsonProperty("transaction_id")
    private String transactionId;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("CoiDetail{");
        sb.append("encodeMethod='").append(encodeMethod).append('\'');
        sb.append(", ginextnofront=").append(ginextnofront);
        sb.append(", purchaseKey='").append(purchaseKey).append('\'');
        sb.append(", resourceOwnerId='").append(resourceOwnerId).append('\'');
        sb.append(", transactionId='").append(transactionId).append('\'');
        sb.append('}');
        return sb.toString();
    }
}

