package hk.com.aia.ws.eapp.configuration;


import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.util.StringUtils;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;
import java.util.Properties;

@Slf4j
@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(basePackages = "hk.com.aia.ws.eapp.repository.mag",
        entityManagerFactoryRef = "magEntityManagerFactory",
        transactionManagerRef = "magTransactionManager")
public class DBConfigurationMag {

    @ConditionalOnExpression("'${spring.profiles}'.equals('local') || '${spring.profiles}'.equals('dev')")
    @ConfigurationProperties(prefix = "connection.mag.datasource.local")
    @Bean(name = "magDataSource")
    public DataSource magDataSourceLocal() {
        log.info("initializing magDataSourceLocal ... ");
        return DataSourceBuilder.create().build();
    }

    @Bean(name = "magEntityManagerFactory")
    public LocalContainerEntityManagerFactoryBean magEntityManagerFactory(
            @Qualifier("magDataSource") DataSource dataSource,
            @Qualifier("magProperties") Properties properties,
            @Value("${connection.mag.jpa.show-sql}") Boolean showSql) {

        LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
        em.setDataSource(dataSource);
        em.setPersistenceUnitName("mag_persist_unit");
        em.setPackagesToScan("hk.com.aia.ws.eapp.model.db.mag");
        HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
        vendorAdapter.setShowSql(showSql);
        em.setJpaVendorAdapter(vendorAdapter);
        em.setJpaProperties(properties);

        return em;
    }

    @Bean(name = "magTransactionManager")
    public PlatformTransactionManager sqlTransactionManager(
            @Qualifier("magEntityManagerFactory") EntityManagerFactory sqlEntityManagerFactory) {
        return new JpaTransactionManager(sqlEntityManagerFactory);
    }

    @Bean(name = "magProperties")
    public Properties additionalProperties(
            @Value("${connection.mag.jpa.database-platform}") String hibernateDialect,
            @Value("${connection.mag.jpa.default-schema}") String schema) {

        Properties properties = new Properties();
        properties.setProperty("hibernate.dialect", hibernateDialect);

        if (!StringUtils.isEmpty(schema)) {
            properties.setProperty("hibernate.default_schema", schema);
        }

        return properties;
    }

}
