package hk.com.aia.ws.eapp.model.base.calculator;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@EqualsAndHashCode(callSuper = false)
public class PerLifeRowResultBean extends PerLifeResultAbstractBean {

    protected List<PerLifeRowResultRecordBean> resultDataByCat;
    protected List<PerLifeRowResultRecordBean> resultDataByDetail;
}
