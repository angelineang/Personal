package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.annotation.AllowedValuesValidation;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@ApiModel(value = "Beneficiary model")
@Data
public class Beneficiary {

    @ApiModelProperty(value = "Beneficiary number - B1,B2 and so on (tbl_ms_pol_bene.ben_no)", example = "B1")
    @JsonProperty("ben_no")
    @NotBlank
    @Size(min = 2, max = 2)
    private String benNo;

    @ApiModelProperty(value = "Beneficiary name - tbl_ms_pol_bene.name", example = "CHAN TAI MAN")
    @JsonProperty("name")
    @Size(max = 50)
    @NotNull
    private String name;

    @ApiModelProperty(value = "Beneficiary relationship - A = Parent, B - Brother/Sister, C = Children, D = Creditor/Debtor, F = Fiance/Fiancee, G = Grandparent, H,V = Step Children, J = Grandchild, M = Company, N,L = Niece/Nephew, O = Others, P = Parent, R = Relative, S = Spouse, T,K = Step Parents, U = Uncle/Aunt, Blank/'-'/I = Own Estate - (tbl_ms_pol_bene.ben_rel)", example = "A", allowableValues = "A,B,C,D,F,G,H,J,M,N,O,P,R,S,T,U,-,K,V,L,I")
    @JsonProperty("ben_rel")
    @NotNull
    @AllowedValuesValidation(values = {"A", "B", "C", "D", "F", "G", "H", "J", "M", "N", "O", "P", "R", "S", "T", "U", "-", "K", "V", "L", "I"}, caseSensitive = true)
    private String benRel;

    @ApiModelProperty(value = "Beneficiary allocation (tbl_ms_pol_bene.ben_allocation)", example = "\"100\"")
    @JsonProperty("ben_allocation")
    @Size(max = 15)
    private String benAllocation;

    @ApiModelProperty(value = "Beneficiary age (tbl_ms_pol_bene.ben_age", example = "\"26\"")
    @JsonProperty("ben_age")
    @Size(max = 3)
    @Pattern(regexp = "^[0-9]{0,3}$", message = "Beneficiary age must not exceed 3 digits")
    private String benAge;

    @ApiModelProperty(value = "Beneficiary Id (tbl_ms_pol_bene.ben_id)", example = "A1234567")
    @JsonProperty("ben_id")
    @Size(max = 16)
    private String benId;
    
    @ApiModelProperty(value = "type")
    @JsonProperty("type")
    private String type;
    
    @ApiModelProperty(value = "chineseName")
    @JsonProperty("chineseName")
    private String chineseName;
    
    @ApiModelProperty(value = "dob")
    @JsonProperty("dob")
    private String dob;
    
    @ApiModelProperty(value = "idType")
    @JsonProperty("idType")
    private String idType;
    
    @ApiModelProperty(value = "sex")
    @JsonProperty("sex")
    private String sex;
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Beneficiary{");
        sb.append("benNo='").append(ConversionHandler.mask(benNo)).append('\'');
        sb.append(", name='").append(ConversionHandler.mask(name)).append('\'');
        sb.append(", benRel='").append(benRel).append('\'');
        sb.append(", benAllocation='").append(benAllocation).append('\'');
        sb.append(", benAge='").append(benAge).append('\'');
        sb.append(", benId='").append(ConversionHandler.mask(benId)).append('\'');
        sb.append(", type='").append(type).append('\'');
        sb.append(", chineseName='").append(chineseName).append('\'');
        sb.append(", dob='").append(dob).append('\'');
        sb.append(", idType='").append(idType).append('\'');
        sb.append(", sex='").append(sex).append('\'');
        sb.append('}');
        return sb.toString();
    }
}

