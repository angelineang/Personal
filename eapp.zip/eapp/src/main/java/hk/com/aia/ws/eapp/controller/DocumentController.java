package hk.com.aia.ws.eapp.controller;

import hk.com.aia.ws.eapp.constant.Constants;
import hk.com.aia.ws.eapp.constant.Constants.APIPath;
import hk.com.aia.ws.eapp.model.base.*;
import hk.com.aia.ws.eapp.model.dto.ResultDto;
import hk.com.aia.ws.eapp.model.dto.ReturnPolicyDto;
import hk.com.aia.ws.eapp.model.request.Request;
import hk.com.aia.ws.eapp.model.request.letter.LetterDocRequest;
import hk.com.aia.ws.eapp.model.response.Response;
import hk.com.aia.ws.eapp.model.response.error.GatewayError400;
import hk.com.aia.ws.eapp.model.response.error.GatewayError401;
import hk.com.aia.ws.eapp.model.response.error.InternalError500;
import hk.com.aia.ws.eapp.service.EappPolicyService;
import hk.com.aia.ws.eapp.service.LogService;
import hk.com.aia.ws.eapp.service.PayloadRequestService;
import hk.com.aia.ws.eapp.service.letter.LetterDocumentService;
import hk.com.aia.ws.eapp.service.BatchSubmissionService;
import io.swagger.annotations.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

import static hk.com.aia.ws.eapp.constant.Constants.RETURN_CODE_1;

import java.time.Duration;
import java.time.LocalDateTime;

@Slf4j
@RestController
@RequestMapping("/documents")
@Api(value = "Document Submission", tags = {"API(s) for submitting the documents to be used for underwriting."})
@Validated
public class DocumentController {

    @Autowired
    private EappPolicyService eappPolicyService;

    @Autowired
    private BatchSubmissionService batchSubmissionService;
    
    @Autowired
    LetterDocumentService letterDocumentService;

	@Autowired
	private LogService logService;
	
	@Autowired
	private PayloadRequestService payloadRequestService;
	
    @ApiOperation(value = "To submit supporting documents for policy application.")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Supporting documents successfully submitted."),
            @ApiResponse(code = 400, message = "Bad Request", response = GatewayError400.class),
            @ApiResponse(code = 401, message = "Unauthorized", response = GatewayError401.class),
            @ApiResponse(code = 404, message = "Invalid request.", response = Response.class),
            @ApiResponse(code = 500, message = "Internal Server Error", response = InternalError500.class)
    })
    @PostMapping(value = "/submit", produces = MediaType.APPLICATION_JSON_VALUE)
    public Response<ReturnPolicy> submit(
            @ApiParam(value = "Local business unit.    | Valid Values |   | ----------   |   | HK, TH, SG   | ", required = true)
            @RequestHeader(value = Constants.RequestHeader.AIA_LBU, required = true) String xAiaLbu,
            @ApiParam(value = "Unique id for the request for tracking purposes.        ", required = true)
            @RequestHeader(value = Constants.RequestHeader.REQUEST_ID, required = true) String xAiaRequestId,
            @ApiParam(value = "Target environment of the request. Note that this header is required only when accessing non-production environments.    | Valid Values       |   | ------------------ |   | qa1, qa2, qa3, qa4 |        ")
            @RequestHeader(value = Constants.RequestHeader.AIA_ENV, required = false) String xAiaEnv,
            @ApiParam(value = "JWT Token for the request to verify Agent Authorization")
            @RequestHeader(value = Constants.RequestHeader.TOKEN_AGENT, required = false) String xAiaTokenAgent,
            @ApiParam(value = "Trace Id for EFK Logging")
            @RequestHeader(value = Constants.RequestHeader.TRACE_ID, required = false) String xAiaHkTraceId,
            @ApiParam(value = "Context Id for EFK Logging")
            @RequestHeader(value = Constants.RequestHeader.CONTEXT_ID, required = true) String xAiaHkContextId,
            @ApiParam(value = "Documents to be submitted", required = true)
            @Valid @RequestBody Request<SubmitDocument> documentPayload) {

        ResultDto<ReturnPolicyDto> result = eappPolicyService.submitAdditionalDocument(documentPayload.getData());

        Response<ReturnPolicy> payload = new Response<>();

        payload.setTransId(documentPayload.getTransId());

        payload.setStatus(CustomResponseStatus.ERROR.getDescription());
        if (RETURN_CODE_1.equals(result.getReturnCode())) {
            payload.setStatus(CustomResponseStatus.SUCCESS.getDescription());
        }
        payload.getResultMessages().add(new ResultMessage(result.getReturnCode(),
                result.getReturnMessage()));

        ReturnPolicy returnPolicy = new ReturnPolicy();
        returnPolicy.setPolicyNo(result.getData().getPolicyNo());
        returnPolicy.setType(result.getData().getType());

        payload.setData(returnPolicy);

        return payload;
    }

    @ApiOperation("To send document via email")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Requested document sent successfully."),
            @ApiResponse(code = 400, message = "Bad Request", response = GatewayError400.class),
            @ApiResponse(code = 401, message = "Unauthorized", response = GatewayError401.class),
            @ApiResponse(code = 404, message = "Invalid request.", response = Response.class),
            @ApiResponse(code = 500, message = "Internal Server Error", response = InternalError500.class)
    })
    @PostMapping(value = "/send", produces = MediaType.APPLICATION_JSON_VALUE)
    public Response<Payload> send(
            @ApiParam(value = "Local business unit.    | Valid Values |   | ----------   |   | HK, TH, SG   | ", required = true)
            @RequestHeader(value = Constants.RequestHeader.AIA_LBU, required = true) String xAiaLbu,
            @ApiParam(value = "Unique id for the request for tracking purposes.        ", required = true)
            @RequestHeader(value = Constants.RequestHeader.REQUEST_ID, required = true) String xAiaRequestId,
            @ApiParam(value = "Target environment of the request. Note that this header is required only when accessing non-production environments.    | Valid Values       |   | ------------------ |   | qa1, qa2, qa3, qa4 |        ")
            @RequestHeader(value = Constants.RequestHeader.AIA_ENV, required = false) String xAiaEnv,
            @ApiParam(value = "JWT Token for the request to verify Agent Authorization")
            @RequestHeader(value = Constants.RequestHeader.TOKEN_AGENT, required = false) String xAiaTokenAgent,
            @ApiParam(value = "Trace Id for EFK Logging")
            @RequestHeader(value = Constants.RequestHeader.TRACE_ID, required = false) String xAiaHkTraceId,
            @ApiParam(value = "Context Id for EFK Logging")
            @RequestHeader(value = Constants.RequestHeader.CONTEXT_ID, required = true) String xAiaHkContextId,
            @ApiParam(value = "Document to be sent", required = true)
            @Valid @RequestBody Request<SendDocument> sendDocumentPayload) {

        final ResultDto<ReturnPolicyDto> result = eappPolicyService.sendDoc(sendDocumentPayload.getData());

        final Response<Payload> payload = new Response<>();
        payload.setTransId(sendDocumentPayload.getTransId());
        payload.setStatus(result.getReturnCode());
        payload.setResultMessages(result.getResultMessageOuts());

        return payload;
    }
    
    @ApiOperation("To send requested document")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Requested document sent successfully."),
            @ApiResponse(code = 400, message = "Bad Request", response = GatewayError400.class),
            @ApiResponse(code = 401, message = "Unauthorized", response = GatewayError401.class),
            @ApiResponse(code = 404, message = "Invalid request.", response = Response.class),
            @ApiResponse(code = 500, message = "Internal Server Error", response = InternalError500.class)
    })
    @PostMapping(value = "/get-letter-doc", produces = MediaType.APPLICATION_JSON_VALUE)
	public Response<LetterDocumentPayload> getLetterDocuments(
			@ApiParam(value = "Local business unit.    | Valid Values |   | ----------   |   | HK, TH, SG   | ", required = true) @RequestHeader(value = Constants.RequestHeader.AIA_LBU, required = true) String xAiaLbu,
			@ApiParam(value = "Unique id for the request for tracking purposes.        ", required = true) @RequestHeader(value = Constants.RequestHeader.REQUEST_ID, required = true) String xAiaRequestId,
			@ApiParam(value = "Target environment of the request. Note that this header is required only when accessing non-production environments.    | Valid Values       |   | ------------------ |   | qa1, qa2, qa3, qa4 |        ") @RequestHeader(value = Constants.RequestHeader.AIA_ENV, required = false) String xAiaEnv,
			@ApiParam(value = "An access token issued by an AIA Authorization server. This will have the format Bearer + {space} + {accessToken}.") @RequestHeader(value = Constants.RequestHeader.AIAACESSTOKEN, required = true) String authorization,
			@ApiParam(value = "Trace Id for EFK Logging") @RequestHeader(value = Constants.RequestHeader.TRACE_ID, required = false) String xAiaHkTraceId,
			@ApiParam(value = "Context Id for EFK Logging") @RequestHeader(value = Constants.RequestHeader.CONTEXT_ID, required = true) String xAiaHkContextId,
			@ApiParam(value = "Document to be sent", required = true) @Valid @RequestBody Request<LetterDocRequest> request) {
		Response<LetterDocumentPayload> response = null;

		logService.logStartWorkingIntegration(APIPath.EAPP_D_GET_LETTER_DOC);
		LocalDateTime start = LocalDateTime.now();
		payloadRequestService.saveRequestJson("", "E-LETTER-C", request);

		response = letterDocumentService.getLetterDocuments(request);
		payloadRequestService.saveRequestJson("", "E-LETTER-R", response);

		LocalDateTime end = LocalDateTime.now();
		Duration duration = Duration.between(start, end);
		logService.logEndWorkingSuccessIntegration(APIPath.EAPP_D_GET_LETTER_DOC, duration.toMillis());
		return response;

	}

}

