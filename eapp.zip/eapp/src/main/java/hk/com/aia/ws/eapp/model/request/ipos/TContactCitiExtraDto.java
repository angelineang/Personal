package hk.com.aia.ws.eapp.model.request.ipos;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.util.Date;

import static hk.com.aia.ws.eapp.constant.Constants.TIMEZONE;

@ApiModel(value = "T_CONTACTCITIEXTRA Model")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TContactCitiExtraDto {

    @ApiModelProperty(value = "citi Extra Id", required = true)
    @JsonProperty("citi_extra_id")
    @Size(max = 60)
    @NotBlank
    private String citiExtraId;

    @JsonProperty("contact_id")
    @Size(max = 60)
    private String contactId;

    @JsonProperty("education_code")
    @Size(max = 10)
    private String educationCode;

    @JsonProperty("education_other")
    @Size(max = 60)
    private String educationOther;

    @JsonProperty("employment_code")
    @Size(max = 10)
    private String employmentCode;

    @JsonProperty("employment_other")
    @Size(max = 60)
    private String employmentOther;

    @JsonProperty("years_to_support")
    private Integer yearsToSupport;

    @JsonProperty("citi_occupation_code")
    @Size(max = 10)
    private String citiOccupationCode;

    @JsonProperty("retirement_age")
    @Size(max = 10)
    private String retirementAge;

    @JsonProperty("has_exper_indicate")
    private Integer hasExperIndicate;

    @JsonProperty("no_exper_confirm")
    private Integer noExperConfirm;

    @JsonProperty("hybrid_flow")
    @Size(max = 5)
    private String hybridFlow;

    @ApiModelProperty(value = "hybrid flow update date, format = yyyy-MM-dd", example = "2020-12-31")
    @JsonProperty("hybrid_flow_update_date")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = TIMEZONE)
    private Date hybridFlowUpdateDate;

    @JsonProperty("sc_flag")
    @Size(max = 5)
    private String scFlag;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TContactCitiExtraDto{");
        sb.append("citiExtraId='").append(citiExtraId).append('\'');
        sb.append(", contactId='").append(contactId).append('\'');
        sb.append(", educationCode='").append(educationCode).append('\'');
        sb.append(", educationOther='").append(educationOther).append('\'');
        sb.append(", employmentCode='").append(employmentCode).append('\'');
        sb.append(", employmentOther='").append(employmentOther).append('\'');
        sb.append(", yearsToSupport=").append(yearsToSupport);
        sb.append(", citiOccupationCode='").append(citiOccupationCode).append('\'');
        sb.append(", retirementAge='").append(retirementAge).append('\'');
        sb.append(", hasExperIndicate=").append(hasExperIndicate);
        sb.append(", noExperConfirm=").append(noExperConfirm);
        sb.append(", hybridFlow='").append(hybridFlow).append('\'');
        sb.append(", hybridFlowUpdateDate=").append(hybridFlowUpdateDate);
        sb.append(", scFlag='").append(scFlag).append('\'');
        sb.append('}');
        return sb.toString();
    }
}


