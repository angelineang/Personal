package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "T_EAPPCITIREVIEWER")
public class TEappCitiReviewer {

    @Column(name = "CITIREVIEWERID", length = 60)
    @Id
    private String citiReviewerId;

    @Column(name = "EAPPID", length = 60)
    private String eappId;

    @Column(name = "MODULE", length = 20)
    private String module;

    @Column(name = "NAME", length = 100)
    private String name;

    @Column(name = "NAMEOTHER", length = 100)
    private String nameOther;

    @Column(name = "REGISTRATIONNO", length = 60)
    private String registrationNo;

    @Column(name = "SOEID", length = 60)
    private String soeId;

    @Column(name = "RELATIONSHIP", length = 60)
    private String relationship;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TEappCitiReviewer{");
        sb.append("citiReviewerId='").append(citiReviewerId).append('\'');
        sb.append(", eappId='").append(eappId).append('\'');
        sb.append(", module='").append(module).append('\'');
        sb.append(", name='").append(name).append('\'');
        sb.append(", nameOther='").append(nameOther).append('\'');
        sb.append(", registrationNo='").append(registrationNo).append('\'');
        sb.append(", soeId='").append(soeId).append('\'');
        sb.append(", relationship='").append(relationship).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
