package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

@ApiModel(value = "Coverage Model")
@Data
public class Coverage {

    @ApiModelProperty(value = "Plan sequence number - 01, 02, and so on tbl_ms_pol_cov.plan_seq_no", example = "01", required = true)
    @JsonProperty("plan_seq_no")
    @NotBlank
    private String planSeqNo;

    @ApiModelProperty(value = "Plan short name - Based on existing - tbl_ms_pol_cov.plan_short_name ", example = "PPLUS", required = true)
    @JsonProperty("plan_short_name")
    @NotBlank
    private String planShortName;

    @ApiModelProperty(value = "Plan type - B = Basic, R - Rider, S - Supplementary Benefit - tbl_ms_pol_cov.plan_type", example = "B", allowableValues = "B,S,R", required = true)
    @JsonProperty("plan_type")
    @NotBlank
    private String planType;

    @ApiModelProperty(value = "Parent Plan (Link to Basic Plan) - tbl_ms_pol_cov.parent_plan", example = "PPLUS")
    @JsonProperty("parent_plan")
    private String parentPlan;

    @ApiModelProperty(value = "Sum assured - tbl_ms_pol_cov.sum_assured", example = "\"100000\"")
    @JsonProperty("sum_assured")
    private String sumAssured;

    @ApiModelProperty(value = "Vitality indicator - Y = Vitality Feature - tbl_ms_pol_cov.vitality_ind", example = "Y")
    @JsonProperty("vitality_ind")
    private String vitalityInd;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Coverage{");
        sb.append("planSeqNo='").append(planSeqNo).append('\'');
        sb.append(", planShortName='").append(planShortName).append('\'');
        sb.append(", planType='").append(planType).append('\'');
        sb.append(", parentPlan='").append(parentPlan).append('\'');
        sb.append(", sumAssured='").append(sumAssured).append('\'');
        sb.append(", vitalityInd='").append(vitalityInd).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
