package hk.com.aia.ws.eapp.configuration;


import hk.com.aia.ws.eapp.model.properties.TaskProperties;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.SchedulingConfigurer;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.scheduling.config.ScheduledTaskRegistrar;

@Slf4j
@EnableAsync
@Configuration
public class ThreadSchedulerConfiguration implements SchedulingConfigurer {

    @Value("${task.pool-size}")
    private Integer poolSize;

    @ConfigurationProperties(prefix = "task")
    @Bean
    public TaskProperties taskProperties() {
        return new TaskProperties();
    }

    @Override
    public void configureTasks(ScheduledTaskRegistrar scheduledTaskRegistrar) {

        ThreadPoolTaskScheduler taskScheduler = new ThreadPoolTaskScheduler();
        taskScheduler.setErrorHandler(t -> log.error("Caught exception on the @Scheduled task. " + t.getMessage()));
        taskScheduler.setPoolSize(poolSize);
        taskScheduler.setThreadNamePrefix("Spring-scheduler-task-pool-");
        taskScheduler.initialize();

        scheduledTaskRegistrar.setTaskScheduler(taskScheduler);

    }
}
