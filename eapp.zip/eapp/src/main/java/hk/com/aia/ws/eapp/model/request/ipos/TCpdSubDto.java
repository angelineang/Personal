package hk.com.aia.ws.eapp.model.request.ipos;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.util.Date;

import static hk.com.aia.ws.eapp.constant.Constants.TIMEZONE;

@ApiModel(value = "T_CPDSub Model")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TCpdSubDto {

    @ApiModelProperty(value = "eapp Cpd Sub Id", required = true)
    @JsonProperty("eapp_cpd_sub_id")
    @Size(max = 60)
    @NotBlank
    private String eappCpdSubId;

    @JsonProperty("eapp_cpd_id")
    @Size(max = 60)
    private String eappCpdId;

    @JsonProperty("company_name")
    @Size(max = 5)
    private String companyName;

    @JsonProperty("other_company")
    @Size(max = 200)
    private String otherCompany;

    @JsonProperty("policy_no")
    @Size(max = 100)
    private String policyNo;

    @ApiModelProperty(value = "q4a year ", example = "2020-12-31", notes = "yyyy-MM-dd")
    @JsonProperty("q4a_year")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = TIMEZONE)
    private Date q4aYear;

    @JsonProperty("q4a_other")
    @Size(max = 80)
    private String q4aOther;

    @JsonProperty("q4a_month")
    @Size(max = 2)
    private String q4aMonth;

    @JsonProperty("q4a_month_other")
    @Size(max = 200)
    private String q4aMonthOther;

    @ApiModelProperty(value = "q4b year, format = yyyy-MM-dd ", example = "2020-12-31")
    @JsonProperty("q4b_year")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = TIMEZONE)
    private Date q4bYear;

    @JsonProperty("q4b_other")
    @Size(max = 80)
    private String q4bOther;

    @JsonProperty("q4b_month")
    @Size(max = 2)
    private String q4bMonth;

    @JsonProperty("q4b_month_other")
    @Size(max = 200)
    private String q4bMonthOther;

    @JsonProperty("q4c_option")
    @Size(max = 1)
    private String q4cOption;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TCpdSubDto{");
        sb.append("eappCpdSubId='").append(eappCpdSubId).append('\'');
        sb.append(", eappCpdId='").append(eappCpdId).append('\'');
        sb.append(", companyName='").append(companyName).append('\'');
        sb.append(", otherCompany='").append(otherCompany).append('\'');
        sb.append(", policyNo='").append(policyNo).append('\'');
        sb.append(", q4aYear=").append(q4aYear);
        sb.append(", q4aOther='").append(q4aOther).append('\'');
        sb.append(", q4aMonth='").append(q4aMonth).append('\'');
        sb.append(", q4aMonthOther='").append(q4aMonthOther).append('\'');
        sb.append(", q4bYear=").append(q4bYear);
        sb.append(", q4bOther='").append(q4bOther).append('\'');
        sb.append(", q4bMonth='").append(q4bMonth).append('\'');
        sb.append(", q4bMonthOther='").append(q4bMonthOther).append('\'');
        sb.append(", q4cOption='").append(q4cOption).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
