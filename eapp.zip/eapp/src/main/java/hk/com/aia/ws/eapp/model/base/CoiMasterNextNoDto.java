package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@ApiModel(value = "Coi Master Next No Model")
@Data
public class CoiMasterNextNoDto {

    @ApiModelProperty(value = "Gi number")
    @JsonProperty("gi_no")
    private String giNo;

    @ApiModelProperty(value = "Gi verification")
    @JsonProperty("gi_ver")
    private String giVer;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("CoiMasterNextNoDto{");
        sb.append("giNo='").append(giNo).append('\'');
        sb.append(", giVer='").append(giVer).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
