package hk.com.aia.ws.eapp.model.db.magnum.ipos;


import hk.com.aia.ws.eapp.util.ConversionHandler;
import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "T_CPDSub")
public class TCpdSub {

    @Column(name = "eAppCPDSubID", length = 60)
    @Id
    private String eappCpdSubId;

    @Column(name = "eAppCPDID", length = 60)
    private String eappCpdId;

    @Column(name = "companyName", length = 5)
    private String companyName;

    @Column(name = "otherCompany", length = 200)
    private String otherCompany;

    @Column(name = "policyNo", length = 100)
    private String policyNo;

    @Column(name = "q4aYear")
    @Temporal(TemporalType.DATE)
    private Date q4aYear;

    @Column(name = "q4aOther", length = 80)
    private String q4aOther;

    @Column(name = "q4aMonth", length = 2)
    private String q4aMonth;

    @Column(name = "q4aMonthOther", length = 200)
    private String q4aMonthOther;

    @Column(name = "q4bYear")
    @Temporal(TemporalType.DATE)
    private Date q4bYear;

    @Column(name = "q4bOther", length = 80)
    private String q4bOther;

    @Column(name = "q4bMonth", length = 2)
    private String q4bMonth;

    @Column(name = "q4bMonthOther", length = 200)
    private String q4bMonthOther;

    @Column(name = "q4cOption", length = 1)
    private String q4cOption;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "LASTUPDATEDATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    @LastModifiedDate
    private Date lastUpdatedDateTime;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TCpdSub{");
        sb.append("eappCpdSubId='").append(eappCpdSubId).append('\'');
        sb.append(", eappCpdId='").append(eappCpdId).append('\'');
        sb.append(", companyName='").append(companyName).append('\'');
        sb.append(", otherCompany='").append(otherCompany).append('\'');
        sb.append(", policyNo='").append(ConversionHandler.mask(policyNo)).append('\'');
        sb.append(", q4aYear=").append(q4aYear);
        sb.append(", q4aOther='").append(q4aOther).append('\'');
        sb.append(", q4aMonth='").append(q4aMonth).append('\'');
        sb.append(", q4aMonthOther='").append(q4aMonthOther).append('\'');
        sb.append(", q4bYear=").append(q4bYear);
        sb.append(", q4bOther='").append(q4bOther).append('\'');
        sb.append(", q4bMonth='").append(q4bMonth).append('\'');
        sb.append(", q4bMonthOther='").append(q4bMonthOther).append('\'');
        sb.append(", q4cOption='").append(q4cOption).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", lastUpdatedDateTime=").append(lastUpdatedDateTime);
        sb.append('}');
        return sb.toString();
    }
}
