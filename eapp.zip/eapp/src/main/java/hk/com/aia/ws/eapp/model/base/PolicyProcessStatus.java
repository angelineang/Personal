package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.annotation.AllowedValuesValidation;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import java.util.Date;

import static hk.com.aia.ws.eapp.constant.Constants.TIMEZONE;

@ApiModel(value = "Policy with Process Status Model ")
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class PolicyProcessStatus extends Payload {

    // API Model Property - copied from old code
    private final static String ISO_8601_DATETIME_DESC = "YYYY-MM-DDThh24:mm:ss";
    private final static String TIME_STAMP_DATE_TIME_PATTERN = "yyyy-MM-dd'T'HH:mm:ss";

    @ApiModelProperty(value = "Policy Number", required = true, example = "B620836159")
    @JsonProperty("pol_no")
    @NotBlank
    private String polNo;

    @ApiModelProperty(value = "Date time pattern: " + ISO_8601_DATETIME_DESC, example = "2020-04-06T03:34:58")
    @JsonProperty("nb_start_time")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = TIME_STAMP_DATE_TIME_PATTERN, timezone = TIMEZONE)
    private Date nbStartTime;

    @ApiModelProperty(value = "Date time pattern: " + ISO_8601_DATETIME_DESC, example = "2020-04-06T03:34:58")
    @JsonProperty("nb_end_time")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = TIME_STAMP_DATE_TIME_PATTERN, timezone = TIMEZONE)
    private Date nbEndTime;

    @ApiModelProperty(value = "Y or N indicator. If irrelevant,this attribute can be omitted, default is null.", allowableValues = "Y,N,null")
    @JsonProperty("nb_ind")
    @AllowedValuesValidation(values = {"Y", "N"})
    private String nbInd;

    @ApiModelProperty(value = "Date time pattern: " + ISO_8601_DATETIME_DESC, example = "2020-04-06T03:34:58")
    @JsonProperty("pe_start_time")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = TIME_STAMP_DATE_TIME_PATTERN, timezone = TIMEZONE)
    private Date peStartTime;

    @ApiModelProperty(value = "Date time pattern: " + ISO_8601_DATETIME_DESC, example = "2020-04-06T03:34:58")
    @JsonProperty("pe_end_time")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = TIME_STAMP_DATE_TIME_PATTERN, timezone = TIMEZONE)
    private Date peEndTime;

    @ApiModelProperty(value = "Y or N indicator. If irrelevant,this attribute can be omitted, default is null.", allowableValues = "Y,N,null")
    @JsonProperty("pe_ind")
    @AllowedValuesValidation(values = {"Y", "N"})
    private String peInd;

    @ApiModelProperty(value = "Date time pattern: " + ISO_8601_DATETIME_DESC, example = "2020-04-06T03:34:58")
    @JsonProperty("as_start_time")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = TIME_STAMP_DATE_TIME_PATTERN, timezone = TIMEZONE)
    private Date asStartTime;

    @ApiModelProperty(value = "Date time pattern: " + ISO_8601_DATETIME_DESC, example = "2020-04-06T03:34:58")
    @JsonProperty("as_end_time")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = TIME_STAMP_DATE_TIME_PATTERN, timezone = TIMEZONE)
    private Date asEndTime;

    @ApiModelProperty(value = "Y or N indicator. If irrelevant,this attribute can be omitted, default is null.", allowableValues = "Y,N,null")
    @JsonProperty("as_ind")
    @AllowedValuesValidation(values = {"Y", "N"})
    private String asInd;

    @ApiModelProperty(value = "Date time pattern: " + ISO_8601_DATETIME_DESC, example = "2020-04-06T03:34:58")
    @JsonProperty("cm_start_time")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = TIME_STAMP_DATE_TIME_PATTERN, timezone = TIMEZONE)
    private Date cmStartTime;

    @ApiModelProperty(value = "Date time pattern: " + ISO_8601_DATETIME_DESC, example = "2020-04-06T03:34:58")
    @JsonProperty("cm_end_time")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = TIME_STAMP_DATE_TIME_PATTERN, timezone = TIMEZONE)
    private Date cmEndTime;

    @ApiModelProperty(value = "Y or N indicator. If irrelevant,this attribute can be omitted, default is null.", allowableValues = "Y,N,null")
    @JsonProperty("cm_ind")
    @AllowedValuesValidation(values = {"Y", "N"})
    private String cmInd;

    @ApiModelProperty(value = "Date time pattern: " + ISO_8601_DATETIME_DESC, example = "2020-04-06T03:34:58")
    @JsonProperty("eh_start_time")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = TIME_STAMP_DATE_TIME_PATTERN, timezone = TIMEZONE)
    private Date ehStartTime;

    @ApiModelProperty(value = "Date time pattern: " + ISO_8601_DATETIME_DESC, example = "2020-04-06T03:34:58")
    @JsonProperty("eh_end_time")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = TIME_STAMP_DATE_TIME_PATTERN, timezone = TIMEZONE)
    private Date ehEndTime;

    @ApiModelProperty(value = "Y or N indicator. If irrelevant,this attribute can be omitted, default is null.", allowableValues = "Y,N,null")
    @JsonProperty("eh_ind")
    @AllowedValuesValidation(values = {"Y", "N"})
    private String ehInd;

    @ApiModelProperty(value = "Date time pattern: " + ISO_8601_DATETIME_DESC, example = "2020-04-06T03:34:58")
    @JsonProperty("ac_start_time")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = TIME_STAMP_DATE_TIME_PATTERN, timezone = TIMEZONE)
    private Date acStartTime;

    @ApiModelProperty(value = "Date time pattern: " + ISO_8601_DATETIME_DESC, example = "2020-04-06T03:34:58")
    @JsonProperty("ac_end_time")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = TIME_STAMP_DATE_TIME_PATTERN, timezone = TIMEZONE)
    private Date acEndTime;

    @ApiModelProperty(value = "Y or N indicator. If irrelevant,this attribute can be omitted, default is null.", allowableValues = "Y,N,null")
    @JsonProperty("ac_ind")
    @AllowedValuesValidation(values = {"Y", "N"})
    private String acInd;

    @ApiModelProperty(value = "Date time pattern: " + ISO_8601_DATETIME_DESC, example = "2020-04-06T03:34:58")
    @JsonProperty("vi_start_time")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = TIME_STAMP_DATE_TIME_PATTERN, timezone = TIMEZONE)
    private Date viStartTime;

    @ApiModelProperty(value = "Date time pattern: " + ISO_8601_DATETIME_DESC, example = "2020-04-06T03:34:58")
    @JsonProperty("vi_end_time")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = TIME_STAMP_DATE_TIME_PATTERN, timezone = TIMEZONE)
    private Date viEndTime;

    @ApiModelProperty(value = "Y or N indicator. If irrelevant,this attribute can be omitted, default is null.", allowableValues = "Y,N,null")
    @JsonProperty("vi_ind")
    @AllowedValuesValidation(values = {"Y", "N"})
    private String viInd;

    @ApiModelProperty(value = "Date time pattern: " + ISO_8601_DATETIME_DESC, example = "2020-04-06T03:34:58")
    @JsonProperty("coi_start_time")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = TIME_STAMP_DATE_TIME_PATTERN, timezone = TIMEZONE)
    private Date coiStartTime;

    @ApiModelProperty(value = "Date time pattern: " + ISO_8601_DATETIME_DESC, example = "2020-04-06T03:34:58")
    @JsonProperty("coi_end_time")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = TIME_STAMP_DATE_TIME_PATTERN, timezone = TIMEZONE)
    private Date coiEndTime;

    @ApiModelProperty(value = "Y or N indicator. If irrelevant,this attribute can be omitted, default is null.", allowableValues = "Y,N,null")
    @JsonProperty("coi_ind")
    @AllowedValuesValidation(values = {"Y", "N"})
    private String coiInd;

    @ApiModelProperty(value = "Y or N indicator. If irrelevant,this attribute can be omitted, default is null.", allowableValues = "Y,N,null")
    @JsonProperty("oth_ins_ind")
    @AllowedValuesValidation(values = {"Y", "N"})
    private String othInsInd;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("PolicyProcessStatus{");
        sb.append("polNo='").append(ConversionHandler.mask(polNo)).append('\'');
        sb.append(", nbStartTime=").append(nbStartTime);
        sb.append(", nbEndTime=").append(nbEndTime);
        sb.append(", nbInd='").append(nbInd).append('\'');
        sb.append(", peStartTime=").append(peStartTime);
        sb.append(", peEndTime=").append(peEndTime);
        sb.append(", peInd='").append(peInd).append('\'');
        sb.append(", asStartTime=").append(asStartTime);
        sb.append(", asEndTime=").append(asEndTime);
        sb.append(", asInd='").append(asInd).append('\'');
        sb.append(", cmStartTime=").append(cmStartTime);
        sb.append(", cmEndTime=").append(cmEndTime);
        sb.append(", cmInd='").append(cmInd).append('\'');
        sb.append(", ehStartTime=").append(ehStartTime);
        sb.append(", ehEndTime=").append(ehEndTime);
        sb.append(", ehInd='").append(ehInd).append('\'');
        sb.append(", acStartTime=").append(acStartTime);
        sb.append(", acEndTime=").append(acEndTime);
        sb.append(", acInd='").append(acInd).append('\'');
        sb.append(", viStartTime=").append(viStartTime);
        sb.append(", viEndTime=").append(viEndTime);
        sb.append(", viInd='").append(viInd).append('\'');
        sb.append(", coiStartTime=").append(coiStartTime);
        sb.append(", coiEndTime=").append(coiEndTime);
        sb.append(", coiInd='").append(coiInd).append('\'');
        sb.append(", othInsInd='").append(othInsInd).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
