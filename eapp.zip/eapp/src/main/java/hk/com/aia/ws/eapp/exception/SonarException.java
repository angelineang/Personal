package hk.com.aia.ws.eapp.exception;

public class SonarException extends Exception {
	public SonarException(String s) {
		super(s);
	}
}
