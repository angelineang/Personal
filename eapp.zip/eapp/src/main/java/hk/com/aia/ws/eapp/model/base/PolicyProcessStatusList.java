package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.annotation.ListMaxSizeValidation;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import java.util.List;

@ApiModel("List of Policy Process Status - Wrapper")
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class PolicyProcessStatusList extends Payload {

    @ApiModelProperty(value="List of Policies with ", required = true)
    @JsonProperty("policy_process_status_list")
    @ListMaxSizeValidation(message = "List of Policy No cannot exceed maximum of 1")
    @NotEmpty
    @Valid
    List<PolicyProcessStatus> policyProcessStatusList;
}
