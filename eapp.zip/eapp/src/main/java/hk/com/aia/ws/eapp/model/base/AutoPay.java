package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.annotation.AllowedValuesValidation;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@ApiModel(value = "Autopay model")
@Getter
@Setter
public class AutoPay {

    // API Model Property - copied from old code

    @ApiModelProperty(value = "Autopay Type - DD, CC (tbl_ms_pol_autopay.autopay_type)", example = "DD", allowableValues = "DD,CC")
    @JsonProperty("auto_pay_type")
    @NotBlank
    @AllowedValuesValidation(values = {"DD", "CC"})
    private String autopayType;

    @ApiModelProperty(value = "Back Code (Numeric) (tbl_ms_pol_autopay.bank_code)", example = "004")
    @JsonProperty("bank_code")
    @Pattern(regexp = "^[0-9]{0,10}$", message = "Please enter a valid numeric Bank code (not exceeding 10 digits)")
    private String bankCode;

    @ApiModelProperty(value = "Branch Code (Numeric) (tbl_ms_pol_autopay.branch_code)", example = "\"118\"")
    @JsonProperty("branch_code")
    @Pattern(regexp = "^[0-9]{0,10}$", message = "Please enter a valid numeric Branch code (not exceeding 10 digits)")
    private String branchCode;

    @ApiModelProperty(value = "Account Number (Numeric)  (tbl_ms_pol_autopay.account_no)", example = "\"8029511\"")
    @JsonProperty("account_no")
    @Pattern(regexp = "^[0-9]{0,50}$", message = "Please enter a valid numeric Account number (not exceeding 50 digits)")
    private String accountNo;

    @ApiModelProperty(value = " Holder Name - Free Text (tbl_ms_pol_autopay.holder_name)", example = "CHAN TAI MAN")
    @JsonProperty("holder_name")
    @Size(max = 60)
    private String holderName;

    @ApiModelProperty(value = "Id 1 Type - ID = HKID / HK Birth Cert., MD = Macau ID / Macau Work ID, PR = PRC ID, PA = Passport / Non HKID / Non Macau ID   (tbl_ms_pol_autopay.id_type_1)", example = "ID", allowableValues = "ID,MD,PR,PA")
    @JsonProperty("id_type_1")
    @Size(max = 2)
    private String idType1;

    @ApiModelProperty(value = "Id 1 Number - Maximum 18 alphanumerics (tbl_ms_pol_autopay.id_no_1)", example = "G1234567")
    @JsonProperty("id_no_1")
    @Size(max = 24)
    private String idNo1;

    @ApiModelProperty(value = "Id 2 Type - ID = HKID / HK Birth Cert., MD = Macau ID / Macau Work ID, PR = PRC ID, PA = Passport / Non HKID / Non Macau ID   (tbl_ms_pol_autopay.id_type_1)", example = "ID", allowableValues = "ID,MD,PR,PA")
    @JsonProperty("id_type_2")
    @Size(max = 2)
    private String idType2;

    @ApiModelProperty(value = "Id 2 Number - Maximum 18 alphanumerics (tbl_ms_pol_autopay.id_no_2)", example = "G1234567")
    @JsonProperty("id_no_2")
    @Size(max = 24)
    private String idNo2;

    @ApiModelProperty(value = "Expiry Year (Last 2 digits of year) (tbl_ms_pol_autopay.exp_date_yy)", example = "\"18\"")
    @JsonProperty("exp_date_yy")
    @Pattern(regexp = "^[0-9]{0,2}$", message = "Please enter a valid 2 digit year.")
    private String expDateYY;

    @ApiModelProperty(value = "Expiry Month (2 digits) (tbl_ms_pol_autopay.exp_date_mm)", example = "\"10\"")
    @JsonProperty("exp_date_mm")
    @Pattern(regexp = "^(0?[1-9]|1[012])$", message = "Please enter a valid 2 digit month")
    private String expDateMM;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("AutoPay{");
        sb.append("autopayType='").append(autopayType).append('\'');
        sb.append(", bankCode='").append(bankCode).append('\'');
        sb.append(", branchCode='").append(branchCode).append('\'');
        sb.append(", accountNo='").append(ConversionHandler.mask(accountNo)).append('\'');
        sb.append(", holderName='").append(ConversionHandler.mask(holderName)).append('\'');
        sb.append(", idType1='").append(idType1).append('\'');
        sb.append(", idNo1='").append(idNo1).append('\'');
        sb.append(", idType2='").append(idType2).append('\'');
        sb.append(", idNo2='").append(idNo2).append('\'');
        sb.append(", expDateYY='").append(expDateYY).append('\'');
        sb.append(", expDateMM='").append(expDateMM).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
