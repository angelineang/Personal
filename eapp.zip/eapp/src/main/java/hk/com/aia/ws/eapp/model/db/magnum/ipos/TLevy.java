package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import lombok.Data;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "T_LEVY")
public class TLevy {

    @Column(name = "levyID", length = 60)
    @Id
    private String levyId;

    @Column(name = "eappID", length = 60)
    private String eappId;

    @Column(name = "levyRate", length = 10)
    private String levyRate;

    @Column(name = "basicAmount", length = 20)
    private String basicAmount;

    @Column(name = "riderAmount", length = 20)
    private String riderAmount;

    @Column(name = "levyTotalModalPremium", length = 20)
    private String levyTotalModalPremium;

    @Column(name = "levyTotalAnnualPremium", length = 20)
    private String levyTotalAnnualPremium;

    @Column(name = "createby", length = 10, updatable = false)
    @CreatedBy
    private String createBy;

    @Column(name = "createddatetime", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "quotationLastUpdateTime")
    @Temporal(TemporalType.TIMESTAMP)
    private Date quotationLastUpdateTime;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TLevy{");
        sb.append("levyId='").append(levyId).append('\'');
        sb.append(", eappId='").append(eappId).append('\'');
        sb.append(", levyRate='").append(levyRate).append('\'');
        sb.append(", basicAmount='").append(basicAmount).append('\'');
        sb.append(", riderAmount='").append(riderAmount).append('\'');
        sb.append(", levyTotalModalPremium='").append(levyTotalModalPremium).append('\'');
        sb.append(", levyTotalAnnualPremium='").append(levyTotalAnnualPremium).append('\'');
        sb.append(", createBy='").append(createBy).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", quotationLastUpdateTime=").append(quotationLastUpdateTime);
        sb.append('}');
        return sb.toString();
    }
}