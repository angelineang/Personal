package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import lombok.Data;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@Table(name = "T_SIMULATION")
@EntityListeners(AuditingEntityListener.class)
public class TSimulation {

    @Column(name = "SIMULATIONID", length = 60)
    @Id
    private String simulationId;

    @Column(name = "EAPPID", length = 60)
    private String eAppId;

    @Column(name = "MESSAGEID", length = 12)
    private String messageId;

    @Column(name = "DESCRIPTION", length = 255)
    private String description;

    @Column(name = "SIMULATIONDATE")
    @Temporal(TemporalType.DATE)
    private Date simulationDate;

    @Column(name = "CREATEDBY", length = 10, updatable = false)
    @CreatedBy
    private String createdBy;

    @Column(name = "UPDATEDBY", length = 10)
    @LastModifiedBy
    private String updatedBy;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "LASTUPDATEDATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    @LastModifiedDate
    private Date lastUpdateDateTime;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TSimulation{");
        sb.append("simulationId='").append(simulationId).append('\'');
        sb.append(", eAppId='").append(eAppId).append('\'');
        sb.append(", messageId='").append(messageId).append('\'');
        sb.append(", description='").append(description).append('\'');
        sb.append(", simulationDate=").append(simulationDate);
        sb.append(", createdBy='").append(createdBy).append('\'');
        sb.append(", updatedBy='").append(updatedBy).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", lastUpdateDateTime=").append(lastUpdateDateTime);
        sb.append('}');
        return sb.toString();
    }
}