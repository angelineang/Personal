package hk.com.aia.ws.eapp.model.kafka.incoming;

import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import lombok.Data;

@Data
public class MessagePayload {

    @JsonProperty("workItemId")
    private String workItemId;

    @JsonProperty("batchId")
    private String batchId;

    @JsonProperty("policyNo")
    private String policyNo;

    @JsonProperty("requestNo")
    private String requestNo;

    @JsonProperty("cloudWorkflow")
    private boolean cloudWorkflow;

    @JsonProperty("event")
    private String event;

    @JsonProperty("error")
    private Error error;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("MessagePayload{");
        sb.append("workItemId='").append(workItemId).append('\'');
        sb.append(", batchId='").append(batchId).append('\'');
        sb.append(", policyNo='").append(ConversionHandler.mask(policyNo)).append('\'');
        sb.append(", requestNo='").append(requestNo).append('\'');
        sb.append(", cloudWorkflow=").append(cloudWorkflow);
        sb.append(", event='").append(event).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
