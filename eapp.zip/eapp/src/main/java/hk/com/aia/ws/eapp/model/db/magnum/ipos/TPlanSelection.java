package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import hk.com.aia.ws.eapp.model.db.magnum.ipos.idclass.TPlanSelectionId;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import lombok.Data;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "T_PLANSELECTION")
@IdClass(TPlanSelectionId.class)
public class TPlanSelection {

    @Column(name = "PLANSELECTIONID", length = 60)
    @Id
    private String planSelectionId;

    @Column(name = "AGENTCODE", length = 10)
    private String agentCode;

    @Column(name = "ACCESSCODE", length = 30)
    private String accessCode;

    @Column(name = "SQSQUOTATIONID", length = 60)
    @Id
    private String sqsQuotationId;

    @Column(name = "INSUREDID", length = 60)
    @Id
    private String insuredId;

    @Column(name = "PLANCODE", length = 6)
    private String planCode;

    @Column(name = "COVERAGETERM")
    private Integer coverageTerm;

    @Column(name = "PREMIUMTERM")
    private Integer premiumTerm;

    @Column(name = "SUMASSURED")
    private BigDecimal sumAssured;

    @Column(name = "ANNUALPREMIUM")
    private BigDecimal annualPremium;

    @Column(name = "MODALPREMIUM")
    private BigDecimal modalPremium;

    @Column(name = "ISRIDER")
    private Integer isRider;

    @Column(name = "CLASSRATING")
    private Integer classRating;

    @Column(name = "OCCCATEGORY", length = 10)
    private String occCategory;

    @Column(name = "OCCRATING", length = 10)
    private String occRating;

    @Column(name = "CREATEDBY", length = 10, updatable = false)
    @CreatedBy
    private String createdBy;

    @Column(name = "UPDATEDBY", length = 10)
    @LastModifiedBy
    private String updatedBy;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "LASTUPDATEDATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    @LastModifiedDate
    private Date lastUpdateDateTime;

    @Column(name = "SHORTNAME", length = 255)
    private String shortName;

    @Column(name = "PARENTPLANCODE", length = 255)
    private String parentPlanCode;

    @Column(name = "PREMIUMPAYMENTPERIOD")
    private Integer premiumPaymentPeriod;

    @Column(name = "INTERESTRATE")
    private BigDecimal interestRate;

    @Column(name = "ORIGINALANNUALPREMIUM")
    private BigDecimal originalAnnualPremium;

    @Column(name = "ORIGINALMODALPREMIUM")
    private BigDecimal originalModalPremium;

    @Column(name = "ISHIDDEN")
    private Integer isHidden;

    @Column(name = "RISKCLASSTEXT", length = 255)
    private String riskClassText;

    @Column(name = "RISKCLASSNUMBER")
    private Integer riskClassNumber;

    @Column(name = "MEDICALRATING")
    private BigDecimal medicalRating;

    @Column(name = "ISVITALITY")
    private Integer isVitality;

    @Column(name = "isFamilyProduct", length = 10)
    private String isFamilyProduct;

    @Column(name = "relationShip", length = 10)
    private String relationShip;

    @Column(name = "occi", length = 10)
    private String occi;

    @Column(name = "OCCLOADING")
    private Integer occLoading;

    @Column(name = "ISOCCFLAT")
    private Integer isOccFlat;

    @Column(name = "RATINGTYPE", length = 255)
    private String ratingType;

    @Column(name = "RATINGTYPECI", length = 255)
    private String ratingTypeCi;

    @Column(name = "ISNEWBORN")
    private Integer isNewBorn;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TPlanSelection{");
        sb.append("planSelectionId='").append(planSelectionId).append('\'');
        sb.append(", agentCode='").append(agentCode).append('\'');
        sb.append(", accessCode='").append(accessCode).append('\'');
        sb.append(", sqsQuotationId='").append(sqsQuotationId).append('\'');
        sb.append(", insuredId='").append(ConversionHandler.mask(insuredId)).append('\'');
        sb.append(", planCode='").append(planCode).append('\'');
        sb.append(", coverageTerm=").append(coverageTerm);
        sb.append(", premiumTerm=").append(premiumTerm);
        sb.append(", sumAssured=").append(sumAssured);
        sb.append(", annualPremium=").append(annualPremium);
        sb.append(", modalPremium=").append(modalPremium);
        sb.append(", isRider=").append(isRider);
        sb.append(", classRating=").append(classRating);
        sb.append(", occCategory='").append(occCategory).append('\'');
        sb.append(", occRating='").append(occRating).append('\'');
        sb.append(", createdBy='").append(createdBy).append('\'');
        sb.append(", updatedBy='").append(updatedBy).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", lastUpdateDateTime=").append(lastUpdateDateTime);
        sb.append(", shortName='").append(ConversionHandler.mask(shortName)).append('\'');
        sb.append(", parentPlanCode='").append(parentPlanCode).append('\'');
        sb.append(", premiumPaymentPeriod=").append(premiumPaymentPeriod);
        sb.append(", interestRate=").append(interestRate);
        sb.append(", originalAnnualPremium=").append(originalAnnualPremium);
        sb.append(", originalModalPremium=").append(originalModalPremium);
        sb.append(", isHidden=").append(isHidden);
        sb.append(", riskClassText='").append(riskClassText).append('\'');
        sb.append(", riskClassNumber=").append(riskClassNumber);
        sb.append(", medicalRating=").append(medicalRating);
        sb.append(", isVitality=").append(isVitality);
        sb.append(", isFamilyProduct='").append(isFamilyProduct).append('\'');
        sb.append(", relationShip='").append(relationShip).append('\'');
        sb.append(", occi='").append(occi).append('\'');
        sb.append(", occLoading=").append(occLoading);
        sb.append(", isOccFlat=").append(isOccFlat);
        sb.append(", ratingType='").append(ratingType).append('\'');
        sb.append(", ratingTypeCi='").append(ratingTypeCi).append('\'');
        sb.append(", isNewBorn=").append(isNewBorn);
        sb.append('}');
        return sb.toString();
    }
}
