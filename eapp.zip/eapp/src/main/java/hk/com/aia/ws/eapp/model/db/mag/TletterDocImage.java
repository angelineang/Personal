package hk.com.aia.ws.eapp.model.db.mag;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import hk.com.aia.ws.eapp.util.ConversionHandler;
import lombok.Data;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "tletter_doc_image")
public class TletterDocImage  {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "comp_no")
    private String compNo;

    @Column(name = "pol_no")
    private String polNo;

    @Column(name = "letter_type")
    private String letterType;

    @Column(name = "cycle_date")
    private Date cycleDate;

    @Column(name = "doc_seq")
    private Integer docSeq;

    @Column(name = "filename")
    private String fileName;

    @Column(name = "file_type")
    private String fileType;

    @Column(name = "file_size")
    private Integer fileSize;

    @Column(name = "last_modified_time")
    private Date lastModifiedTime;

    @Column(name = "md5")
    private String md5;

    @Column(name = "update_on")
    private Date updateOn;

    @Column(name = "channel")
    private String channel;

    @Column(name = "lang")
    private String lang;

    @Column(name = "last_view_count")
    private Integer lastViewCount;

    @Column(name = "last_view_time")
    private Date lastViewTime;

    @Column(name = "eSign_date")
    private Date esignDate;

    @Column(name = "create_date")
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createDate;

    @Column(name = "blob_path")
    private String blobPath;

    @Column(name = "blob_path_watermark")
    private String blobPathWithWatermark;


    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TletterDocImage{");
        sb.append("compNo='").append(compNo).append('\'');
        sb.append(", channel='").append(channel).append('\'');
        sb.append(", lastViewCount='").append(lastViewCount).append('\'');
        sb.append(", updateOn='").append(updateOn).append('\'');
        sb.append(", cycleDate='").append(cycleDate).append('\'');
        sb.append(", id='").append(id);
        sb.append(", createDate='").append(createDate).append('\'');
        sb.append(", lang='").append(lang).append('\'');
        sb.append(", lastViewTime='").append(lastViewTime).append('\'');
        sb.append(", fileName='").append(fileName).append('\'');
        sb.append(", blobPath='").append(blobPath);
        sb.append(", md5='").append(md5).append('\'');
        sb.append(", letterType='").append(letterType).append('\'');
        sb.append(", polNo='").append(ConversionHandler.mask(polNo)).append('\'');
        sb.append(", fileType='").append(fileType).append('\'');
        sb.append(", docSeq=").append(docSeq).append('\'');
        sb.append(", fileSize='").append(fileSize).append('\'');
        sb.append(", eSignDate='").append(esignDate).append('\'');
        sb.append(", lastModifiedTime='").append(lastModifiedTime).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
