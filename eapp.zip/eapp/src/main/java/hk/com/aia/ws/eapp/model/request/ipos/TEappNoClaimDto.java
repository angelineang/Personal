package hk.com.aia.ws.eapp.model.request.ipos;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.util.Date;

@ApiModel(value = "T_EAPPNOCLAIM Model")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TEappNoClaimDto {
    @ApiModelProperty(value = "eapp no claim Id", required = true)
    @JsonProperty("eapp_no_claim_id")
    @Size(max = 60)
    @NotBlank
    private String eappNoClaimId;

    @ApiModelProperty(value = "eapp Id")
    @JsonProperty("eapp_id")
    @Size(max = 60)
    private String eappId;

    @ApiModelProperty(value = "insure company")
    @JsonProperty("insure_company")
    @Size(max = 512)
    private String insureCompany;

    @ApiModelProperty(value = "product name")
    @JsonProperty("product_name")
    @Size(max = 512)
    private String productName;

    @ApiModelProperty(value = "last date")
    @JsonProperty("last_date")
    private Date lastDate;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TEappNoClaimDto{");
        sb.append("eappNoClaimId='").append(eappNoClaimId).append('\'');
        sb.append(", eappId='").append(eappId).append('\'');
        sb.append(", insureCompany='").append(insureCompany).append('\'');
        sb.append(", productName='").append(productName).append('\'');
        sb.append(", lastDate=").append(lastDate);
        sb.append('}');
        return sb.toString();
    }
}
