package hk.com.aia.ws.eapp.model.db.magnum.ipos.idclass;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TPlanSelectionId implements Serializable {

    private static final long serialVersionUID = 787414924007016496L;
    private String planSelectionId;
    private String sqsQuotationId;
    private String insuredId;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TPlanSelectionId{");
        sb.append("planSelectionId='").append(planSelectionId).append('\'');
        sb.append(", sqsQuotationId='").append(sqsQuotationId).append('\'');
        sb.append(", insuredId='").append(insuredId).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
