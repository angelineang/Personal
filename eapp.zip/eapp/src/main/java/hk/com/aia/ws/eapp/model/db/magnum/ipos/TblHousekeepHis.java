package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import hk.com.aia.ws.eapp.model.db.magnum.ipos.idclass.TblHousekeepHisId;
import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.annotation.Nullable;
import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Data
@Table(name = "tbl_housekeep_his")
@IdClass(TblHousekeepHisId.class)
@EntityListeners(AuditingEntityListener.class)
public class TblHousekeepHis implements Serializable {

    @Column(name = "table_name")
    @Id
    private String table_name;

    @Column(name = "housekeep_date")
    @Id
    private String housekeep_date;

    @Column(name = "delete_cnt")
    @Nullable
    private Integer delete_cnt;

    @Column(name = "delete_start")
    @Nullable
    private Date delete_start;

    @Column(name = "delete_end")
    @Nullable
    private Date delete_end;

    @Column(name = "time_consumed_sec")
    @Nullable
    private Integer time_consumed_sec;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("tbl_housekeep_his{");
        sb.append("table_name='").append(table_name).append('\'');
        sb.append(", housekeep_date='").append(housekeep_date).append('\'');
        sb.append(", delete_cnt='").append(delete_cnt).append('\'');
        sb.append(", delete_start='").append(delete_start).append('\'');
        sb.append(", delete_end=").append(delete_end);
        sb.append(", time_consumed_sec='").append(time_consumed_sec).append('\'');
        sb.append('}');
        return sb.toString();
    }

}
