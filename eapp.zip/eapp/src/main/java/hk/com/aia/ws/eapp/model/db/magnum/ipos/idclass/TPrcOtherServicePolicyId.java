package hk.com.aia.ws.eapp.model.db.magnum.ipos.idclass;

import hk.com.aia.ws.eapp.util.ConversionHandler;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TPrcOtherServicePolicyId implements Serializable {
    private static final long serialVersionUID = -7910712198027516175L;
    private String iverifyId;
    private String serviceType;
    private String policyNo;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TPrcOtherServicePolicyId{");
        sb.append("iverifyId='").append(iverifyId).append('\'');
        sb.append(", serviceType='").append(serviceType).append('\'');
        sb.append(", policyNo='").append(ConversionHandler.mask(policyNo)).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
