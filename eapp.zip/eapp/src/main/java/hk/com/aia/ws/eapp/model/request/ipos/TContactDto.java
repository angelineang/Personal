package hk.com.aia.ws.eapp.model.request.ipos;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.util.Date;

import static hk.com.aia.ws.eapp.constant.Constants.TIMEZONE;

@ApiModel(value = "T_CONTACT Model")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TContactDto {

    @ApiModelProperty(value = "contact Id", required = true)
    @JsonProperty("contact_id")
    @Size(max = 60)
    @NotBlank
    private String contactId;

    @JsonProperty("title_id")
    @Size(max = 10)
    private String titleId;

    @JsonProperty("last_name_en")
    @Size(max = 100)
    private String lastNameEn;

    @JsonProperty("first_name_en")
    @Size(max = 50)
    private String firstNameEn;

    @JsonProperty("alias")
    @Size(max = 45)
    private String alias;

    @JsonProperty("name_chn")
    @Size(max = 500)
    private String nameChn;

    @JsonProperty("gender")
    @Size(max = 1)
    private String gender;

    @JsonProperty("agent_code")
    @Size(max = 5)
    private String agentCode;

    @JsonProperty("access_code")
    @Size(max = 30)
    private String accesscode;

    @JsonProperty("citizenship_code")
    @Size(max = 2)
    private String citizenshipCode;

    @JsonProperty("citizenship_name")
    @Size(max = 255)
    private String citizenshipName;

    @JsonProperty("other_citizenship")
    @Size(max = 50)
    private String otherCitizenship;

    @JsonProperty("nationality_code")
    @Size(max = 2)
    private String nationalityCode;

    @JsonProperty("nationality_name")
    @Size(max = 255)
    private String nationalityName;

    @JsonProperty("other_nationality")
    @Size(max = 50)
    private String otherNationality;

    @JsonProperty("residential_code")
    @Size(max = 2)
    private String residentialCode;

    @JsonProperty("residential_name")
    @Size(max = 255)
    private String residentialName;

    @JsonProperty("other_residential")
    @Size(max = 50)
    private String otherResidential;

    @ApiModelProperty(value = "Date of birth ,format = yyyy-MM-dd", example = "2020-12-31")
    @JsonProperty("dob")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = TIMEZONE)
    private Date dob;

    @JsonProperty("age")
    private Integer age;

    @JsonProperty("marital_status")
    @Size(max = 1)
    private String maritalStatus;

    @JsonProperty("ssn")
    @Size(max = 20)
    private String ssn;

    @JsonProperty("contact_type")
    @Size(max = 1)
    private String contactType;

    @JsonProperty("process_status")
    @Size(max = 10)
    private String processStatus;

    @JsonProperty("prc")
    private Integer prc;

    @JsonProperty("original_contact_id")
    @Size(max = 60)
    private String originalContactId;

    @JsonProperty("business_certificate_no")
    @Size(max = 300)
    private String businessCertificateNo;

    @JsonProperty("business_nature_code")
    @Size(max = 60)
    private String businessNatureCode;

    @JsonProperty("remark")
    @Size(max = 500)
    private String remark;

    @JsonProperty("smoker")
    @Size(max = 1)
    private String smoker;

    @JsonProperty("i_amp_customer_id")
    @Size(max = 60)
    private String iAmpCustomerId;

    @JsonProperty("server_contact_id")
    @Size(max = 60)
    private String serverContactId;

    @JsonProperty("master_contact_id")
    @Size(max = 60)
    private String masterContactId;

    @JsonProperty("city_code")
    @Size(max = 20)
    private String cityCode;

    @JsonProperty("duplicate")
    private Integer duplicate;

    @JsonProperty("merged")
    private Integer merged;

    @JsonProperty("vitality")
    private Integer vitality;

    @JsonProperty("contactid_ipos")
    @Size(max = 60)
    private String contactIdIpos;

    @JsonProperty("province")
    @Size(max = 50)
    private String province;

    @JsonProperty("city")
    @Size(max = 50)
    private String city;

    @JsonProperty("other_city_detail")
    @Size(max = 200)
    private String otherCityDetail;

    @JsonProperty("alpha_id")
    @Size(max = 60)
    private String alphaId;

    @JsonProperty("prospect_id")
    @Size(max = 60)
    private String prospectId;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TContactDto{");
        sb.append("contactId='").append(contactId).append('\'');
        sb.append(", titleId='").append(titleId).append('\'');
        sb.append(", lastNameEn='").append(ConversionHandler.mask(lastNameEn)).append('\'');
        sb.append(", firstNameEn='").append(ConversionHandler.mask(firstNameEn)).append('\'');
        sb.append(", alias='").append(alias).append('\'');
        sb.append(", nameChn='").append(ConversionHandler.mask(nameChn)).append('\'');
        sb.append(", gender='").append(gender).append('\'');
        sb.append(", agentCode='").append(agentCode).append('\'');
        sb.append(", accesscode='").append(accesscode).append('\'');
        sb.append(", citizenshipCode='").append(citizenshipCode).append('\'');
        sb.append(", citizenshipName='").append(citizenshipName).append('\'');
        sb.append(", otherCitizenship='").append(otherCitizenship).append('\'');
        sb.append(", nationalityCode='").append(nationalityCode).append('\'');
        sb.append(", nationalityName='").append(nationalityName).append('\'');
        sb.append(", otherNationality='").append(otherNationality).append('\'');
        sb.append(", residentialCode='").append(residentialCode).append('\'');
        sb.append(", residentialName='").append(residentialName).append('\'');
        sb.append(", otherResidential='").append(otherResidential).append('\'');
        sb.append(", dob=").append(ConversionHandler.mask(dob));
        sb.append(", age=").append(ConversionHandler.mask(age));
        sb.append(", maritalStatus='").append(maritalStatus).append('\'');
        sb.append(", ssn='").append(ssn).append('\'');
        sb.append(", contactType='").append(contactType).append('\'');
        sb.append(", processStatus='").append(processStatus).append('\'');
        sb.append(", prc=").append(prc);
        sb.append(", originalContactId='").append(originalContactId).append('\'');
        sb.append(", businessCertificateNo='").append(businessCertificateNo).append('\'');
        sb.append(", businessNatureCode='").append(businessNatureCode).append('\'');
        sb.append(", remark='").append(remark).append('\'');
        sb.append(", smoker='").append(smoker).append('\'');
        sb.append(", iAmpCustomerId='").append(iAmpCustomerId).append('\'');
        sb.append(", serverContactId='").append(serverContactId).append('\'');
        sb.append(", masterContactId='").append(masterContactId).append('\'');
        sb.append(", cityCode='").append(cityCode).append('\'');
        sb.append(", duplicate=").append(duplicate);
        sb.append(", merged=").append(merged);
        sb.append(", vitality=").append(vitality);
        sb.append(", contactIdIpos='").append(contactIdIpos).append('\'');
        sb.append(", province='").append(province).append('\'');
        sb.append(", city='").append(city).append('\'');
        sb.append(", otherCityDetail='").append(otherCityDetail).append('\'');
        sb.append(", alphaId='").append(alphaId).append('\'');
        sb.append(", prospectId='").append(prospectId).append('\'');
        sb.append('}');
        return sb.toString();
    }
}

