package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import hk.com.aia.ws.eapp.util.ConversionHandler;
import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "T_EAPPCITIDDA")
public class TEappCitiDda {

    @Column(name = "CITIDDAID", length = 60)
    @Id
    private String citiDdaId;

    @Column(name = "EAPPID", length = 60)
    private String eappId;

    @Column(name = "PAYMENTMODE", length = 10)
    private String paymentMode;

    @Column(name = "PAYMENTINSTRUCTION", length = 10)
    private String paymentInstruction;

    @Column(name = "ACCOUNTHOLDERNAME", length = 60)
    private String accountHolderName;

    @Column(name = "ACCOUNTNO", length = 20)
    private String accountNo;

    @Column(name = "BANKCODE", length = 3)
    private String bankCode;

    @Column(name = "BANKBRANCHNO", length = 20)
    private String bankBranchNo;

    @Column(name = "BANKACCOUNTTYPE", length = 10)
    private String bankAccountType;

    @Column(name = "CREDITCARDEXPIRYDATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date creditCardExpiryDate;

    @Column(name = "CREDITCARDAUTHORISATIONCODE", length = 20)
    private String creditCardAuthorisationCode;

    @Column(name = "CREDITCARDAUTHORISATIONDATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date creditCardAuthorisationDate;

    @Column(name = "CREDITCARDMERCHANTNUMBER")
    private String creditCardMerchantNumber;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TEappCitiDda{");
        sb.append("citiDdaId='").append(citiDdaId).append('\'');
        sb.append(", eappId='").append(eappId).append('\'');
        sb.append(", paymentMode='").append(paymentMode).append('\'');
        sb.append(", paymentInstruction='").append(paymentInstruction).append('\'');
        sb.append(", accountHolderName='").append(accountHolderName).append('\'');
        sb.append(", accountNo='").append(ConversionHandler.mask(accountNo)).append('\'');
        sb.append(", bankCode='").append(bankCode).append('\'');
        sb.append(", bankBranchNo='").append(bankBranchNo).append('\'');
        sb.append(", bankAccountType='").append(bankAccountType).append('\'');
        sb.append(", creditCardExpiryDate=").append(creditCardExpiryDate);
        sb.append(", creditCardAuthorisationCode='").append(creditCardAuthorisationCode).append('\'');
        sb.append(", creditCardAuthorisationDate=").append(creditCardAuthorisationDate);
        sb.append(", creditCardMerchantNumber='").append(creditCardMerchantNumber).append('\'');
        sb.append('}');
        return sb.toString();
    }
}

