package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@Table(name = "T_TAX")
@EntityListeners(AuditingEntityListener.class)
public class TTax {

    @Column(name = "TAXID", length = 60)
    @Id
    private String taxId;

    @Column(name = "EAPPID", length = 60)
    private String eappId;

    @Column(name = "TIN", length = 120)
    private String tin;

    @Column(name = "DECLAREDRESIDENT")
    private Integer declaredResident;

    @Column(name = "JURISDICTION", length = 300)
    private String jurisdiction;

    @Column(name = "NOTINREASONCODE", length = 5)
    private String notInReasonCode;

    @Column(name = "EXPLAIN")
    private String explain;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "isSameAsPRCID")
    private Integer isSameAsPrcId;

    @Column(name = "reasonExplain")
    private String reasonExplain;

    @Column(name = "highRiskQ1", length = 10)
    private String highRiskQ1;

    @Column(name = "highRiskQ2a", length = 10)
    private String highRiskQ2a;

    @Column(name = "highRiskQ2b", length = 10)
    private String highRiskQ2b;

    @Column(name = "highRiskQ2c", length = 10)
    private String highRiskQ2c;

    @Column(name = "highRiskReason", length = 800)
    private String highRiskReason;

    @Column(name = "hasHighRiskQuestion", length = 10)
    private String hasHighRiskQuestion;

    @Column(name = "JURISDICTIONOTHER", length = 300)
    private String jurisdictionOther;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TTax{");
        sb.append("taxId='").append(taxId).append('\'');
        sb.append(", eappId='").append(eappId).append('\'');
        sb.append(", tin='").append(tin).append('\'');
        sb.append(", declaredResident=").append(declaredResident);
        sb.append(", jurisdiction='").append(jurisdiction).append('\'');
        sb.append(", notInReasonCode='").append(notInReasonCode).append('\'');
        sb.append(", explain='").append(explain).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", isSameAsPrcId=").append(isSameAsPrcId);
        sb.append(", reasonExplain='").append(reasonExplain).append('\'');
        sb.append(", highRiskQ1='").append(highRiskQ1).append('\'');
        sb.append(", highRiskQ2a='").append(highRiskQ2a).append('\'');
        sb.append(", highRiskQ2b='").append(highRiskQ2b).append('\'');
        sb.append(", highRiskQ2c='").append(highRiskQ2c).append('\'');
        sb.append(", highRiskReason='").append(highRiskReason).append('\'');
        sb.append(", hasHighRiskQuestion='").append(hasHighRiskQuestion).append('\'');
        sb.append(", jurisdictionOther='").append(jurisdictionOther).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
