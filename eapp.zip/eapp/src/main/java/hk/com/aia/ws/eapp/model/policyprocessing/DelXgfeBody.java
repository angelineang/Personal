package hk.com.aia.ws.eapp.model.policyprocessing;

import com.fasterxml.jackson.annotation.JsonProperty;

@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2020-11-08T22:59:07.866Z")

public class DelXgfeBody {
    @JsonProperty("mode")
    private String mode = "D";

    @JsonProperty("policyNo")
    private String policyNo = null;

    public DelXgfeBody(String policyNo) {
        this.policyNo = policyNo;
    }

    @Override
    public String toString() {
        return "{\"mode\":\"" + mode + "\",\"policyNo\":\"" + policyNo + "\"}";
    }
}
