package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import hk.com.aia.ws.eapp.util.ConversionHandler;
import lombok.Data;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Data
@Table(name = "T_SQSQUOTATION")
@EntityListeners(AuditingEntityListener.class)
public class TSqsQuotation {

    @Column(name = "SQSQUOTATIONID", length = 60)
    @Id
    private String sqsQuotationId;

    @Column(name = "AGENTCODE", length = 10)
    private String agentCode;

    @Column(name = "ACCESSCODE", length = 30)
    private String accessCode;

    @Column(name = "MODULETYPE", length = 10)
    private String moduleType;

    @Column(name = "ORIGINALSQSQUOTATIONID", length = 60)
    private String originalSqsQuotationId;

    @Column(name = "POLICYNO", length = 12)
    private String policyNo;

    @Column(name = "SUBMITSQS")
    private Integer submitSqs;

    @Column(name = "OWNERID", length = 60)
    private String ownerId;

    @Column(name = "SQSVERSION", length = 10)
    private String sqsVersion;

    @Column(name = "PAYMENTFREQUENCY")
    private Integer paymentFrequency;

    @Column(name = "BACKDATE")
    @Temporal(TemporalType.DATE)
    private Date backDate;

    @Column(name = "ISBACKDATED")
    private Integer isBackDated;

    @Column(name = "STATUS")
    private Integer status;

    @Column(name = "TOTALSUMASSURED")
    private BigDecimal totalSumAssured;

    @Column(name = "TOTALINSTPREMIUM")
    private BigDecimal totalInstPremium;

    @Column(name = "ILLUSTRATIONDATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date illustrationDatetime;

    @Column(name = "COMPLETESTATUS")
    private Integer completeStatus;

    @Column(name = "CREATEDBY", length = 10, updatable = false)
    @CreatedBy
    private String createdBy;

    @Column(name = "UPDATEDBY", length = 10)
    @LastModifiedBy
    private String updatedBy;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "LASTUPDATEDATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    @LastModifiedDate
    private Date lastUpdateDateTime;

    @Column(name = "CURRENCYCODE", length = 255)
    private String currencyCode;


    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TSqsQuotation{");
        sb.append("sqsQuotationId='").append(sqsQuotationId).append('\'');
        sb.append(", agentCode='").append(agentCode).append('\'');
        sb.append(", accessCode='").append(accessCode).append('\'');
        sb.append(", moduleType='").append(moduleType).append('\'');
        sb.append(", originalSqsQuotationId='").append(originalSqsQuotationId).append('\'');
        sb.append(", policyNo='").append(ConversionHandler.mask(policyNo)).append('\'');
        sb.append(", submitSqs=").append(submitSqs);
        sb.append(", ownerId='").append(ownerId).append('\'');
        sb.append(", sqsVersion='").append(sqsVersion).append('\'');
        sb.append(", paymentFrequency=").append(paymentFrequency);
        sb.append(", backDate=").append(backDate);
        sb.append(", isBackDated=").append(isBackDated);
        sb.append(", status=").append(status);
        sb.append(", totalSumAssured=").append(totalSumAssured);
        sb.append(", totalInstPremium=").append(totalInstPremium);
        sb.append(", illustrationDatetime=").append(illustrationDatetime);
        sb.append(", completeStatus=").append(completeStatus);
        sb.append(", createdBy='").append(createdBy).append('\'');
        sb.append(", updatedBy='").append(updatedBy).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", lastUpdateDateTime=").append(lastUpdateDateTime);
        sb.append(", currencyCode='").append(currencyCode).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
