package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import hk.com.aia.ws.eapp.annotation.DataTruncation;
import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "T_EAppCPD")
public class TEappCpd {

    @Column(name = "eAppCPDID", length = 60)
    @Id
    private String eappCPDId;

    @Column(name = "eAppID", length = 60)
    private String eappId;

    @Column(name = "q2aLoss", length = 9)
    private BigDecimal q2aLoss;

    @Column(name = "q2aReason")
    private String q2aReason;

    @Column(name = "q2bOption", length = 1)
    private String q2bOption;

    @Column(name = "q2bReason")
    private String q2bReason;

    @Column(name = "q2cYear", length = 80)
    private String q2cYear;

    @Column(name = "q2cExistCurrency", length = 5)
    private String q2cExistCurrency;

    @Column(name = "q2cNewCurrency", length = 5)
    private String q2cNewCurrency;

    @Column(name = "q2cNewValue")
    private BigDecimal q2cNewValue;

    @Column(name = "q2cExistValue")
    private BigDecimal q2cExistValue;

    @Column(name = "q3aOption", length = 1)
    private String q3aOption;

    @Column(name = "q3bOption", length = 1)
    private String q3bOption;

    @Column(name = "q3cOption", length = 1)
    private String q3cOption;

    @Column(name = "q3dOption", length = 1)
    private String q3dOption;

    @Column(name = "q5aReason")
    private String q5aReason;

    @Column(name = "q5bReason")
    private String q5bReason;

    @Column(name = "q5cOption")
    @DataTruncation(max = 1, validateByte = true, log = true)
    private String q5cOption;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "LASTUPDATEDATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    @LastModifiedDate
    private Date lastUpdateDateTime;

    @Column(name = "MACAUQ2REASON", length = 800)
    private String macauq2Reason;

    @Column(name = "MACAUQ3REASON", length = 800)
    private String macauq3Reason;

    @Column(name = "MACAUQ4REASON", length = 800)
    private String macauq4Reason;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TEappCpd{");
        sb.append("eappCPDId='").append(eappCPDId).append('\'');
        sb.append(", eappId='").append(eappId).append('\'');
        sb.append(", q2aLoss=").append(q2aLoss);
        sb.append(", q2aReason='").append(q2aReason).append('\'');
        sb.append(", q2bOption='").append(q2bOption).append('\'');
        sb.append(", q2bReason='").append(q2bReason).append('\'');
        sb.append(", q2cYear='").append(q2cYear).append('\'');
        sb.append(", q2cExistCurrency='").append(q2cExistCurrency).append('\'');
        sb.append(", q2cNewCurrency='").append(q2cNewCurrency).append('\'');
        sb.append(", q2cNewValue=").append(q2cNewValue);
        sb.append(", q2cExistValue=").append(q2cExistValue);
        sb.append(", q3aOption='").append(q3aOption).append('\'');
        sb.append(", q3bOption='").append(q3bOption).append('\'');
        sb.append(", q3cOption='").append(q3cOption).append('\'');
        sb.append(", q3dOption='").append(q3dOption).append('\'');
        sb.append(", q5aReason='").append(q5aReason).append('\'');
        sb.append(", q5bReason='").append(q5bReason).append('\'');
        sb.append(", q5cOption='").append(q5cOption).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", lastUpdateDateTime=").append(lastUpdateDateTime);
        sb.append(", macauq2Reason='").append(macauq2Reason).append('\'');
        sb.append(", macauq3Reason='").append(macauq3Reason).append('\'');
        sb.append(", macauq4Reason='").append(macauq4Reason).append('\'');
        sb.append('}');
        return sb.toString();
    }
}


