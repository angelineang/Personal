package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@ApiModel(value = "Flow Result Model")
@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class FlowResult extends Payload{

    @ApiModelProperty(value = "Is Cloud indicator", example = "Y", allowableValues = "Y,N")
    @JsonProperty("is_cloud")
    private String isCloud;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("FlowResult{");
        sb.append("isCloud='").append(isCloud).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
