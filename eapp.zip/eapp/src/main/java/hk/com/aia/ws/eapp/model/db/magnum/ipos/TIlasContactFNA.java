package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import lombok.Data;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "T_ILASCONTACTFNA")
public class TIlasContactFNA {

    @Column(name = "CONTACTFNAID", length = 60)
    @Id
    private String contactFnaId;

    @Column(name = "CONTACTID", length = 60)
    private String contactId;

    @Column(name = "DEPENDENTNUMBER")
    private Integer dependentNumber;

    @Column(name = "EDUCATIONLV", length = 20)
    private String educationlv;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @LastModifiedDate
    private Date createdDateTime;

    @Column(name = "LIQUIDASSETS", length = 9)
    private BigDecimal liquidAssets;

    @Column(name = "RETIREMENT_AGE", length = 10)
    private String retirementAge;

    @Column(name = "LQDASSERT_RETIRE", length = 60)
    private String lqdassertRetire;

    @Column(name = "MONINCOME_RETIRE", length = 60)
    private String monincomeRetire;

    @Column(name = "INCOME_PERCENT", length = 10)
    private String incomePercent;

    @Column(name = "ASSERT_PERCENT", length = 10)
    private String assertPercent;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TIlasContactFNA{");
        sb.append("contactFnaId='").append(contactFnaId).append('\'');
        sb.append(", contactId='").append(contactId).append('\'');
        sb.append(", dependentNumber=").append(dependentNumber);
        sb.append(", educationlv='").append(educationlv).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", liquidAssets=").append(liquidAssets);
        sb.append(", retirementAge='").append(retirementAge).append('\'');
        sb.append(", lqdassertRetire='").append(lqdassertRetire).append('\'');
        sb.append(", monincomeRetire='").append(monincomeRetire).append('\'');
        sb.append(", incomePercent='").append(incomePercent).append('\'');
        sb.append(", assertPercent='").append(assertPercent).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
