package hk.com.aia.ws.eapp.model.dto;

import hk.com.aia.ws.eapp.util.ConversionHandler;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ReturnPolicyDto {

    private String policyNo;
    private String type;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("ReturnPolicyDto{");
        sb.append("policyNo='").append(ConversionHandler.mask(policyNo)).append('\'');
        sb.append(", type='").append(type).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
