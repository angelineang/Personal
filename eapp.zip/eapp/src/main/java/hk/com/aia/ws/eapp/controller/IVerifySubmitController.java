package hk.com.aia.ws.eapp.controller;

import static hk.com.aia.ws.eapp.constant.Constants.RETURN_CODE_1;

import java.time.Duration;
import java.time.LocalDateTime;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import hk.com.aia.ws.eapp.constant.Constants;
import hk.com.aia.ws.eapp.constant.Constants.APIFunction;
import hk.com.aia.ws.eapp.constant.Constants.APIPath;
import hk.com.aia.ws.eapp.model.base.CheckPRCIdentity;
import hk.com.aia.ws.eapp.model.base.CustomResponseStatus;
import hk.com.aia.ws.eapp.model.base.IVerifyDocSubmitRequest;
import hk.com.aia.ws.eapp.model.base.Payload;
import hk.com.aia.ws.eapp.model.base.ResultMessage;
import hk.com.aia.ws.eapp.model.base.SearchPRCIdentity;
import hk.com.aia.ws.eapp.model.dto.ResultDto;
import hk.com.aia.ws.eapp.model.log.TranKeys;
import hk.com.aia.ws.eapp.model.request.IVerifyRequest;
import hk.com.aia.ws.eapp.model.request.Request;
import hk.com.aia.ws.eapp.model.response.Response;
import hk.com.aia.ws.eapp.model.response.error.GatewayError400;
import hk.com.aia.ws.eapp.model.response.error.GatewayError401;
import hk.com.aia.ws.eapp.model.response.error.InternalError500;
import hk.com.aia.ws.eapp.service.IVerifyService;
import hk.com.aia.ws.eapp.service.LogService;
import hk.com.aia.ws.eapp.service.PRCIdentityService;
import hk.com.aia.ws.eapp.service.PayloadRequestService;
import hk.com.aia.ws.eapp.service.jwt.JwtService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/policies")
@Api(value = "IVerify Services", tags = {"API(s) for iverify services"})
public class IVerifySubmitController {

    @Autowired
    private IVerifyService iverifyService;

    @Autowired
    private PRCIdentityService prcIdentityService;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private LogService logService;
    
    @Autowired
    private PayloadRequestService payloadRequestService;
    
    
    @ApiOperation(value = "To rematch and release i-verify submission process.")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "IVerify successfully rematched."),
            @ApiResponse(code = 400, message = "Bad Request", response = GatewayError400.class),
            @ApiResponse(code = 401, message = "Unauthorized", response = GatewayError401.class),
            @ApiResponse(code = 404, message = "Invalid request.", response = Response.class),
            @ApiResponse(code = 500, message = "Internal Server Error", response = InternalError500.class)
    })
    @PostMapping(value = "/rematch-iverify", produces = MediaType.APPLICATION_JSON_VALUE)
    public Response<Payload> getIVerifySubmit(
            @ApiParam(value = "Local business unit.    | Valid Values |   | ----------   |   | HK, TH, SG   | ", required = true)
            @RequestHeader(value = Constants.RequestHeader.AIA_LBU, required = true) String xAiaLbu,
            @ApiParam(value = "Unique id for the request for tracking purposes.        ", required = true)
            @RequestHeader(value = Constants.RequestHeader.REQUEST_ID, required = true) String xAiaRequestId,
            @ApiParam(value = "Target environment of the request. Note that this header is required only when accessing non-production environments.    | Valid Values       |   | ------------------ |   | qa1, qa2, qa3, qa4 |        ")
            @RequestHeader(value = Constants.RequestHeader.AIA_ENV, required = false) String xAiaEnv,
            @ApiParam(value = "JWT Token for the request to verify Agent Authorization")
            @RequestHeader(value = Constants.RequestHeader.TOKEN_AGENT, required = false) String xAiaTokenAgent,
            @ApiParam(value = "Trace Id for EFK Logging")
            @RequestHeader(value = Constants.RequestHeader.TRACE_ID, required = false) String xAiaHkTraceId,
            @ApiParam(value = "Context Id for EFK Logging")
            @RequestHeader(value = Constants.RequestHeader.CONTEXT_ID, required = true) String xAiaHkContextId,
            @ApiParam(value = "IVerify Submit Document Request", required = true)
            @Valid @RequestBody Request<IVerifyDocSubmitRequest> request
    ) {
    	
    	logService.logTranKey(new TranKeys(request.getData().getPolicyNo(), "E", "",request.getData().getIVerifyId(),request.getAppId(),APIFunction.EAPP_SUBMIT_REMATCH_IVERIFY));
    	logService.logStartWorkingIntegration( APIPath.EAPP_SUBMIT_REMATCH_IVERIFY );
    	LocalDateTime start = LocalDateTime.now();
    	payloadRequestService.saveRequestJson(request.getData().getPolicyNo(), "RM-IVER-C", request,request.getData().getIVerifyId());
        
    	
        final IVerifyDocSubmitRequest iVerifyDocSubmitRequest = request.getData();
        final Response<Payload> payload = new Response<>();

        final ResultDto<Object> result = iverifyService.getIVerify(iVerifyDocSubmitRequest);

        payload.setTransId(request.getTransId());
        payload.setStatus(CustomResponseStatus.SUCCESS.getDescription());
        payload.getResultMessages().add(new ResultMessage(result.getReturnCode(),
                result.getReturnMessage()));


		payloadRequestService.saveRequestJson(request.getData().getPolicyNo(), "RM-IVER-R",payload, request.getData().getIVerifyId());
		 
    	LocalDateTime end =LocalDateTime.now() ;
    	Duration duration = Duration.between( start,end );
    	logService.logEndWorkingSuccessIntegration( APIPath.EAPP_SUBMIT_REMATCH_IVERIFY,  duration.toMillis());
        
        
        
        return payload;
    }

    @ApiOperation(value = "To submit People Republic China (PRC) identity related documents for i-verify process.")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "IVerify successfully inserted."),
            @ApiResponse(code = 400, message = "Bad Request", response = GatewayError400.class),
            @ApiResponse(code = 401, message = "Unauthorized", response = GatewayError401.class),
            @ApiResponse(code = 404, message = "Invalid request.", response = Response.class),
            @ApiResponse(code = 500, message = "Internal Server Error", response = InternalError500.class)
    })
    @PostMapping(value = "/submit-iverify", produces = MediaType.APPLICATION_JSON_VALUE)
    public Response<Payload> getIVerify(
            @ApiParam(value = "Local business unit.    | Valid Values |   | ----------   |   | HK, TH, SG   | ", required = true)
            @RequestHeader(value = Constants.RequestHeader.AIA_LBU, required = true) String xAiaLbu,
            @ApiParam(value = "Unique id for the request for tracking purposes.        ", required = true)
            @RequestHeader(value = Constants.RequestHeader.REQUEST_ID, required = true) String xAiaRequestId,
            @ApiParam(value = "Target environment of the request. Note that this header is required only when accessing non-production environments.    | Valid Values       |   | ------------------ |   | qa1, qa2, qa3, qa4 |        ")
            @RequestHeader(value = Constants.RequestHeader.AIA_ENV, required = false) String xAiaEnv,
            @ApiParam(value = "JWT Token for the request to verify Agent Authorization")
            @RequestHeader(value = Constants.RequestHeader.TOKEN_AGENT, required = false) String xAiaTokenAgent,
            @ApiParam(value = "Trace Id for EFK Logging")
            @RequestHeader(value = Constants.RequestHeader.TRACE_ID, required = false) String xAiaHkTraceId,
            @ApiParam(value = "Context Id for EFK Logging")
            @RequestHeader(value = Constants.RequestHeader.CONTEXT_ID, required = true) String xAiaHkContextId,
            @ApiParam(value = "IVerify Request", required = true)
            @Valid @RequestBody Request<IVerifyRequest> request) {

        final IVerifyRequest iverifyRequest = request.getData();
        final Response<Payload> payload = new Response<>();
        
    	 
        String iVerifyNo = iverifyRequest.getTPrcDocDetailDto().get(0).getIverifyId();
		logService.logTranKey(new TranKeys("", "E", "",iVerifyNo,request.getAppId(),APIFunction.EAPP_SUBMIT_IVERIFY));
    	logService.logStartWorkingIntegration( APIPath.EAPP_SUBMIT_IVERIFY );
    	LocalDateTime start = LocalDateTime.now();
    	payloadRequestService.saveRequestJson("", "S-IVER-C", request,iVerifyNo);
        
        
        
      
        iverifyService.submitIverify(iverifyRequest);

        payload.setTransId(request.getTransId());
        payload.setStatus(CustomResponseStatus.SUCCESS.getDescription());

        
		payloadRequestService.saveRequestJson("", "S-IVER-R",payload, iVerifyNo);
		 
    	LocalDateTime end =LocalDateTime.now() ;
    	Duration duration = Duration.between( start,end );
    	logService.logEndWorkingSuccessIntegration( APIPath.EAPP_SUBMIT_IVERIFY,  duration.toMillis());
        
        
        return payload;

    }

    @ApiOperation("To check PRC i-verify submission process status.")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Return Prc."),
            @ApiResponse(code = 400, message = "Bad Request", response = GatewayError400.class),
            @ApiResponse(code = 401, message = "Unauthorized", response = GatewayError401.class),
            @ApiResponse(code = 404, message = "Invalid request.", response = Response.class),
            @ApiResponse(code = 500, message = "Internal Server Error", response = InternalError500.class)
    })
    @PostMapping(value = "/check-iverify", produces = MediaType.APPLICATION_JSON_VALUE)
    public Response<Payload> checkPRCIdentity(
            @ApiParam(value = "Local business unit.    | Valid Values |   | ----------   |   | HK, TH, SG   | ", required = true)
            @RequestHeader(value = Constants.RequestHeader.AIA_LBU, required = true) String xAiaLbu,
            @ApiParam(value = "Unique id for the request for tracking purposes.        ", required = true)
            @RequestHeader(value = Constants.RequestHeader.REQUEST_ID, required = true) String xAiaRequestId,
            @ApiParam(value = "Target environment of the request. Note that this header is required only when accessing non-production environments.    | Valid Values       |   | ------------------ |   | qa1, qa2, qa3, qa4 |        ")
            @RequestHeader(value = Constants.RequestHeader.AIA_ENV, required = false) String xAiaEnv,
            @ApiParam(value = "JWT Token for the request to verify Agent Authorization")
            @RequestHeader(value = Constants.RequestHeader.TOKEN_AGENT, required = false) String xAiaTokenAgent,
            @ApiParam(value = "Trace Id for EFK Logging")
            @RequestHeader(value = Constants.RequestHeader.TRACE_ID, required = false) String xAiaHkTraceId,
            @ApiParam(value = "Context Id for EFK Logging")
            @RequestHeader(value = Constants.RequestHeader.CONTEXT_ID, required = true) String xAiaHkContextId,
            @ApiParam(value = "Check with Prc Identity", required = true)
            @Valid @RequestBody Request<CheckPRCIdentity> request) {


		logService.logTranKey(new TranKeys(request.getData().getPolNo(), "E", "","",request.getAppId(),APIFunction.EAPP_SUBMIT_CHECK_IVERIFY));
    	logService.logStartWorkingIntegration( APIPath.EAPP_SUBMIT_CHECK_IVERIFY );
    	LocalDateTime start = LocalDateTime.now();
    	payloadRequestService.saveRequestJson(request.getData().getPolNo(), "C-IVER-C", request,"");
        
    	
        Response<Payload> responsePayload = new Response<>();

        ResultDto<ResultMessage> result = prcIdentityService.checkPRCIdentity(request.getData());

        responsePayload.setTransId(request.getTransId());

        if (RETURN_CODE_1.equals(result.getReturnCode())) {
            responsePayload.setStatus(CustomResponseStatus.SUCCESS.getDescription());
        } else {
            responsePayload.setStatus(CustomResponseStatus.ERROR.getDescription());
        }

        responsePayload.getResultMessages().add(new ResultMessage(result.getReturnCode(),
                result.getReturnMessage()));

        responsePayload.setData(result.getData());
        
		payloadRequestService.saveRequestJson(request.getData().getPolNo(), "C-IVER-R",responsePayload, "");
		 
    	LocalDateTime end =LocalDateTime.now() ;
    	Duration duration = Duration.between( start,end );
    	logService.logEndWorkingSuccessIntegration( APIPath.EAPP_SUBMIT_CHECK_IVERIFY,  duration.toMillis());
        
        
        
        return responsePayload;
    }

    @ApiOperation("To match and release the PRC i-verify submission process.")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Return Prc."),
            @ApiResponse(code = 400, message = "Bad Request", response = GatewayError400.class),
            @ApiResponse(code = 401, message = "Unauthorized", response = GatewayError401.class),
            @ApiResponse(code = 404, message = "Invalid request.", response = Response.class),
            @ApiResponse(code = 500, message = "Internal Server Error", response = InternalError500.class)
    })
    @PostMapping(value = "/match-iverify", produces = MediaType.APPLICATION_JSON_VALUE)
    public Response<Payload> searchPRCIdentityRecord(
            @ApiParam(value = "Local business unit.    | Valid Values |   | ----------   |   | HK, TH, SG   | ", required = true)
            @RequestHeader(value = Constants.RequestHeader.AIA_LBU, required = true) String xAiaLbu,
            @ApiParam(value = "Unique id for the request for tracking purposes.        ", required = true)
            @RequestHeader(value = Constants.RequestHeader.REQUEST_ID, required = true) String xAiaRequestId,
            @ApiParam(value = "Target environment of the request. Note that this header is required only when accessing non-production environments.    | Valid Values       |   | ------------------ |   | qa1, qa2, qa3, qa4 |        ")
            @RequestHeader(value = Constants.RequestHeader.AIA_ENV, required = false) String xAiaEnv,
            @ApiParam(value = "JWT Token for the request to verify Agent Authorization")
            @RequestHeader(value = Constants.RequestHeader.TOKEN_AGENT, required = false) String xAiaTokenAgent,
            @ApiParam(value = "Trace Id for EFK Logging")
            @RequestHeader(value = Constants.RequestHeader.TRACE_ID, required = false) String xAiaHkTraceId,
            @ApiParam(value = "Context Id for EFK Logging")
            @RequestHeader(value = Constants.RequestHeader.CONTEXT_ID, required = true) String xAiaHkContextId,
            @ApiParam(value = "Match with Prc Identity", required = true)
            @Valid @RequestBody Request<SearchPRCIdentity> request) {


		logService.logTranKey(new TranKeys(request.getData().getPolNo(), "E", "",request.getData().getIverifyId(),request.getAppId(),APIFunction.EAPP_SUBMIT_MATCH_IVERIFY));
    	logService.logStartWorkingIntegration( APIPath.EAPP_SUBMIT_MATCH_IVERIFY );
    	LocalDateTime start = LocalDateTime.now();
    	payloadRequestService.saveRequestJson(request.getData().getPolNo(), "M-IVER-C", request,request.getData().getIverifyId());
        
    	
        Response<Payload> responsePayload = new Response<>();

        ResultDto<ResultMessage> result = prcIdentityService.searchPRCIdentity(request.getData());

        responsePayload.setTransId(request.getTransId());

        if (RETURN_CODE_1.equals(result.getReturnCode())) {
            responsePayload.setStatus(CustomResponseStatus.SUCCESS.getDescription());
        } else {
            responsePayload.setStatus(CustomResponseStatus.ERROR.getDescription());
        }

        responsePayload.getResultMessages().add(new ResultMessage(result.getReturnCode(),
                result.getReturnMessage()));

        responsePayload.setData(result.getData());
		payloadRequestService.saveRequestJson(request.getData().getPolNo(), "M-IVER-R",responsePayload, request.getData().getIverifyId());
		 
    	LocalDateTime end =LocalDateTime.now() ;
    	Duration duration = Duration.between( start,end );
    	logService.logEndWorkingSuccessIntegration( APIPath.EAPP_SUBMIT_MATCH_IVERIFY,  duration.toMillis());
        
        return responsePayload;
    }
}
