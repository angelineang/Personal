package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@ApiModel(value = "Question Model")
@Data
public class Question {

    @ApiModelProperty(value = "Question Id")
    @JsonProperty("qid")
    @NotBlank
    @Size(max = 20)
    private String qid;

    @ApiModelProperty(value = "Question")
    @JsonProperty("question")
    @NotBlank
    @Size(max = 255)
    private String question;

    @ApiModelProperty(value = "Answer")
    @JsonProperty("answer")
    @NotBlank
    @Size(max = 50)
    private String answer;

    @ApiModelProperty(value = "Others")
    @JsonProperty("others")
    @Size(max = 1000)
    private String others;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Question{");
        sb.append("qid='").append(qid).append('\'');
        sb.append(", question='").append(question).append('\'');
        sb.append(", answer='").append(answer).append('\'');
        sb.append(", others='").append(others).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
