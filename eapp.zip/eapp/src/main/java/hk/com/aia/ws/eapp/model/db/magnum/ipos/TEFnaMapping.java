package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import hk.com.aia.ws.eapp.util.ConversionHandler;
import lombok.Data;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "T_EfnaMapping")
public class TEFnaMapping {

    @Column(name = "id", length = 60)
    @Id
    private String id;

    @Column(name = "efna_id", length = 60)
    private String efnaId;

    @Column(name = "policyNo", length = 50)
    private String policyNo;

    @Column(name = "eappID", length = 60)
    private String eappID;

    @Column(name = "createby", length = 10, updatable = false)
    @CreatedBy
    private String createBy;

    @Column(name = "createddatetime", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "submittingCompany", length = 30)
    private String submittingCompany;

    @Column(name = "fnaReferenceId", length = 60)
    private String fnaReferenceId;

    @Column(name = "companyCertificateNo", length = 60)
    private String companyCertificateNo;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TEFnaMapping{");
        sb.append("id='").append(id).append('\'');
        sb.append(", efnaId='").append(efnaId).append('\'');
        sb.append(", policyNo='").append(ConversionHandler.mask(policyNo)).append('\'');
        sb.append(", eappID='").append(eappID).append('\'');
        sb.append(", createBy='").append(createBy).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", submittingCompany='").append(submittingCompany).append('\'');
        sb.append(", fnaReferenceId='").append(fnaReferenceId).append('\'');
        sb.append(", companyCertificateNo='").append(companyCertificateNo).append('\'');
        sb.append('}');
        return sb.toString();
    }
}