package hk.com.aia.ws.eapp.exception;

import hk.com.aia.ws.eapp.model.dto.SubmissionActivity;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
@AllArgsConstructor
public class SubmissionErrorResultException extends RuntimeException {

    private static final long serialVersionUID = 1L;
    private String code;
    private String message;
    private transient SubmissionActivity submissionActivity;

}
