package hk.com.aia.ws.eapp.mapper;

import hk.com.aia.ws.eapp.model.db.magnum.ipos.TSimulation;
import hk.com.aia.ws.eapp.model.request.ipos.TSimulationDto;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

@Mapper
public interface TSimulationMapper {

    TSimulationMapper MAPPER = Mappers.getMapper(TSimulationMapper.class);
    
    @Mappings({
        @Mapping(target = "createdBy", ignore = true),
        @Mapping(target = "createdDateTime", ignore = true),
        @Mapping(target = "updatedBy", ignore = true),
        @Mapping(target = "lastUpdateDateTime", ignore = true)})
    List<TSimulation> mapToTSimulationList(List<TSimulationDto> tSimulationDto);
}
