package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;

import javax.validation.constraints.NotBlank;

@ApiModel(value = "Client Address Model")
@Getter
@Setter
public class Address {

    // API Model Property - copied from old code

    @ApiModelProperty(value = "Client Type - I = Insured, O = Owner, IO = Insured / Owner (tbl_ms_pol_addr.client_type)", example = "O", allowableValues = "I,O,IO")
    @JsonProperty("client_type")
    @NotBlank
    private String clientType;

    @ApiModelProperty(value = "Address Tu[e = C = Correspondence Address, R = Residential Address, P = Permanent Address, B = Business Address, V = Vitality Address (tbl_ms_pol_addr.addr_type)", example = "C", allowableValues = "C,R,P,B,V")
    @JsonProperty("addr_type")
    @NotBlank
    private String addrType;

    @ApiModelProperty(value = "Address Language - E = English, C = Chinese (tbl_ms_pol_addr.addr_language)", example = "C", allowableValues = "C,E")
    @JsonProperty("addr_language")
    private String addrLanguage;

    @ApiModelProperty(value = "Address same as Correspondence - Y = Yes, N = No  (tbl_ms_pol_addr.same_as_corr)", example = "Y", allowableValues = "Y,N")
    @JsonProperty("same_as_corr")
    private String sameAsCorr;

    @ApiModelProperty(value = "Address Line 1 (tbl_ms_pol_addr.addr_1)")
    @JsonProperty("addr_1")
    private String addr1;

    @ApiModelProperty(value = "Address Line 2 (tbl_ms_pol_addr.addr_2)")
    @JsonProperty("addr_2")
    private String addr2;

    @ApiModelProperty(value = "Address Line 3 (tbl_ms_pol_addr.addr_3)")
    @JsonProperty("addr_3")
    private String addr3;

    @ApiModelProperty(value = "Address Line 4 (tbl_ms_pol_addr.addr_4)")
    @JsonProperty("addr_4")
    private String addr4;

    @ApiModelProperty(value = "Address Line 5 (tbl_ms_pol_addr.addr_5)")
    @JsonProperty("addr_5")
    private String addr5;

    @ApiModelProperty(value = "Country Code - 22 = Hong Kong, 23 = NT / Kowloon , etc (tbl_ms_pol_addr.country_code)", example = "\"22\"")
    @JsonProperty("country_code")
    private String countryCode;

    @ApiModelProperty(value = "Country Name - HK = Hong Kong, KLN = Kowloon, and etc (tbl_ms_pol_addr.country_name)", example = "HK")
    @JsonProperty("country_name")
    private String countryName;

    @ApiModelProperty(value = "Correspondence Country Name (tbl_ms_pol_addr.crs_country_name)", example = "MAC")
    @JsonProperty("crs_country_name")
    private String crsCountryName;

    @ApiModelProperty(value = "Address Proof - Y = Received, N = Not Received, W - Waived  (tbl_ms_pol_addr.addr_proof)", example = "Y", allowableValues = "N,Y,W")
    @JsonProperty("addr_proof")
    private String addrProof;

    //Import from old code, the custom getters

    public String getClientType() {
        return  StringUtils.isBlank(clientType) ? "O" : clientType;
    }

    public String getAddrType() {
        return StringUtils.isBlank(addrType) ? "C" : addrType;
    }

    public String getSameAsCorr() {
        return StringUtils.isBlank(sameAsCorr) ? "N" : sameAsCorr;
    }

    public String getAddrProof() {
        return StringUtils.isBlank(addrProof) ? "N" : addrProof;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Address{");
        sb.append("clientType='").append(clientType).append('\'');
        sb.append(", addrType='").append(addrType).append('\'');
        sb.append(", addrLanguage='").append(addrLanguage).append('\'');
        sb.append(", sameAsCorr='").append(sameAsCorr).append('\'');
        sb.append(", addr1='").append(addr1).append('\'');
        sb.append(", addr2='").append(addr2).append('\'');
        sb.append(", addr3='").append(addr3).append('\'');
        sb.append(", addr4='").append(addr4).append('\'');
        sb.append(", addr5='").append(addr5).append('\'');
        sb.append(", countryCode='").append(countryCode).append('\'');
        sb.append(", countryName='").append(countryName).append('\'');
        sb.append(", crsCountryName='").append(crsCountryName).append('\'');
        sb.append(", addrProof='").append(addrProof).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
