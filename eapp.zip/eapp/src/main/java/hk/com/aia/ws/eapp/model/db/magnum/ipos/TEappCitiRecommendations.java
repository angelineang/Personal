package hk.com.aia.ws.eapp.model.db.magnum.ipos;


import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.math.BigDecimal;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "T_EAPPCITIRECOMMENDATIONS")
public class TEappCitiRecommendations {

    @Column(name = "CITIRECID", length = 60)
    @Id
    private String citiRecId;

    @Column(name = "SQSQUOTATIONID", length = 60)
    private String sqsQuotationId;

    @Column(name = "PLANCODE", length = 10)
    private String planCode;

    @Column(name = "EAPPID", length = 60)
    private String eappId;

    @Column(name = "MODULE", length = 10)
    private String module;

    @Column(name = "FNAID", length = 60)
    private String fnaId;

    @Column(name = "SELECTRECOMMEND", length = 5)
    private String selectRecommend;

    @Column(name = "PRODUCTNAME", length = 250)
    private String productName;

    @Column(name = "PAYMENTTYPE", length = 10)
    private String paymentType;

    @Column(name = "CURRENCY", length = 10)
    private String currency;

    @Column(name = "PAYMENTTERM")
    private Integer paymentTerm;

    @Column(name = "POLICYTENOR")
    private Integer policyTenor;

    @Column(name = "SUMASSURED")
    private BigDecimal sumAssured;

    @Column(name = "BASICAMOUNT")
    private BigDecimal basicAmount;

    @Column(name = "FXRATE")
    private BigDecimal fxRate;

    @Column(name = "UNDERWRITER", length = 200)
    private String underWriter;

    @Column(name = "TOTALAMOUT")
    private BigDecimal totalAmout;

    @Column(name = "RIDERS", length = 400)
    private String riders;

    @Column(name = "RESON", length = 400)
    private String reson;

    @Column(name = "OTHERDETAIL", length = 1250)
    private String otherDetail;

    @Column(name = "RECOMMENDATION", length = 100)
    private String recommendation;

    @Column(name = "RECOMMENDREASON")
    private String recommendreason;

    @Column(name = "PGSPRODUCTKEY", length = 100)
    private String pgsProductKey;

    @Column(name = "IsSelectCurApplication", length = 5)
    private String IsSelectCurApplication;

    @Column(name = "RIDERPGSPRODUCTKEY", length = 400)
    private String riderPgsProductKey;

    @Column(name = "RIDERRENEWALYEAR", length = 100)
    private String riderRenewalYear;

    @Column(name = "RIDERPREMIUM", length = 100)
    private String riderPremium;

    @Column(name = "LIFEPROTECTIONLEVEL", length = 50)
    private String lifeProtectionLevel;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TEappCitiRecommendations{");
        sb.append("citiRecId='").append(citiRecId).append('\'');
        sb.append(", sqsQuotationId='").append(sqsQuotationId).append('\'');
        sb.append(", planCode='").append(planCode).append('\'');
        sb.append(", eappId='").append(eappId).append('\'');
        sb.append(", module='").append(module).append('\'');
        sb.append(", fnaId='").append(fnaId).append('\'');
        sb.append(", selectRecommend='").append(selectRecommend).append('\'');
        sb.append(", productName='").append(productName).append('\'');
        sb.append(", paymentType='").append(paymentType).append('\'');
        sb.append(", currency='").append(currency).append('\'');
        sb.append(", paymentTerm=").append(paymentTerm);
        sb.append(", policyTenor=").append(policyTenor);
        sb.append(", sumAssured=").append(sumAssured);
        sb.append(", basicAmount=").append(basicAmount);
        sb.append(", fxRate=").append(fxRate);
        sb.append(", underWriter='").append(underWriter).append('\'');
        sb.append(", totalAmout=").append(totalAmout);
        sb.append(", riders='").append(riders).append('\'');
        sb.append(", reson='").append(reson).append('\'');
        sb.append(", otherDetail='").append(otherDetail).append('\'');
        sb.append(", recommendation='").append(recommendation).append('\'');
        sb.append(", recommendreason='").append(recommendreason).append('\'');
        sb.append(", pgsProductKey='").append(pgsProductKey).append('\'');
        sb.append(", IsSelectCurApplication='").append(IsSelectCurApplication).append('\'');
        sb.append(", riderPgsProductKey='").append(riderPgsProductKey).append('\'');
        sb.append(", riderRenewalYear='").append(riderRenewalYear).append('\'');
        sb.append(", riderPremium='").append(riderPremium).append('\'');
        sb.append(", lifeProtectionLevel='").append(lifeProtectionLevel).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
