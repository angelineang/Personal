package hk.com.aia.ws.eapp.model.base.calculator;

import java.util.List;

import javax.xml.datatype.XMLGregorianCalendar;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@EqualsAndHashCode(callSuper = false)
public class AlphaSearchResultCustomerBean {

    protected List<String> aliasIdList;
    protected XMLGregorianCalendar dob;
    protected String firstName;
    protected List<AlphaSearchResultIDBean> idList;
    protected String lastName;
    protected String middleName;
    protected List<AlphaSearchResultPolicyBean> policyList;
    protected String priAlphaID;
    protected String sex;
    protected String score;

}
