package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import hk.com.aia.ws.eapp.annotation.DataTruncation;
import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@Table(name = "T_SOWDAddress")
@EntityListeners(AuditingEntityListener.class)
public class TSowdAddress {

    @Column(name = "SOWDAddressID", length = 60)
    @Id
    private String sowdAddressId;

    @Column(name = "EAPPID", length = 60)
    private String eappId;

    @Column(name = "postalcode", length = 25)
    private String postalCode;

    @Column(name = "roomno")
    @DataTruncation(max = 60, validateByte = true, log = true)
    private String roomNo;

    @Column(name = "floor", length = 20)
    private String floor;

    @Column(name = "block")
    @DataTruncation(max = 60, validateByte = true, log = true)
    private String block;

    @Column(name = "building", length = 500)
    private String building;

    @Column(name = "streetline1", length = 500)
    private String streetLine1;

    @Column(name = "streetline2", length = 500)
    private String streetLine2;

    @Column(name = "city", length = 500)
    private String city;

    @Column(name = "province")
    @DataTruncation(max = 500, validateByte = true, log = true)
    private String province;

    @Column(name = "countrycode", length = 100)
    private String countryCode;

    @Column(name = "sameas", length = 10)
    private String sameAs;

    @Column(name = "addresstype", length = 50)
    private String addressType;

    @Column(name = "estimate", length = 60)
    private String estimate;

    @Column(name = "inputlanguage", length = 10)
    private String inputLanguage;

    @Column(name = "isFirst", length = 10)
    private String isFirst;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "aValue", length = 50)
    private String aValue;

    @Column(name = "bValue", length = 50)
    private String bValue;

    @Column(name = "cValue", length = 50)
    private String cValue;

    @Column(name = "CONTACTID", length = 60)
    private String contactId;

    @Column(name = "indicator", length = 20)
    private String indicator;

    @Column(name = "district")
    @DataTruncation(max = 30, validateByte = true, log = true)
    private String district;

    @Column(name = "streets", length = 30)
    private String streets;

    @Column(name = "streetLine3", length = 300)
    private String streetLine3;

    @Column(name = "streetLine4", length = 300)
    private String streetLine4;

    @Column(name = "purchaseDate")
    @Temporal(TemporalType.DATE)
    private Date purchaseDate;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TSowdAddress{");
        sb.append("sowdAddressId='").append(sowdAddressId).append('\'');
        sb.append(", eappId='").append(eappId).append('\'');
        sb.append(", postalCode='").append(postalCode).append('\'');
        sb.append(", roomNo='").append(roomNo).append('\'');
        sb.append(", floor='").append(floor).append('\'');
        sb.append(", block='").append(block).append('\'');
        sb.append(", building='").append(building).append('\'');
        sb.append(", streetLine1='").append(streetLine1).append('\'');
        sb.append(", streetLine2='").append(streetLine2).append('\'');
        sb.append(", city='").append(city).append('\'');
        sb.append(", province='").append(province).append('\'');
        sb.append(", countryCode='").append(countryCode).append('\'');
        sb.append(", sameAs='").append(sameAs).append('\'');
        sb.append(", addressType='").append(addressType).append('\'');
        sb.append(", estimate='").append(estimate).append('\'');
        sb.append(", inputLanguage='").append(inputLanguage).append('\'');
        sb.append(", isFirst='").append(isFirst).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", aValue='").append(aValue).append('\'');
        sb.append(", bValue='").append(bValue).append('\'');
        sb.append(", cValue='").append(cValue).append('\'');
        sb.append(", contactId='").append(contactId).append('\'');
        sb.append(", indicator='").append(indicator).append('\'');
        sb.append(", district='").append(district).append('\'');
        sb.append(", streets='").append(streets).append('\'');
        sb.append(", streetLine3='").append(streetLine3).append('\'');
        sb.append(", streetLine4='").append(streetLine4).append('\'');
        sb.append(", purchaseDate=").append(purchaseDate);
        sb.append('}');
        return sb.toString();
    }
}

