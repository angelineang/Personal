package hk.com.aia.ws.eapp.model.request.ipos;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@ApiModel(value = "T_EAPPCITIREVIEWER Model")
@Data
@NoArgsConstructor
@AllArgsConstructor

public class TEappCitiReviewerDto {

	@ApiModelProperty(value = "citi Reviewer Id", required = true)
    @JsonProperty("citi_reviewer_id")
	@Size(max = 60)
	@NotBlank
    private String citiReviewerId;

    @JsonProperty("eapp_id")
    @Size(max = 60)
    private String eappId;

    @JsonProperty("module")
    @Size(max = 20)
    private String module;

	@JsonProperty("name")
	@Size(max = 100)
    private String name;

    @JsonProperty("name_other")
    @Size(max = 100)
    private String nameOther;

    @JsonProperty("registration_no")
    @Size(max = 60)
    private String registrationNo;

    @JsonProperty("soe_id")
    @Size(max = 60)
    private String soeId;

    @JsonProperty("relationship")
    @Size(max = 60)
    private String relationship;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TEappCitiReviewerDto{");
        sb.append("citiReviewerId='").append(citiReviewerId).append('\'');
        sb.append(", eappId='").append(eappId).append('\'');
        sb.append(", module='").append(module).append('\'');
        sb.append(", name='").append(ConversionHandler.mask(name)).append('\'');
        sb.append(", nameOther='").append(nameOther).append('\'');
        sb.append(", registrationNo='").append(ConversionHandler.mask(registrationNo)).append('\'');
        sb.append(", soeId='").append(soeId).append('\'');
        sb.append(", relationship='").append(relationship).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
