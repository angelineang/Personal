package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import lombok.Data;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "T_EAPPQINSURANCEHIS")
public class TEappQInsuranceHis {

    @Column(name = "EAPPQHINSURANCEHISID", length = 60)
    @Id
    private String eappQhInsuranceHisId;

    @Column(name = "EAPPQANSWERID", length = 60)
    private String eappQAnswerId;

    @Column(name = "FIELD1")
    private String field1;

    @Column(name = "FIELD2")
    private String field2;

    @Column(name = "FIELD3")
    private String field3;

    @Column(name = "FIELD4")
    private String field4;

    @Column(name = "FIELD5")
    private String field5;

    @Column(name = "FIELD6")
    private String field6;

    @Column(name = "FIELD7")
    private String field7;

    @Column(name = "FIELD8")
    private String field8;

    @Column(name = "FIELD9")
    private String field9;

    @Column(name = "FIELD10")
    private String field10;

    @Column(name = "FIELD11")
    private String field11;

    @Column(name = "FIELD12")
    private String field12;

    @Column(name = "FIELD13")
    private String field13;

    @Column(name = "FIELD14")
    private String field14;

    @Column(name = "FIELD15")
    private String field15;

    @Column(name = "FIELD16")
    private String field16;

    @Column(name = "FIELD17")
    private String field17;

    @Column(name = "FIELD18")
    private String field18;

    @Column(name = "FIELD19")
    private String field19;

    @Column(name = "FIELD20")
    private String field20;

    @Column(name = "FIELD21")
    private String field21;

    @Column(name = "FIELD22")
    private String field22;

    @Column(name = "FIELD23")
    private String field23;

    @Column(name = "FIELD24")
    private String field24;

    @Column(name = "FIELD25")
    private String field25;

    @Column(name = "FIELD26")
    private String field26;

    @Column(name = "FIELD27")
    private String field27;

    @Column(name = "FIELD28")
    private String field28;

    @Column(name = "FIELD29")
    private String field29;

    @Column(name = "FIELD30")
    private String field30;

    @Column(name = "FIELD31")
    private String field31;

    @Column(name = "CBXDURTREA", length = 10)
    private String cbxdurtrea;

    @Column(name = "CREATEDBY", length = 10, updatable = false)
    @CreatedBy
    private String createdBy;

    @Column(name = "UPDATEDBY", length = 10)
    @LastModifiedBy
    private String updatedBy;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "LASTUPDATEDATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    @LastModifiedDate
    private Date lastUpdateDateTime;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TEappQInsuranceHis{");
        sb.append("eappQhInsuranceHisId='").append(eappQhInsuranceHisId).append('\'');
        sb.append(", eappQAnswerId='").append(eappQAnswerId).append('\'');
        sb.append(", field1='").append(field1).append('\'');
        sb.append(", field2='").append(field2).append('\'');
        sb.append(", field3='").append(field3).append('\'');
        sb.append(", field4='").append(field4).append('\'');
        sb.append(", field5='").append(field5).append('\'');
        sb.append(", field6='").append(field6).append('\'');
        sb.append(", field7='").append(field7).append('\'');
        sb.append(", field8='").append(field8).append('\'');
        sb.append(", field9='").append(field9).append('\'');
        sb.append(", field10='").append(field10).append('\'');
        sb.append(", field11='").append(field11).append('\'');
        sb.append(", field12='").append(field12).append('\'');
        sb.append(", field13='").append(field13).append('\'');
        sb.append(", field14='").append(field14).append('\'');
        sb.append(", field15='").append(field15).append('\'');
        sb.append(", field16='").append(field16).append('\'');
        sb.append(", field17='").append(field17).append('\'');
        sb.append(", field18='").append(field18).append('\'');
        sb.append(", field19='").append(field19).append('\'');
        sb.append(", field20='").append(field20).append('\'');
        sb.append(", field21='").append(field21).append('\'');
        sb.append(", field22='").append(field22).append('\'');
        sb.append(", field23='").append(field23).append('\'');
        sb.append(", field24='").append(field24).append('\'');
        sb.append(", field25='").append(field25).append('\'');
        sb.append(", field26='").append(field26).append('\'');
        sb.append(", field27='").append(field27).append('\'');
        sb.append(", field28='").append(field28).append('\'');
        sb.append(", field29='").append(field29).append('\'');
        sb.append(", field30='").append(field30).append('\'');
        sb.append(", field31='").append(field31).append('\'');
        sb.append(", cbxdurtrea='").append(cbxdurtrea).append('\'');
        sb.append(", createdBy='").append(createdBy).append('\'');
        sb.append(", updatedBy='").append(updatedBy).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", lastUpdateDateTime=").append(lastUpdateDateTime);
        sb.append('}');
        return sb.toString();
    }
}
