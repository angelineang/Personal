package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;

@Entity
@Data
@Table(name = "T_CITIINSPRODUCTTYPE")
@EntityListeners(AuditingEntityListener.class)
public class TCitiInsProductType {

    @Column(name = "CITIINSPRODUCTTYPEID", length = 60)
    @Id
    private String citiInsProductTypeId;

    @Column(name = "FNAID", length = 60)
    private String fnaId;

    @Column(name = "PRODUCTTYPECHECK", length = 50)
    private String productTypeCheck;

    @Column(name = "OTHERTYPESPEC", length = 200)
    private String otherTypeSpec;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TCitiInsProductType{");
        sb.append("citiInsProductTypeId='").append(citiInsProductTypeId).append('\'');
        sb.append(", fnaId='").append(fnaId).append('\'');
        sb.append(", productTypeCheck='").append(productTypeCheck).append('\'');
        sb.append(", otherTypeSpec='").append(otherTypeSpec).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
