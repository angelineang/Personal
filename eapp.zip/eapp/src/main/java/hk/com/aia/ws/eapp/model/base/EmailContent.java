package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EmailContent {

    @JsonProperty("notify")
    private boolean notify = false;

    @JsonProperty("policy_no")
    private String policyNo;

    @JsonProperty("content")
    private StringBuffer content = new StringBuffer();

    @JsonProperty("recipients")
    private String recipients;

    @JsonProperty("subject")
    private String subject;

    @JsonProperty("header")
    private String header;

    @JsonProperty("footer")
    private String footer;
    
    @JsonProperty("submit_type")
    private String submitType;

    @JsonProperty("context_id")
    private String contextId;
    
    @JsonProperty("trace_id")
    private String traceId;
    
    @JsonProperty("eapp_id")
    private String eappId;
    
    
    public boolean isNotify() {
        return notify;
    }

    public void appendContent(int stage, String str) {
        this.content.append(getSubtitle(stage) + str);
    }

    public void appendContent(String str) {
        this.content.append(str);
    }

    // TODO Pulling message from properties
    public String getSubtitle(int stage) {
        String msg = "<br><br>";

        switch (stage) {
            case 1:
                msg += "Copy data from Staging to UI encounter error:<br>";
                break;
            case 2:
                msg += "Chinese conversion encounter error:<br>";
                break;
            case 3:
                msg += "Generating package expender encounter error:<br>";
                break;
            case 4:
                msg += "Alpha search web service encounter error:<br>";
                break;
            case 5:
                msg += "Event handler validation encounter error:<br>";
                break;
            case 6:
                msg += "LFCM uploader encounter error:<br>";
                break;
            case 7:
                msg += "Filter pending message encounter error:<br>";
                break;
            case 8:
                msg += "Check sync table encounter error:<br>";
                break;
            case 9:
                msg += "Client module encounter error:<br>";
                break;
            case 10:
                msg += "Update bill to date encounter error:<br>";
                break;
            case 11:
                msg += "Check validation encounter error:<br>";
                break;
            case 12:
                msg += "Insert eApp data encounter error:<br>";
                break;
            case 13:
                msg += "Time logger encounter error:<br>";
                break;
            case 14:
                msg += "Insert eApp polling encounter error:<br>";
                break;
            case 15:
                msg += "Vitality WS encounter error:<br>";
                break;
            case 16:
                msg += "NBCreator Alpha search process encounter error (caused by NBCreator SP - po_ipos_stage_upd_alpha_id):<br>";
                break;
            case 17:
                msg += "IPOS submission getting Documents from Blob storage encountered error:<br>";
                break;
            case 18:
                msg += "IPOS submission copy properties to entity encountered error:<br>";
                break;
            case 19:
                msg += "IPOS insert data into tables encountered error:<br>";
                break;
            case 20:
                msg += "Error response from XGFE-NB - Record submitted for retry: <br>";
            default:
                msg += "System encounter error:<br>";
                break;
        }
        return msg;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("EmailContent{");
        sb.append("notify=").append(notify);
        sb.append(", policyNo='").append(ConversionHandler.mask(policyNo)).append('\'');
        sb.append(", content=").append(content);
        sb.append(", recipients='").append(recipients).append('\'');
        sb.append(", subject='").append(subject).append('\'');
        sb.append(", header='").append(header).append('\'');
        sb.append(", footer='").append(footer).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
