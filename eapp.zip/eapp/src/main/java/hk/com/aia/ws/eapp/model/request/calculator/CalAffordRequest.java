package hk.com.aia.ws.eapp.model.request.calculator;

import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.annotation.AllowedValuesValidation;
import hk.com.aia.ws.eapp.model.base.Payload;
import hk.com.aia.ws.eapp.model.base.calculator.LoginUser;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import hk.com.aia.ws.eapp.util.RiskCalculatorUtils;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.math.BigDecimal;
import java.math.RoundingMode;

import static hk.com.aia.ws.eapp.constant.Constants.CalculatorConstants.DECIMAL_MODE;

@ApiModel(value = "Cal Afford Request Model")
@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class CalAffordRequest extends Payload {

    private static final BigDecimal rate = new BigDecimal("7.5");

    @ApiModelProperty(value = "", example = "en", required = true)
    @JsonProperty("locale")
    @AllowedValuesValidation(values = {"en", "cn"}, allowNull = false)
    private String locale;

    @JsonProperty("id_no")
    private String idNo;

    @JsonProperty("name")
    private String name;

    @JsonProperty("dob")
    private String dob;

    @JsonProperty("sex")
    private String sex;

    @JsonProperty("current_age")
    private String currentAge;

    @JsonProperty("retirement_age")
    private String retirementAge;

    @JsonProperty("monthly_avg_income_before_retired")
    private String monthlyAvgIncomeBeforeRetired;

    @JsonProperty("monthly_avg_expense_before_retired")
    private String monthlyAvgExpenseBeforeRetired;

    @JsonProperty("monthly_disposable_income_after_retired")
    private String monthlyDisposableIncomeAfterRetired;

    @JsonProperty("annual_disposable_income_before_retired")
    private String annualDisposableIncomeBeforeRetired;

    @JsonProperty("annual_disposable_income_after_retried")
    private String annualDisposableIncomeAfterRetired;

    @JsonProperty("liquid_asset_before_retire")
    private String liquidAssetBeforeRetired;

    @JsonProperty("liquid_asset_after_retired")
    private String liquidAssetAfterRetired;

    @JsonProperty("income_contribution_pct")
    private String incomeContributionPct;

    @JsonProperty("asset_contribution_pct")
    private String assetContributionPct;

    @JsonProperty("sp_amt_1")
    @Pattern(regexp = "^([0-9]+\\.?[0-9]*|\\.[0-9]+)$")
    private String spAmt1;

    @JsonProperty("ann_amt_1")
    @Pattern(regexp = "^([0-9]+\\.?[0-9]*|\\.[0-9]+)$")
    private String annAmt1;

    @JsonProperty("sp_curr_1")
    private String spCurr1;

    @JsonProperty("ann_curr_1")
    private String annCurr1;

    @JsonProperty("payment_term_1")
    private String paymentTerm1;

    @JsonProperty("sp_amt_2")
    private String spAmt2;

    @JsonProperty("ann_amt_2")
    private String annAmt2;

    @JsonProperty("sp_curr_2")
    private String spCurr2;

    @JsonProperty("ann_curr_2")
    private String annCurr2;

    @JsonProperty("payment_term_2")
    private String paymentTerm2;

    @JsonProperty("sp_amt_3")
    private String spAmt3;

    @JsonProperty("ann_amt_3")
    private String annAmt3;

    @JsonProperty("sp_curr_3")
    private String spCurr3;

    @JsonProperty("ann_curr_3")
    private String annCurr3;

    @JsonProperty("payment_term_3")
    private String paymentTerm3;

    @JsonProperty("sp_amt_4")
    private String spAmt4;

    @JsonProperty("ann_amt_4")
    private String annAmt4;

    @JsonProperty("sp_curr_4")
    private String spCurr4;

    @JsonProperty("ann_curr_4")
    private String annCurr4;

    @JsonProperty("payment_term_4")
    private String paymentTerm4;

    @JsonProperty("sp_amt_5")
    private String spAmt5;

    @JsonProperty("ann_amt_5")
    private String annAmt5;

    @JsonProperty("sp_curr_5")
    private String spCurr5;

    @JsonProperty("ann_curr_5")
    private String annCurr5;

    @JsonProperty("payment_term_5")
    private String paymentTerm5;

    @JsonProperty("loanAmt")
    private String loanAmt;
    
    @JsonProperty("loanInterestRate")
    private String loanInterestRate;
    
    @JsonProperty("repaymentAmt")
    private String repaymentAmt;
    
    @JsonProperty("loanTenors")
    private String loanTenors;    

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("CalAffordRequest{");
        sb.append(", locale='").append(locale).append('\'');
        sb.append(", idNo='").append(idNo).append('\'');
        sb.append(", name='").append(name).append('\'');
        sb.append(", dob='").append(dob).append('\'');
        sb.append(", sex='").append(sex).append('\'');
        sb.append(", currentAge='").append(currentAge).append('\'');
        sb.append(", retirementAge='").append(retirementAge).append('\'');
        sb.append(", monthlyAvgIncomeBeforeRetired='").append(monthlyAvgIncomeBeforeRetired).append('\'');
        sb.append(", monthlyAvgExpenseBeforeRetired='").append(monthlyAvgExpenseBeforeRetired).append('\'');
        sb.append(", monthlyDisposableIncomeAfterRetired='").append(monthlyDisposableIncomeAfterRetired).append('\'');
        sb.append(", liquidAssetBeforeRetired='").append(liquidAssetBeforeRetired).append('\'');
        sb.append(", liquidAssetAfterRetired='").append(liquidAssetAfterRetired).append('\'');
        sb.append(", incomeContributionPct='").append(incomeContributionPct).append('\'');
        sb.append(", assetContributionPct='").append(assetContributionPct).append('\'');
        sb.append(", spAmt1='").append(spAmt1).append('\'');
        sb.append(", annAmt1='").append(annAmt1).append('\'');
        sb.append(", spCurr1='").append(spCurr1).append('\'');
        sb.append(", annCurr1='").append(annCurr1).append('\'');
        sb.append(", paymentTerm1='").append(paymentTerm1).append('\'');
        sb.append(", spAmt2='").append(spAmt2).append('\'');
        sb.append(", annAmt2='").append(annAmt2).append('\'');
        sb.append(", spCurr2='").append(spCurr2).append('\'');
        sb.append(", annCurr2='").append(annCurr2).append('\'');
        sb.append(", paymentTerm2='").append(paymentTerm2).append('\'');
        sb.append(", spAmt3='").append(spAmt3).append('\'');
        sb.append(", annAmt3='").append(annAmt3).append('\'');
        sb.append(", spCurr3='").append(spCurr3).append('\'');
        sb.append(", annCurr3='").append(annCurr3).append('\'');
        sb.append(", paymentTerm3='").append(paymentTerm3).append('\'');
        sb.append(", spAmt4='").append(spAmt4).append('\'');
        sb.append(", annAmt4='").append(annAmt4).append('\'');
        sb.append(", spCurr4='").append(spCurr4).append('\'');
        sb.append(", annCurr4='").append(annCurr4).append('\'');
        sb.append(", paymentTerm4='").append(paymentTerm4).append('\'');
        sb.append(", spAmt5='").append(spAmt5).append('\'');
        sb.append(", annAmt5='").append(annAmt5).append('\'');
        sb.append(", spCurr5='").append(spCurr5).append('\'');
        sb.append(", annCurr5='").append(annCurr5).append('\'');
        sb.append(", paymentTerm5='").append(paymentTerm5).append('\'');
        sb.append('}');
        return sb.toString();
    }

    public String getSp1() {
        BigDecimal val = ConversionHandler.bigDecimalValueOf(this.getSpAmt1());

        if ("048".equals(this.getSpCurr1())) {
            // HKD
            val = val.divide(rate, 2, RoundingMode.HALF_UP);
        }

        return (val == null ? "" : RiskCalculatorUtils.INSTANCE.premiumFormat(val, 2, DECIMAL_MODE));
    }

    public String getSp2() {
        BigDecimal val = ConversionHandler.bigDecimalValueOf(this.getSpAmt2());

        if ("048".equals(this.getSpCurr2())) {
            // HKD
            val = val.divide(rate, 2, RoundingMode.HALF_UP);
        }

        return (val == null ? "" : RiskCalculatorUtils.INSTANCE.premiumFormat(val, 2, DECIMAL_MODE));
    }

    public String getSp3() {
        BigDecimal val = ConversionHandler.bigDecimalValueOf(this.getSpAmt3());

        if ("048".equals(this.getSpCurr3())) {
            // HKD
            val = val.divide(rate, 2, RoundingMode.HALF_UP);
        }

        return (val == null ? "" : RiskCalculatorUtils.INSTANCE.premiumFormat(val, 2, DECIMAL_MODE));
    }

    public String getSp4() {
        BigDecimal val = ConversionHandler.bigDecimalValueOf(this.getSpAmt4());

        if ("048".equals(this.getSpCurr4())) {
            // HKD
            val = val.divide(rate, 2, RoundingMode.HALF_UP);
        }

        return (val == null ? "" : RiskCalculatorUtils.INSTANCE.premiumFormat(val, 2, DECIMAL_MODE));
    }

    public String getSp5() {
        BigDecimal val = ConversionHandler.bigDecimalValueOf(this.getSpAmt5());

        if ("048".equals(this.getSpCurr5())) {
            // HKD
            val = val.divide(rate, 2, RoundingMode.HALF_UP);
        }

        return (val == null ? "" : RiskCalculatorUtils.INSTANCE.premiumFormat(val, 2, DECIMAL_MODE));
    }

    public String getAp1() {
        BigDecimal val = ConversionHandler.bigDecimalValueOf(this.getAnnAmt1());

        if ("048".equals(this.getAnnCurr1())) {
            // HKD
            val = val.divide(rate, 2, RoundingMode.HALF_UP);
        }

        return (val == null ? "" : RiskCalculatorUtils.INSTANCE.premiumFormat(val, 2, DECIMAL_MODE));
    }

    public String getAp2() {
        BigDecimal val = ConversionHandler.bigDecimalValueOf(this.getAnnAmt2());

        if ("048".equals(this.getAnnCurr2())) {
            // HKD
            val = val.divide(rate, 2, RoundingMode.HALF_UP);
        }

        return (val == null ? "" : RiskCalculatorUtils.INSTANCE.premiumFormat(val, 2, DECIMAL_MODE));
    }

    public String getAp3() {
        BigDecimal val = ConversionHandler.bigDecimalValueOf(this.getAnnAmt3());

        if ("048".equals(this.getAnnCurr3())) {
            // HKD
            val = val.divide(rate, 2, RoundingMode.HALF_UP);
        }

        return (val == null ? "" : RiskCalculatorUtils.INSTANCE.premiumFormat(val, 2, DECIMAL_MODE));
    }

    public String getAp4() {
        BigDecimal val = ConversionHandler.bigDecimalValueOf(this.getAnnAmt4());

        if ("048".equals(this.getAnnCurr4())) {
            // HKD
            val = val.divide(rate, 2, RoundingMode.HALF_UP);
        }

        return (val == null ? "" : RiskCalculatorUtils.INSTANCE.premiumFormat(val, 2, DECIMAL_MODE));
    }

    public String getAp5() {
        BigDecimal val = ConversionHandler.bigDecimalValueOf(this.getAnnAmt5());

        if ("048".equals(this.getAnnCurr5())) {
            // HKD
            val = val.divide(rate, 2, RoundingMode.HALF_UP);
        }

        return (val == null ? "" : RiskCalculatorUtils.INSTANCE.premiumFormat(val, 2, DECIMAL_MODE));
    }

    public BigDecimal getMonthlyAvgIncomeBrUsd() {
        BigDecimal val = ConversionHandler.bigDecimalValueOf(this.getMonthlyAvgIncomeBeforeRetired());
        val = val.divide(rate, 2, RoundingMode.HALF_UP);
        return val;
    }

    public BigDecimal getMonthlyAvgExpenseBrUsd() {
        BigDecimal val = ConversionHandler.bigDecimalValueOf(this.getMonthlyAvgExpenseBeforeRetired());
        val = val.divide(rate, 2, RoundingMode.HALF_UP);
        return val;
    }

    public BigDecimal getMonthlyDisposableIncomeArUsd() {
        BigDecimal val = ConversionHandler.bigDecimalValueOf(this.getMonthlyDisposableIncomeAfterRetired());
        val = val.divide(rate,2,RoundingMode.HALF_UP);
        return val;
    }

    public BigDecimal getAnnualDisposableIncomeBrUsd() {
        BigDecimal val = ConversionHandler.bigDecimalValueOf(this.getAnnualDisposableIncomeBeforeRetired());
        val = val.divide(rate, 2, RoundingMode.HALF_UP);
        return val;
    }

    public BigDecimal getAnnualDisposableIncomeArUsd() {
        BigDecimal val = ConversionHandler.bigDecimalValueOf(this.getAnnualDisposableIncomeAfterRetired());
        val = val.divide(rate, 2, RoundingMode.HALF_UP);
        return val;
    }

    public BigDecimal getLiquidAssetBrUsd() {
        BigDecimal val = ConversionHandler.bigDecimalValueOf(this.getLiquidAssetBeforeRetired());
        val = val.divide(rate, 2, RoundingMode.HALF_UP);
        return val;
    }

    public BigDecimal getLiquidAssetArUsd() {
        BigDecimal val = ConversionHandler.bigDecimalValueOf(this.getLiquidAssetAfterRetired());
        val = val.divide(rate, 2, RoundingMode.HALF_UP);
        return val;
    }

    public BigDecimal getLoanAmtUsd() {
    	BigDecimal val = ConversionHandler.bigDecimalValueOf(this.getLoanAmt());
        val = val.divide(rate, 2, RoundingMode.HALF_UP);       
        return val;
    }
    
    public BigDecimal getRepaymentAmtUsd() {
    	BigDecimal val = ConversionHandler.bigDecimalValueOf(this.getRepaymentAmt());
        val = val.divide(rate, 2, RoundingMode.HALF_UP);        
        return val;
    }

}
