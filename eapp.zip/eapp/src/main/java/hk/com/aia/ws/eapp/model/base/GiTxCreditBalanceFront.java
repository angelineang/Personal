package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@ApiModel(value = "GiTx Credit Balance Front Model")
@Data
public class GiTxCreditBalanceFront {

    @ApiModelProperty(value = "Coupon")
    @JsonProperty("coupon")
    private Double coupon;

    @ApiModelProperty(value = "Coupon code")
    @JsonProperty("coupon_code")
    private String couponCode;

    @ApiModelProperty(value = "Credit")
    @JsonProperty("credit")
    private Double credit;

    @ApiModelProperty(value = "Gi number")
    @JsonProperty("gi_no")
    private String giNo;

    @ApiModelProperty(value = "Gi type")
    @JsonProperty("gi_type")
    private String giType;

    @ApiModelProperty(value = "Gi Version")
    @JsonProperty("gi_ver")
    private Integer giVer;

    @ApiModelProperty(value = "Policy number")
    @JsonProperty("pol_no")
    private String polNo;

    @ApiModelProperty(value = "Record status")
    @JsonProperty("record_status")
    private String recordStatus;

    @ApiModelProperty(value = "Tx date")
    @JsonProperty("tx_date")
    private String txDate;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("GiTxCreditBalanceFront{");
        sb.append("coupon=").append(coupon);
        sb.append(", couponCode='").append(couponCode).append('\'');
        sb.append(", credit=").append(credit);
        sb.append(", giNo='").append(giNo).append('\'');
        sb.append(", giType='").append(giType).append('\'');
        sb.append(", giVer=").append(giVer);
        sb.append(", polNo='").append(ConversionHandler.mask(polNo)).append('\'');
        sb.append(", recordStatus='").append(recordStatus).append('\'');
        sb.append(", txDate='").append(txDate).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
