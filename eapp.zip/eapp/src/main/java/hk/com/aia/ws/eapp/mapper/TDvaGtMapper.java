package hk.com.aia.ws.eapp.mapper;

import hk.com.aia.ws.eapp.model.db.magnum.ipos.TDvaGt;
import hk.com.aia.ws.eapp.model.request.ipos.TDvaGtDto;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

@Mapper
public interface TDvaGtMapper {

    TDvaGtMapper MAPPER = Mappers.getMapper(TDvaGtMapper.class);

    @Mappings({
        @Mapping(target = "createdBy", ignore = true),
        @Mapping(target = "createdDateTime", ignore = true),
        @Mapping(target = "updatedBy", ignore = true),
        @Mapping(target = "lastUpdatedDateTime", ignore = true)})
    List<TDvaGt> mapToTDvaGtList(List<TDvaGtDto> tDvaGtDto);
}
