package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import lombok.Data;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "T_OCRContactCount")
public class TOcrContactCount {

    @Column(name = "OCRCountID", length = 60)
    @Id
    private String ocrCountId;

    @Column(name = "OCRContactID", length = 60)
    private String ocrContactId;

    @Column(name = "EAPPID", length = 60)
    private String eappId;

    @Column(name = "ContactID", length = 60)
    private String contactId;

    @Column(name = "CaptureCount")
    private Integer captureCount;

    @Column(name = "EditCount")
    private Integer editCount;

    @Column(name = "LastNameCount")
    private Integer lastNameCount;

    @Column(name = "FirstNameCount")
    private Integer firstNameCount;

    @Column(name = "ChineseNameCount")
    private Integer chineseNameCount;

    @Column(name = "GenderCount")
    private Integer genderCount;

    @Column(name = "DOBCount")
    private Integer dobCount;

    @Column(name = "IDNumberCount")
    private Integer idNumberCount;

    @Column(name = "createby", updatable = false)
    @CreatedBy
    private String createBy;

    @Column(name = "createddatetime", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "IDExpiryDateCount")
    private Integer idExpiryDateCount;

    @Column(name = "IssueDateCount")
    private Integer issueDateCount;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TOcrContactCount{");
        sb.append("ocrCountId='").append(ocrCountId).append('\'');
        sb.append(", ocrContactId='").append(ocrContactId).append('\'');
        sb.append(", eappId='").append(eappId).append('\'');
        sb.append(", contactId='").append(contactId).append('\'');
        sb.append(", captureCount=").append(captureCount);
        sb.append(", editCount=").append(editCount);
        sb.append(", lastNameCount=").append(lastNameCount);
        sb.append(", firstNameCount=").append(firstNameCount);
        sb.append(", chineseNameCount=").append(chineseNameCount);
        sb.append(", genderCount=").append(genderCount);
        sb.append(", dobCount=").append(dobCount);
        sb.append(", idNumberCount=").append(idNumberCount);
        sb.append(", createBy='").append(createBy).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", idExpiryDateCount=").append(idExpiryDateCount);
        sb.append(", issueDateCount=").append(issueDateCount);
        sb.append('}');
        return sb.toString();
    }
}
	
	
	
	
	
	