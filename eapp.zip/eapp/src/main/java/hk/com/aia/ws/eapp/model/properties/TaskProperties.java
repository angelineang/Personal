package hk.com.aia.ws.eapp.model.properties;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class TaskProperties {

    private int poolSize;
    private String milliseconds;
    private List<String> userList = new ArrayList<>();

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TaskProperties{");
        sb.append("poolSize=").append(poolSize);
        sb.append(", milliseconds='").append(milliseconds).append('\'');
        sb.append('}');
        return sb.toString();
    }
}