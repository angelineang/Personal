package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import hk.com.aia.ws.eapp.util.ConversionHandler;
import lombok.Data;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;

import java.io.Serializable;
import java.util.Date;

@Entity
@Data
@Table(name = "T_VOMEETING")
@EntityListeners(AuditingEntityListener.class)
public class TVomeeting {

    @Column(name = "EAPPID")
    @Id
    private String eappId;
    
    @Column(name = "MEETINGID")

    private String meetingId;

    @Column(name = "OPTOUTREASON")
    private String optOutReason;

    @Column(name = "OTHERREASON")
    private String otherReason;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TVomeeting{");
        sb.append("EAPPID='").append(eappId).append('\'');
        sb.append(", MEETINGID='").append(meetingId).append('\'');
        sb.append(", OPTOUTREASON='").append(optOutReason).append('\'');
        sb.append(", OTHERREASON='").append(otherReason).append('\'');
        sb.append('}');
        return sb.toString();
    }



}


