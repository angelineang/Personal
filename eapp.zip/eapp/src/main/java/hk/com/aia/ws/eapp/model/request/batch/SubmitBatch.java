package hk.com.aia.ws.eapp.model.request.batch;

import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.model.base.Payload;
import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import java.util.List;

@ApiModel(value = "SubmitBatchRequest Model")
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class SubmitBatch extends Payload {

    @JsonProperty("batch_id")
    @NotBlank
    private String batchId;

    @JsonProperty("policy_no")
    @NotBlank
    private String policyNo;

    @JsonProperty("batch_mst")
    @Valid
    private List<BatchMstDto> batchMstDto;

    @JsonProperty("batch_pdf_list")
    @Valid
    private List<BatchPdfDto> batchPdfDtoList;

    @JsonProperty("batch_data_list")
    @Valid
    private List<BatchDataDto> batchDataDtoList;

    @JsonProperty("sig_mst_list")
    private List<SigMstDto> sigMstDtoList;


}
