package hk.com.aia.ws.eapp.model.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class Document {


    @JsonProperty("document_id")
    private String documentId;

    @JsonProperty("document_file")
    private String documentFile;

    @JsonProperty("document_name")
    private String documentName;

    @JsonProperty("document_seq_no")
    private String documentSeqNo;

    @JsonProperty("document_type")
    private String documentType;

    @JsonProperty("client_type")
    private String clientType;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Document{");
        sb.append("documentId='").append(documentId).append('\'');
        sb.append(", documentFile='").append(documentFile).append('\'');
        sb.append(", documentName='").append(documentName).append('\'');
        sb.append(", documentSeqNo='").append(documentSeqNo).append('\'');
        sb.append(", documentType='").append(documentType).append('\'');
        sb.append(", clientType='").append(clientType).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
