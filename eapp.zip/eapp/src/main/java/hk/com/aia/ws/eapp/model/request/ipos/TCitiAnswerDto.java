package hk.com.aia.ws.eapp.model.request.ipos;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@ApiModel(value = "T_CITIANSWER Model")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TCitiAnswerDto {

    @ApiModelProperty(value = "answer Id", required = true)
    @JsonProperty("answer_id")
	@Size(max = 60)
    @NotBlank
    private String answerId;

    @JsonProperty("fna_id")
	@Size(max = 60)
    private String fnaId;

    @JsonProperty("biz_id")
	@Size(max = 60)
    private String bizId;

    @JsonProperty("question_group")
	@Size(max = 60)
    private String questionGroup;

    @JsonProperty("question_type")
	@Size(max = 60)
    private String questionType;

    @JsonProperty("question_key")
	@Size(max = 60)
    private String questionKey;

    @JsonProperty("field_yes_or_no")
    private Integer fieldYesOrNo;

    @JsonProperty("field_sl_a")
	@Size(max = 400)
    private String fieldSLA;

    @JsonProperty("field_sl_b")
	@Size(max = 400)
    private String fieldSLB;

    @JsonProperty("field_sl_c")
	@Size(max = 400)
    private String fieldSLC;

    @JsonProperty("field_free_input")
	@Size(max = 400)
    private String fieldFreeInputs;

    @JsonProperty("field_nm_a")
    private BigDecimal fieldNMA;

    @JsonProperty("field_nm_b")
    private BigDecimal fieldNMB;

    @JsonProperty("field_nm_c")
    private BigDecimal fieldNMC;

    @JsonProperty("field_nm_d")
    private BigDecimal fieldNMD;

    @JsonProperty("field_nm_e")
    private BigDecimal fieldNME;

    @JsonProperty("field_ns_a")
	@Size(max = 100)
    private String fieldNSA;

    @JsonProperty("field_ns_b")
	@Size(max = 100)
    private String fieldNSB;

    @JsonProperty("field_ns_c")
	@Size(max = 100)
    private String fieldNSC;

    @JsonProperty("field_ns_d")
	@Size(max = 100)
    private String fieldNSD;

    @JsonProperty("field_ns_e")
	@Size(max = 100)
    private String fieldNSE;

    @JsonProperty("field_ns_f")
	@Size(max = 100)
    private String fieldNSF;

    @JsonProperty("field_sl_d")
	@Size(max = 400)
    private String fieldSLD;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TCitiAnswerDto{");
        sb.append("answerId='").append(answerId).append('\'');
        sb.append(", fnaId='").append(fnaId).append('\'');
        sb.append(", bizId='").append(bizId).append('\'');
        sb.append(", questionGroup='").append(questionGroup).append('\'');
        sb.append(", questionType='").append(questionType).append('\'');
        sb.append(", questionKey='").append(questionKey).append('\'');
        sb.append(", fieldYesOrNo=").append(fieldYesOrNo);
        sb.append(", fieldSLA='").append(fieldSLA).append('\'');
        sb.append(", fieldSLB='").append(fieldSLB).append('\'');
        sb.append(", fieldSLC='").append(fieldSLC).append('\'');
        sb.append(", fieldFreeInputs='").append(fieldFreeInputs).append('\'');
        sb.append(", fieldNMA=").append(fieldNMA);
        sb.append(", fieldNMB=").append(fieldNMB);
        sb.append(", fieldNMC=").append(fieldNMC);
        sb.append(", fieldNMD=").append(fieldNMD);
        sb.append(", fieldNME=").append(fieldNME);
        sb.append(", fieldNSA='").append(fieldNSA).append('\'');
        sb.append(", fieldNSB='").append(fieldNSB).append('\'');
        sb.append(", fieldNSC='").append(fieldNSC).append('\'');
        sb.append(", fieldNSD='").append(fieldNSD).append('\'');
        sb.append(", fieldNSE='").append(fieldNSE).append('\'');
        sb.append(", fieldNSF='").append(fieldNSF).append('\'');
        sb.append(", fieldSLD='").append(fieldSLD).append('\'');
        sb.append('}');
        return sb.toString();
    }
}


