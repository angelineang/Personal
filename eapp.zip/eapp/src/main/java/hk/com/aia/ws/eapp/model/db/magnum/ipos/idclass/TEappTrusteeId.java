package hk.com.aia.ws.eapp.model.db.magnum.ipos.idclass;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TEappTrusteeId implements Serializable {

    private static final long serialVersionUID = -1880928081474048547L;
    private String eappTrusteeId;
    private String eappId;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TEappTrusteeId{");
        sb.append("eappTrusteeId='").append(eappTrusteeId).append('\'');
        sb.append(", eappId='").append(eappId).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
