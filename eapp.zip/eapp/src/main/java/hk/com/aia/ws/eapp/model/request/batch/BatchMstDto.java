package hk.com.aia.ws.eapp.model.request.batch;

import java.util.Date;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;

import hk.com.aia.ws.eapp.annotation.AllowedValuesValidation;
import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;


@ApiModel(value = "BatchMst Model")
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class BatchMstDto {

    @JsonProperty("doc_id")
    @NotBlank
    private String docId;

    @JsonProperty("agy_code")
    @NotBlank
    private String agyCode;

    @JsonProperty("agt_code")
    @NotBlank
    private String agtCode;

    @JsonProperty("team_code")
    private String teamCode;

    @JsonProperty("seq")
    @NotNull
    private Integer seq;

    @JsonProperty("agt_code2")
    private String agtCode2;

    @JsonProperty("otp_ind")
    private String otpInd;

    @JsonProperty("citi")
    private String citi;

    @JsonProperty("org_batch_id")
    private String orgBatchId;

    @JsonProperty("stp_ind")
    private String stpInd;

    @JsonProperty("parent_batch_id")
    private String parentBatchId;

    @JsonProperty("documents_id")
    private String documentsId;

    @JsonProperty("iverify_id")
    private String iVerifyId;

    @JsonProperty("iverify_client_id")
    private String iVerifyClientId;

    @JsonProperty("iverify_doc_seq")
    private String iVerifyDocSeq;

    @JsonProperty("content_type")
    private String contentType;

    @JsonProperty("access_id")
    private String accessId;

    @JsonProperty("tr_code")
    private String trCode;

    @JsonProperty("otp_confirm_date")
    private Date otpConfirmDate;

    @JsonProperty("status")
    @Size(max = 1)
    @AllowedValuesValidation(values = {"I", "C"})
    private String status;
    
 
}
