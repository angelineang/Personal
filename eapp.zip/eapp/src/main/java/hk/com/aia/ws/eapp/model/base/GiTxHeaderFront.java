package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@ApiModel(value = "GiTx Header Front Model")
@Data
public class GiTxHeaderFront {

    @ApiModelProperty(value = "Action")
    @JsonProperty("action")
    private String action;

    @ApiModelProperty(value = "Deduct amount")
    @JsonProperty("deduct_amount")
    private Double deductAmount;

    @ApiModelProperty(value = "Gi from date")
    @JsonProperty("gi_from_date")
    private String giFromDate;

    @ApiModelProperty(value = "Gi to date")
    @JsonProperty("gi_to_date")
    private String giToDate;

    @ApiModelProperty(value = "Levy amount")
    @JsonProperty("levy_amount")
    private Double levyAmount;

    @ApiModelProperty(value = "Premium amount")
    @JsonProperty("premium_amount")
    private Double premiumAmount;

    @ApiModelProperty(value = "Premium discount amount")
    @JsonProperty("premium_discount_amount")
    private Double premiumDiscountAmount;

    @ApiModelProperty(value = "Commission amount")
    @JsonProperty("commission_amount")
    private Double commissionAmount;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("GiTxHeaderFront{");
        sb.append("action='").append(action).append('\'');
        sb.append(", deductAmount=").append(deductAmount);
        sb.append(", giFromDate='").append(giFromDate).append('\'');
        sb.append(", giToDate='").append(giToDate).append('\'');
        sb.append(", levyAmount=").append(levyAmount);
        sb.append(", premiumAmount=").append(premiumAmount);
        sb.append(", premiumDiscountAmount=").append(premiumDiscountAmount);
        sb.append(", commissionAmount=").append(commissionAmount);
        sb.append('}');
        return sb.toString();
    }
}
