package hk.com.aia.ws.eapp.controller;

import static hk.com.aia.ws.eapp.constant.Constants.RETURN_CODE_98;

import java.time.Duration;
import java.time.LocalDateTime;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import hk.com.aia.ws.eapp.constant.Constants;
import hk.com.aia.ws.eapp.constant.Constants.APIPath;
import hk.com.aia.ws.eapp.model.base.ResultMessage;
import hk.com.aia.ws.eapp.model.request.Request;
import hk.com.aia.ws.eapp.model.request.calculator.AMLRequest;
import hk.com.aia.ws.eapp.model.request.calculator.CalAffordRequest;
import hk.com.aia.ws.eapp.model.request.calculator.CalSuitabilityRequest;
import hk.com.aia.ws.eapp.model.request.calculator.SioGioRequest;
import hk.com.aia.ws.eapp.model.response.Response;
import hk.com.aia.ws.eapp.model.response.calculator.AMLResponse;
import hk.com.aia.ws.eapp.model.response.calculator.CalAffordResponse;
import hk.com.aia.ws.eapp.model.response.calculator.CalSuitabilityResponse;
import hk.com.aia.ws.eapp.model.response.calculator.SioGioResponse;
import hk.com.aia.ws.eapp.model.response.error.GatewayError400;
import hk.com.aia.ws.eapp.model.response.error.GatewayError401;
import hk.com.aia.ws.eapp.model.response.error.InternalError500;
import hk.com.aia.ws.eapp.model.token.CustomizeClaims;
import hk.com.aia.ws.eapp.service.LogService;
import hk.com.aia.ws.eapp.service.PayloadRequestService;
import hk.com.aia.ws.eapp.service.calculator.CalculatorService;
import hk.com.aia.ws.eapp.service.jwt.JwtService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@AllArgsConstructor
@RestController
@RequestMapping("/calculators")
@Api(value = "Calculator Services", tags = { "API(s) for calculator services" })
public class CalculatorController {

	@Autowired
	private CalculatorService calculatorService;

	@Autowired
	private JwtService jwtService;

	@Autowired
	private PayloadRequestService payloadRequestService;

	@Autowired
	private LogService logService;

	@ApiOperation(value = "To calculate risk.")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Calculated Risk successfully."),

			@ApiResponse(code = 400, message = "Bad Request", response = GatewayError400.class),
			@ApiResponse(code = 401, message = "Unauthorized", response = GatewayError401.class),
			@ApiResponse(code = 404, message = "Invalid request.", response = Response.class),
			@ApiResponse(code = 500, message = "Internal Server Error", response = InternalError500.class) })
	@PostMapping(value = "/calculate-risk", produces = MediaType.APPLICATION_JSON_VALUE)
	public Response<AMLResponse> calculateRisk(
			@ApiParam(value = "Local business unit.    | Valid Values |   | ----------   |   | HK, TH, SG   | ", required = true) @RequestHeader(value = Constants.RequestHeader.AIA_LBU, required = true) String xAiaLbu,
			@ApiParam(value = "Unique id for the request for tracking purposes.        ", required = true) @RequestHeader(value = Constants.RequestHeader.REQUEST_ID, required = true) String xAiaRequestId,
			@ApiParam(value = "Target environment of the request. Note that this header is required only when accessing non-production environments.    | Valid Values       |   | ------------------ |   | qa1, qa2, qa3, qa4 |        ") @RequestHeader(value = Constants.RequestHeader.AIA_ENV, required = false) String xAiaEnv,
			@ApiParam(value = "An access token issued by an AIA Authorization server. This will have the format Bearer + {space} + {accessToken}.") @RequestHeader(value = Constants.RequestHeader.AIAACESSTOKEN, required = true) String authorization,
			@ApiParam(value = "Trace Id for EFK Logging") @RequestHeader(value = Constants.RequestHeader.TRACE_ID, required = true) String xAiaHkTraceId,
			@ApiParam(value = "Context Id for EFK Logging") @RequestHeader(value = Constants.RequestHeader.CONTEXT_ID, required = true) String xAiaHkContextId,
			@ApiParam(value = "AML Request", required = true) @Valid @RequestBody Request<AMLRequest> request) {
		Response<AMLResponse> response = null;
		String calType = request.getData().getAmlFlag();

		logService.logStartWorkingIntegration("Y".equals(calType) ? APIPath.EAPP_CAL_AML : APIPath.EAPP_CAL_NON_MED);
		LocalDateTime start = LocalDateTime.now();

		CustomizeClaims claims = null;
		try {
			claims = jwtService.authentication(authorization);

		} catch (Exception e) {
			Response<AMLResponse> errorsPayload = new Response<>();
			errorsPayload.setTransId("");
			errorsPayload.setStatus("0");
			errorsPayload.getResultMessages().add(new ResultMessage(RETURN_CODE_98, "failed to  validate  token "));
			return errorsPayload;
		}

		payloadRequestService.saveRequestJson("", "Y".equals(calType) ? "CAL-RISK-AML-C" : "CAL-RISK-NON-MED-C",
				request);

		if ("Y".equals(claims.getStf())) {
			response = calculatorService.calculateRisk(request, claims.getSid(), claims.getAtr(), null);
		} else {
			request.getData().setAgtCode(claims.getAid());
			response = calculatorService.calculateRisk(request, claims.getAid(), claims.getAtr(), null);

		}
		payloadRequestService.saveRequestJson("", "Y".equals(calType) ? "CAL-RISK-AML-R" : "CAL-RISK-NON-MED-R",
				response);

		LocalDateTime end = LocalDateTime.now();
		Duration duration = Duration.between(start, end);
		logService.logEndWorkingSuccessIntegration(
				"Y".equals(calType) ? APIPath.EAPP_CAL_AML : APIPath.EAPP_CAL_NON_MED, duration.toMillis());

		return response;
	}

	@ApiOperation(value = "To calculate risk - SIO GIO.")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Calculated Risk successfully."),

			@ApiResponse(code = 400, message = "Bad Request", response = GatewayError400.class),
			@ApiResponse(code = 401, message = "Unauthorized", response = GatewayError401.class),
			@ApiResponse(code = 404, message = "Invalid request.", response = Response.class),
			@ApiResponse(code = 500, message = "Internal Server Error", response = InternalError500.class) })
	@PostMapping(value = "/calculate-risk-sio-gio", produces = MediaType.APPLICATION_JSON_VALUE)
	public Response<SioGioResponse> calculateRiskSioGio(
			@ApiParam(value = "Local business unit.    | Valid Values |   | ----------   |   | HK, TH, SG   | ", required = true) @RequestHeader(value = Constants.RequestHeader.AIA_LBU, required = true) String xAiaLbu,
			@ApiParam(value = "Unique id for the request for tracking purposes.        ", required = true) @RequestHeader(value = Constants.RequestHeader.REQUEST_ID, required = true) String xAiaRequestId,
			@ApiParam(value = "Target environment of the request. Note that this header is required only when accessing non-production environments.    | Valid Values       |   | ------------------ |   | qa1, qa2, qa3, qa4 |        ") @RequestHeader(value = Constants.RequestHeader.AIA_ENV, required = false) String xAiaEnv,
			@ApiParam(value = "An access token issued by an AIA Authorization server. This will have the format Bearer + {space} + {accessToken}.") @RequestHeader(value = Constants.RequestHeader.AIAACESSTOKEN, required = true) String authorization,
			@ApiParam(value = "Trace Id for EFK Logging") @RequestHeader(value = Constants.RequestHeader.TRACE_ID, required = true) String xAiaHkTraceId,
			@ApiParam(value = "Context Id for EFK Logging") @RequestHeader(value = Constants.RequestHeader.CONTEXT_ID, required = true) String xAiaHkContextId,
			@ApiParam(value = "Sio Gio Request", required = true) @Valid @RequestBody Request<SioGioRequest> request) {
		Response<SioGioResponse> response = null;
		logService.logStartWorkingIntegration(APIPath.EAPP_CAL_SIO_GIO);
		LocalDateTime start = LocalDateTime.now();

		CustomizeClaims claims = null;
		try {
			claims = jwtService.authentication(authorization);

		} catch (Exception e) {
			Response<SioGioResponse> errorsPayload = new Response<>();
			errorsPayload.setTransId("");
			errorsPayload.setStatus("0");
			errorsPayload.getResultMessages().add(new ResultMessage(RETURN_CODE_98, "failed to  validate  token "));
			return errorsPayload;
		}
		payloadRequestService.saveRequestJson("", "CAL-SIO-C", request);

		response = calculatorService.calculateSioGio(request,
				"Y".equals(claims.getStf()) ? claims.getSid() : claims.getAid(), claims.getAtr());

		payloadRequestService.saveRequestJson("", "CAL-SIO-R", response);

		LocalDateTime end = LocalDateTime.now();
		Duration duration = Duration.between(start, end);
		logService.logEndWorkingSuccessIntegration(APIPath.EAPP_CAL_SIO_GIO, duration.toMillis());
		return response;

	}

	@ApiOperation(value = "Calculate Afford Action.")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Calculated Risk successfully."),

			@ApiResponse(code = 400, message = "Bad Request", response = GatewayError400.class),
			@ApiResponse(code = 401, message = "Unauthorized", response = GatewayError401.class),
			@ApiResponse(code = 404, message = "Invalid request.", response = Response.class),
			@ApiResponse(code = 500, message = "Internal Server Error", response = InternalError500.class) })
	@PostMapping(value = "/cal-afford", produces = MediaType.APPLICATION_JSON_VALUE)
	public Response<CalAffordResponse> calculateAfford(
			@ApiParam(value = "Local business unit.    | Valid Values |   | ----------   |   | HK, TH, SG   | ", required = true) @RequestHeader(value = Constants.RequestHeader.AIA_LBU) String xAiaLbu,
			@ApiParam(value = "Unique id for the request for tracking purposes.        ", required = true) @RequestHeader(value = Constants.RequestHeader.REQUEST_ID) String xAiaRequestId,
			@ApiParam(value = "Target environment of the request. Note that this header is required only when accessing non-production environments.    | Valid Values       |   | ------------------ |   | qa1, qa2, qa3, qa4 |        ") @RequestHeader(value = Constants.RequestHeader.AIA_ENV, required = false) String xAiaEnv,
			@ApiParam(value = "An access token issued by an AIA Authorization server. This will have the format Bearer + {space} + {accessToken}.") @RequestHeader(value = Constants.RequestHeader.AIAACESSTOKEN) String authorization,
			@ApiParam(value = "Trace Id for EFK Logging") @RequestHeader(value = Constants.RequestHeader.TRACE_ID) String xAiaHkTraceId,
			@ApiParam(value = "Context Id for EFK Logging") @RequestHeader(value = Constants.RequestHeader.CONTEXT_ID) String xAiaHkContextId,
			@ApiParam(value = "CalAfford Request", required = true) @Valid @RequestBody Request<CalAffordRequest> request) {

		Response<CalAffordResponse> response = null;
		logService.logStartWorkingIntegration(APIPath.EAPP_CAL_AFF);
		LocalDateTime start = LocalDateTime.now();

		CustomizeClaims claims = null;
		try {
			claims = jwtService.authentication(authorization);

		} catch (Exception e) {
			Response<CalAffordResponse> errorsPayload = new Response<>();
			errorsPayload.setTransId("");
			errorsPayload.setStatus("0");
			errorsPayload.getResultMessages().add(new ResultMessage(RETURN_CODE_98, "failed to  validate token "));
			return errorsPayload;
		}

		payloadRequestService.saveRequestJson("", "CAL-AFF-C", request);

		response = calculatorService.calculateAfford(request,
				"Y".equals(claims.getStf()) ? claims.getSid() : claims.getAid(), claims.getAtr());

		payloadRequestService.saveRequestJson("", "CAL-AFF-R", request);

		LocalDateTime end = LocalDateTime.now();
		Duration duration = Duration.between(start, end);
		logService.logEndWorkingSuccessIntegration(APIPath.EAPP_CAL_AFF, duration.toMillis());
		return response;
	}

	@ApiOperation(value = "Calculate Suitability Action.")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Calculated Risk successfully."),

			@ApiResponse(code = 400, message = "Bad Request", response = GatewayError400.class),
			@ApiResponse(code = 401, message = "Unauthorized", response = GatewayError401.class),
			@ApiResponse(code = 404, message = "Invalid request.", response = Response.class),
			@ApiResponse(code = 500, message = "Internal Server Error", response = InternalError500.class) })
	@PostMapping(value = "/cal-suitability", produces = MediaType.APPLICATION_JSON_VALUE)
	public Response<CalSuitabilityResponse> calculateSuitability(
			@ApiParam(value = "Local business unit.    | Valid Values |   | ----------   |   | HK, TH, SG   | ", required = true) @RequestHeader(value = Constants.RequestHeader.AIA_LBU, required = true) String xAiaLbu,
			@ApiParam(value = "Unique id for the request for tracking purposes.        ", required = true) @RequestHeader(value = Constants.RequestHeader.REQUEST_ID, required = true) String xAiaRequestId,
			@ApiParam(value = "Target environment of the request. Note that this header is required only when accessing non-production environments.    | Valid Values       |   | ------------------ |   | qa1, qa2, qa3, qa4 |        ") @RequestHeader(value = Constants.RequestHeader.AIA_ENV, required = false) String xAiaEnv,
			@ApiParam(value = "An access token issued by an AIA Authorization server. This will have the format Bearer + {space} + {accessToken}.") @RequestHeader(value = Constants.RequestHeader.AIAACESSTOKEN, required = true) String authorization,
			@ApiParam(value = "Trace Id for EFK Logging") @RequestHeader(value = Constants.RequestHeader.TRACE_ID, required = true) String xAiaHkTraceId,
			@ApiParam(value = "Context Id for EFK Logging") @RequestHeader(value = Constants.RequestHeader.CONTEXT_ID, required = true) String xAiaHkContextId,
			@ApiParam(value = "Cal Suitability Request", required = true) @Valid @RequestBody Request<CalSuitabilityRequest> request) {

		Response<CalSuitabilityResponse> response = null;
		logService.logStartWorkingIntegration(APIPath.EAPP_CAL_SUIT);
		LocalDateTime start = LocalDateTime.now();

		CustomizeClaims claims = null;
		try {
			claims = jwtService.authentication(authorization);

		} catch (Exception e) {
			Response<CalSuitabilityResponse> errorsPayload = new Response<>();
			errorsPayload.setTransId("");
			errorsPayload.setStatus("0");
			errorsPayload.getResultMessages().add(new ResultMessage(RETURN_CODE_98, "failed to  validate token "));
			return errorsPayload;
		}

		payloadRequestService.saveRequestJson("", "CAL-SUI-C", request);

		response = calculatorService.calculateSuitability(request,
				"Y".equals(claims.getStf()) ? claims.getSid() : claims.getAid(), claims.getAtr());

		payloadRequestService.saveRequestJson("", "CAL-SUI-R", request);

		LocalDateTime end = LocalDateTime.now();
		Duration duration = Duration.between(start, end);
		logService.logEndWorkingSuccessIntegration(APIPath.EAPP_CAL_SUIT, duration.toMillis());
		return response;
	}

}
