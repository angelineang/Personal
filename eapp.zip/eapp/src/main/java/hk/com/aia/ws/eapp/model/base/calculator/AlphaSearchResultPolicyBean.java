package hk.com.aia.ws.eapp.model.base.calculator;

import java.util.List;

import javax.xml.datatype.XMLGregorianCalendar;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
@JsonIgnoreProperties(ignoreUnknown = true)
public class AlphaSearchResultPolicyBean {

    protected XMLGregorianCalendar applicationDate;
    protected List<AlphaSearchResultCoverageBean> coverageList;
    protected String currency;
    protected String exclusion;
    protected String finalCode;
    protected List<String> impairmentCode;
    protected XMLGregorianCalendar policyDate;
    protected String policyNo;
    protected XMLGregorianCalendar policyPaidToDate;
    protected String policyStatus;
    protected String roleInfo;
    protected String policyStatusDesc;
    protected String vtyPrimaryIPInd;
    protected String agentCode;
    protected String agentChannelCode;
    protected String policyCategory;

}
