package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.annotation.AllowedValuesValidation;
import hk.com.aia.ws.eapp.annotation.DateTimeValidation;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@ApiModel(value = "IfsPr model")
@Data
public class IfsPr {

    // Size values comes from sp - po_ms_ins_staging_ifspr

    @ApiModelProperty(value = "Y - Yes, N - No", example = "Y", allowableValues = "Y,N")
    @AllowedValuesValidation(values = {"Y", "N"})
    @JsonProperty(value = "ifs_pr", required = true)
    @NotBlank
    @Size(max = 1)
    private String ifsPr;

    @ApiModelProperty(value = "IFS PR Received DATE (MM/DD/YYYY) ", example = "03/11/2016")
    @DateTimeValidation(format = "MM/dd/yyyy")
    @JsonProperty(value = "ifs_pr_receive_date")
    private String ifsPrReceiveDate;

    @ApiModelProperty(value = "Y - Yes", example = "Y", allowableValues = "Y")
    @AllowedValuesValidation(values = {"Y", "N"})
    @JsonProperty(value = "pr_reason_better_cov")
    private String prReasonBetterCov;

    @ApiModelProperty(value = "Y - Yes", example = "Y", allowableValues = "Y")
    @AllowedValuesValidation(values = {"Y", "N"})
    @JsonProperty("pr_reason_shorter_payment")
    private String prReasonShorterPayment;

    @ApiModelProperty(value = "Y - Yes", example = "Y", allowableValues = "Y")
    @AllowedValuesValidation(values = {"Y", "N"})
    @JsonProperty("pr_reason_longer_period")
    private String prReasonLongerPeriod;

    @ApiModelProperty(value = "Y - Yes", example = "Y", allowableValues = "Y")
    @AllowedValuesValidation(values = {"Y", "N"})
    @JsonProperty("pr_reason_lower_premium")
    private String prReasonLowerPremium;

    @ApiModelProperty(value = "pr Reason Higher Saving", example = "Y", allowableValues = "Y")
    @AllowedValuesValidation(values = {"Y", "N"})
    @JsonProperty("pr_reason_higher_saving")
    private String prReasonHigherSaving;

    @ApiModelProperty(value = "pr Reason Higher Flexi", example = "Y", allowableValues = "Y")
    @AllowedValuesValidation(values = {"Y", "N"})
    @JsonProperty("pr_reason_higher_flexi")
    private String prReasonHigherFlexi;

    @ApiModelProperty(value = "pr Reason Others", example = "Y", allowableValues = "Y")
    @AllowedValuesValidation(values = {"Y", "N"})
    @JsonProperty("pr_reason_others")
    private String prReasonOthers;

    public String getIfsPr() {
        return StringUtils.isBlank(ifsPr) ? "N" : ifsPr;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("IfsPr{");
        sb.append("ifsPr='").append(ifsPr).append('\'');
        sb.append(", ifsPrReceiveDate='").append(ifsPrReceiveDate).append('\'');
        sb.append(", prReasonBetterCov='").append(prReasonBetterCov).append('\'');
        sb.append(", prReasonShorterPayment='").append(prReasonShorterPayment).append('\'');
        sb.append(", prReasonLongerPeriod='").append(prReasonLongerPeriod).append('\'');
        sb.append(", prReasonLowerPremium='").append(prReasonLowerPremium).append('\'');
        sb.append(", prReasonHigherSaving='").append(prReasonHigherSaving).append('\'');
        sb.append(", prReasonHigherFlexi='").append(prReasonHigherFlexi).append('\'');
        sb.append(", prReasonOthers='").append(prReasonOthers).append('\'');
        sb.append('}');
        return sb.toString();
    }
}