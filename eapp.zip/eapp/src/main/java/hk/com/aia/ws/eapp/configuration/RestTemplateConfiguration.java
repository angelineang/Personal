package hk.com.aia.ws.eapp.configuration;

import hk.com.aia.ws.eapp.interceptor.LoggingReqRespInterceptor;
import hk.com.aia.ws.eapp.rest.RestTemplateResponseErrorHandler;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.util.ResourceUtils;
import org.springframework.web.client.RestTemplate;

import javax.net.ssl.SSLContext;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.*;
import java.security.cert.CertificateException;

@Configuration
public class RestTemplateConfiguration {

    @Bean("subModuleRestTemplate")
    public RestTemplate subModuleRestTemplate(@Value("${api.submission-module.ssl.enable}") Boolean apiSSLEnable,
                                              @Value("${api.submission-module.keystore.path}") String apiKeystorePath,
                                              @Value("${api.submission-module.keystore.pass}") String apiKeystorePass,
                                              @Value("${api.submission-module.timeout.connect}") Integer apiConnectTimeout,
                                              @Value("${api.submission-module.timeout.socket}") Integer apiSocketTimeout,
                                              @Value("${api.submission-module.jks}") String jks) throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException, KeyManagementException, IOException {

        return getRestTemplate(apiSSLEnable, apiKeystorePath, apiKeystorePass,
                apiConnectTimeout, apiSocketTimeout, jks);
    }

    @Bean("coiRestTemplate")
    public RestTemplate coiRestTemplate(@Value("${api.coi.ssl.enable}") Boolean apiSSLEnable,
                                        @Value("${api.coi.keystore.path}") String apiKeystorePath,
                                        @Value("${api.coi.keystore.pass}") String apiKeystorePass,
                                        @Value("${api.coi.timeout.connect}") Integer apiConnectTimeout,
                                        @Value("${api.coi.timeout.socket}") Integer apiSocketTimeout,
                                        @Value("${api.coi.jks}") String jks) throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException, KeyManagementException, IOException {

        return getRestTemplate(apiSSLEnable, apiKeystorePath, apiKeystorePass,
                apiConnectTimeout, apiSocketTimeout, jks);
    }

    @Bean("pnaRestTemplate")
    public RestTemplate pnaRestTemplate(@Value("${api.pna.ssl.enable}") Boolean apiSSLEnable,
                                        @Value("${api.pna.keystore.path}") String apiKeystorePath,
                                        @Value("${api.pna.keystore.pass}") String apiKeystorePass,
                                        @Value("${api.pna.timeout.connect}") Integer apiConnectTimeout,
                                        @Value("${api.pna.timeout.socket}") Integer apiSocketTimeout,
                                        @Value("${api.pna.jks}") String jks) throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException, KeyManagementException, IOException {

        return getRestTemplate(apiSSLEnable, apiKeystorePath, apiKeystorePass,
                apiConnectTimeout, apiSocketTimeout, jks);
    }

    @Bean("xgfeRestTemplate")
    public RestTemplate xgfeRestTemplate(@Value("${api.xgfe.ssl.enable}") Boolean apiSSLEnable,
                                         @Value("${api.xgfe.keystore.path}") String apiKeystorePath,
                                         @Value("${api.xgfe.keystore.pass}") String apiKeystorePass,
                                         @Value("${api.xgfe.timeout.connect}") Integer apiConnectTimeout,
                                         @Value("${api.xgfe.timeout.socket}") Integer apiSocketTimeout,
                                         @Value("${api.xgfe.jks}") String jks) throws CertificateException,
            UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException, KeyManagementException, IOException {

        return getRestTemplate(apiSSLEnable, apiKeystorePath, apiKeystorePass,
                apiConnectTimeout, apiSocketTimeout, jks);
    }

    @Bean("alphaSearchRestTemplate")
    public RestTemplate alphaSearchRestTemplate(@Value("${api.alpha-search.ssl.enable}") Boolean apiSSLEnable,
                                                @Value("${api.alpha-search.keystore.path}") String apiKeystorePath,
                                                @Value("${api.alpha-search.keystore.pass}") String apiKeystorePass,
                                                @Value("${api.alpha-search.timeout.connect}") Integer apiConnectTimeout,
                                                @Value("${api.alpha-search.timeout.socket}") Integer apiSocketTimeout,
                                                @Value("${api.alpha-search.jks}") String jks) throws CertificateException,
            UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException, KeyManagementException, IOException {
        return getRestTemplate(apiSSLEnable, apiKeystorePath, apiKeystorePass,
                apiConnectTimeout, apiSocketTimeout, jks);
    }

    @Bean("perLifeRestTemplate")
    public RestTemplate perLifeRestTemplate(@Value("${api.per-life.ssl.enable}") Boolean apiSSLEnable,
                                            @Value("${api.per-life.keystore.path}") String apiKeystorePath,
                                            @Value("${api.per-life.keystore.pass}") String apiKeystorePass,
                                            @Value("${api.per-life.timeout.connect}") Integer apiConnectTimeout,
                                            @Value("${api.per-life.timeout.socket}") Integer apiSocketTimeout,
                                            @Value("${api.per-life.jks}") String jks) throws CertificateException,
            UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException, KeyManagementException, IOException {
        return getRestTemplate(apiSSLEnable, apiKeystorePath, apiKeystorePass,
                apiConnectTimeout, apiSocketTimeout, jks);
    }

    @Bean("bewsRestTemplate")
    public RestTemplate bewsRestTemplate(@Value("${api.bews.ssl.enable}") Boolean apiSSLEnable,
                                         @Value("${api.bews.keystore.path}") String apiKeystorePath,
                                         @Value("${api.bews.keystore.pass}") String apiKeystorePass,
                                         @Value("${api.bews.timeout.connect}") Integer apiConnectTimeout,
                                         @Value("${api.bews.timeout.socket}") Integer apiSocketTimeout,
                                         @Value("${api.bews.jks}") String jks) throws CertificateException,
            UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException, KeyManagementException, IOException {

        return getRestTemplate(apiSSLEnable, apiKeystorePath, apiKeystorePass,
                apiConnectTimeout, apiSocketTimeout, jks);
    }

    @Bean("commonTokenRestTemplate")
    public RestTemplate commonTokenRestTemplate(@Value("${api.common-token.ssl.enable}") Boolean apiSSLEnable,
                                                @Value("${api.common-token.keystore.path}") String apiKeystorePath,
                                                @Value("${api.common-token.keystore.pass}") String apiKeystorePass,
                                                @Value("${api.common-token.timeout.connect}") Integer apiConnectTimeout,
                                                @Value("${api.common-token.timeout.socket}") Integer apiSocketTimeout,
                                                @Value("${api.common-token.jks}") String jks) throws CertificateException,
            UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException, KeyManagementException, IOException {

        return getRestTemplate(apiSSLEnable, apiKeystorePath, apiKeystorePass,
                apiConnectTimeout, apiSocketTimeout, jks);
    }

    private RestTemplate getRestTemplate(boolean apiSSLEnable, String apiKeystorePath, String apiKeystorePass,
                                         Integer apiConnectTimeout, Integer apiSocketTimeout, String jks)
            throws KeyStoreException, IOException, NoSuchAlgorithmException, CertificateException, KeyManagementException,
            UnrecoverableKeyException {

        RestTemplate restTemplate = new RestTemplate();

        if (apiSSLEnable) {

            KeyStore keyStore = KeyStore.getInstance(jks);
            File key = ResourceUtils.getFile(apiKeystorePath);
            try (InputStream in = new FileInputStream(key)) {
                keyStore.load(in, apiKeystorePass.toCharArray());
            }

            SSLContext sslContext = SSLContextBuilder.create()
                    .loadKeyMaterial(keyStore, apiKeystorePass.toCharArray())
                    .loadTrustMaterial(null, new TrustSelfSignedStrategy()).build();

            RequestConfig requestConfig = RequestConfig.custom().setConnectTimeout(apiConnectTimeout * 1000)
                    .setSocketTimeout(apiSocketTimeout * 1000).build();

            HttpClient client = HttpClients.custom().setSSLContext(sslContext).setDefaultRequestConfig(requestConfig)
                    .build();

            restTemplate.setRequestFactory(new HttpComponentsClientHttpRequestFactory(client));

        } else {
            restTemplate.setRequestFactory(new HttpComponentsClientHttpRequestFactory());
        }

        restTemplate.setErrorHandler(new RestTemplateResponseErrorHandler());

        LoggingReqRespInterceptor loggingReqRespInterceptor = new LoggingReqRespInterceptor();
        restTemplate.getInterceptors().add(loggingReqRespInterceptor);

        return restTemplate;
    }
}
