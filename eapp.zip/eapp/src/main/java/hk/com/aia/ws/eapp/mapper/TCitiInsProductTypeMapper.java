package hk.com.aia.ws.eapp.mapper;

import hk.com.aia.ws.eapp.model.db.magnum.ipos.TCitiInsProductType;
import hk.com.aia.ws.eapp.model.request.ipos.TCitiInsProductTypeDto;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper
public interface TCitiInsProductTypeMapper {

    TCitiInsProductTypeMapper MAPPER = Mappers.getMapper(TCitiInsProductTypeMapper.class);

    List<TCitiInsProductType> mapToTCitiInsProductTypeList(List<TCitiInsProductTypeDto> tCitiInsProductTypeDto);

}
