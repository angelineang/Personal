package hk.com.aia.ws.eapp.model.db.magnum.ipos.idclass;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TContactHistoryId implements Serializable {

    private static final long serialVersionUID = 271684505125945773L;
    private String contactHistoryId;
    private String contactId;
    private String sqsQuotationId;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TContactHistoryId{");
        sb.append("contactHistoryId='").append(contactHistoryId).append('\'');
        sb.append(", contactId='").append(contactId).append('\'');
        sb.append(", sqsQuotationId='").append(sqsQuotationId).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
