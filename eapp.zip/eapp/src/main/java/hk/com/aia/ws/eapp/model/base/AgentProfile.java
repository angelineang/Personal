package hk.com.aia.ws.eapp.model.base;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class AgentProfile extends Payload {

    @JsonProperty("rtn_code")
    private String rtnCode;

    @JsonProperty("error_msg")
    private String errorMsg;

    @JsonProperty("login_id")
    private String loginId;

    @JsonProperty("agt_code")
    private String agtCode;

    @JsonProperty("agt_name")
    private String agtName;

    @JsonProperty("agt_type")
    private String agtType;

    @JsonProperty("agt_last_name")
    private String agtLastName;

    @JsonProperty("agt_first_name")
    private String agtFirstName;

    @JsonProperty("agt_chinese_name")
    private String agtChineseName;

    @JsonProperty("agy_code")
    private String agyCode;

    @JsonProperty("agy_name")
    private String agyName;

    @JsonProperty("leader")
    private String leader;

    @JsonProperty("agt_title")
    private String agtTitle;

    @JsonProperty("agt_level")
    private String agtLevel;

    @JsonProperty("status")
    private String status;

    @JsonProperty("areacode")
    private String areacode;

    @JsonProperty("team_code")
    private String teamCode;

    @JsonProperty("contract_date")
    private String contractDate;

    @JsonProperty("mobile")
    private String mobile;

    @JsonProperty("phone")
    private String phone;

    @JsonProperty("fax_no")
    private String faxNo;

    @JsonProperty("email")
    private String email;

    @JsonProperty("esubmission_ind")
    private String esubmissionInd;

    @JsonProperty("access_code")
    private String accessCode;

    @JsonProperty("secretary_code")
    private String secretaryCode;

    @JsonProperty("alias_id")
    private String aliasId;

    @JsonProperty("user_group")
    private String userGroup;

    @JsonProperty("channel_name")
    private String channelName;

    @JsonProperty("channel_code")
    private String channelCode;

    @JsonProperty("location")
    private String location;

    @JsonProperty("address")
    private String address;

    @JsonProperty("ipad_access")
    private String ipadAccess;

    @JsonProperty("web_access")
    private String webAccess;

    @JsonProperty("pgs_access")
    private String pgsAccess;

    @JsonProperty("reg_no")
    private String regNo;

    @JsonProperty("leader_code")
    private String leaderCode;

    @JsonProperty("unit_agycode")
    private String unitAgycode;

    @JsonProperty("unit_agtcode")
    private String unitAgtcode;

    @JsonProperty("dist_agycode")
    private String distAgycode;

    @JsonProperty("dist_agtcode")
    private String distAgtcode;

    @JsonProperty("staff")
    private String staff;

    @JsonProperty("tr_mobile")
    private String trMobile;

    @JsonProperty("tr_user_type")
    private String trUserType;

    @JsonProperty("dist_name")
    private String distName;

    @JsonProperty("mpf_reg_no")
    private String mpfRegNo;

    @JsonProperty("christian_name")
    private String christianName;

    @JsonProperty("office_address")
    private String officeAddress;

    @JsonProperty("agt_mobile")
    private String agtMobile;

    @JsonProperty("id")
    private String id;

    @JsonProperty("nonmed_desc")
    private String nonmedDesc;

    @JsonProperty("zone")
    private String zone;

    @JsonProperty("res_phone")
    private String resPhone;

    @JsonProperty("per_email")
    private String perEmail;

    @JsonProperty("broker_email")
    private String brokerEmail;

    @JsonProperty("staff_email")
    private String staffEmail;

    @JsonProperty("tr_app_access")
    private String trAppAccess;

    @JsonProperty("staff_name")
    private String staffName;

    @JsonProperty("otp_mobile")
    private String otpMobile;

    @JsonProperty("old_reg_no")
    private String oldRegNo;

    @JsonProperty("sas_location")
    private String sasLocation;

    @JsonProperty("sas_address")
    private String sasAddress;

    @JsonProperty("sas_location_chi")
    private String sasLocationChi;

    @JsonProperty("sas_address_chi")
    private String sasAddressChi;

    @JsonProperty("office_address_chi")
    private String officeAddressChi;

    @JsonProperty("das_agt_type")
    private String dasAgtType;

    @JsonProperty("comp_title")
    private String compTitle;

    @JsonProperty("ro_name")
    private String roName;

    @JsonProperty("scode_auth")
    private String scodeAuth;

    @JsonProperty("tr_title")
    private String trTitle;

    @JsonProperty("dob")
    private String dob;

    @JsonProperty("sex")
    private String sex;

    @JsonProperty("scode_type")
    private String scodeType;

    @JsonProperty("scode_email")
    private String scodeEmail;

    @JsonProperty("eac_level")
    private String eacLevel;

    @JsonProperty("ifa_level")
    private String ifaLevel;

    @JsonProperty("staff_id")
    private String staffId;

    @JsonProperty("staff_eac_level")
    private String staffEacLevel;

    @JsonProperty("staff_ifa_level")
    private String staffIfaLevel;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("AgentProfile{");
        sb.append("rtnCode='").append(rtnCode).append('\'');
        sb.append(", errorMsg='").append(errorMsg).append('\'');
        sb.append(", loginId='").append(loginId).append('\'');
        sb.append(", agtCode='").append(agtCode).append('\'');
        sb.append(", agtName='").append(ConversionHandler.mask(agtName)).append('\'');
        sb.append(", agtType='").append(agtType).append('\'');
        sb.append(", agtLastName='").append(ConversionHandler.mask(agtLastName)).append('\'');
        sb.append(", agtFirstName='").append(ConversionHandler.mask(agtFirstName)).append('\'');
        sb.append(", agtChineseName='").append(ConversionHandler.mask(agtChineseName)).append('\'');
        sb.append(", agyCode='").append(agyCode).append('\'');
        sb.append(", agyName='").append(ConversionHandler.mask(agyName)).append('\'');
        sb.append(", leader='").append(leader).append('\'');
        sb.append(", agtTitle='").append(agtTitle).append('\'');
        sb.append(", agtLevel='").append(agtLevel).append('\'');
        sb.append(", status='").append(status).append('\'');
        sb.append(", areacode='").append(areacode).append('\'');
        sb.append(", teamCode='").append(teamCode).append('\'');
        sb.append(", contractDate='").append(contractDate).append('\'');
        sb.append(", mobile='").append(ConversionHandler.mask(mobile)).append('\'');
        sb.append(", phone='").append(ConversionHandler.mask(phone)).append('\'');
        sb.append(", faxNo='").append(ConversionHandler.mask(faxNo)).append('\'');
        sb.append(", email='").append(ConversionHandler.mask((email))).append('\'');
        sb.append(", esubmissionInd='").append(esubmissionInd).append('\'');
        sb.append(", accessCode='").append(accessCode).append('\'');
        sb.append(", secretaryCode='").append(secretaryCode).append('\'');
        sb.append(", aliasId='").append(aliasId).append('\'');
        sb.append(", userGroup='").append(userGroup).append('\'');
        sb.append(", channelName='").append(channelName).append('\'');
        sb.append(", channelCode='").append(channelCode).append('\'');
        sb.append(", location='").append(location).append('\'');
        sb.append(", address='").append(address).append('\'');
        sb.append(", ipadAccess='").append(ipadAccess).append('\'');
        sb.append(", webAccess='").append(webAccess).append('\'');
        sb.append(", pgsAccess='").append(pgsAccess).append('\'');
        sb.append(", regNo='").append(regNo).append('\'');
        sb.append(", leaderCode='").append(leaderCode).append('\'');
        sb.append(", unitAgycode='").append(unitAgycode).append('\'');
        sb.append(", unitAgtcode='").append(unitAgtcode).append('\'');
        sb.append(", distAgycode='").append(distAgycode).append('\'');
        sb.append(", distAgtcode='").append(distAgtcode).append('\'');
        sb.append(", staff='").append(staff).append('\'');
        sb.append(", trMobile='").append(ConversionHandler.mask(trMobile)).append('\'');
        sb.append(", trUserType='").append(trUserType).append('\'');
        sb.append(", distName='").append(distName).append('\'');
        sb.append(", mpfRegNo='").append(mpfRegNo).append('\'');
        sb.append(", christianName='").append(ConversionHandler.mask(christianName)).append('\'');
        sb.append(", officeAddress='").append(officeAddress).append('\'');
        sb.append(", agtMobile='").append(ConversionHandler.mask(agtMobile)).append('\'');
        sb.append(", id='").append(ConversionHandler.mask(id)).append('\'');
        sb.append(", nonmedDesc='").append(nonmedDesc).append('\'');
        sb.append(", zone='").append(zone).append('\'');
        sb.append(", resPhone='").append(ConversionHandler.mask(resPhone)).append('\'');
        sb.append(", perEmail='").append(ConversionHandler.mask(perEmail)).append('\'');
        sb.append(", brokerEmail='").append(ConversionHandler.mask(brokerEmail)).append('\'');
        sb.append(", staffEmail='").append(ConversionHandler.mask(staffEmail)).append('\'');
        sb.append(", trAppAccess='").append(trAppAccess).append('\'');
        sb.append(", staffName='").append(ConversionHandler.mask(staffName)).append('\'');
        sb.append(", otpMobile='").append(otpMobile).append('\'');
        sb.append(", oldRegNo='").append(oldRegNo).append('\'');
        sb.append(", sasLocation='").append(sasLocation).append('\'');
        sb.append(", sasAddress='").append(sasAddress).append('\'');
        sb.append(", sasLocationChi='").append(sasLocationChi).append('\'');
        sb.append(", sasAddressChi='").append(sasAddressChi).append('\'');
        sb.append(", officeAddressChi='").append(officeAddressChi).append('\'');
        sb.append(", dasAgtType='").append(dasAgtType).append('\'');
        sb.append(", compTitle='").append(compTitle).append('\'');
        sb.append(", roName='").append(ConversionHandler.mask(roName)).append('\'');
        sb.append(", scodeAuth='").append(scodeAuth).append('\'');
        sb.append(", trTitle='").append(trTitle).append('\'');
        sb.append(", dob='").append(ConversionHandler.mask(dob)).append('\'');
        sb.append(", sex='").append(sex).append('\'');
        sb.append(", scodeType='").append(scodeType).append('\'');
        sb.append(", scodeEmail='").append(ConversionHandler.mask(scodeEmail)).append('\'');
        sb.append(", eacLevel='").append(eacLevel).append('\'');
        sb.append(", ifaLevel='").append(ifaLevel).append('\'');
        sb.append(", staffId='").append(staffId).append('\'');
        sb.append(", staffEacLevel='").append(staffEacLevel).append('\'');
        sb.append(", staffIfaLevel='").append(staffIfaLevel).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
