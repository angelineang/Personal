package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import lombok.Data;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "T_EAPPSPECIALREQ")
public class TEappSpecialReq {

    @Column(name = "EAPPSPECIALREQID", length = 60)
    @Id
    private String eappSpecialReqId;

    @Column(name = "EAPPID", length = 60)
    private String eappId;

    @Column(name = "ISPOLEFFECTIVEDATEFR")
    private Integer isPolEffectiveDateFr;

    @Column(name = "POLEFFECTIVEDATEFR")
    @Temporal(TemporalType.DATE)
    private Date polEffectiveDateFr;

    @Column(name = "ISENCONTRACT")
    private Integer isEnContract;

    @Column(name = "ISTERMCONVERSION")
    private Integer isTermConversion;

    @Column(name = "FROMPOLICYNO", length = 10)
    private String fromPolicyNo;

    @Column(name = "CONVERTEDPLANNAME", length = 150)
    private String convertedPlanName;

    @Column(name = "CONVERTEDAMT")
    private BigDecimal convertedAmt;

    @Column(name = "REMAININGAMT")
    private Integer remainingAmt;

    @Column(name = "CIRCONVERTEDAMT")
    private BigDecimal cirConvertedAmt;

    @Column(name = "CIRREMAININGAMT")
    private BigDecimal cirRemainingAmt;

    @Column(name = "OTHERS")
    private String others;

    @Column(name = "CREATEDBY", length = 10, updatable = false)
    @CreatedBy
    private String createdBy;

    @Column(name = "UPDATEDBY", length = 10)
    @LastModifiedBy
    private String updatedBy;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "LASTUPDATEDATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    @LastModifiedDate
    private Date lastUpdateDateTime;

    @Column(name = "MAINPOLNO", length = 10)
    private String mainPolNo;

    @Column(name = "EINVEST")
    private Integer eInvest;

    @Column(name = "PROMOTIONCODE", length = 20)
    private String promotionCode;

    @Column(name = "isPolicyContract")
    private Integer isPolicyContract;

    @Column(name = "IsIssueDate", length = 10)
    private String IsIssueDate;

    @Column(name = "ISPCP2SIOADULT")
    private Integer isPcp2SioAdult;

    @Column(name = "ISPCP2GIOADULT")
    private Integer isPcp2GioAdult;

    @Column(name = "ISPCP2SIOCHILD")
    private Integer isPcp2SioChild;

    @Column(name = "ISPCP2GIOCHILD")
    private Integer isPcp2GioChild;

    @Column(name = "SELECTEDOPTIONSTRING", length = 10)
    private String selectedOptionString;

    @Column(name = "REFERRALCODE", length = 30)
    private String referralCode;

    @Column(name = "isSelectCPS")
    private Integer isSelectCPS;

    @Column(name = "isAcceptCPSLoanRate")
    private Integer isAcceptCPSLoanRate;

    @Column(name = "isAcceptCPSTerms")
    private Integer isAcceptCPSTerms;

    @Column(name = "transferOutPolicyNum", length = 20)
    private String transferOutPolicyNum;

    @Column(name = "ISAPPLYPF")
    private Integer isApplyPf;

    @Column(name = "ISSTAFFPLAN")
    private Integer isStaffPlan;

    @Column(name = "ISRECAPTURE")
    private Integer isRecapture;

//    Uncomment EAPP-348 from Prod Image
    @Column(name = "isContactAddress")
    private Integer isContactAddress;

    @Column(name = "isContactTell")
    private Integer isContactTell;

    @Column(name = "isContactEmail")
    private Integer isContactEmail;


    @Column(name = "REFERRERPOLNO")
    private String referrerPolNo;

    @Column(name = "REFERRERDECLCONFIRM")
    private Integer referrerDeclConfirm;

    @Column(name = "ISEARLYMATURITY")
    private Integer isEarlyMaturity;

    @Column(name = "REFAGYCODE")
    private String refAgencyCode;
    
    @Column(name = "REFAGTCODE")
    private String refAgentCode;
    
    @Column(name = "ISJMOFFER")
    private Integer isJMOffer;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TEappSpecialReq{");
        sb.append("eappSpecialReqId='").append(eappSpecialReqId).append('\'');
        sb.append(", eappId='").append(eappId).append('\'');
        sb.append(", isPolEffectiveDateFr=").append(isPolEffectiveDateFr);
        sb.append(", polEffectiveDateFr=").append(polEffectiveDateFr);
        sb.append(", isEnContract=").append(isEnContract);
        sb.append(", isTermConversion=").append(isTermConversion);
        sb.append(", fromPolicyNo='").append(fromPolicyNo).append('\'');
        sb.append(", convertedPlanName='").append(convertedPlanName).append('\'');
        sb.append(", convertedAmt=").append(convertedAmt);
        sb.append(", remainingAmt=").append(remainingAmt);
        sb.append(", cirConvertedAmt=").append(cirConvertedAmt);
        sb.append(", cirRemainingAmt=").append(cirRemainingAmt);
        sb.append(", others='").append(others).append('\'');
        sb.append(", createdBy='").append(createdBy).append('\'');
        sb.append(", updatedBy='").append(updatedBy).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", lastUpdateDateTime=").append(lastUpdateDateTime);
        sb.append(", mainPolNo='").append(mainPolNo).append('\'');
        sb.append(", eInvest=").append(eInvest);
        sb.append(", promotionCode='").append(promotionCode).append('\'');
        sb.append(", isPolicyContract=").append(isPolicyContract);
        sb.append(", IsIssueDate='").append(IsIssueDate).append('\'');
        sb.append(", isPcp2SioAdult=").append(isPcp2SioAdult);
        sb.append(", isPcp2GioAdult=").append(isPcp2GioAdult);
        sb.append(", isPcp2SioChild=").append(isPcp2SioChild);
        sb.append(", isPcp2GioChild=").append(isPcp2GioChild);
        sb.append(", selectedOptionString='").append(selectedOptionString).append('\'');
        sb.append(", referralCode='").append(referralCode).append('\'');
        sb.append(", isSelectCPS=").append(isSelectCPS);
        sb.append(", isAcceptCPSLoanRate=").append(isAcceptCPSLoanRate);
        sb.append(", isAcceptCPSTerms=").append(isAcceptCPSTerms);
        sb.append(", transferOutPolicyNum='").append(transferOutPolicyNum).append('\'');
        sb.append(", isApplyPf=").append(isApplyPf);
        sb.append(", isStaffPlan=").append(isStaffPlan);
        sb.append(", isRecapture=").append(isRecapture);
        sb.append(", isContactAddress='").append(isContactAddress).append('\'');
        sb.append(", isContactTell='").append(isContactTell).append('\'');
        sb.append(", isContactEmail='").append(isContactEmail).append('\'');
        sb.append(", referrerPolNo=").append(referrerPolNo);
        sb.append(", referrerDeclConfirm=").append(referrerDeclConfirm);
        sb.append(", isEarlyMaturity=").append(isEarlyMaturity);
        sb.append(", refAgencyCode=").append(refAgencyCode);
        sb.append(", refAgentCode=").append(refAgentCode);
        sb.append(", isJMOffer=").append(isJMOffer);
        sb.append('}');
        return sb.toString();
    }
}
