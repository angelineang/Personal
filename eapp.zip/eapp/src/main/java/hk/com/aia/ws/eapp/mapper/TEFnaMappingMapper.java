package hk.com.aia.ws.eapp.mapper;

import hk.com.aia.ws.eapp.model.db.magnum.ipos.TEFnaMapping;
import hk.com.aia.ws.eapp.model.request.ipos.TEfnaMappingDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper
public interface TEFnaMappingMapper {

    TEFnaMappingMapper MAPPER = Mappers.getMapper(TEFnaMappingMapper.class);

    @Mappings({
            @Mapping(target = "createBy", ignore = true),
            @Mapping(target = "createdDateTime", ignore = true)})
    List<TEFnaMapping> mapToTEFnaMappingList(List<TEfnaMappingDto> tEFnaMappingDto);
}
