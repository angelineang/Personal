package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import hk.com.aia.ws.eapp.util.ConversionHandler;
import lombok.Data;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "T_EAPP")
public class TEapp {

    @Column(name = "EAPPID", length = 60)
    @Id
    private String eappId;

    @Column(name = "POLICYNO", length = 10)
    private String policyNo;

    @Column(name = "POLICYCURRENCY", length = 3)
    private String policyCurrency;

    @Column(name = "POLICYLANGUAGE", length = 10)
    private String policyLanguage;

    @Column(name = "EREFERENCENO", length = 60)
    private String eReferenceNo;

    @Column(name = "AGENTCODE1", length = 5)
    private String agentCode1;

    @Column(name = "AGENTNAME1", length = 120)
    private String agentName1;

    @Column(name = "AGENTCODE2", length = 5)
    private String agentCode2;

    @Column(name = "AGENTNAME2", length = 35)
    private String agentName2;

    @Column(name = "AGENCYCODE", length = 5)
    private String agencyCode;

    @Column(name = "AGENCYNAME", length = 120)
    private String agencyName;

    @Column(name = "AREACODE", length = 2)
    private String areaCode;

    @Column(name = "ACCESSCODE", length = 30)
    private String accessCode;

    @Column(name = "PAYMENTMODE", length = 20)
    private String paymentMode;

    @Column(name = "ISAUTOPAY")
    private Integer isAutoPay;

    @Column(name = "INITIALPAYMENTCURR", length = 3)
    private String initialPaymentCurr;

    @Column(name = "INITIALPAYMENTAMT")
    private BigDecimal initialPaymentAmt;

    @Column(name = "INITIALPAYMENTMONTHS")
    private Integer initialPaymentMonths;

    @Column(name = "ISFHCCOMPLETED")
    private Integer isFhcCompleted;

    @Column(name = "FHCINCOMPREASON", length = 255)
    private String fhcInCompReason;

    @Column(name = "ISACCEPTDECLAR")
    private Integer isAcceptDeclar;

    @Column(name = "EAPPSIGNEDAT", length = 20)
    private String eappSigneDat;

    @Column(name = "EAPPSIGNEDDATE")
    @Temporal(TemporalType.DATE)
    private Date eappSignedDate;

    @Column(name = "AGENTSIGNEDAT", length = 20)
    private String agentSigneDat;

    @Column(name = "AGENTSIGNEDDATE")
    @Temporal(TemporalType.DATE)
    private Date agentSignedDate;

    @Column(name = "PAYMENTTYPE", length = 20)
    private String paymentType;

    @Column(name = "ISPERSONALDATAFORMAKETING")
    private Integer isPersonalDataForMarketing;

    @Column(name = "VERSIONNO", length = 30)
    private String versionNo;

    @Column(name = "CREATEDBY", length = 10, updatable = false)
    @CreatedBy
    private String createdBy;

    @Column(name = "UPDATEDBY", length = 10)
    @LastModifiedBy
    private String updatedBy;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "LASTUPDATEDATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    @LastModifiedDate
    private Date lastUpdateDateTime;

    @Column(name = "ISSELECTAPPLICANT")
    private Integer isSelectApplicant;

    @Column(name = "ISSELECTINSURED")
    private Integer isSelectInsured;

    @Column(name = "APPLICATIONFORMTYPE", length = 10)
    private String applicationFormType;

    @Column(name = "MEDICAL", length = 20)
    private String medical;

    @Column(name = "DIVIDENDSOPTION", length = 20)
    private String dividendsOption;

    @Column(name = "ILPEINVESTCHECKED")
    private Integer ilpeInvestChecked;

    @Column(name = "ILPDCACHECKED", length = 4)
    private Integer ilpdcaChecked;

    @Column(name = "ILPDCAAMOUNT")
    private BigDecimal ilpdcaAmount;

    @Column(name = "FNAANSWERID", length = 60)
    private String fnaAnswerId;

    @Column(name = "RPQANSWERID", length = 60)
    private String rpqAnswerId;

    @Column(name = "DECLARATIONANSWERID", length = 60)
    private String declarationAnswerId;

    @Column(name = "FHCREASON", length = 1050)
    private String fhcReason;

    @Column(name = "APPLYVITALITY")
    private Integer applyVitality;

    @Column(name = "CHANNELCODE", length = 20)
    private String channelCode;

    @Column(name = "USERGROUP", length = 20)
    private String userGroup;

    @Column(name = "PLATFORM", length = 20)
    private String platform;

    @Column(name = "ISFNA")
    private Integer isFna;

    @Column(name = "CIES")
    private Integer cies;

    @Column(name = "RPQTOTALSCORE")
    private Integer rpqTotalScore;

    @Column(name = "FNASIGNEDDATE")
    @Temporal(TemporalType.DATE)
    private Date fnAsignedDate;

    @Column(name = "PGSSIGNEDDATE")
    @Temporal(TemporalType.DATE)
    private Date pgsSignedDate;

    @Column(name = "IPOS_CREATEDDATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date iposCreatedDateTime;

    @Column(name = "IPOS_LASTUPDATEDDATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date iposLastUpdatedDateTime;

    @Column(name = "MATURITY_POLICYNO", length = 10)
    private String maturityPolicyNo;

    @Column(name = "IFSPRCSIGNEDDATE")
    @Temporal(TemporalType.DATE)
    private Date ifsPrcSignedDate;

    @Column(name = "MAGNUMCASE", length = 1)
    private String magnumCase;

    @Column(name = "ISPRCCASE", length = 1)
    private String isPrcCase;

    @Column(name = "doc_cnt")
    private Integer docCnt;

    @Column(name = "handInputPolicyNo", length = 5)
    private String handInputPolicyNo;

    @Column(name = "isVitalityDataForMarketing")
    private Integer isVitalityDataForMarketing;

    @Column(name = "SUBMIT_TYPE", length = 20)
    private String submitType;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TEapp{");
        sb.append("eappId='").append(eappId).append('\'');
        sb.append(", policyNo='").append(ConversionHandler.mask(policyNo)).append('\'');
        sb.append(", policyCurrency='").append(policyCurrency).append('\'');
        sb.append(", policyLanguage='").append(policyLanguage).append('\'');
        sb.append(", eReferenceNo='").append(eReferenceNo).append('\'');
        sb.append(", agentCode1='").append(agentCode1).append('\'');
        sb.append(", agentName1='").append(agentName1).append('\'');
        sb.append(", agentCode2='").append(agentCode2).append('\'');
        sb.append(", agentName2='").append(agentName2).append('\'');
        sb.append(", agencyCode='").append(agencyCode).append('\'');
        sb.append(", agencyName='").append(agencyName).append('\'');
        sb.append(", areaCode='").append(areaCode).append('\'');
        sb.append(", accessCode='").append(accessCode).append('\'');
        sb.append(", paymentMode='").append(paymentMode).append('\'');
        sb.append(", isAutoPay=").append(isAutoPay);
        sb.append(", initialPaymentCurr='").append(initialPaymentCurr).append('\'');
        sb.append(", initialPaymentAmt=").append(initialPaymentAmt);
        sb.append(", initialPaymentMonths=").append(initialPaymentMonths);
        sb.append(", isFhcCompleted=").append(isFhcCompleted);
        sb.append(", fhcInCompReason='").append(fhcInCompReason).append('\'');
        sb.append(", isAcceptDeclar=").append(isAcceptDeclar);
        sb.append(", eappSigneDat='").append(eappSigneDat).append('\'');
        sb.append(", eappSignedDate=").append(eappSignedDate);
        sb.append(", agentSigneDat='").append(agentSigneDat).append('\'');
        sb.append(", agentSignedDate=").append(agentSignedDate);
        sb.append(", paymentType='").append(paymentType).append('\'');
        sb.append(", isPersonalDataForMarketing=").append(isPersonalDataForMarketing);
        sb.append(", versionNo='").append(versionNo).append('\'');
        sb.append(", createdBy='").append(createdBy).append('\'');
        sb.append(", updatedBy='").append(updatedBy).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", lastUpdateDateTime=").append(lastUpdateDateTime);
        sb.append(", isSelectApplicant=").append(isSelectApplicant);
        sb.append(", isSelectInsured=").append(isSelectInsured);
        sb.append(", applicationFormType='").append(applicationFormType).append('\'');
        sb.append(", medical='").append(medical).append('\'');
        sb.append(", dividendsOption='").append(dividendsOption).append('\'');
        sb.append(", ilpeInvestChecked=").append(ilpeInvestChecked);
        sb.append(", ilpdcaChecked=").append(ilpdcaChecked);
        sb.append(", ilpdcaAmount=").append(ilpdcaAmount);
        sb.append(", fnaAnswerId='").append(fnaAnswerId).append('\'');
        sb.append(", rpqAnswerId='").append(rpqAnswerId).append('\'');
        sb.append(", declarationAnswerId='").append(declarationAnswerId).append('\'');
        sb.append(", fhcReason='").append(fhcReason).append('\'');
        sb.append(", applyVitality=").append(applyVitality);
        sb.append(", channelCode='").append(channelCode).append('\'');
        sb.append(", userGroup='").append(userGroup).append('\'');
        sb.append(", platform='").append(platform).append('\'');
        sb.append(", isFna=").append(isFna);
        sb.append(", cies=").append(cies);
        sb.append(", rpqTotalScore=").append(rpqTotalScore);
        sb.append(", fnAsignedDate=").append(fnAsignedDate);
        sb.append(", pgsSignedDate=").append(pgsSignedDate);
        sb.append(", iposCreatedDateTime=").append(iposCreatedDateTime);
        sb.append(", iposLastUpdatedDateTime=").append(iposLastUpdatedDateTime);
        sb.append(", maturityPolicyNo='").append(maturityPolicyNo).append('\'');
        sb.append(", ifsPrcSignedDate=").append(ifsPrcSignedDate);
        sb.append(", magnumCase='").append(magnumCase).append('\'');
        sb.append(", isPrcCase='").append(isPrcCase).append('\'');
        sb.append(", docCnt=").append(docCnt);
        sb.append(", handInputPolicyNo='").append(handInputPolicyNo).append('\'');
        sb.append(", isVitalityDataForMarketing=").append(isVitalityDataForMarketing);
        sb.append(", submitType=").append(submitType);
        sb.append('}');
        return sb.toString();
    }
}


