package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@ApiModel(value = "Flow Model")
@Getter
@Setter
public class Flow extends Payload{

    // Size max determined by maximum allowed by stored procedure - db_magnum..po_eapp_chk_src_ind

    @ApiModelProperty(value = "Agent Code")
    @JsonProperty("agent_code")
    @Size(max = 5)
    private String agentCode;

    @ApiModelProperty(value = "Submit Channel", required = true)
    @JsonProperty("submit_channel")
    @Size(max = 10)
    @NotBlank
    private String submitChannel;

    @ApiModelProperty(value = "Policy Number")
    @JsonProperty("policy_no")
    @Size(min =10 , max = 10)
    private String policyNo;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Flow{");
        sb.append("agentCode='").append(agentCode).append('\'');
        sb.append(", submitChannel='").append(submitChannel).append('\'');
        sb.append(", policyNo='").append(ConversionHandler.mask(policyNo)).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
