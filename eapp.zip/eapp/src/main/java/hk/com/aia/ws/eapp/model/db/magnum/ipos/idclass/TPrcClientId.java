package hk.com.aia.ws.eapp.model.db.magnum.ipos.idclass;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TPrcClientId implements Serializable {
    private static final long serialVersionUID = 4337560255041623336L;
    private String iverifyId;
    private String clientID;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TPrcClientId{");
        sb.append("iverifyId='").append(iverifyId).append('\'');
        sb.append(", clientID='").append(clientID).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
