package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class IVerifyDocSubmit extends Payload {

    @JsonProperty("iverify_id")
    @NotBlank
    private String iVerifyId;

    @JsonProperty("policy_no")
    @NotBlank
    private String policyNo;

    @JsonProperty("code")
    private String code;

    @JsonProperty("message")
    private String message;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("IVerifyDocSubmit{");
        sb.append("iVerifyId='").append(iVerifyId).append('\'');
        sb.append(", policyNo='").append(ConversionHandler.mask(policyNo)).append('\'');
        sb.append(", code='").append(code).append('\'');
        sb.append(", message='").append(message).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
