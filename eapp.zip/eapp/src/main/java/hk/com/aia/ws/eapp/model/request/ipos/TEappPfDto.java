package hk.com.aia.ws.eapp.model.request.ipos;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.Date;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import static hk.com.aia.ws.eapp.constant.Constants.TIMEZONE;

@ApiModel(value = "T_EAPP_PF Model")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TEappPfDto {

	@ApiModelProperty(value = "eappId", required = true)
    @JsonProperty("eappId")
	@NotBlank
    private String eappId;

    @JsonProperty("usePf")
    private String usePf;

    @JsonProperty("liquidAssets")
    private Double liquidAssets;

    @JsonProperty("pfAmount")
    private Double pfAmount;

    @JsonProperty("longLiability")
    private Double longLiability;

    @JsonProperty("shortLiability")
    private Double shortLiability;

    @JsonProperty("noPfReason")
    private String noPfReason;

    @JsonProperty("disclosePf")
    private String disclosePf;

    @JsonProperty("ifspfSelected")
    private String ifspfSelected;

    @JsonProperty("pfOption")
    private String pfOption;

    @JsonProperty("lenderName")
    private String lenderName;

    @JsonProperty("otherLender")
    private String otherLender;

    @JsonProperty("pfLoanAmount")
    private Double pfLoanAmount;

    @JsonProperty("pfInterestRate")
    private String pfInterestRate;

    @JsonProperty("pfItenor")
    private Integer pfItenor;
    
    @JsonProperty("pfpItenor")
    private Integer pfpItenor;


    @JsonProperty("tenorReason")
    private String tenorReason;

    @JsonProperty("pfRepaymentAmount")
    private Double pfRepaymentAmount;

    @JsonProperty("ifspfReceived")
    private String ifspfReceived;

    @JsonProperty("ifspfSignDate")
    private String ifspfSignDate;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TEappPf{");
        sb.append('}');
        return sb.toString();
    }
}