package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import hk.com.aia.ws.eapp.model.db.magnum.ipos.idclass.TEappTrusteeId;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import lombok.Data;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "T_EAPPTRUSTEE")
@IdClass(TEappTrusteeId.class)
public class TEappTrustee {

    @Column(name = "EAPPTRUSTEEID", length = 60)
    @Id
    private String eappTrusteeId;

    @Column(name = "EAPPID", length = 60)
    @Id
    private String eappId;

    @Column(name = "FULLNAME_EN", length = 101)
    private String fullNameEn;

    @Column(name = "NAME_CHN", length = 550)
    private String nameChn;

    @Column(name = "AGE")
    private Integer age;

    @Column(name = "IDCARDPASSPORTNO", length = 18)
    private String idCardPassportNo;

    @Column(name = "RELATIONSHIP", length = 2)
    private String relationship;

    @Column(name = "OTHERS", length = 255)
    private String others;

    @Column(name = "AGENTCODE", length = 10)
    private String agentCode;

    @Column(name = "ACCESSCODE", length = 10)
    private String accessCode;

    @Column(name = "CREATEDBY", length = 10,updatable = false)
    @CreatedBy
    private String createdBy;

    @Column(name = "UPDATEDBY", length = 10)
    @LastModifiedBy
    private String updatedBy;

    @Column(name = "CREATEDDATETIME",updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "LASTUPDATEDATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    @LastModifiedDate
    private Date lastUpdateDateTime;

    @Column(name = "dob")
    @Temporal(TemporalType.DATE)
    private Date dob;

    @Column(name = "gender", length = 10)
    private String gender;

    @Column(name = "idType", length = 20)
    private String idType;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TEappTrustee{");
        sb.append("eappTrusteeId='").append(eappTrusteeId).append('\'');
        sb.append(", eappId='").append(eappId).append('\'');
        sb.append(", fullNameEn='").append(ConversionHandler.mask(fullNameEn)).append('\'');
        sb.append(", nameChn='").append(ConversionHandler.mask(nameChn)).append('\'');
        sb.append(", age=").append(age);
        sb.append(", idCardPassportNo='").append(ConversionHandler.mask(idCardPassportNo)).append('\'');
        sb.append(", relationship='").append(relationship).append('\'');
        sb.append(", others='").append(others).append('\'');
        sb.append(", agentCode='").append(agentCode).append('\'');
        sb.append(", accessCode='").append(accessCode).append('\'');
        sb.append(", createdBy='").append(createdBy).append('\'');
        sb.append(", updatedBy='").append(updatedBy).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", lastUpdateDateTime=").append(lastUpdateDateTime);
        sb.append(", dob=").append(ConversionHandler.mask(dob));
        sb.append(", gender='").append(gender).append('\'');
        sb.append(", idType='").append(idType).append('\'');
        sb.append('}');
        return sb.toString();
    }
}


