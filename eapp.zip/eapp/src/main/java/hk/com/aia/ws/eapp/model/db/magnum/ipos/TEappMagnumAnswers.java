package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import hk.com.aia.ws.eapp.annotation.DataTruncation;
import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "T_EAPPMAGNUMANSWERS")
public class TEappMagnumAnswers {

    @Column(name = "EAPPMAGNUMANSWERID", length = 60)
    @Id
    private String eappMagnumAnswerid;

    @Column(name = "CONTACTID", length = 60)
    private String contactId;

    @Column(name = "EAPPID", length = 60)
    private String eappId;

    @Column(name = "FRIENDLYNAME", length = 1000)
    private String friendlyName;

    @Column(name = "QUESTIONID", length = 100)
    private String questionId;

    @Column(name = "QTYPE", length = 50)
    private String qType;

    @Column(name = "ANSWERS")
    @DataTruncation(max = 2000, validateByte = true, log = true)
    private String answers;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "QTEXT")
    private String qText;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TEappMagnumAnswers{");
        sb.append("eappMagnumAnswerid='").append(eappMagnumAnswerid).append('\'');
        sb.append(", contactId='").append(contactId).append('\'');
        sb.append(", eappId='").append(eappId).append('\'');
        sb.append(", friendlyName='").append(friendlyName).append('\'');
        sb.append(", questionId='").append(questionId).append('\'');
        sb.append(", qType='").append(qType).append('\'');
        sb.append(", answers='").append(answers).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", qText='").append(qText).append('\'');
        sb.append('}');
        return sb.toString();
    }
}