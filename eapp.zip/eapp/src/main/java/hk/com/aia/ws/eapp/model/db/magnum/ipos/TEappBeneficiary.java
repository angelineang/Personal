package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import hk.com.aia.ws.eapp.util.ConversionHandler;
import lombok.Data;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "T_EAPPBENEFICIARY")
public class TEappBeneficiary {

    @Column(name = "EAPPBENEFICIARYID", length = 60)
    @Id
    private String eappBeneficiaryId;

    @Column(name = "EAPPID", length = 60)
    private String eappId;

    @Column(name = "FULLNAME_EN", length = 200)
    private String fullNameEn;

    @Column(name = "NAME_CHN", length = 650)
    private String nameChn;

    @Column(name = "BENESEQUENCE")
    private Integer beneSequence;

    @Column(name = "AGE")
    private Integer age;

    @Column(name = "BENETYPE", length = 10)
    private String beneType;

    @Column(name = "BENESHARE")
    private Integer beneShare;

    @Column(name = "ISEQUALSHARE")
    private Integer isEqualShare;

    @Column(name = "ISOWNESTATE")
    private Integer isOwneState;

    @Column(name = "IDCARDPASSPORTNO", length = 18)
    private String idCardPassportNo;

    @Column(name = "RELATIONSHIP", length = 2)
    private String relationship;

    @Column(name = "OTHERS", length = 255)
    private String others;

    @Column(name = "OTHERSREASON", length = 255)
    private String othersReason;

    @Column(name = "CREATEDBY", length = 10, updatable = false)
    @CreatedBy
    private String createdBy;

    @Column(name = "UPDATEDBY", length = 10)
    @LastModifiedBy
    private String updatedBy;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "LASTUPDATEDATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    @LastModifiedDate
    private Date lastUpdateDateTime;

    @Column(name = "dob")
    @Temporal(TemporalType.DATE)
    private Date dob;

    @Column(name = "gender", length = 10)
    private String gender;

    @Column(name = "idType", length = 20)
    private String idType;

    @Column(name = "charityNumber", length = 50)
    private String charityNumber;

    @Column(name = "charityExistStatus", length = 4)
    private Integer charityExistStatus;

    @Column(name = "CONTINGENT_INSURE_RELATIONSHIP", length = 1)
    private String contingentInsureRelationship;

    @Column(name = "CONTINGENT_INSURE_RELATIONSHIP_OTHER", length = 500)
    private String contingentInsureRelationshipOther;

    @Column(name = "CONTINGENT_INSURE_RELATIONSHIP_OTHER_REASON", length = 500)
    private String contingentInsureRelationshipOtherReason;

    @Column(name = "isDesignedPerson", length = 10)
    private String isDesignedPerson;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TEappBeneficiary{");
        sb.append("eappBeneficiaryId='").append(eappBeneficiaryId).append('\'');
        sb.append(", eappId='").append(eappId).append('\'');
        sb.append(", fullNameEn='").append(ConversionHandler.mask(fullNameEn)).append('\'');
        sb.append(", nameChn='").append(ConversionHandler.mask(nameChn)).append('\'');
        sb.append(", beneSequence=").append(beneSequence);
        sb.append(", age=").append(age);
        sb.append(", beneType='").append(beneType).append('\'');
        sb.append(", beneShare=").append(beneShare);
        sb.append(", isEqualShare=").append(isEqualShare);
        sb.append(", isOwneState=").append(isOwneState);
        sb.append(", idCardPassportNo='").append(idCardPassportNo).append('\'');
        sb.append(", relationship='").append(relationship).append('\'');
        sb.append(", others='").append(others).append('\'');
        sb.append(", othersReason='").append(othersReason).append('\'');
        sb.append(", createdBy='").append(createdBy).append('\'');
        sb.append(", updatedBy='").append(updatedBy).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", lastUpdateDateTime=").append(lastUpdateDateTime);
        sb.append(", dob=").append(ConversionHandler.mask(dob));
        sb.append(", gender='").append(gender).append('\'');
        sb.append(", idType='").append(idType).append('\'');
        sb.append(", charityNumber='").append(charityNumber).append('\'');
        sb.append(", charityExistStatus=").append(charityExistStatus);
        sb.append(", contingentInsureRelationship='").append(contingentInsureRelationship).append('\'');
        sb.append(", contingentInsureRelationshipOther='").append(contingentInsureRelationshipOther).append('\'');
        sb.append(", contingentInsureRelationshipOtherReason='").append(contingentInsureRelationshipOtherReason).append('\'');
        sb.append(", isDesignedPerson='").append(isDesignedPerson).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
