package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;

@ApiModel(value = "PrcSearch Model")
@Getter
@Setter
public class PrcSearchResult extends Payload {
    @ApiModelProperty(value = "Search iverify record for iPOS,1  means Valid! Record found,0  means Invalid! Record not found ")
    @JsonProperty("prc_search_return_code")
    @NotBlank
    private String prcSearchReturnCode;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("PrcSearchResult{");
        sb.append("prcSearchReturnCode='").append(prcSearchReturnCode).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
