package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import hk.com.aia.ws.eapp.util.ConversionHandler;
import lombok.Data;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@Table(name = "T_ACCOUNTCARDOWNER")
@EntityListeners(AuditingEntityListener.class)
public class TAccountCardOwner {

    @Column(name = "ACCOUNTCARDOWNERID", length = 60)
    @Id
    private String accountCardOwnerId;

    @Column(name = "PAYMENTDETAILID", length = 60)
    private String paymentDetailId;

    @Column(name = "OWNERNAME", length = 100)
    private String ownerName;

    @Column(name = "IDDOCSEQUENCE")
    private Integer idDocSequence;

    @Column(name = "IDDOCTYPE", length = 1)
    private String idDocType;

    @Column(name = "IDDOCNAME", length = 30)
    private String idDocName;

    @Column(name = "IDDOCNO", length = 18)
    private String idDocNo;

    @Column(name = "RELATIONSHIP", length = 60)
    private String relationship;

    @Column(name = "RELATIONSHIPOTHERTEXT", length = 80)
    private String relationshipOtherText;

    @Column(name = "CREATEDBY", length = 10, updatable = false)
    @CreatedBy
    private String createdBy;

    @Column(name = "UPDATEDBY", length = 10)
    @LastModifiedBy
    private String updatedBy;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "LASTUPDATEDATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    @LastModifiedDate
    private Date lastUpdateDateTime;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TAccountCardOwner{");
        sb.append("accountCardOwnerId='").append(accountCardOwnerId).append('\'');
        sb.append(", paymentDetailId='").append(paymentDetailId).append('\'');
        sb.append(", ownerName='").append(ConversionHandler.mask(ownerName)).append('\'');
        sb.append(", idDocSequence=").append(idDocSequence);
        sb.append(", idDocType='").append(idDocType).append('\'');
        sb.append(", idDocName='").append(idDocName).append('\'');
        sb.append(", idDocNo='").append(idDocNo).append('\'');
        sb.append(", relationship='").append(relationship).append('\'');
        sb.append(", relationshipOtherText='").append(relationshipOtherText).append('\'');
        sb.append(", createdBy='").append(createdBy).append('\'');
        sb.append(", updatedBy='").append(updatedBy).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", lastUpdateDateTime=").append(lastUpdateDateTime);
        sb.append('}');
        return sb.toString();
    }
}
