package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import lombok.Data;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "T_IDCARD")
public class TIdCard {

    @Column(name = "IDCARDID", length = 60)
    @Id
    private String idCardId;

    @Column(name = "CONTACTID", length = 60)
    private String contactId;

    @Column(name = "IDTYPE", length = 12)
    private String idType;

    @Column(name = "IDCARDNUMBER")
    private String idCardNumber;

    @Column(name = "EXPIRYDATE")
    @Temporal(TemporalType.DATE)
    private Date expiryDate;

    @Column(name = "CREATEDBY", length = 10, updatable = false)
    @CreatedBy
    private String createdBy;

    @Column(name = "UPDATEDBY", length = 10)
    @LastModifiedBy
    private String updatedBy;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "LASTUPDATEDATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    @LastModifiedDate
    private Date lastUpdateDateTime;

    @Column(name = "expiryind", length = 10)
    private String expiryInd;

    @Column(name = "issuedate")
    @Temporal(TemporalType.DATE)
    private Date issueDate;
    
    @Column(name = "SMARTCARD")
    private String smartcard;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TIdCard{");
        sb.append("idCardId='").append(idCardId).append('\'');
        sb.append(", contactId='").append(contactId).append('\'');
        sb.append(", idType='").append(idType).append('\'');
        sb.append(", idCardNumber='").append(idCardNumber).append('\'');
        sb.append(", expiryDate=").append(expiryDate);
        sb.append(", createdBy='").append(createdBy).append('\'');
        sb.append(", updatedBy='").append(updatedBy).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", lastUpdateDateTime=").append(lastUpdateDateTime);
        sb.append(", expiryInd='").append(expiryInd).append('\'');
        sb.append(", issueDate=").append(issueDate);
        sb.append(", smartcard=").append(smartcard);
        sb.append('}');
        return sb.toString();
    }
}

