package hk.com.aia.ws.eapp.model.request.ipos;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.annotation.AllowedValuesIntValidation;
import hk.com.aia.ws.eapp.annotation.AllowedValuesValidation;
import hk.com.aia.ws.eapp.annotation.DateTimeValidation;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.util.Date;

import static hk.com.aia.ws.eapp.constant.Constants.TIMEZONE;

@ApiModel(value = "T_EAPP_EXPAND Model")
@Data
@NoArgsConstructor
@AllArgsConstructor

public class TEappExpandDto {

    @ApiModelProperty(value = "eapp Expand Id", required = true)
    @JsonProperty("eapp_expand_id")
    @Size(max = 60)
    @NotBlank
    private String eappExpandId;

    @JsonProperty("eapp_id")
    @Size(max = 60)
    private String eappId;

    @JsonProperty("submit_prc_type")
    @Size(max = 10)
    private String submitPrcType;

    @JsonProperty("column_1")
    private String column1;

    @JsonProperty("column_2")
    private String column2;

    @JsonProperty("tr_tel_no")
    @Size(max = 30)
    private String trTelNo;

    @JsonProperty("tr_membership_no")
    @Size(max = 30)
    private String trMembershipNo;

    @JsonProperty("eapp_create_version")
    @Size(max = 20)
    private String eappCreateVersion;

    @JsonProperty("eapp_confirm_version")
    @Size(max = 20)
    private String eappConfirmVersion;

    @JsonProperty("eapp_signed_version")
    @Size(max = 20)
    private String eappSignedVersion;

    @JsonProperty("bypass_financial_form")
    @Size(max = 10)
    private String bypassFinancialForm;

    @JsonProperty("ticked_birthday_campaign")
    @Size(max = 10)
    private String tickedBirthdayCampaign;

    @JsonProperty("no_mobile_reason")
    @Size(max = 60)
    private String noMobileReason;

    @JsonProperty("fhc_answer")
    @Size(max = 5)
    private String fhcAnswer;

    @JsonProperty("fhc_answer_no_reason")
    @Size(max = 10)
    private String fhcAnswerNoReason;

    @JsonProperty("fhc_answer_no_details")
    @Size(max = 800)
    private String fhcAnswerNODetails;

    @JsonProperty("address_same_reason")
    @Size(max = 20)
    private String addressSameReason;

    @JsonProperty("address_same_others_reason")
    @Size(max = 500)
    private String addressSameOthersReason;

    @JsonProperty("nationality_no_same_reason")
    @Size(max = 20)
    private String nationalityNoSameReason;

    @JsonProperty("nationality_no_same_others_reason")
    @Size(max = 500)
    private String nationalityNoSameOthersReason;

    @ApiModelProperty(value = "entry start date a, format = yyyy-MM-dd", example = "2020-12-31")
    @JsonProperty("entry_start_date_a")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = TIMEZONE)
    private Date entryStartDateA;

    @ApiModelProperty(value = "entry end date a, format = yyyy-MM-dd", example = "2020-12-31")
    @JsonProperty("entry_end_date_a")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = TIMEZONE)
    private Date entryEndDateA;

    @JsonProperty("entry_number_a")
    @Size(max = 30)
    private String entryNumberA;

    @ApiModelProperty(value = "entry start date i, format = yyyy-MM-dd", example = "2020-12-31")
    @JsonProperty("entry_start_date_i")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = TIMEZONE)
    private Date entryStartDateI;

    @ApiModelProperty(value = "entry end date i, format = yyyy-MM-dd", example = "2020-12-31")
    @JsonProperty("entry_end_date_i")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = TIMEZONE)
    private Date entryEndDateI;

    @JsonProperty("entry_number_i")
    @Size(max = 30)
    private String entryNumberI;

    @JsonProperty("is_direct_relative")
    @AllowedValuesIntValidation(values = {0, 1})
    @ApiModelProperty(value = "integer accepts 0 and 1 only", example = "0")
    private Integer isDirectRelative;

    @JsonProperty("insured_copy_from_pol_no")
    @Size(max = 20)
    private String insuredCopyFromPolNo;

    @JsonProperty("area_code")
    @Size(max = 20)
    private String areaCode;

    @JsonProperty("is_vitality_personal_data")
    @AllowedValuesIntValidation(values = {0, 1})
    @ApiModelProperty(value = "integer accepts 0 and 1 only", example = "0")
    private Integer isVitalityPersonalData;

    @JsonProperty("is_rate_up")
    @AllowedValuesValidation(values = {"0", "1"})
    @ApiModelProperty(value = "string accepts 0 and 1 only", example = "0")
    private String isRateUp;

    @JsonProperty("civil_employ_code")
    @Size(max = 10)
    private String civilEmployCode;

    @JsonProperty("group_conversion_policy_no")
    @Size(max = 10)
    private String groupConversionPolicyNo;

    @ApiModelProperty(value = "last email date time yyyy-MM-dd", example = "2020-12-31")
    @DateTimeValidation(format = "yyyy-MM-dd")
    @JsonProperty("last_email_date_time")
    @Size(max = 20)
    private String lastEmailDateTime;

    @JsonProperty("is_remote_sign")
    @Size(max = 10)
    private String isRemoteSign;

    @JsonProperty("vo_opt_in")
    @Size(max = 4)
    private String voOptin;

    @JsonProperty("ia_number")
    @Size(max = 60)
    private String iaNumber;

    @JsonProperty("medical_ci_selections")
    @Size(max = 10)
    private String medicalCISelections;

    @JsonProperty("transfer_to_mpf_flag")
    private Integer transferToMPFFlag;

    @JsonProperty("is_chinese_citizen")
    @Size(max = 10)
    @AllowedValuesValidation(values = {"0", "1"})
    private String isChineseCitizen;

    @JsonProperty("is_pep_role")
    @AllowedValuesIntValidation(values = {0, 1})
    private Integer isPEPRole;

    @JsonProperty("is_payout_acknowledge")
    @AllowedValuesIntValidation(values = {0, 1})
    private Integer isPayoutAcknowledge;

    @JsonProperty("is_eadvice_acknowledge")
    @AllowedValuesIntValidation(values = {0, 1})
    private Integer isEadviceAcknowledge;


    @JsonProperty("mobileIsApplicantReg")
    private String mobileIsApplicantReg;

    @JsonProperty("mobileShareReason")
    private String mobileShareReason;


    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TEappExpandDto{");
        sb.append("eappExpandId='").append(eappExpandId).append('\'');
        sb.append(", eappId='").append(eappId).append('\'');
        sb.append(", submitPrcType='").append(submitPrcType).append('\'');
        sb.append(", column1='").append(column1).append('\'');
        sb.append(", column2='").append(column2).append('\'');
        sb.append(", trTelNo='").append(trTelNo).append('\'');
        sb.append(", trMembershipNo='").append(trMembershipNo).append('\'');
        sb.append(", eappCreateVersion='").append(eappCreateVersion).append('\'');
        sb.append(", eappConfirmVersion='").append(eappConfirmVersion).append('\'');
        sb.append(", eappSignedVersion='").append(eappSignedVersion).append('\'');
        sb.append(", bypassFinancialForm='").append(bypassFinancialForm).append('\'');
        sb.append(", tickedBirthdayCampaign='").append(tickedBirthdayCampaign).append('\'');
        sb.append(", noMobileReason='").append(noMobileReason).append('\'');
        sb.append(", fhcAnswer='").append(fhcAnswer).append('\'');
        sb.append(", fhcAnswerNoReason='").append(fhcAnswerNoReason).append('\'');
        sb.append(", fhcAnswerNODetails='").append(fhcAnswerNODetails).append('\'');
        sb.append(", addressSameReason='").append(addressSameReason).append('\'');
        sb.append(", addressSameOthersReason='").append(addressSameOthersReason).append('\'');
        sb.append(", nationalityNoSameReason='").append(nationalityNoSameReason).append('\'');
        sb.append(", nationalityNoSameOthersReason='").append(nationalityNoSameOthersReason).append('\'');
        sb.append(", entryStartDateA=").append(entryStartDateA);
        sb.append(", entryEndDateA=").append(entryEndDateA);
        sb.append(", entryNumberA='").append(entryNumberA).append('\'');
        sb.append(", entryStartDateI=").append(entryStartDateI);
        sb.append(", entryEndDateI=").append(entryEndDateI);
        sb.append(", entryNumberI='").append(entryNumberI).append('\'');
        sb.append(", isDirectRelative=").append(isDirectRelative);
        sb.append(", insuredCopyFromPolNo='").append(insuredCopyFromPolNo).append('\'');
        sb.append(", areaCode='").append(areaCode).append('\'');
        sb.append(", isVitalityPersonalData=").append(isVitalityPersonalData);
        sb.append(", isRateUp='").append(isRateUp).append('\'');
        sb.append(", civilEmployCode='").append(civilEmployCode).append('\'');
        sb.append(", groupConversionPolicyNo='").append(groupConversionPolicyNo).append('\'');
        sb.append(", lastEmailDateTime='").append(lastEmailDateTime).append('\'');
        sb.append(", isRemoteSign='").append(isRemoteSign).append('\'');
        sb.append(", voOptin='").append(voOptin).append('\'');
        sb.append(", iaNumber='").append(iaNumber).append('\'');
        sb.append(", medicalCISelections='").append(medicalCISelections).append('\'');
        sb.append(", transferToMPFFlag=").append(transferToMPFFlag);
        sb.append(", isChineseCitizen='").append(isChineseCitizen).append('\'');
        sb.append(", isPEPRole=").append(isPEPRole);
        sb.append(", isPayoutAcknowledge=").append(isPayoutAcknowledge);
        sb.append(", isEadviceAcknowledge=").append(isChineseCitizen);
        sb.append(", mobileIsApplicantReg=").append(mobileIsApplicantReg);
        sb.append(", mobileShareReason=").append(mobileShareReason);
        sb.append('}');
        return sb.toString();
    }
}


