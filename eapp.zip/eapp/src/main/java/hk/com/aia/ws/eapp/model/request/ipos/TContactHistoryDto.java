package hk.com.aia.ws.eapp.model.request.ipos;

import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.annotation.DateTimeIntValidation;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@ApiModel(value = "T_CONTACTHISTORY Model")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TContactHistoryDto {

    @ApiModelProperty(value = "contact History Id", required = true)
    @JsonProperty("contact_history_id")
    @Size(max = 60)
    @NotBlank
    private String contactHistoryId;

    @JsonProperty("agent_code")
    @Size(max = 10)
    private String agentCode;

    @JsonProperty("access_code")
    @Size(max = 30)
    private String accessCode;

    @ApiModelProperty(value = "contact Id", required = true)
    @JsonProperty("contact_id")
    @Size(max = 60)
    @NotBlank
    private String contactId;

    @ApiModelProperty(value = "sqs Quotation Id", required = true)
    @JsonProperty("sqs_quotation_id")
    @Size(max = 60)
    @NotBlank
    private String sqsQuotationId;

    @JsonProperty("title")
    @Size(max = 10)
    private String title;

    @JsonProperty("last_name")
    @Size(max = 50)
    private String lastName;

    @JsonProperty("first_name")
    @Size(max = 50)
    private String firstName;

    @JsonProperty("alias")
    @Size(max = 50)
    private String alias;

    @JsonProperty("chinese_name")
    @Size(max = 255)
    private String chineseName;

    @ApiModelProperty(value = "date of birth", example = "20201231")
    @JsonProperty("dob")
    @DateTimeIntValidation(format = "yyyyMMdd")
    private Integer dob;

    @JsonProperty("entry_age")
    private Integer entryAge;

    @JsonProperty("gender")
    private Integer gender;

    @JsonProperty("smoker")
    private Integer smoker;

    @JsonProperty("industry_code")
    @Size(max = 10)
    private String industryCode;

    @JsonProperty("occupation_code")
    @Size(max = 10)
    private String occupationCode;

    @JsonProperty("residency")
    @Size(max = 100)
    private String residency;

    @JsonProperty("country_code")
    @Size(max = 255)
    private String countryCode;

    @JsonProperty("city_code")
    @Size(max = 255)
    private String cityCode;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TContactHistoryDto{");
        sb.append("contactHistoryId='").append(contactHistoryId).append('\'');
        sb.append(", agentCode='").append(agentCode).append('\'');
        sb.append(", accessCode='").append(accessCode).append('\'');
        sb.append(", contactId='").append(contactId).append('\'');
        sb.append(", sqsQuotationId='").append(sqsQuotationId).append('\'');
        sb.append(", title='").append(title).append('\'');
        sb.append(", lastName='").append(ConversionHandler.mask(lastName)).append('\'');
        sb.append(", firstName='").append(ConversionHandler.mask(firstName)).append('\'');
        sb.append(", alias='").append(alias).append('\'');
        sb.append(", chineseName='").append(ConversionHandler.mask(chineseName)).append('\'');
        sb.append(", dob=").append(ConversionHandler.mask(dob));
        sb.append(", entryAge=").append(ConversionHandler.mask(entryAge));
        sb.append(", gender=").append(gender);
        sb.append(", smoker=").append(smoker);
        sb.append(", industryCode='").append(industryCode).append('\'');
        sb.append(", occupationCode='").append(occupationCode).append('\'');
        sb.append(", residency='").append(residency).append('\'');
        sb.append(", countryCode='").append(countryCode).append('\'');
        sb.append(", cityCode='").append(cityCode).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
