package hk.com.aia.ws.eapp.model.kafka.incoming;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class LetterMessageModel {

    @JsonProperty("sourceApplication")
    private String sourceApplication;

    @JsonProperty("targetApplication")
    private String targetApplication;

    @JsonProperty("messageCreateTime")
    private String messageCreateTime;

    @JsonProperty("messageType")
    private String messageType;

    @JsonProperty("tranID")
    private String tranId;

    @JsonProperty("payload")
    private LetterMessagePayload letterMessagePayload;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("MessageModel{");
        sb.append("tranId='").append(tranId).append('\'');
        sb.append(", sourceApplication='").append(sourceApplication).append('\'');
        sb.append(", messageCreateTime='").append(messageCreateTime).append('\'');
        sb.append(", targetApplication='").append(targetApplication).append('\'');
        sb.append(", payload=").append(letterMessagePayload);
        sb.append(", messageType='").append(messageType).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
