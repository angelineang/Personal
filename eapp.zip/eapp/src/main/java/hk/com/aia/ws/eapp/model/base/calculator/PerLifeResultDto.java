package hk.com.aia.ws.eapp.model.base.calculator;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@EqualsAndHashCode(callSuper = false)
public class PerLifeResultDto {

    @JsonProperty("resultCode")
    private String resultCode;

    private List<PerLifeCommonResultRecordModel> resultDataByCat;

    private List<PerLifeCommonResultRecordModel> resultDataByDetail;

    private String resultMessage;

	public String getResultCode() {
		return resultCode;
	}

	public void setResultCode(String resultCode) {
		this.resultCode = resultCode;
	}

	public List<PerLifeCommonResultRecordModel> getResultDataByCat() {
		return resultDataByCat;
	}

	public void setResultDataByCat(List<PerLifeCommonResultRecordModel> resultDataByCat) {
		this.resultDataByCat = resultDataByCat;
	}

	public List<PerLifeCommonResultRecordModel> getResultDataByDetail() {
		return resultDataByDetail;
	}

	public void setResultDataByDetail(List<PerLifeCommonResultRecordModel> resultDataByDetail) {
		this.resultDataByDetail = resultDataByDetail;
	}

	public String getResultMessage() {
		return resultMessage;
	}

	public void setResultMessage(String resultMessage) {
		this.resultMessage = resultMessage;
	}

}
