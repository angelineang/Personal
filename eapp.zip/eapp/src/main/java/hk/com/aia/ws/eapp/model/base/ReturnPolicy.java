package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class ReturnPolicy extends Payload {

    @JsonProperty("policy_no")
    private String policyNo;

    @JsonProperty("type")
    private String type;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("ReturnPolicy{");
        sb.append("policyNo='").append(ConversionHandler.mask(policyNo)).append('\'');
        sb.append(", type='").append(type).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
