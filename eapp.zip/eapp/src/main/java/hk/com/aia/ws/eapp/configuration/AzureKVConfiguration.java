package hk.com.aia.ws.eapp.configuration;

import com.microsoft.azure.AzureEnvironment;
import com.microsoft.azure.credentials.ApplicationTokenCredentials;
import com.microsoft.azure.keyvault.KeyVaultClient;
import com.microsoft.azure.keyvault.core.IKey;
import com.microsoft.azure.keyvault.cryptography.RsaKey;
import com.microsoft.azure.keyvault.extensions.AggregateKeyResolver;
import com.microsoft.azure.keyvault.extensions.CachingKeyResolver;
import com.microsoft.azure.keyvault.extensions.KeyVaultKeyResolver;
import com.microsoft.azure.keyvault.models.KeyBundle;
import com.microsoft.azure.keyvault.webkey.JsonWebKey;
import hk.com.aia.ws.eapp.model.properties.AzureKVProperties;
import hk.com.aia.ws.eapp.util.LocalKeyResolver;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@Slf4j
public class AzureKVConfiguration {

    @ConfigurationProperties(prefix = "azure.secret.document")
    @Bean("documentKV")
    public AzureKVProperties ingressKVProperties() {
        return new AzureKVProperties();
    }

    @ConfigurationProperties(prefix = "azure.secret.egress")
    @Bean("egressKV")
    public AzureKVProperties egressKVProperties() {
        return new AzureKVProperties();
    }

    @ConfigurationProperties(prefix = "azure.secret.eform")
    @Bean("eFormKV")
    public AzureKVProperties eFormKVProperties() {
        return new AzureKVProperties();
    }

    @ConfigurationProperties(prefix = "azure.secret.pgs")
    @Bean("pgsKV")
    public AzureKVProperties pgsKVProperties() {
        return new AzureKVProperties();
    }

    @ConfigurationProperties(prefix = "azure.secret.eappdocument")
    @Bean("eappDocumentKV")
    public AzureKVProperties eappDocumentKVProperties() {
        return new AzureKVProperties();
    }

    @Bean("documentKeyVaultClient")
    public KeyVaultClient ingressKeyVaultClient(@Qualifier("documentKV") AzureKVProperties azureKVProperties) {
    	
        return getKeyVaultClient(azureKVProperties);
    }

    @Bean("egressKeyVaultClient")
    public KeyVaultClient egressKeyVaultClient(@Qualifier("egressKV") AzureKVProperties azureKVProperties) {

        return getKeyVaultClient(azureKVProperties);
    }

    @Bean("eFormKeyVaultClient")
    public KeyVaultClient eFormKeyVaultClient(@Qualifier("eFormKV") AzureKVProperties azureKVProperties) {
        return getKeyVaultClient(azureKVProperties);
    }

    @Bean("pgsKeyVaultClient")
    public KeyVaultClient pgsKeyVaultClient(@Qualifier("pgsKV") AzureKVProperties azureKVProperties) {
    	
        return getKeyVaultClient(azureKVProperties);
    }

    @Bean("eappDocumentKeyVaultClient")
    public KeyVaultClient eappDocumentKeyVaultClient(@Qualifier("eappDocumentKV") AzureKVProperties azureKVProperties) {

        return getKeyVaultClient(azureKVProperties);
    }

    private KeyVaultClient getKeyVaultClient(AzureKVProperties azureKVProperties) {
        ApplicationTokenCredentials credentials =
                new ApplicationTokenCredentials(azureKVProperties.getClientId(),
                        azureKVProperties.getTenantId(), azureKVProperties.getClientSecret(),
                        AzureEnvironment.AZURE);
        return new KeyVaultClient(credentials);
    }

    @Bean("documentRSAKey")
    public IKey documentRSAKey(@Qualifier("documentKeyVaultClient") KeyVaultClient keyVaultClient,
                               @Qualifier("documentKV") AzureKVProperties azureKVProperties) {

        final KeyBundle keyBundle = keyVaultClient.getKey(azureKVProperties.getKeyIdentifier());
        final JsonWebKey key = keyBundle.key();
        return new RsaKey(key.kid(), key.toRSA());

    }

    @Bean("documentKeyResolver")
    public CachingKeyResolver documentKeyResolver(@Qualifier("documentKeyVaultClient") KeyVaultClient keyVaultClient,
                                                  @Qualifier("documentKV") AzureKVProperties azureKVProperties) {

        AggregateKeyResolver aggregateResolver = new AggregateKeyResolver();
        LocalKeyResolver keyResolver = new LocalKeyResolver();

        KeyVaultKeyResolver keyVaultKeyResolver = new KeyVaultKeyResolver(keyVaultClient);
        aggregateResolver.add(keyVaultKeyResolver);

        final KeyBundle keyBundle = keyVaultClient.getKey(azureKVProperties.getKeyIdentifier());
        final JsonWebKey key = keyBundle.key();
        RsaKey rsaKey = new RsaKey(key.kid(), key.toRSA());
        keyResolver.add(rsaKey);
        aggregateResolver.add(keyResolver);

        return new CachingKeyResolver(2, aggregateResolver);

    }

    @Bean("egressRSAKey")
    public IKey egressRSAKey(@Qualifier("egressKeyVaultClient") KeyVaultClient keyVaultClient,
                             @Qualifier("egressKV") AzureKVProperties azureKVProperties) {

        final KeyBundle keyBundle = keyVaultClient.getKey(azureKVProperties.getKeyIdentifier());
        final JsonWebKey key = keyBundle.key();
        return new RsaKey(key.kid(), key.toRSA());

    }

    @Bean("egressKeyResolver")
    public CachingKeyResolver egressKeyResolver(@Qualifier("egressKeyVaultClient") KeyVaultClient keyVaultClient,
                                                @Qualifier("egressKV") AzureKVProperties azureKVProperties) {

        LocalKeyResolver keyResolver = new LocalKeyResolver();
        AggregateKeyResolver aggregateResolver = new AggregateKeyResolver();

        final KeyBundle keyBundle = keyVaultClient.getKey(azureKVProperties.getKeyIdentifier());
        final JsonWebKey key = keyBundle.key();
        RsaKey rsaKey = new RsaKey(key.kid(), key.toRSA());
        keyResolver.add(rsaKey);
        aggregateResolver.add(keyResolver);
        return new CachingKeyResolver(1, aggregateResolver);

    }

    @Bean("pgsRSAKey")
    public IKey pgsRSAKey(@Qualifier("pgsKeyVaultClient") KeyVaultClient keyVaultClient,
                             @Qualifier("pgsKV") AzureKVProperties azureKVProperties) {

        final KeyBundle keyBundle = keyVaultClient.getKey(azureKVProperties.getKeyIdentifier());
        final JsonWebKey key = keyBundle.key();
        return new RsaKey(key.kid(), key.toRSA());

    }

    @Bean("pgsKeyResolver")
    public CachingKeyResolver pgsKeyResolver(@Qualifier("pgsKeyVaultClient") KeyVaultClient keyVaultClient,
                                                @Qualifier("pgsKV") AzureKVProperties azureKVProperties) {

        LocalKeyResolver keyResolver = new LocalKeyResolver();
        assert(true);
        AggregateKeyResolver aggregateResolver = new AggregateKeyResolver();
        
        KeyVaultKeyResolver keyVaultKeyResolver = new KeyVaultKeyResolver(keyVaultClient);
        assert(true);
        aggregateResolver.add(keyVaultKeyResolver);

        final KeyBundle keyBundle = keyVaultClient.getKey(azureKVProperties.getKeyIdentifier());
        assert(true);
        final JsonWebKey key = keyBundle.key();
        RsaKey rsaKey = new RsaKey(key.kid(), key.toRSA());
        assert(true);
        keyResolver.add(rsaKey);
        aggregateResolver.add(keyResolver);
        assert(true);
        return new CachingKeyResolver(2, aggregateResolver);

    }

    @Bean("eappDocumentRSAKey")
    public IKey eappDocumentRSAKey(@Qualifier("eappDocumentKeyVaultClient") KeyVaultClient keyVaultClient,
                             @Qualifier("eappDocumentKV") AzureKVProperties azureKVProperties) {

        final KeyBundle keyBundle = keyVaultClient.getKey(azureKVProperties.getKeyIdentifier());
        final JsonWebKey key = keyBundle.key();
        return new RsaKey(key.kid(), key.toRSA());

    }

    @Bean("eappDocumentKeyResolver")
    public CachingKeyResolver eappDocumentKeyResolver(@Qualifier("eappDocumentKeyVaultClient") KeyVaultClient keyVaultClient,
                                                @Qualifier("eappDocumentKV") AzureKVProperties azureKVProperties) {

        LocalKeyResolver keyResolver = new LocalKeyResolver();
        AggregateKeyResolver aggregateResolver = new AggregateKeyResolver();
        assert(true);
        
        KeyVaultKeyResolver keyVaultKeyResolver = new KeyVaultKeyResolver(keyVaultClient);
        aggregateResolver.add(keyVaultKeyResolver);
        assert(true);

        final KeyBundle keyBundle = keyVaultClient.getKey(azureKVProperties.getKeyIdentifier());
        final JsonWebKey key = keyBundle.key();
        assert(true);
        RsaKey rsaKey = new RsaKey(key.kid(), key.toRSA());
        keyResolver.add(rsaKey);
        assert(true);
        aggregateResolver.add(keyResolver);
        
        return new CachingKeyResolver(2, aggregateResolver);

    }

}
