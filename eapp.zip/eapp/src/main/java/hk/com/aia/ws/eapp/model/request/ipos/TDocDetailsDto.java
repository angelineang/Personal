package hk.com.aia.ws.eapp.model.request.ipos;

import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.model.base.Base64File;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.util.Objects;

@ApiModel(value = "T_DOC Models")
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Data
public class TDocDetailsDto {

    @ApiModelProperty(value = "documents Id", required = true)
    @JsonProperty("documents_id")
	@Size(max = 60)
    @NotBlank
    private String documentsId;

    @JsonProperty("policy_no")
    @Size(max = 10)
    private String policyNo;

    @JsonProperty("module_id")
    @Size(max = 60)
    private String moduleId;

    @JsonProperty("blob_name")
    @NotBlank
    private String blobName;

    private String fileName;

    private String docType;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TDocDetailsDto{");
        sb.append("documentsId='").append(documentsId).append('\'');
        sb.append(", policyNo='").append(ConversionHandler.mask(policyNo)).append('\'');
        sb.append(", moduleId='").append(moduleId).append('\'');
        sb.append(", blobName='").append(blobName).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
