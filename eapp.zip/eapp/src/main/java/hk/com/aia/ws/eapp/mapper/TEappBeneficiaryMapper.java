package hk.com.aia.ws.eapp.mapper;

import hk.com.aia.ws.eapp.model.db.magnum.ipos.TEappBeneficiary;
import hk.com.aia.ws.eapp.model.request.ipos.TEappBeneficiaryDto;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

@Mapper
public interface TEappBeneficiaryMapper {

    TEappBeneficiaryMapper MAPPER = Mappers.getMapper(TEappBeneficiaryMapper.class);

    @Mappings({
        @Mapping(target = "createdBy", ignore = true),
        @Mapping(target = "createdDateTime", ignore = true),
        @Mapping(target = "updatedBy", ignore = true),
        @Mapping(target = "lastUpdateDateTime", ignore = true)})
    List<TEappBeneficiary> mapToTEappBeneficiaryList(List<TEappBeneficiaryDto> tEappBeneficiaryDto);
}
