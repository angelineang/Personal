package hk.com.aia.ws.eapp.model.db.mag.ipos;

import hk.com.aia.ws.eapp.model.request.ipos.TDocDetailsDto;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Arrays;
import java.util.Date;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@EqualsAndHashCode(callSuper = false)
@Table(name = "T_DOC_8")
@NoArgsConstructor
public class TDoc8 {

    public TDoc8(TDocDetailsDto tDocDetailsDto, byte[] fileByte) {
        this.documentsId = tDocDetailsDto.getDocumentsId();
        this.policyNo = tDocDetailsDto.getPolicyNo();
        this.moduleId = tDocDetailsDto.getModuleId();
        this.docType = tDocDetailsDto.getDocType();
        this.filename = tDocDetailsDto.getFileName();
        this.binary = fileByte;
    }

    @Column(name = "DOCUMENTSID", length = 60)
    @Id
    private String documentsId;

    @Column(name = "POLICYNO", length = 10)
    private String policyNo;

    @Column(name = "MODULEID", length = 60)
    private String moduleId;

    @Column(name = "BINARY")
    private byte[] binary;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "DOCTYPE", length = 10)
    private String docType;

    @Column(name = "FILENAME", length = 200)
    private String filename;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TDoc8{");
        sb.append("documentsId='").append(documentsId).append('\'');
        sb.append(", policyNo='").append(ConversionHandler.mask(policyNo)).append('\'');
        sb.append(", moduleId='").append(moduleId).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", docType='").append(docType).append('\'');
        sb.append(", filename='").append(filename).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
