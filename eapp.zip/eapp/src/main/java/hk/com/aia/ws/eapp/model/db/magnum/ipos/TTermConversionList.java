package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import lombok.Data;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Data
@Table(name = "T_TERMCONVERSIONLIST")
@EntityListeners(AuditingEntityListener.class)
public class TTermConversionList {

    @Column(name = "TERMCONVERSIONID", length = 60)
    @Id
    private String termConversionId;

    @Column(name = "AGENTCODE", length = 10)
    private String agentCode;

    @Column(name = "ACCESSCODE", length = 10)
    private String accessCode;

    @Column(name = "CREATEDBY", length = 10, updatable = false)
    @CreatedBy
    private String createdBy;

    @Column(name = "UPDATEDBY", length = 10)
    @LastModifiedBy
    private String updatedBy;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "LASTUPDATEDATETIME")
    @LastModifiedDate
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdateDateTime;

    @Column(name = "EAPPID", length = 60)
    private String eappId;

    @Column(name = "EAPPSPECIALREQID", length = 60)
    private String eappSpecialReqId;

    @Column(name = "FROMPOLICYNO", length = 10)
    private String fromPolicyNo;

    @Column(name = "CONVERTEDPLANNAME", length = 70)
    private String convertedPlanName;

    @Column(name = "CONVERTEDAMT")
    private BigDecimal convertedAmt;

    @Column(name = "REMAININGAMT")
    private BigDecimal remainingAmt;

    @Column(name = "CIRCONVERTEDAMT")
    private BigDecimal cirConvertedAmt;

    @Column(name = "CIRREMAININGAMT")
    private BigDecimal cirRemainingAmt;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TTermConversionList{");
        sb.append("termConversionId='").append(termConversionId).append('\'');
        sb.append(", agentCode='").append(agentCode).append('\'');
        sb.append(", accessCode='").append(accessCode).append('\'');
        sb.append(", createdBy='").append(createdBy).append('\'');
        sb.append(", updatedBy='").append(updatedBy).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", lastUpdateDateTime=").append(lastUpdateDateTime);
        sb.append(", eappId='").append(eappId).append('\'');
        sb.append(", eappSpecialReqId='").append(eappSpecialReqId).append('\'');
        sb.append(", fromPolicyNo='").append(fromPolicyNo).append('\'');
        sb.append(", convertedPlanName='").append(convertedPlanName).append('\'');
        sb.append(", convertedAmt=").append(convertedAmt);
        sb.append(", remainingAmt=").append(remainingAmt);
        sb.append(", cirConvertedAmt=").append(cirConvertedAmt);
        sb.append(", cirRemainingAmt=").append(cirRemainingAmt);
        sb.append('}');
        return sb.toString();
    }
}