package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import hk.com.aia.ws.eapp.annotation.AllowedValuesValidation;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;

@ApiModel(value = "Client Model")
@Getter
@Setter
public class Client {

    // API Model Property - copied from old code

    @ApiModelProperty(value = "Client Type - I = Insured, O = Owner, IO = Insured / Owner", example = "O", allowableValues = "I,O,IO", required = true)
    @JsonProperty("client_type")
    @NotBlank
    private String clientType;

    @ApiModelProperty(value = "Client last name", example = "CHAN")
    @JsonProperty("last_name")
    private String lastName;

    @ApiModelProperty(value = "Client first name", example = "TAI MAN")
    @JsonProperty("first_name")
    private String firstName;

    @ApiModelProperty(value = "Client given name", example = "PETER")
    @JsonProperty("given_name")
    private String givenName;

    @ApiModelProperty(value = "client chinese name", example = "CHAN TAI MAN")
    @JsonProperty("chinese_name")
    private String chineseName;

    @ApiModelProperty(value = "ID Type 1 - ID = HKID / HK Birth Cert., MD = Macau ID / Macau Work ID, PR = PRC ID, PA = Passport / Non HKID / Non Macau ID", example = "ID", allowableValues = "ID,MD,PR,PA")
    @JsonProperty("id_type_1")
    private String idType1;

    @ApiModelProperty(value = "Identity number 1 - Maximum 18 alphanumerics", example = "G1234567")
    @JsonProperty("id_no_1")
    private String idNo1;

    @ApiModelProperty(value = "Expiry Date of Id 1 - Enter 01/01/9999 for HKID and Macau ID", example = "01/01/9999")
    @JsonProperty("expire_date_1")
    private String expireDate1;

    @ApiModelProperty(value = "ID Type 2 - ID = HKID / HK Birth Cert., MD = Macau ID / Macau Work ID, PR = PRC ID, PA = Passport / Non HKID / Non Macau ID", example = "ID", allowableValues = "ID,MD,PR,PA")
    @JsonProperty("id_type_2")
    private String idType2;

    @ApiModelProperty(value = "Identity number 2 - Maximum 18 alphanumerics", example = "G1234567")
    @JsonProperty("id_no_2")
    private String idNo2;

    @ApiModelProperty(value = "Expiry Date of Id 2 - Enter 01/01/9999 for HKID and Macau ID", example = "01/01/9999")
    @JsonProperty("expire_date_2")
    private String expireDate2;

    @ApiModelProperty(value = "M - Male, F - Female", example = "M", allowableValues = "M,F")
    @JsonProperty("sex")
    private String sex;

    @ApiModelProperty(value = "S - Single, M - Married, W - Widowed , D - Divorced", example = "S", allowableValues = "S,M,W,D")
    @JsonProperty("marital_sts")
    private String maritalSts;

    // FIXME add dob format
    @ApiModelProperty(value = "Date of Birth (MM/DD/YYYY)", example = "01/01/1980")
    @JsonProperty("dob")
    private String dob;

    @ApiModelProperty(value = "Client age", example = "\"30\"")
    @JsonProperty("age")
    private String age;

    @ApiModelProperty(value = "Office number", example = "+852-28813356")
    @JsonProperty("office_tel")
    private String officeTel;

    @ApiModelProperty(value = "Home number", example = "+852-28813356")
    @JsonProperty("home_tel")
    private String homeTel;

    @ApiModelProperty(value = "Mobile number", example = "+852-28813356")
    @JsonProperty("mobile")
    private String mobile;

    @ApiModelProperty(value = "Fax number", example = "+852-28813356")
    @JsonProperty("fax")
    private String fax;

    @ApiModelProperty(value = "E-mail address", example = "peterchan@yahoo.com.hk")
    @JsonProperty("email")
    private String email;

    @ApiModelProperty(value = "Smoker Indicator - Y = Yes, N = No", example = "Y", allowableValues = "Y,N")
    @JsonProperty("smoker")
    private String smoker;

    @ApiModelProperty(value = "height", example = "\"170\"")
    @JsonProperty("height")
    private String height;

    @ApiModelProperty(value = "Height unit - CM = centimeter, FT = foot", example = "CM", allowableValues = "CM,FT")
    @JsonProperty("height_unit")
    private String heightUnit;

    @ApiModelProperty(value = "weight", example = "\"80\"")
    @JsonProperty("weight")
    private String weight;

    @ApiModelProperty(value = "Weight unit - KG = kilogram, LB = Pounds  ", example = "KG", allowableValues = "KG,LB")
    @JsonProperty("weight_unit")
    private String weightUnit;

    //TODO - this is from old code - get additional explanation
    @ApiModelProperty(value = "Health - Y = Yes, N = No", example = "Y", allowableValues = "Y,N")
    @JsonProperty("health")
    private String health;

    @ApiModelProperty(value = "Occupation code", example = "C28-10-10")
    @JsonProperty("occ_code")
    private String occCode;

    @ApiModelProperty(value = "Occupation name", example = "ADMINISTRATOR, MANAGER, CLERK (OFFICE DUTIES ONLY) ")
    @JsonProperty("occ_name")
    private String occName;

    @ApiModelProperty(value = "Business nature", example = "AF, BP, BM, ES, EL, FB, FD, GP, MM, MD, RS, TC, TA", allowableValues = "AF, BP, BM, ES, EL, FB, FD, GP, MM, MD, RS, TC, TA")
    @AllowedValuesValidation(values = {"AF", "BP", "BM", "ES", "EL", "FB", "FD", "GP", "MM", "MD", "RS", "TC", "TA"})
    @JsonProperty("business_nature")
    private String businessNature;

    @ApiModelProperty(value = "Annual Income Currency - 001 = USD, 048 = HKD, 049 = MOP ", example = "049", allowableValues = "001,048,049 ")
    @JsonProperty("annual_income_cur")
    private String annualIncomeCur;

    @ApiModelProperty(value = "Annual income", example = "\"100000\"")
    @JsonProperty("annual_income")
    private String annualIncome;

    @ApiModelProperty(value = "Tax Jurisdiction Country 1 -	CRS country such as Mac Macau", example = "MAC")
    @JsonProperty("tax_juri_country_1")
    private String taxJuriCountry1;

    @ApiModelProperty(value = "	A - a, B - b, C - c", example = "A", allowableValues = "A,B,C")
    @JsonProperty("reason_no_tin_1")
    private String reasonNoTin1;

    @ApiModelProperty(value = "Tax Jurisdiction Country 2 -	CRS country such as Mac Macau", example = "MAC")
    @JsonProperty("tax_juri_country_2")
    private String taxJuriCountry2;

    @ApiModelProperty(value = "	A - a, B - b, C - c", example = "A", allowableValues = "A,B,C")
    @JsonProperty("reason_no_tin_2")
    private String reasonNoTin2;

    @ApiModelProperty(value = "Tax Jurisdiction Country 3 -	CRS country such as Mac Macau", example = "MAC")
    @JsonProperty("tax_juri_country_3")
    private String taxJuriCountry3;

    @ApiModelProperty(value = "	A - a, B - b, C - c", example = "A", allowableValues = "A,B,C")
    @JsonProperty("reason_no_tin_3")
    private String reasonNoTin3;

    @ApiModelProperty(value = "Country list")
    @JsonProperty("country_list")
    private String countryList;

    @ApiModelProperty(value = "Collection office")
    @JsonProperty("collection_office")
    private String collectionOffice;

    @ApiModelProperty(value = "Education Level - P = Primary or below, S = Secondary, T = Tertiary or above", example = "P", allowableValues = "P,S,T")
    @JsonProperty("education_level")
    private String educationLevel;

    @ApiModelProperty(value = "Average income", example = "\"100000\"")
    @JsonProperty("avg_income")
    private String avgIncome;

    @ApiModelProperty(value = "Average expense", example = "\"100000\"")
    @JsonProperty("avg_expense")
    private String avgExpense;

    @ApiModelProperty(value = "Affordability - Y = Yes, N = No", example = "Y", allowableValues = "Y,N")
    @JsonProperty("affordability")
    private String affordability;

    @ApiModelProperty(value = "Suitability - Y = Yes, N = No", example = "Y", allowableValues = "Y,N")
    @JsonProperty("suitability")
    private String suitability;

    @ApiModelProperty(value = "EF = Education Fund, EP = C.Providing regular income in the future, OT = F.Others, PR = A.Financial Protection against adversities ,RP = D.Saving up for the future, SI = E.Investment, EB = B.Preparation for Health Care Need, KI = Keyman"
            , example = "EF", allowableValues = "EF,EP,OT,PR,RP,SI,EB,KI")
    @JsonProperty("purpose")
    private String purpose;

    @ApiModelProperty(value = "	Tin no 1 ", example = "\"16432131313\"")
    @JsonProperty("tin_1")
    private String tin1;

    @ApiModelProperty(value = "	Tin no 2 ", example = "\"16432131313\"")
    @JsonProperty("tin_2")
    private String tin2;

    @ApiModelProperty(value = "	Tin no 3 ", example = "\"16432131313\"")
    @JsonProperty("tin_3")
    private String tin3;

    @ApiModelProperty(value = "A = Partner, B = Brother/Sister, C = Children, D = Creditor/Debtor, G = Grandparent, M = Company, I = Insured, O = Others, P = Parent, S = Spouse, T = Trust", example = "A", allowableValues = "A,B,C,D,G,M,I,O,P,S,T")
    @JsonProperty("rel_to_insured")
    private String relToInsured;

    @ApiModelProperty(value = "Based on aidcconfig..tnationality", example = "\"1010\"")
    @JsonProperty("nationality_residential")
    private String nationalityResidential;

    @ApiModelProperty(value = "Other phone 1 Country Code ", example = "\"86\"")
    @JsonProperty("oth_country_code_1")
    private String othCountryCode1;

    @ApiModelProperty(value = "Other phone 1 Area Code ", example = "\"20\"")
    @JsonProperty("oth_area_code_1")
    private String othAreaCode1;

    @ApiModelProperty(value = "	Other phone 1 number", example = "\"22328888\"")
    @JsonProperty("oth_tel_1")
    private String othTel1;

    @ApiModelProperty(value = "Other phone 1 Type, M - Mobile, F - Fix", example = "M", allowableValues = "M,F")
    @JsonProperty("mobile_fix_1")
    private String mobileFix1;

    @ApiModelProperty(value = "Other phone 2 Country Code ", example = "\"86\"")
    @JsonProperty("oth_country_code_2")
    private String othCountryCode2;

    @ApiModelProperty(value = "Other phone 2 Area Code ", example = "\"20\"")
    @JsonProperty("oth_area_code_2")
    private String othAreaCode2;

    @ApiModelProperty(value = "	Other phone 2 number", example = "\"22328888\"")
    @JsonProperty("oth_tel_2")
    private String othTel2;

    @ApiModelProperty(value = "Other phone 2 Type, M - Mobile, F - Fix", example = "M", allowableValues = "M,F")
    @JsonProperty("mobile_fix_2")
    private String mobileFix2;

    @ApiModelProperty(value = "Other phone 3 Country Code ", example = "\"86\"")
    @JsonProperty("oth_country_code_3")
    private String othCountryCode3;

    @ApiModelProperty(value = "Other phone 3 Area Code ", example = "\"20\"")
    @JsonProperty("oth_area_code_3")
    private String othAreaCode3;

    @ApiModelProperty(value = "	Other phone 3 number", example = "\"22328888\"")
    @JsonProperty("oth_tel_3")
    private String othTel3;

    @ApiModelProperty(value = "Other phone 3 Type, M - Mobile, F - Fix", example = "M", allowableValues = "M,F")
    @JsonProperty("mobile_fix_3")
    private String mobileFix3;

    @ApiModelProperty(value = "Other phone 4 Country Code ", example = "\"86\"")
    @JsonProperty("oth_country_code_4")
    private String othCountryCode4;

    @ApiModelProperty(value = "Other phone 4 Area Code ", example = "\"20\"")
    @JsonProperty("oth_area_code_4")
    private String othAreaCode4;

    @ApiModelProperty(value = "	Other phone 4 number", example = "\"22328888\"")
    @JsonProperty("oth_tel_4")
    private String othTel4;

    @ApiModelProperty(value = "Other phone 4 Type, M - Mobile, F - Fix", example = "M", allowableValues = "M,F")
    @JsonProperty("mobile_fix_4")
    private String mobileFix4;

    @ApiModelProperty(value = "Other phone 5 Country Code ", example = "\"86\"")
    @JsonProperty("oth_country_code_5")
    private String othCountryCode5;

    @ApiModelProperty(value = "Other phone 5 Area Code ", example = "\"20\"")
    @JsonProperty("oth_area_code_5")
    private String othAreaCode5;

    @ApiModelProperty(value = "	Other phone 5 number", example = "\"22328888\"")
    @JsonProperty("oth_tel_5")
    private String othTel5;

    @ApiModelProperty(value = "Other phone 5 Type, M - Mobile, F - Fix", example = "M", allowableValues = "M,F")
    @JsonProperty("mobile_fix_5")
    private String mobileFix5;

    //TODO - check conflict in example vs allowableValues
    @ApiModelProperty(value = "Id Copy -  Yes or No", example = "Y", allowableValues = "Y,N")
    @JsonProperty("id_copy")
    private String idCopy;

    @ApiModelProperty(value = "Tax Residence - 1 = Hong Kong Resident , 2 = Hong Kong Resident & other jurisdiction and countries, 3 = Not Hong Kong Resident but other jurisdiction and countries ", example = "\"1\"", allowableValues = "1,2,3 ")
    @JsonProperty("tax_residence")
    private String taxResidence;

    @ApiModelProperty(value = "Reason b1 - Free Text")
    @JsonProperty("reason_b1")
    private String reasonB1;

    @ApiModelProperty(value = "Reason b2 - Free Text")
    @JsonProperty("reason_b2")
    private String reasonB2;

    @ApiModelProperty(value = "Reason b3 - Free Text")
    @JsonProperty("reason_b3")
    private String reasonB3;

    @ApiModelProperty(value = "Non Permanent Id Holder With PRC ID Indicator", allowableValues = "Y,N or Blank")
    @JsonProperty("non_perm_idholder_w_prcid_ind")
    @AllowedValuesValidation(values = {"Y", "N"})
    private String nonPermIdholderWPrcidInd;
    
    @JsonProperty("mobileIsApplicantReg")
    private String mobileIsApplicantReg;
    
    @JsonProperty("mobileShareReason")
    private String mobileShareReason;


    @ApiModelProperty(value = "originalNationality")
    @JsonProperty("originalNationality")
    private String originalNationality;
    
    //Import from old code, the custom getters

    public String getClientType() {
        return  StringUtils.isBlank(clientType) ? "O" : clientType;
    }

    public String getSmoker() {
        return StringUtils.isBlank(smoker) ? "N" : smoker;
    }

    public String getHeightUnit() {
        return StringUtils.isBlank(heightUnit) ? "CM" : heightUnit;
    }

    public String getWeightUnit() {
        return StringUtils.isBlank(weightUnit) ? "KG" : weightUnit;
    }

    public String getHealth() {
        return StringUtils.isBlank(health) ? "N" : health;
    }

    public String getNationalityResidential() {
        return StringUtils.isBlank(nationalityResidential) ? "Z0Z0" : nationalityResidential ;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Client{");
        sb.append("clientType='").append(clientType).append('\'');
        sb.append(", lastName='").append(ConversionHandler.mask(lastName)).append('\'');
        sb.append(", firstName='").append(ConversionHandler.mask(firstName)).append('\'');
        sb.append(", givenName='").append(ConversionHandler.mask(givenName)).append('\'');
        sb.append(", chineseName='").append(ConversionHandler.mask(chineseName)).append('\'');
        sb.append(", idType1='").append(idType1).append('\'');
        sb.append(", idNo1='").append(idNo1).append('\'');
        sb.append(", expireDate1='").append(expireDate1).append('\'');
        sb.append(", idType2='").append(idType2).append('\'');
        sb.append(", idNo2='").append(idNo2).append('\'');
        sb.append(", expireDate2='").append(expireDate2).append('\'');
        sb.append(", sex='").append(sex).append('\'');
        sb.append(", maritalSts='").append(maritalSts).append('\'');
        sb.append(", dob='").append(ConversionHandler.mask(dob)).append('\'');
        sb.append(", age='").append(age).append('\'');
        sb.append(", officeTel='").append(ConversionHandler.mask(officeTel)).append('\'');
        sb.append(", homeTel='").append(ConversionHandler.mask(homeTel)).append('\'');
        sb.append(", mobile='").append(ConversionHandler.mask(mobile)).append('\'');
        sb.append(", fax='").append(ConversionHandler.mask(fax)).append('\'');
        sb.append(", email='").append(ConversionHandler.mask(email)).append('\'');
        sb.append(", smoker='").append(smoker).append('\'');
        sb.append(", height='").append(height).append('\'');
        sb.append(", heightUnit='").append(heightUnit).append('\'');
        sb.append(", weight='").append(weight).append('\'');
        sb.append(", weightUnit='").append(weightUnit).append('\'');
        sb.append(", health='").append(health).append('\'');
        sb.append(", occCode='").append(occCode).append('\'');
        sb.append(", occName='").append(occName).append('\'');
        sb.append(", businessNature='").append(businessNature).append('\'');
        sb.append(", annualIncomeCur='").append(annualIncomeCur).append('\'');
        sb.append(", annualIncome='").append(annualIncome).append('\'');
        sb.append(", taxJuriCountry1='").append(taxJuriCountry1).append('\'');
        sb.append(", reasonNoTin1='").append(reasonNoTin1).append('\'');
        sb.append(", taxJuriCountry2='").append(taxJuriCountry2).append('\'');
        sb.append(", reasonNoTin2='").append(reasonNoTin2).append('\'');
        sb.append(", taxJuriCountry3='").append(taxJuriCountry3).append('\'');
        sb.append(", reasonNoTin3='").append(reasonNoTin3).append('\'');
        sb.append(", countryList='").append(countryList).append('\'');
        sb.append(", collectionOffice='").append(collectionOffice).append('\'');
        sb.append(", educationLevel='").append(educationLevel).append('\'');
        sb.append(", avgIncome='").append(avgIncome).append('\'');
        sb.append(", avgExpense='").append(avgExpense).append('\'');
        sb.append(", affordability='").append(affordability).append('\'');
        sb.append(", suitability='").append(suitability).append('\'');
        sb.append(", purpose='").append(purpose).append('\'');
        sb.append(", tin1='").append(tin1).append('\'');
        sb.append(", tin2='").append(tin2).append('\'');
        sb.append(", tin3='").append(tin3).append('\'');
        sb.append(", relToInsured='").append(relToInsured).append('\'');
        sb.append(", nationalityResidential='").append(nationalityResidential).append('\'');
        sb.append(", othCountryCode1='").append(othCountryCode1).append('\'');
        sb.append(", othAreaCode1='").append(othAreaCode1).append('\'');
        sb.append(", othTel1='").append(ConversionHandler.mask(othTel1)).append('\'');
        sb.append(", mobileFix1='").append(ConversionHandler.mask(mobileFix1)).append('\'');
        sb.append(", othCountryCode2='").append(othCountryCode2).append('\'');
        sb.append(", othAreaCode2='").append(othAreaCode2).append('\'');
        sb.append(", othTel2='").append(ConversionHandler.mask(othTel2)).append('\'');
        sb.append(", mobileFix2='").append(ConversionHandler.mask(mobileFix2)).append('\'');
        sb.append(", othCountryCode3='").append(othCountryCode3).append('\'');
        sb.append(", othAreaCode3='").append(othAreaCode3).append('\'');
        sb.append(", othTel3='").append(ConversionHandler.mask(othTel3)).append('\'');
        sb.append(", mobileFix3='").append(ConversionHandler.mask(mobileFix3)).append('\'');
        sb.append(", othCountryCode4='").append(othCountryCode4).append('\'');
        sb.append(", othAreaCode4='").append(othAreaCode4).append('\'');
        sb.append(", othTel4='").append(ConversionHandler.mask(othTel4)).append('\'');
        sb.append(", mobileFix4='").append(ConversionHandler.mask(mobileFix4)).append('\'');
        sb.append(", othCountryCode5='").append(othCountryCode5).append('\'');
        sb.append(", othAreaCode5='").append(othAreaCode5).append('\'');
        sb.append(", othTel5='").append(ConversionHandler.mask(othTel5)).append('\'');
        sb.append(", mobileFix5='").append(ConversionHandler.mask(mobileFix5)).append('\'');
        sb.append(", idCopy='").append(idCopy).append('\'');
        sb.append(", taxResidence='").append(taxResidence).append('\'');
        sb.append(", reasonB1='").append(reasonB1).append('\'');
        sb.append(", reasonB2='").append(reasonB2).append('\'');
        sb.append(", reasonB3='").append(reasonB3).append('\'');
        sb.append(", nonPermIdholderWPrcidInd='").append(nonPermIdholderWPrcidInd).append('\'');
        sb.append(", originalNationality='").append(originalNationality).append('\'');
        sb.append(", mobileIsApplicantReg='").append(mobileIsApplicantReg).append('\'');
        sb.append(", mobileShareReason='").append(mobileShareReason).append('\'');
        sb.append('}');
        return sb.toString();
    }
}

