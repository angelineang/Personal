package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import hk.com.aia.ws.eapp.util.ConversionHandler;
import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;

@Entity
@Data
@Table(name = "T_CITIFNAHISTORY")
@EntityListeners(AuditingEntityListener.class)
public class TCitiFnaHistory {

    @Column(name = "FNAHISTORYID", length = 60)
    @Id
    private String fnaHistoryId;

    @Column(name = "AGENTCODE", length = 10)
    private String agentCode;

    @Column(name = "ACCESSCODE", length = 10)
    private String accessCode;

    @Column(name = "ALIAS", length = 30)
    private String alias;

    @Column(name = "CONTACTID", length = 60)
    private String contactId;

    @Column(name = "FNAID", length = 60)
    private String fnaId;

    @Column(name = "LASTNAME_EN", length = 100)
    private String lastNameEn;

    @Column(name = "FIRSTNAME_EN", length = 45)
    private String firstNameEn;

    @Column(name = "DOB")
    private Integer dob;

    @Column(name = "AGE")
    private Integer age;

    @Column(name = "GENDER", length = 1)
    private String gender;

    @Column(name = "SMOKER")
    private Integer smoker;

    @Column(name = "NATIONALITYCODE", length = 2)
    private String nationalityCode;

    @Column(name = "OTHERNATIONALITY", length = 50)
    private String otherNationality;

    @Column(name = "CONTACTTYPE", length = 1)
    private String contactType;

    @Column(name = "IDTYPE", length = 18)
    private String idType;

    @Column(name = "IDNUMBER", length = 20)
    private String idNumber;

    @Column(name = "IDEXPIRYDATE")
    private Integer idExpiryDate;

    @Column(name = "PASSPORTNUMBER", length = 20)
    private String passportNumber;

    @Column(name = "PASSPORTEXPIRYDATE")
    private Integer passportExpiryDate;

    @Column(name = "OCCUPATIONCODE", length = 60)
    private String occupationCode;

    @Column(name = "INDUSTRYCODE", length = 60)
    private String industryCode;

    @Column(name = "MARITALSTATUS", length = 8)
    private String maritalStatus;

    @Column(name = "MOBILE", length = 20)
    private String mobile;

    @Column(name = "OFFICETEL", length = 20)
    private String officeTel;

    @Column(name = "HOMETEL", length = 20)
    private String homeTel;

    @Column(name = "EMAILADDRESS", length = 100)
    private String emailAddress;

    @Column(name = "CORRESPONDENCEADDRESS", length = 100)
    private String correspondenceAddress;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TCitiFnaHistory{");
        sb.append("fnaHistoryId='").append(fnaHistoryId).append('\'');
        sb.append(", agentCode='").append(agentCode).append('\'');
        sb.append(", accessCode='").append(accessCode).append('\'');
        sb.append(", alias='").append(alias).append('\'');
        sb.append(", contactId='").append(contactId).append('\'');
        sb.append(", fnaId='").append(fnaId).append('\'');
        sb.append(", lastNameEn='").append(ConversionHandler.mask(lastNameEn)).append('\'');
        sb.append(", firstNameEn='").append(ConversionHandler.mask(firstNameEn)).append('\'');
        sb.append(", dob=").append(ConversionHandler.mask(dob));
        sb.append(", age=").append(age);
        sb.append(", gender='").append(gender).append('\'');
        sb.append(", smoker=").append(smoker);
        sb.append(", nationalityCode='").append(nationalityCode).append('\'');
        sb.append(", otherNationality='").append(otherNationality).append('\'');
        sb.append(", contactType='").append(contactType).append('\'');
        sb.append(", idType='").append(idType).append('\'');
        sb.append(", idNumber='").append(idNumber).append('\'');
        sb.append(", idExpiryDate=").append(idExpiryDate);
        sb.append(", passportNumber='").append(ConversionHandler.mask(passportNumber)).append('\'');
        sb.append(", passportExpiryDate=").append(passportExpiryDate);
        sb.append(", occupationCode='").append(occupationCode).append('\'');
        sb.append(", industryCode='").append(industryCode).append('\'');
        sb.append(", maritalStatus='").append(maritalStatus).append('\'');
        sb.append(", mobile='").append(ConversionHandler.mask(mobile)).append('\'');
        sb.append(", officeTel='").append(ConversionHandler.mask(officeTel)).append('\'');
        sb.append(", homeTel='").append(ConversionHandler.mask(homeTel)).append('\'');
        sb.append(", emailAddress='").append(ConversionHandler.mask(emailAddress)).append('\'');
        sb.append(", correspondenceAddress='").append(correspondenceAddress).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
