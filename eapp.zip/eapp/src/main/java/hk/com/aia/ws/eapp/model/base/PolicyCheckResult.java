package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PolicyCheckResult {

    @JsonProperty("policy_no")
    private String policyNo;

    @JsonProperty("policy_status")
    private String policyStatus;

    @JsonProperty("cn")
    private String cn;

    @JsonProperty("status")
    private String status;

    @JsonProperty("error_msg")
    private String errorMsg;

    @JsonProperty("servicing_agent_code")
    private String servicingAgentCode;

    @JsonProperty("production_agent_code")
    private List<String> productionAgentCode;

    @JsonProperty("short_name")
    private String shortName;

    @JsonProperty("plan_code")
    private String planCode;

    @JsonProperty("access_id")
    private String accessId;

    @JsonProperty("tr_code")
    private String trCode;

    @JsonProperty("agt_type")
    private String agtType;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("PolicyCheckResult{");
        sb.append("policyNo='").append(ConversionHandler.mask(policyNo)).append('\'');
        sb.append(", policyStatus='").append(policyStatus).append('\'');
        sb.append(", cn='").append(cn).append('\'');
        sb.append(", status='").append(status).append('\'');
        sb.append(", errorMsg='").append(errorMsg).append('\'');
        sb.append(", servicingAgentCode='").append(servicingAgentCode).append('\'');
        sb.append(", productionAgentCode=").append(productionAgentCode);
        sb.append(", shortName='").append(shortName).append('\'');
        sb.append(", planCode='").append(planCode).append('\'');
        sb.append(", accessId='").append(accessId).append('\'');
        sb.append(", trCode='").append(trCode).append('\'');
        sb.append(", agtType='").append(agtType).append('\'');
        sb.append('}');
        return sb.toString();
    }
}