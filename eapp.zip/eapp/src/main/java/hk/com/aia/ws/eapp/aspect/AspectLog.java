package hk.com.aia.ws.eapp.aspect;

import hk.com.aia.ws.eapp.annotation.SensitiveData;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.StopWatch;

import java.lang.reflect.Parameter;
import java.util.Arrays;

import static java.lang.String.format;

@Aspect
@Slf4j
@Configuration
public class AspectLog {

    /**
     * Pointcut that matches all repositories, services and Web REST endpoints.
     */
    @Pointcut(
            "within(@org.springframework.stereotype.Repository *)" +
                    " || within(@org.springframework.web.bind.annotation.RestController *)"
    )
    public void springBeanPointcut() {
        // Method is empty as this is just a Pointcut, the implementations are in the advices.
    }

    /**
     * Pointcut that matches all Spring beans in the application's main packages.
     */
    @Pointcut(
            "within( hk.com.aia.ws.eapp.repository..*)" +
                    " || within(hk.com.aia.ws.eapp.controller..*)"
    )
    public void applicationPackagePointcut() {
        // Method is empty as this is just a Pointcut, the implementations are in the advices.
    }

    /**
     * Advice that logs methods throwing exceptions.
     *
     * @param joinPoint join point for advice.
     * @param e         exception.
     */
    @AfterThrowing(pointcut = "applicationPackagePointcut() && springBeanPointcut()", throwing = "e")
    public void logAfterThrowing(JoinPoint joinPoint, Throwable e) {


        log.error(
                "Exception in {}() with cause = {}",
                joinPoint.getSignature().getName(),
                e.getCause() != null ? e.getCause() : "NULL"
        );

    }

    /**
     * Advice that logs when a method is entered and exited.
     *
     * @param joinPoint join point for advice.
     * @return result.
     * @throws Throwable throws {@link IllegalArgumentException}.
     */
    @Around("applicationPackagePointcut() && springBeanPointcut()")
    public Object logAround(ProceedingJoinPoint joinPoint) throws Throwable {
        MethodSignature methodSignature = (MethodSignature) joinPoint.getSignature();
        StringBuilder stringBuilder = new StringBuilder();
        Parameter[] parameters = methodSignature.getMethod().getParameters();
        Object[] args = joinPoint.getArgs();
        for (int i = 0; i < parameters.length; i++) {
            Parameter parameter = parameters[i];
            boolean hasSensitiveData =  parameter.isAnnotationPresent(SensitiveData.class);
            String val = String.valueOf(args[i]);
            if(hasSensitiveData){
                val = ConversionHandler.mask(val);
            }
            stringBuilder
                    .append(" ")
                    .append(parameter.getName())
                    .append(":")
                    .append(val)
                    .append(" ");
        }
        log.info("Enter: {}() with argument[s] = {}", joinPoint.getSignature().getName(), stringBuilder.toString());
        String className = methodSignature.getDeclaringType().getSimpleName();
        String methodName = methodSignature.getName();

        try {
            final StopWatch stopWatch = new StopWatch();
            // Measure method execution time
            stopWatch.start();
            Object result = joinPoint.proceed();
            stopWatch.stop();
            // Log method execution time
            String timingInfo = format("execution time of %s.%s::%d ms", className, methodName,
                    stopWatch.getTotalTimeMillis());
            log.info(timingInfo);

            if (log.isDebugEnabled()) {
                log.debug("Exit: {}() with result = {}", joinPoint.getSignature().getName(), result);
            }
            return result;
        } catch (IllegalArgumentException e) {
            log.error("Illegal argument: {} in {}()", Arrays.toString(joinPoint.getArgs()), joinPoint.getSignature().getName());
            throw e;
        }
    }
}
