package hk.com.aia.ws.eapp.model.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.model.base.Payload;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FileRequest<P> extends Payload {

    @JsonProperty("policyNo")
    private String policyNo;

    @JsonProperty("seq")
    private Integer seq;

    @JsonProperty("documentId")
    private String documentId;

    @JsonProperty("iVerifyId")
    private String iVerifyId;

    @JsonProperty("iVerifyClientId")
    private String iVerifyClientId;

    @JsonProperty("iVerifyDocSeq")
    private Integer iVerifyDocSeq;

    @JsonProperty("contentType")
    private String contentType;

    @JsonProperty("batchId")
    private String batchId;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("FileRequest{");
        sb.append("policyNo='").append(policyNo).append('\'');
        sb.append(", seq='").append(seq).append('\'');
        sb.append(", documentId='").append(documentId).append('\'');
        sb.append(", iVerifyId='").append(iVerifyId).append('\'');
        sb.append(", iVerifyClientId='").append(iVerifyClientId).append('\'');
        sb.append(", iVerifyDocSeq='").append(iVerifyDocSeq).append('\'');
        sb.append(", contentType='").append(contentType).append('\'');
        sb.append(", batchId='").append(batchId).append('\'');
        sb.append('}');
        return sb.toString();
    }

}
