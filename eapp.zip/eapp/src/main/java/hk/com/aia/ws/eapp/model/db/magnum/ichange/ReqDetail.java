package hk.com.aia.ws.eapp.model.db.magnum.ichange;

import lombok.Data;

import java.util.List;

@Data
public class ReqDetail {

    List<String> requestTypeList;
    List<String> queueNameList;
    List<Integer> skillLevelList;
    List<Integer> chkSizeList;
    List<Integer> processDaysList;
    List<String> operTeamList;

}
