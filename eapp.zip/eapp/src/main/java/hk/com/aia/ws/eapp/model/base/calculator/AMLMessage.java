package hk.com.aia.ws.eapp.model.base.calculator;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AMLMessage {

    @JsonProperty("risk_msg_e")
    private String riskMsgE;

    @JsonProperty("pend_code")
    private String pendCode;

    @JsonProperty("seq")
    private int seq;

    @JsonProperty("risk_desc_s")
    private String riskDescS;

    @JsonProperty("risk_level")
    private String riskLevel;

    @JsonProperty("risk_msg_c")
    private String riskMsgC;

    @JsonProperty("risk_msg_s")
    private String riskMsgS;

    @JsonProperty("risk_desc_c")
    private String riskDescC;

    @JsonProperty("risk_desc_e")
    private String riskDescE;

}
