package hk.com.aia.ws.eapp.mapper;

import hk.com.aia.ws.eapp.model.db.magnum.ipos.TEappCitiReviewer;
import hk.com.aia.ws.eapp.model.request.ipos.TEappCitiReviewerDto;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper
public interface TEappCitiReviewerMapper {

    TEappCitiReviewerMapper MAPPER = Mappers.getMapper(TEappCitiReviewerMapper.class);

    List<TEappCitiReviewer> mapToTEappCitiReviewerList(List<TEappCitiReviewerDto> tEappCitiReviewerDto);
}
