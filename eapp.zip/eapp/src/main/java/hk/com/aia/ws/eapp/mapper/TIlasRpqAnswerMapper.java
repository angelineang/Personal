package hk.com.aia.ws.eapp.mapper;

import hk.com.aia.ws.eapp.model.db.magnum.ipos.TIlasRpqAnswer;
import hk.com.aia.ws.eapp.model.request.ipos.TIlasRpqAnswerDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper
public interface TIlasRpqAnswerMapper {

    TIlasRpqAnswerMapper MAPPER = Mappers.getMapper(TIlasRpqAnswerMapper.class);

    @Mapping(target = "createdDateTime", ignore = true)
    List<TIlasRpqAnswer> mapToTIlasRpqAnswerList(List<TIlasRpqAnswerDto> tIlasRpqAnswerDto);
}
