package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import lombok.Data;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "T_COMMUNICATION")
public class TCommunication {

    @Column(name = "COMMUNICATIONID", length = 60)
    @Id
    private String communicationId;

    @Column(name = "CONTACTID", length = 60)
    private String contactId;

    @Column(name = "COUNTRYCODE", length = 4)
    private String countryCode;

    @Column(name = "COUNTRYNAME", length = 60)
    private String countryName;

    @Column(name = "AREACODE", length = 4)
    private String areaCode;

    @Column(name = "AREANAME", length = 100)
    private String areaName;

    @Column(name = "COMMUNICATION", length = 60)
    private String communication;

    @Column(name = "EADVICE", length = 4)
    private Integer eAdvice;

    @Column(name = "TYPE", length = 10)
    private String type;

    @Column(name = "CREATEDBY", length = 10, updatable = false)
    @CreatedBy
    private String createdBy;

    @Column(name = "UPDATEDBY", length = 10)
    @LastModifiedBy
    private String updatedBy;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "LASTUPDATEDATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    @LastModifiedDate
    private Date lastUpdateDateTime;

    @Column(name = "SubType", length = 20)
    private String subType;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TCommunication{");
        sb.append("communicationId='").append(communicationId).append('\'');
        sb.append(", contactId='").append(contactId).append('\'');
        sb.append(", countryCode='").append(countryCode).append('\'');
        sb.append(", countryName='").append(countryName).append('\'');
        sb.append(", areaCode='").append(areaCode).append('\'');
        sb.append(", areaName='").append(areaName).append('\'');
        sb.append(", communication='").append(communication).append('\'');
        sb.append(", eAdvice=").append(eAdvice);
        sb.append(", type='").append(type).append('\'');
        sb.append(", createdBy='").append(createdBy).append('\'');
        sb.append(", updatedBy='").append(updatedBy).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", lastUpdateDateTime=").append(lastUpdateDateTime);
        sb.append(", subType='").append(subType).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
