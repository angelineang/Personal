package hk.com.aia.ws.eapp.controller;

import hk.com.aia.ws.eapp.model.base.Payload;
import hk.com.aia.ws.eapp.model.request.*;
import hk.com.aia.ws.eapp.model.request.FileRequest;
import hk.com.aia.ws.eapp.model.request.PulishKafkaRequest;
import hk.com.aia.ws.eapp.model.request.Request;
import hk.com.aia.ws.eapp.model.request.RRRequest;
import hk.com.aia.ws.eapp.model.request.Request;
import hk.com.aia.ws.eapp.model.response.FileResponse;
import hk.com.aia.ws.eapp.model.response.Response;
import hk.com.aia.ws.eapp.service.RRService;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@AllArgsConstructor
@RestController
@RequestMapping("/rr")
public class RRController {

    @Autowired
    RRService rrService;

    @ApiOperation(value = "To push EAPP case to XGFE-NB only , will not trigger stage_to_eus")
    @PostMapping(value = "/retry", produces = MediaType.APPLICATION_JSON_VALUE)
    public Response<Payload> retryXGFE(@RequestBody Request<RRRequest> request) {
        return rrService.retryXgfe(request);
    }

    @ApiOperation(value = "To trigger SP nb_stage_to_eus and push to XGFE-NB ")
    @PostMapping(value = "/restage", produces = MediaType.APPLICATION_JSON_VALUE)
    public Response<Payload> restageToEus(@RequestBody Request<RRRequest> request) {
        return rrService.restageToEus(request);
    }

    @ApiOperation(value = "To trigger SP nb_stage_to_iw , to release document again")
    @PostMapping(value = "/restage-iw", produces = MediaType.APPLICATION_JSON_VALUE)
    public Response<Payload> restageToIW(@RequestBody Request<RRRequest> request) {
        return rrService.restageToIW(request);
    }

    @PostMapping(value = "/getfilefromdb", produces = MediaType.APPLICATION_JSON_VALUE)
    public FileResponse<Payload> getFileFromDbMag(@RequestBody FileRequest<Payload> request) {

        return rrService.getFileFromDbMag(request);
    }

    @PostMapping(value = "/updbatchmst", produces = MediaType.APPLICATION_JSON_VALUE)
    public Response<Payload> updBatchMst(@RequestBody Request<UpdBatchMstRequest> request) {

        return rrService.updBatchMst(request);
    }

    @PostMapping(value = "/retry-sftp", produces = MediaType.APPLICATION_JSON_VALUE)
    public Response<Payload> retrySftp(@RequestBody Request<RetrySftpRequest> request) {

        return rrService.retrySftp(request);
    }

    @PostMapping(value = "/retry-pgs-kafka", produces = MediaType.APPLICATION_JSON_VALUE)
    public Response<Payload> retryPGSKafka(@RequestBody Request<RetryPGSKafkaRequest> request) {

        return rrService.retryPGSKafka(request);
    }
    





}
