package hk.com.aia.ws.eapp.model.request.ipos;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@ApiModel(value = "T_ADDRESS Model")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TAddressDto {

	@ApiModelProperty(value = "address Id", required = true) 
    @JsonProperty("address_id")
	@Size(max = 60)
    @NotBlank
    private String addressId;

    @JsonProperty("contact_id")
    @Size(max = 60)
    private String contactId;

    @JsonProperty("postal_code")
    @Size(max = 10)
    private String postalCode;

    @JsonProperty("room_no")
    @Size(max = 100)
    private String roomNo;

    @JsonProperty("floor")
    @Size(max = 60)
    private String floor;

    @JsonProperty("block")
    @Size(max = 300)
    private String block;

    @JsonProperty("building")
    @Size(max = 500)
    private String building;

    @JsonProperty("street_line_1")
    @Size(max = 800)
    private String streetLine1;

    @JsonProperty("street_line_2")
    @Size(max = 800)
    private String streetLine2;

    @JsonProperty("city")
    @Size(max = 255)
    private String city;

    @JsonProperty("province")
    @Size(max = 255)
    private String province;

    @JsonProperty("country_code")
    @Size(max = 100)
    private String countryCode;

    @JsonProperty("country_name")
    @Size(max = 255)
    private String countryName;

    @JsonProperty("same_as")
    @Size(max = 20)
    private String sameAs;

    @JsonProperty("address_type")
    @Size(max = 20)
    private String addressType;

    @JsonProperty("employer_name")
    @Size(max = 500)
    private String employerName;

    @JsonProperty("input_language")
    @Size(max = 10)
    private String inputLanguage;

    @JsonProperty("district")
    @Size(max = 500)
    private String district;

    @JsonProperty("streets")
    @Size(max = 255)
    private String streets;

    @JsonProperty("street_line_3")
    @Size(max = 1000)
    private String streetLine3;

    @JsonProperty("street_line_4")
    @Size(max = 1000)
    private String streetLine4;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TAddressDto{");
        sb.append("addressId='").append(addressId).append('\'');
        sb.append(", contactId='").append(ConversionHandler.mask(contactId)).append('\'');
        sb.append(", postalCode='").append(postalCode).append('\'');
        sb.append(", roomNo='").append(roomNo).append('\'');
        sb.append(", floor='").append(floor).append('\'');
        sb.append(", block='").append(block).append('\'');
        sb.append(", building='").append(building).append('\'');
        sb.append(", streetLine1='").append(streetLine1).append('\'');
        sb.append(", streetLine2='").append(streetLine2).append('\'');
        sb.append(", city='").append(city).append('\'');
        sb.append(", province='").append(province).append('\'');
        sb.append(", countryCode='").append(countryCode).append('\'');
        sb.append(", countryName='").append(countryName).append('\'');
        sb.append(", sameAs='").append(sameAs).append('\'');
        sb.append(", addressType='").append(addressType).append('\'');
        sb.append(", employerName='").append(ConversionHandler.mask(employerName)).append('\'');
        sb.append(", inputLanguage='").append(inputLanguage).append('\'');
        sb.append(", district='").append(district).append('\'');
        sb.append(", streets='").append(streets).append('\'');
        sb.append(", streetLine3='").append(streetLine3).append('\'');
        sb.append(", streetLine4='").append(streetLine4).append('\'');
        sb.append('}');
        return sb.toString();
    }
}