package hk.com.aia.ws.eapp.model.request.ipos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.annotation.DateTimeValidation;
import hk.com.aia.ws.eapp.model.base.Payload;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.List;

@ApiModel(value = "Submit Policy - IPOS - Model ")
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class SubmitPolicyIpos extends Payload {

    @ApiModelProperty(value = "eapp Id", required = true)
    @NotBlank
    @JsonProperty("eapp_id")
    private String eappId;

    @ApiModelProperty(value = "Policy Number")
    @JsonProperty("policy_no")
    @NotBlank
    private String policyNo;

    @ApiModelProperty(value = "Last Sign Date yyyy-MM-dd", example = "2020-12-31", required = true)
    @JsonProperty("last_sign_date")
    @NotBlank
    @DateTimeValidation(format = "yyyy-MM-dd")
    private String lastSignDate;

    @ApiModelProperty(value = "Submit Type")
    @JsonProperty("submit_type")
    private String submitType;

    @ApiModelProperty(value = "T_Relationship")
    @JsonProperty("t_relationship")
    @Valid
    private List<TRelationshipDto> tRelationshipDto;

    @ApiModelProperty(value = "T_Communication")
    @JsonProperty("t_communication")
    @Valid
    private List<TCommunicationDto> tCommunicationDto;

    @ApiModelProperty(value = "T_EappContact")
    @JsonProperty("t_eapp_contact")
    @Valid
    private List<TEappContactDto> tEappContactDto;

    @ApiModelProperty(value = "T_Occupation")
    @JsonProperty("t_occupation")
    @Valid
    private List<TOccupationDto> tOccupationDto;

    @ApiModelProperty(value = "T_Eapp")
    @JsonProperty("t_eapp")
    @Valid
    @NotNull
    private TEappDto tEappDto;

    @ApiModelProperty(value = "T_EappPayor")
    @JsonProperty("t_eapppayor")
    @Valid
    private TEappPayorDto tEappPayorDto;
    
    @ApiModelProperty(value = "T_VOMEETING")
    @JsonProperty("t_vomeeting")
    @Valid
    private TVomeetingDto tVomeetingDto;

    @ApiModelProperty(value = "T_EAPP_PF")
    @JsonProperty("t_eapp_pf")
    @Valid
    private TEappPfDto tEappPfDto;

    @ApiModelProperty(value = "T_Contact")
    @JsonProperty("t_contact")
    @Valid
    @NotNull
    private List<TContactDto> tContactDto;

    @ApiModelProperty(value = "T_Address")
    @JsonProperty("t_address")
    @Valid
    private List<TAddressDto> tAddressDto;

    @ApiModelProperty(value = "T_PaymentDetail")
    @JsonProperty("t_payment_detail")
    @Valid
    private List<TPaymentDetailDto> tPaymentDetailDto;

    @ApiModelProperty(value = "T_EappInsurancePurpose")
    @JsonProperty("t_eapp_insurance_purpose")
    @Valid
    private List<TEappInsurancePurposeDto> tEappInsurancePurposeDto;

    @ApiModelProperty(value = "T_EAPPPREMIUMPAYMENTSOURCE")
    @JsonProperty("t_eapp_premium_payment_source")
    @Valid
    private List<TEappPremiumPaymentSourcedDto> tEappPremiumPaymentSourcedDto;

    @ApiModelProperty(value = "T_EAPPSPECIALREQ")
    @JsonProperty("t_eapp_special_req")
    @Valid
    private List<TEappSpecialReqDto> tEappSpecialReqDto;

    @ApiModelProperty(value = "T_IDCARD")
    @JsonProperty("t_id_card")
    @Valid
    private List<TIdCardDto> tIdCardDto;

    @ApiModelProperty(value = "T_SIMULATION")
    @JsonProperty("t_simulation")
    @Valid
    private List<TSimulationDto> tSimulationDto;

    @ApiModelProperty(value = "T_EAPPBENEFICIARY")
    @JsonProperty("t_eapp_beneficiary")
    @Valid
    private List<TEappBeneficiaryDto> tEappBeneficiaryDto;

    @ApiModelProperty(value = "T_DOC")
    @JsonProperty("t_doc")
    @Valid
    private List<TDocDto> tDocDto;

    @ApiModelProperty(value = "T_DVAGT")
    @JsonProperty("t_dvagt")
    @Valid
    private List<TDvaGtDto> tDvaGtDto;

    @ApiModelProperty(value = "T_ACCOUNTCARDOWNER")
    @JsonProperty("t_account_card_owner")
    @Valid
    private List<TAccountCardOwnerDto> tAccountCardOwnerDto;

    @ApiModelProperty(value = "T_ESUB")
    @JsonProperty("t_esub")
    @Valid
    private TEsubDto tEsubDto;

    @ApiModelProperty(value = "T_ADHOCTOPUP")
    @JsonProperty("t_adhoc_top_up")
    @Valid
    private List<TAdhocTopUpDto> tAdhocTopUpDto;

    @ApiModelProperty(value = "T_BASICPLANSELECTION")
    @JsonProperty("t_basic_plan_selection")
    @Valid
    private List<TBasicPlanSelectionDto> tBasicPlanSelectionDto;

    @ApiModelProperty(value = "T_CHANGESUMASSURED")
    @JsonProperty("t_change_sum_assured")
    @Valid
    private List<TChangeSumAssuredDto> tChangeSumAssuredDto;

    @ApiModelProperty(value = "T_EAPPQANSWER")
    @JsonProperty("t_eapp_q_answer")
    @Valid
    private List<TEappQAnswerDto> tEappqAnswerDto;

    @ApiModelProperty(value = "T_EAPPQINSURANCEHIS")
    @JsonProperty("t_eapp_q_insurance_his")
    @Valid
    private List<TEappQInsuranceHisDto> tEappQInsuranceHisDto;

    @ApiModelProperty(value = "T_SQSQUOTATION")
    @JsonProperty("t_sqs_quotation")
    @Valid
    private TSqsQuotationDto tSqsQuotationDto;

    @ApiModelProperty(value = "T_PREMIUMHOLIDAY")
    @JsonProperty("t_premium_holiday")
    @Valid
    private List<TPremiumHolidayDto> tPremiumHolidayDto;

    @ApiModelProperty(value = "T_PLANSELECTION")
    @JsonProperty("t_plan_selection")
    @Valid
    private List<TPlanSelectionDto> tPlanSelectionDto;

    @ApiModelProperty(value = "T_SPLITPREMIUM")
    @JsonProperty("t_split_premium")
    @Valid
    private List<TSplitPremiumDto> tSplitPremiumDto;

    @ApiModelProperty(value = "T_TEMPORARYRATING")
    @JsonProperty("t_temporary_rating")
    @Valid
    private List<TTemporaryRatingDto> tTemporaryRatingDto;

    @ApiModelProperty(value = "T_PERMANENTRATING")
    @JsonProperty("t_permanent_rating")
    @Valid
    private List<TPermanentRatingDto> tPermanentRatingDto;

    @ApiModelProperty(value = "T_PERMANENTFLATRATING")
    @JsonProperty("t_permanent_flat_rating")
    @Valid
    private List<TPermanentFlatRatingDto> tPermanentFlatRatingDto;

    @ApiModelProperty(value = "T_WITHDRAWAL")
    @JsonProperty("t_withdrawal")
    @Valid
    private List<TWithdrawalDto> tWithdrawalDto;

    @ApiModelProperty(value = "T_CONTACTHISTORY")
    @JsonProperty("t_contact_history")
    @Valid
    private List<TContactHistoryDto> tContactHistoryDto;

    @ApiModelProperty(value = "T_SQSDOCUMENT")
    @JsonProperty("t_sqs_document")
    @Valid
    private List<TSqsDocumentDto> tSqsDocumentDto;

    @ApiModelProperty(value = "T_TERMCONVERSIONLIST")
    @JsonProperty("t_term_conversion_list")
    @Valid
    private List<TTermConversionListDto> tterConversionListDto;

    @ApiModelProperty(value = "T_EAPPTRUSTEE")
    @JsonProperty("t_eapp_trustee")
    @Valid
    private List<TEappTrusteeDto> tEappTrusteeDto;

    @ApiModelProperty(value = "T_CITIFNA")
    @JsonProperty("t_citi_fna")
    @Valid
    private TCitiFnaDto tCitiFnaDto;

    @ApiModelProperty(value = "T_CITIYOURFINANCIALS")
    @JsonProperty("t_citi_your_financials")
    @Valid
    private List<TCitiYourFinancialsDto> tCitiYourFinancialsDto;

    @ApiModelProperty(value = "T_CITIEXISTINGPOLICY")
    @JsonProperty("t_citi_existing_policy")
    @Valid
    private List<TCitiExistingPolicyDto> tCitiExistingPolicyDto;

    @ApiModelProperty(value = "T_CITIINSOBJECTIVES")
    @JsonProperty("t_citi_ins_objectives")
    @Valid
    private List<TCitiInsObjectivesDto> tCitiInsObjectivesDto;

    @ApiModelProperty(value = "T_CITIANSWER")
    @JsonProperty("t_citi_answer")
    @Valid
    private List<TCitiAnswerDto> tCitiAnswerDto;

    @ApiModelProperty(value = "T_CONTACTCITIEXTRA")
    @JsonProperty("t_contact_citi_extra")
    @Valid
    private List<TContactCitiExtraDto> tContactCitiExtraDto;

    @ApiModelProperty(value = "T_EAPPCITIDDA")
    @JsonProperty("t_eapp_citi_dda")
    @Valid
    private List<TEappCitiDdaDto> tEappCitiDdaDto;

    @ApiModelProperty(value = "T_EAPPCITIEXTRA")
    @JsonProperty("t_eapp_citi_extra")
    @Valid
    private TEappCitiExtraDto tEappCitiExtraDto;

    @ApiModelProperty(value = "T_EAPPCITIRECOMMENDATIONS")
    @JsonProperty("t_eapp_citi_recommendations")
    @Valid
    private List<TEappCitiRecommendationsDto> tEappCitiRecommendationsDto;

    @ApiModelProperty(value = "T_EAPPCITIREVIEWER")
    @JsonProperty("t_eapp_citi_reviewer")
    @Valid
    private List<TEappCitiReviewerDto> tEappCitiReviewerDto;

    @ApiModelProperty(value = "T_CITIFNAHISTORY")
    @JsonProperty("t_citi_fna_history")
    @Valid
    private List<TCitiFnaHistoryDto> tCitiFnaHistoryDto;

    @ApiModelProperty(value = "T_ILASCONTACTFNA")
    @JsonProperty("t_ilas_contact_fna")
    @Valid
    private List<TIlasContactFNADto> tIlasContactFNADto;

    @ApiModelProperty(value = "T_ILASFNA")
    @JsonProperty("t_ilas_fna")
    @Valid
    private List<TIlasFNADto> tIlasFNADto;

    @ApiModelProperty(value = "T_ILASFNAAFFORDABILITY")
    @JsonProperty("t_ilas_fna_affordability")
    @Valid
    private List<TIlasFnaAffordabilityDto> tIlasFnaAffordabilityDto;

    @ApiModelProperty(value = "T_ILASFNAEDUCTION")
    @JsonProperty("t_ilas_fna_eduction")
    @Valid
    private List<TIlasFnaEductionDto> tIlasFnaEductionDto;

    @ApiModelProperty(value = "T_ILASFNAEVALUATION")
    @JsonProperty("t_ilas_fna_evaluation")
    @Valid
    private List<TIlasFnaEvaluationDto> tIlasFnaEvaluationDto;

    @ApiModelProperty(value = "T_ILASFNAFINANCIALSTATUS")
    @JsonProperty("t_ilas_fna_financial_status")
    @Valid
    private List<TIlasFnaFinancialStatusDto> tIlasFnaFinancialStatusDto;

    @ApiModelProperty(value = "T_ILASFUNDSELECTION")
    @JsonProperty("t_ilas_fund_selection")
    @Valid
    private List<TIlasFundSelectionDto> tIlasFundSelectionDto;

    @ApiModelProperty(value = "T_ILASIFSANSWER")
    @JsonProperty("t_ilas_ifs_answer")
    @Valid
    private List<TIlasIfsAnswerDto> tIlasIfsAnswerDto;

    @ApiModelProperty(value = "T_ILASRPQANSWER")
    @JsonProperty("t_ilas_rpq_answer")
    @Valid
    private List<TIlasRpqAnswerDto> tIlasRpqAnswerDto;

    @ApiModelProperty(value = "T_CITIINSPRODUCTTYPE")
    @JsonProperty("t_citi_ins_product_type")
    @Valid
    private List<TCitiInsProductTypeDto> tCitiInsProductTypeDto;

    @ApiModelProperty(value = "T_ILASFNADECLARATION")
    @JsonProperty("t_ilas_fna_declaration")
    @Valid
    private List<TIlasFnaDeclarationDto> tIlasFnaDeclarationDto;

    @ApiModelProperty(value = "T_PEP")
    @JsonProperty("t_pep")
    @Valid
    private List<TPepDto> tPepDto;

    @ApiModelProperty(value = "T_EAPPMAGNUM")
    @JsonProperty("t_eapp_magnum")
    @Valid
    private List<TEappMagnumDto> tEappMagnumDto;

    @ApiModelProperty(value = "T_EAPPMAGNUMANSWERS")
    @JsonProperty("t_eapp_magnum_answers")
    @Valid
    private List<TEappMagnumAnswersDto> tEappMagnumAnswersDto;

    @ApiModelProperty(value = "T_TAX")
    @JsonProperty("t_tax")
    @Valid
    private List<TTaxDto> tTaxDto;

    @ApiModelProperty(value = "T_EAPP_EXPAND")
    @JsonProperty("t_eapp_expand")
    @Valid
    private List<TEappExpandDto> tEappExpandDto;

    @ApiModelProperty(value = "T_SOWD")
    @JsonProperty("t_sowd")
    @Valid
    private List<TSowdDto> tSowdDto;

    @ApiModelProperty(value = "T_SOWDAddress")
    @JsonProperty("t_sowd_address")
    @Valid
    private List<TSowdAddressDto> tSowdAddressDto;

    @ApiModelProperty(value = "T_FNAOtherER")
    @JsonProperty("t_fna_other_er")
    @Valid
    private List<TFnaOtherErDto> tFnaOtherErDto;

    @ApiModelProperty(value = "T_FinancialQuestion")
    @JsonProperty("t_financial_question")
    @Valid
    private List<TFinancialQuestionDto> tFinancialQuestionDto;

    @ApiModelProperty(value = "T_EAPPStepUp")
    @JsonProperty("t_eapp_step_up")
    @Valid
    private List<TEappStepUpDto> tEappStepUpDto;

    @ApiModelProperty(value = "T_LEVY")
    @JsonProperty("t_levy")
    @Valid
    private List<TLevyDto> tLevyDto;

    @ApiModelProperty(value = "T_EAPP_PROM_OFFER")
    @JsonProperty("t_eapp_prom_offer")
    @Valid
    private List<TEappPromOfferDto> tEappPromOfferDto;

    @ApiModelProperty(value = "T_OCRContact")
    @JsonProperty("t_ocr_contact")
    @Valid
    private List<TOcrContactDto> tOcrContactDto;

    @ApiModelProperty(value = "T_OCRContactCount")
    @JsonProperty("t_ocr_contact_count")
    @Valid
    private List<TOcrContactCountDto> tOcrContactCountDto;

    @ApiModelProperty(value = "T_TermConversion")
    @JsonProperty("t_term_conversion")
    @Valid
    private List<TTermConversionDto> tTermConversionDto;

    @ApiModelProperty(value = "T_ESubGPSLocation")
    @JsonProperty("t_esub_gps_location")
    @Valid
    private List<TEsubGPSLocationDto> teSubGPSLocationDto;

    @ApiModelProperty(value = "T_EfnaMapping")
    @JsonProperty("t_efna_mapping")
    @Valid
    private List<TEfnaMappingDto> tEfnaMappingDto;

    @ApiModelProperty(value = "T_EAppCPD")
    @JsonProperty("t_eapp_cpd")
    @Valid
    private List<TEappCpdDto> tEappCpdDto;

    @ApiModelProperty(value = "T_CPDSub")
    @JsonProperty("t_cpd_sub")
    @Valid
    private List<TCpdSubDto> tCpdSubDto;

    @ApiModelProperty(value = "T_OCR_RETAKE_COUNT")
    @JsonProperty("t_ocr_retake_count")
    @Valid
    private List<TOcrRetakeCountDto> tOcrRetakeCountDto;

    @ApiModelProperty(value = "T_EAPP_CONTINGENT_INSURE")
    @JsonProperty("t_eapp_contingent_insure")
    @Valid
    private List<TEappContingentInsureDto> tEappContigentInsureDto;

    @ApiModelProperty(value = "T_IRRANSWER")
    @JsonProperty("t_irr_answer")
    @Valid
    private List<TIrrAnswerDto> tIrrAnswerDto;

    @ApiModelProperty(value = "T_DOC_0 -- T_DOC_9")
    @JsonProperty("t_doc_details")
    @Valid
    private List<TDocDetailsDto> tDocDetailsDto;

    @ApiModelProperty(value = "T_EAPP_AUDIO_ANSWER")
    @JsonProperty("t_eapp_audio_answer")
    @Valid
    private List<TEappAudioAnswerDto> tEappAudioAnswerDto;

    @ApiModelProperty(value = "T_EAPP_REVIEWER")
    @JsonProperty("t_eapp_reviewer")
    @Valid
    private List<TEappReviewerDto> tEappReviewerDto;

    @ApiModelProperty(value = "T_EAPPRECOMMENDLEVEL")
    @JsonProperty("t_eapp_recommend_level")
    @Valid
    private List<TEappRecommendLevelDto> tEappRecommendLevelDto;

    @ApiModelProperty(value = "T_EAPPNOCLAIM")
    @JsonProperty("t_eapp_no_claim")
    @Valid
    private List<TEappNoClaimDto> tEappNoClaimDto;
    
    @ApiModelProperty(value = "T_EAPP_DATA")
    @JsonProperty("t_eapp_data")
    @Valid
    private List<TEappDataDto> tEappDataDto;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("SubmitPolicyIpos{");
        sb.append("eappId='").append(eappId).append('\'');
        sb.append(", policyNo='").append(ConversionHandler.mask(policyNo)).append('\'');
        sb.append(", lastSignDate='").append(lastSignDate).append('\'');
        sb.append(", submitType='").append(submitType).append('\'');
        sb.append(", tEappDto=").append(tEappDto);
        sb.append(", tEsubDto=").append(tEsubDto);
        sb.append(", tSqsQuotationDto=").append(tSqsQuotationDto);
        sb.append(", tCitiFnaDto=").append(tCitiFnaDto);
        sb.append(", tEappCitiExtraDto=").append(tEappCitiExtraDto);
        sb.append(", tVomeetingDto=").append(tVomeetingDto);
        sb.append('}');
        return sb.toString();
    }
}
