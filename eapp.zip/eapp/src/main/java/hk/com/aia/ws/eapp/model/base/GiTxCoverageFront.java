package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@ApiModel(value = "GiTx Coverage Front")
@Data
public class GiTxCoverageFront {

    @ApiModelProperty(value = "Commission amount")
    @JsonProperty("commission_amount")
    private Double commissionAmount;

    @ApiModelProperty(value = "Component Code")
    @JsonProperty("component_code")
    private String componentCode;

    @ApiModelProperty(value = "Coverage Number")
    @JsonProperty("covr_no")
    private String covrNo;

    @ApiModelProperty(value = "Premium Amount")
    @JsonProperty("premium_amount")
    private Double premiumAmount;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("GiTxCoverageFront{");
        sb.append("commissionAmount=").append(commissionAmount);
        sb.append(", componentCode='").append(componentCode).append('\'');
        sb.append(", covrNo='").append(covrNo).append('\'');
        sb.append(", premiumAmount=").append(premiumAmount);
        sb.append('}');
        return sb.toString();
    }
}

