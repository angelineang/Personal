package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import lombok.Data;

@Data
public class PolicyInfo {

    @JsonProperty("policy_no")
    String policyNo;

    @JsonProperty("stage_date_time")
    String stageDateTime;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("PolicyInfo{");
        sb.append("policyNo='").append(ConversionHandler.mask(policyNo)).append('\'');
        sb.append(", stageDateTime='").append(stageDateTime).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
