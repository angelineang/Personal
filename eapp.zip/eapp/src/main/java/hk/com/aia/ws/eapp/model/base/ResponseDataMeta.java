package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class ResponseDataMeta {

    // "Code" starts with uppercase based on COIWS Response
    @JsonProperty("Code")
    String code;

    //"Description" starts with uppercase based on COIWS Response
    @JsonProperty("Description")
    String description;

    @JsonProperty("data")
    Object data;

    @JsonProperty("meta")
    ResponseMetaInfo meta;

    @JsonIgnore
    boolean is5xxServerError;

    @JsonIgnore
    int httpStatusCode;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("ResponseDataMeta{");
        sb.append("code='").append(code).append('\'');
        sb.append(", description='").append(description).append('\'');
        sb.append(", data=").append(data);
        sb.append(", meta=").append(meta);
        sb.append(", is5xxServerError=").append(is5xxServerError);
        sb.append(", httpStatusCode=").append(httpStatusCode);
        sb.append('}');
        return sb.toString();
    }
}
