package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "T_ILASRPQANSWER")
public class TIlasRpqAnswer {

    @Column(name = "RPQANSWERID", length = 60)
    @Id
    private String rpqAnswerId;

    @Column(name = "EAPPID", length = 60)
    private String eappId;

    @Column(name = "QNO", length = 3)
    private String qNo;

    @Column(name = "ANSWER")
    private Integer answer;

    @Column(name = "SCORE")
    private Integer score;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "educationLevel", length = 50)
    private String educationLevel;

    @Column(name = "CONTACTID", length = 60)
    private String contactId;

    @Column(name = "RPQVERSION", length = 20)
    private String rpqVersion;

    @Column(name = "QID", length = 60)
    private String qId;

    @Column(name = "QTITLE", length = 1000)
    private String qTitle;

    @Column(name = "AID", length = 60)
    private String aId;

    @Column(name = "ATITLE", length = 1000)
    private String aTitle;

    @Column(name = "RISKLEVEL", length = 10)
    private String riskLevel;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TIlasRpqAnswer{");
        sb.append("rpqAnswerId='").append(rpqAnswerId).append('\'');
        sb.append(", eappId='").append(eappId).append('\'');
        sb.append(", qNo='").append(qNo).append('\'');
        sb.append(", answer=").append(answer);
        sb.append(", score=").append(score);
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", educationLevel='").append(educationLevel).append('\'');
        sb.append(", contactId='").append(contactId).append('\'');
        sb.append(", rpqVersion='").append(rpqVersion).append('\'');
        sb.append(", qId='").append(qId).append('\'');
        sb.append(", qTitle='").append(qTitle).append('\'');
        sb.append(", aId='").append(aId).append('\'');
        sb.append(", aTitle='").append(aTitle).append('\'');
        sb.append(", riskLevel='").append(riskLevel).append('\'');
        sb.append('}');
        return sb.toString();
    }
}


