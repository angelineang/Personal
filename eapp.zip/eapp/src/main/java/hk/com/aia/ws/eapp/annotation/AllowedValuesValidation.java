package hk.com.aia.ws.eapp.annotation;

import hk.com.aia.ws.eapp.validation.AllowedValuesValidator;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.*;

@Documented
@Target({ElementType.FIELD, ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = AllowedValuesValidator.class)
public @interface AllowedValuesValidation {

    String message() default "Value not allowed";

    /**
     * Match the values given
     */
    String[] values() default {};

    /**
     * use the values from property file using the specified property key
     * multiple values is separated by comma ( , )
     * Takes precedence over values (above)
     */
    String propertyKey() default "";

    boolean caseSensitive() default false;

    boolean allowEmpty() default true;
    boolean allowNull() default true;

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

}