package hk.com.aia.ws.eapp.configuration;

import javax.servlet.http.HttpServletRequest;

import org.springframework.security.web.util.matcher.RequestMatcher;

public class AllExceptUrlsStartedWith implements RequestMatcher {

	public AllExceptUrlsStartedWith(String... allowedUrls) {
	}

	@Override
	public boolean matches(HttpServletRequest request) {

		

		return false;
	}

}
