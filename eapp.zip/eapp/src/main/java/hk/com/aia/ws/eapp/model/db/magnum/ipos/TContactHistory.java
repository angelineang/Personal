package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import hk.com.aia.ws.eapp.model.db.magnum.ipos.idclass.TContactHistoryId;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import lombok.Data;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "T_CONTACTHISTORY")
@IdClass(TContactHistoryId.class)
public class TContactHistory {

    @Column(name = "CONTACTHISTORYID", length = 60)
    @Id
    private String contactHistoryId;

    @Column(name = "AGENTCODE", length = 10)
    private String agentCode;

    @Column(name = "ACCESSCODE", length = 30)
    private String accessCode;

    @Column(name = "CONTACTID", length = 60)
    @Id
    private String contactId;

    @Column(name = "SQSQUOTATIONID", length = 60)
    @Id
    private String sqsQuotationId;

    @Column(name = "TITLE", length = 10)
    private String title;

    @Column(name = "LASTNAME", length = 50)
    private String lastName;

    @Column(name = "FIRSTNAME", length = 50)
    private String firstName;

    @Column(name = "ALIAS", length = 50)
    private String alias;

    @Column(name = "CHINESENAME", length = 255)
    private String chineseName;

    @Column(name = "DOB")
    private Integer dob;

    @Column(name = "ENTRYAGE")
    private Integer entryAge;

    @Column(name = "GENDER")
    private Integer gender;

    @Column(name = "SMOKER")
    private Integer smoker;

    @Column(name = "INDUSTRYCODE", length = 10)
    private String industryCode;

    @Column(name = "OCCUPATIONCODE", length = 10)
    private String occupationCode;

    @Column(name = "RESIDENCY", length = 100)
    private String residency;

    @Column(name = "CREATEDBY", length = 10, updatable = false)
    @CreatedBy
    private String createdBy;

    @Column(name = "UPDATEDBY", length = 10)
    @LastModifiedBy
    private String updatedBy;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "LASTUPDATEDATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    @LastModifiedDate
    private Date lastUpdateDateTime;

    @Column(name = "COUNTRYCODE", length = 255)
    private String countryCode;

    @Column(name = "CITYCODE", length = 255)
    private String cityCode;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TContactHistory{");
        sb.append("contactHistoryId='").append(contactHistoryId).append('\'');
        sb.append(", agentCode='").append(agentCode).append('\'');
        sb.append(", accessCode='").append(accessCode).append('\'');
        sb.append(", contactId='").append(contactId).append('\'');
        sb.append(", sqsQuotationId='").append(sqsQuotationId).append('\'');
        sb.append(", title='").append(title).append('\'');
        sb.append(", lastName='").append(ConversionHandler.mask(lastName)).append('\'');
        sb.append(", firstName='").append(ConversionHandler.mask(firstName)).append('\'');
        sb.append(", alias='").append(alias).append('\'');
        sb.append(", chineseName='").append(ConversionHandler.mask(chineseName)).append('\'');
        sb.append(", dob=").append(ConversionHandler.mask(dob));
        sb.append(", entryAge=").append(entryAge);
        sb.append(", gender=").append(gender);
        sb.append(", smoker=").append(smoker);
        sb.append(", industryCode='").append(industryCode).append('\'');
        sb.append(", occupationCode='").append(occupationCode).append('\'');
        sb.append(", residency='").append(residency).append('\'');
        sb.append(", createdBy='").append(createdBy).append('\'');
        sb.append(", updatedBy='").append(updatedBy).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", lastUpdateDateTime=").append(lastUpdateDateTime);
        sb.append(", countryCode='").append(countryCode).append('\'');
        sb.append(", cityCode='").append(cityCode).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
