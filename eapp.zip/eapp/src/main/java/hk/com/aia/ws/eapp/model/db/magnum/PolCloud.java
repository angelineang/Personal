package hk.com.aia.ws.eapp.model.db.magnum;

import hk.com.aia.ws.eapp.util.ConversionHandler;
import lombok.Data;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Data
@Entity
@Table(name = "tbl_pol_cloud")
@EntityListeners(AuditingEntityListener.class)
public class PolCloud {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "app_id")
    private String appId;

    @Column(name = "policy_no")
    private String policyNo;

    @Column(name = "trace_id")
    private String traceId;

    @Column(name = "caller_context_id")
    private String callerContextId;

    @Column(name = "app_context_id")
    private String appContextId;
    
    @Column(name = "source_user_id")
    private String sourceUserId;
    
    @Column(name = "source_user_ip")
    private String sourceUserIp;

    @Column(name = "created_by", length = 50)
    @CreatedBy
    private String createdBy;

    @Column(name = "created_date")
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("PolCloud{");
        sb.append("id=").append(id);
        sb.append(", appId='").append(appId).append('\'');
        sb.append(", policyNo='").append(ConversionHandler.mask(policyNo)).append('\'');
        sb.append(", createdBy='").append(createdBy).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append('}');
        return sb.toString();
    }
}
