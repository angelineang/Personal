package hk.com.aia.ws.eapp.mapper;

import hk.com.aia.ws.eapp.model.db.magnum.ipos.TFnaOtherEr;
import hk.com.aia.ws.eapp.model.request.ipos.TFnaOtherErDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper
public interface TFnaOtherErMapper {

    TFnaOtherErMapper MAPPER = Mappers.getMapper(TFnaOtherErMapper.class);
    @Mapping(target = "createdDateTime", ignore = true)
    List<TFnaOtherEr> mapToTFnaOtherErList(List<TFnaOtherErDto> tFnaOtherErDto);
}
