package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.annotation.AllowedValuesValidation;
import hk.com.aia.ws.eapp.annotation.DateTimeValidation;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;

@ApiModel(value = "Submission Model")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CsSubmission {

    // API Model Property - copied from old code

    @ApiModelProperty(value = "CS - Corporate Solution,CC - Call Centre,EC - Ecommerce,HL - HL ", allowableValues = "CS,CC,EC,HL,FS", required = true)
    @JsonProperty("submit_channel")
    @NotBlank
    @AllowedValuesValidation(values = {"CS", "CC", "EC", "HL", "FS"})
    private String submitChannel;

    @ApiModelProperty(value = "E - Submission", allowableValues = "E", required = true)
    @JsonProperty("submit_type")
    @NotBlank
    @AllowedValuesValidation(values = {"E"})
    private String submitType;

    @ApiModelProperty(value = "Channel  + Agent Code + YYYYMMDD + HHMM + 2 digits of random number ", example = "CS20160311B123456789", required = true)
    @JsonProperty("ref_no")
    @NotBlank
    private String refNo;

    @ApiModelProperty(value = "policy no ", example = "B123456789", required = true)
    @JsonProperty("pol_no")
    @NotBlank
    private String polNo;

    @ApiModelProperty(value = "APPLICATION SIGNED DATE (MM/DD/YYYY) ", example = "03/11/2016", required = true)
    @JsonProperty("last_sign_date")
    private String lastSignDate;

    @ApiModelProperty(value = "0 - Non-medical case, 1 - Medical case, 4 - Conversion, 6 - Mass Marketing", example = "\"0\"")
    @JsonProperty("medical")
    private String medical;

    @ApiModelProperty(value = "12 - Annual,6 - Semi-Annual,3 - Quarterly,1 - Monthly,0 - Single Premium", example = "\"12\"", allowableValues = "12,6,3,1,0")
    @JsonProperty("pay_mode")
    @AllowedValuesValidation(values = {"12", "6", "3", "1", "0"})
    private String payMode;

    @ApiModelProperty(value = "001 - USD , 048 - HKD, 049 - MOP ", example = "048", allowableValues = "001,048,049")
    @JsonProperty("pol_cur")
    @AllowedValuesValidation(values = {"001", "048", "049"})
    private String polCur;

    @ApiModelProperty(value = "Policy Date (MM/DD/YYYY)", example = "03/11/2016")
    @JsonProperty("pol_date")
    @DateTimeValidation(format = "MM/dd/yyyy")
    private String polDate;

    @ApiModelProperty(value = "CPD Section - Y = Yes, N = No, D - Uncertain", allowableValues = "Y,N,D")
    @JsonProperty("cpd_section")
    @AllowedValuesValidation(values = {"Y", "N", "D"})
    private String cpdSection;

    @ApiModelProperty(value = "Mod Premium", example = "\"5000\"")
    @JsonProperty("mod_premium")
    private String modPremium;

    @ApiModelProperty(value = "Par option")
    @JsonProperty("par_option")
    private String parOption;

    @ApiModelProperty(value = "01 - Traditional Chinese, 02 - English, 03 - Simplified Chinese ", example = "02", allowableValues = "01,02,03")
    @JsonProperty("contract_language")
    @AllowedValuesValidation(values = {"01", "02", "03"})
    private String contractLanguage;

    @ApiModelProperty(value = "	1 = China Client form submitted, N = No", example = "N", allowableValues = "1,N")
    @JsonProperty("client_china")
    @AllowedValuesValidation(values = {"1", "N"})
    private String clientChina;

    @ApiModelProperty(value = "E-Invest - Y = Yes, N = No", example = "N", allowableValues = "Y,N")
    @JsonProperty("e_invest")
    @AllowedValuesValidation(values = {"Y", "N"})
    private String eInvest;

    @ApiModelProperty(value = "E-Advice - Y = Yes, N = No", example = "N", allowableValues = "Y,N")
    @JsonProperty("e_advice")
    @AllowedValuesValidation(values = {"Y", "N"})
    private String eAdvice;

    @ApiModelProperty(value = "Opt-out - Y = Yes, N = No", example = "N", allowableValues = "Y,N")
    @JsonProperty("opt_out")
    @AllowedValuesValidation(values = {"Y", "N"})
    private String optOut;

    @ApiModelProperty(value = "Agent Code 1 (5 char)", example = "\"12345\"")
    @JsonProperty("agt_code_1")
    @Size(max = 5)
    private String agtCode1;

    @ApiModelProperty(value = "Agent Code 2 (5 char)", example = "\"12345\"")
    @JsonProperty("agt_code_2")
    @Size(max = 5)
    private String agtCode2;

    @ApiModelProperty(value = "Apply Vitality - Y = Yes, N = No", example = "Y", allowableValues = "Y,N")
    @JsonProperty("apply_vitality")
    @AllowedValuesValidation(values = {"Y", "N"})
    private String applyVitality;

    @ApiModelProperty(value = "I-Contract - Y = Yes, N = No", example = "Y", allowableValues = "Y,N")
    @JsonProperty("i_contract")
    @AllowedValuesValidation(values = {"Y", "N"})
    private String iContract;

    @ApiModelProperty(value = "Application Declaration", example = "A", allowableValues = "A,B")
    @JsonProperty("app_declaration")
    @AllowedValuesValidation(values = {"A", "B"})
    private String appDeclaration;

    @ApiModelProperty(value = "Special Request - Free text", example = "Free text")
    @JsonProperty("special_request")
    private String specialRequest;

    @ApiModelProperty(value = "Transaction code 1 (11 char)", example = "0000012345")
    @JsonProperty("tr_code_1")
    @Size(max = 11)
    private String trCode1;

    @ApiModelProperty(value = "Transaction code 2 (11 char)", example = "0000012345")
    @JsonProperty("tr_code_2")
    @Size(max = 11)
    private String trCode2;

    @ApiModelProperty(value = "coverages list")
    @JsonProperty("coverages")
    @Valid
    private Coverage[] coverages;

    @ApiModelProperty(value = "client list")
    @JsonProperty("clients")
    @Valid
    private Client[] clients;

    @ApiModelProperty(value = "client addresses")
    @JsonProperty("addresses")
    @Valid
    private Address[] addresses;

    @ApiModelProperty(value = "supporting documents")
    @JsonProperty("documents")
    @Valid
    private EappDocument[] documents;

    @ApiModelProperty(value = "beneficiary list")
    @JsonProperty("beneficiary")
    @Valid
    private Beneficiary[] beneficiary;

    @ApiModelProperty(value = "auto pay details")
    @JsonProperty("auto_pays")
    @Valid
    private AutoPay[] autoPays;

    @ApiModelProperty(value = "questionnaire list")
    @JsonProperty("questions")
    @Valid
    private Question[] question;

    @ApiModelProperty(value = "Dduw list")
    @JsonProperty("dduws")
    @Valid
    private Dduw[] dduws;

    @ApiModelProperty(value = "Impairment list")
    @JsonProperty("impairments")
    @Valid
    private Impairment[] impairments;

    @ApiModelProperty(value = "PolFna")
    @JsonProperty("pol_fna")
    @Valid
    private PolFna polFna;

    @ApiModelProperty(value = "ifsPr")
    @JsonProperty("ifs_pr")
    @Valid
    private IfsPr ifsPr;

    @ApiModelProperty(value = "Group Pol No (10 char)", example = "0000012345")
    @JsonProperty("group_pol_no")
    @Size(max = 10)
    private String groupPolNo;

    @ApiModelProperty(value = "Group Member Id (10 char)", example = "0000012345")
    @JsonProperty("group_member_id")
    @Size(max = 10)
    private String groupMemberId;

    @ApiModelProperty(value = "Y - Yes,N - No", example = "Y", allowableValues = "Y,N")
    @JsonProperty("conversion")
    @AllowedValuesValidation(values = {"Y", "N"})
    private String conversion;

    @ApiModelProperty(value = "Medical Cover End date (MM/DD/YYYY)", example = "12/31/2019")
    @JsonProperty("med_cov_end_date")
    @DateTimeValidation(format = "MM/dd/yyyy")
    private String medCovEndDate;

    @ApiModelProperty(value = "Jp Rel Scheme - Y = Yes, N = No", example = "Y", allowableValues = "Y,N")
    @JsonProperty("jp_rel_scheme")
    @AllowedValuesValidation(values = {"Y", "N"})
    private String jpRelScheme;

    @ApiModelProperty(value = "Witness - Y = Yes, N = No", example = "Y", allowableValues = "Y,N")
    @JsonProperty("witness")
    @AllowedValuesValidation(values = {"Y", "N"})
    private String witness;

    @ApiModelProperty(value = "PT Member - Y = Yes, N = No", example = "Y", allowableValues = "Y,N")
    @JsonProperty("pt_member")
    @AllowedValuesValidation(values = {"Y", "N"})
    private String ptMember;

    @ApiModelProperty(value = "Sub Agent Type - 1a->4c")
    @JsonProperty("sub_agt_type")
    private String subAgtType;

    @ApiModelProperty(value = "AIA Customer - Y = New customer, N = Existing customer", example = "Y", allowableValues = "Y,N")
    @JsonProperty("aia_customer")
    @AllowedValuesValidation(values = {"Y", "N"})
    private String aiaCustomer;

    @ApiModelProperty(value = "UW Class Indicator : 1, 2, 3, 4", example = "\"1\"", allowableValues = "1, 2, 3, 4")
    @JsonProperty("uw_class_ind")
    @AllowedValuesValidation(values = {"1", "2", "3", "4"})
    private String uwClassInd;

    @ApiModelProperty(value = "IFS PRC Sign Date")
    @JsonProperty("ifs_prc_sign_date")
    @DateTimeValidation(format = "MM/dd/yyyy")
    private String ifsPrcSignDate;


    //Import from old code, the custom getters
    @JsonIgnore
    SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");

    public String getSubmitType() {
        return StringUtils.isBlank(submitType) ? "E" : submitType;
    }

    public String getLastSignDate() {

        if (StringUtils.isBlank(lastSignDate)) {
            lastSignDate = dateFormat.format(new Date());
        }

        return lastSignDate;
    }

    public String getMedical() {
        return StringUtils.isBlank(medical) ? "0" : medical;
    }

    public String getPolDate() {

        if (StringUtils.isBlank(polDate)) {
            polDate = dateFormat.format(new Date());
        }

        return polDate;
    }

    public String getCpdSection() {
        return StringUtils.isBlank(cpdSection) ? "N" : cpdSection;
    }

    public String getContractLanguage() {
        return StringUtils.isBlank(contractLanguage) ? "02" : contractLanguage;
    }

    public String getClientChina() {
        return StringUtils.isBlank(clientChina) ? "N" : clientChina;
    }

    public String getEInvest() {
        return StringUtils.isBlank(eInvest) ? "N" : eInvest;
    }

    public String getEAdvice() {
        return StringUtils.isBlank(eAdvice) ? "N" : eAdvice;
    }

    public String getIContract() {
        return StringUtils.isBlank(iContract) ? "Y" : iContract;
    }

    public String getAppDeclaration() {
        return StringUtils.isBlank(appDeclaration) ? "Y" : appDeclaration;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("CsSubmission{");
        sb.append("submitChannel='").append(submitChannel).append('\'');
        sb.append(", submitType='").append(submitType).append('\'');
        sb.append(", refNo='").append(refNo).append('\'');
        sb.append(", polNo='").append(ConversionHandler.mask(polNo)).append('\'');
        sb.append(", lastSignDate='").append(lastSignDate).append('\'');
        sb.append(", medical='").append(medical).append('\'');
        sb.append(", payMode='").append(payMode).append('\'');
        sb.append(", polCur='").append(polCur).append('\'');
        sb.append(", polDate='").append(polDate).append('\'');
        sb.append(", cpdSection='").append(cpdSection).append('\'');
        sb.append(", modPremium='").append(modPremium).append('\'');
        sb.append(", parOption='").append(parOption).append('\'');
        sb.append(", contractLanguage='").append(contractLanguage).append('\'');
        sb.append(", clientChina='").append(clientChina).append('\'');
        sb.append(", eInvest='").append(eInvest).append('\'');
        sb.append(", eAdvice='").append(eAdvice).append('\'');
        sb.append(", optOut='").append(optOut).append('\'');
        sb.append(", agtCode1='").append(agtCode1).append('\'');
        sb.append(", agtCode2='").append(agtCode2).append('\'');
        sb.append(", applyVitality='").append(applyVitality).append('\'');
        sb.append(", iContract='").append(iContract).append('\'');
        sb.append(", appDeclaration='").append(appDeclaration).append('\'');
        sb.append(", specialRequest='").append(specialRequest).append('\'');
        sb.append(", trCode1='").append(trCode1).append('\'');
        sb.append(", trCode2='").append(trCode2).append('\'');
        sb.append(", polFna=").append(polFna);
        sb.append(", ifsPr=").append(ifsPr);
        sb.append(", groupPolNo='").append(groupPolNo).append('\'');
        sb.append(", groupMemberId='").append(groupMemberId).append('\'');
        sb.append(", conversion='").append(conversion).append('\'');
        sb.append(", medCovEndDate='").append(medCovEndDate).append('\'');
        sb.append(", jpRelScheme='").append(jpRelScheme).append('\'');
        sb.append(", witness='").append(witness).append('\'');
        sb.append(", ptMember='").append(ptMember).append('\'');
        sb.append(", subAgtType='").append(subAgtType).append('\'');
        sb.append(", aiaCustomer='").append(aiaCustomer).append('\'');
        sb.append(", uwClassInd='").append(uwClassInd).append('\'');
        sb.append(", ifsPrcSignDate='").append(ifsPrcSignDate).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
