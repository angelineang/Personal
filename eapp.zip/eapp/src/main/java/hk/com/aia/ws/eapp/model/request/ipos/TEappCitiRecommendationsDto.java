package hk.com.aia.ws.eapp.model.request.ipos;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.annotation.AllowedValuesValidation;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@ApiModel(value = "T_EAPPCITIRECOMMENDATIONS Model")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TEappCitiRecommendationsDto {

	@ApiModelProperty(value = "citi Rec Id", required = true)
    @JsonProperty("citi_rec_id")
	@Size(max = 60)
	@NotBlank
    private String citiRecId;

    @JsonProperty("sqs_quotation_id")
    @Size(max = 60)
    private String sqsQuotationId;

    @JsonProperty("plan_code")
    @Size(max = 10)
    private String planCode;

    @JsonProperty("eapp_id")
    @Size(max = 60)
    private String eappId;

	@JsonProperty("module")
	@Size(max = 10)
    private String module;

    @JsonProperty("fna_id")
    @Size(max = 60)
    private String fnaId;

    @JsonProperty("select_recommend")
    @Size(max = 5)
    private String selectRecommend;

    @JsonProperty("product_name")
    @Size(max = 250)
    private String productName;

    @JsonProperty("payment_type")
    @Size(max = 10)
    private String paymentType;

    @JsonProperty("currency")
    @Size(max = 10)
    private String currency;

    @JsonProperty("payment_term")
    private Integer paymentTerm;

    @JsonProperty("policy_tenor")
    private Integer policyTenor;

    @JsonProperty("sum_assured")
    private BigDecimal sumAssured;

    @JsonProperty("basic_amount")
    private BigDecimal basicAmount;

    @JsonProperty("fx_rate")
    private BigDecimal fxRate;

    @JsonProperty("under_writer")
    @Size(max = 200)
    private String underWriter;

    @JsonProperty("total_amout")
    private BigDecimal totalAmout;

    @JsonProperty("riders")
    @Size(max = 400)
    private String riders;

	@JsonProperty("reson")
	@Size(max = 400)
    private String reson;

    @JsonProperty("other_detail")
    @Size(max = 1250)
    private String otherDetail;

    @JsonProperty("recommendation")
    @Size(max = 100)
    private String recommendation;

    @JsonProperty("recommend_reason")
    private String recommendreason;

	@JsonProperty("pgs_product_key")
	@Size(max = 100)
    private String pgsProductKey;

    @JsonProperty("is_select_cur_application")
    @AllowedValuesValidation(values = {"0","1"})
    @Size(max = 5)
    @ApiModelProperty(value = "string accepts 0 and 1 only", example = "0")
    private String IsSelectCurApplication;

    @JsonProperty("rider_pgs_product_key")
    @Size(max = 400)
    private String riderPgsProductKey;

    @JsonProperty("rider_renewal_year")
    @Size(max = 100)
    private String riderRenewalYear;

    @JsonProperty("rider_premium")
    @Size(max = 100)
    private String riderPremium;

    @JsonProperty("life_protection_level")
    @Size(max = 50)
    private String lifeProtectionLevel;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TEappCitiRecommendationsDto{");
        sb.append("citiRecId='").append(citiRecId).append('\'');
        sb.append(", sqsQuotationId='").append(sqsQuotationId).append('\'');
        sb.append(", planCode='").append(planCode).append('\'');
        sb.append(", eappId='").append(eappId).append('\'');
        sb.append(", module='").append(module).append('\'');
        sb.append(", fnaId='").append(fnaId).append('\'');
        sb.append(", selectRecommend='").append(selectRecommend).append('\'');
        sb.append(", productName='").append(productName).append('\'');
        sb.append(", paymentType='").append(paymentType).append('\'');
        sb.append(", currency='").append(currency).append('\'');
        sb.append(", paymentTerm=").append(paymentTerm);
        sb.append(", policyTenor=").append(policyTenor);
        sb.append(", sumAssured=").append(sumAssured);
        sb.append(", basicAmount=").append(basicAmount);
        sb.append(", fxRate=").append(fxRate);
        sb.append(", underWriter='").append(underWriter).append('\'');
        sb.append(", totalAmout=").append(totalAmout);
        sb.append(", riders='").append(riders).append('\'');
        sb.append(", reson='").append(reson).append('\'');
        sb.append(", otherDetail='").append(otherDetail).append('\'');
        sb.append(", recommendation='").append(recommendation).append('\'');
        sb.append(", recommendreason='").append(recommendreason).append('\'');
        sb.append(", pgsProductKey='").append(pgsProductKey).append('\'');
        sb.append(", IsSelectCurApplication='").append(IsSelectCurApplication).append('\'');
        sb.append(", riderPgsProductKey='").append(riderPgsProductKey).append('\'');
        sb.append(", riderRenewalYear='").append(riderRenewalYear).append('\'');
        sb.append(", riderPremium='").append(riderPremium).append('\'');
        sb.append(", lifeProtectionLevel='").append(lifeProtectionLevel).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
