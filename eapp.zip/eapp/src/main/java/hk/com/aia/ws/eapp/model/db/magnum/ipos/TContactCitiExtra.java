package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import lombok.Data;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@Table(name = "T_CONTACTCITIEXTRA")
public class TContactCitiExtra {

    @Column(name = "CITIEXTRAID", length = 60)
    @Id
    private String citiExtraId;

    @Column(name = "CONTACTID", length = 60)
    private String contactId;

    @Column(name = "EDUCATIONCODE", length = 10)
    private String educationCode;

    @Column(name = "EDUCATIONOTHER", length = 60)
    private String educationOther;

    @Column(name = "EMPLOYMENTCODE", length = 10)
    private String employmentCode;

    @Column(name = "EMPLOYMENTOTHER", length = 60)
    private String employmentOther;

    @Column(name = "YEARSTOSUPPORT")
    private Integer yearsToSupport;

    @Column(name = "CITIOCCUPATIONCODE", length = 10)
    private String citiOccupationCode;

    @Column(name = "RETIREMENTAGE", length = 10)
    private String retirementAge;

    @Column(name = "HASEXPERINDICATE")
    private Integer hasExperIndicate;

    @Column(name = "NOEXPERCONFIRM")
    private Integer noExperConfirm;

    @Column(name = "hybridFlow", length = 5)
    private String hybridFlow;

    @Column(name = "hybridFlowUpdateDate")
    @Temporal(TemporalType.DATE)
    private Date hybridFlowUpdateDate;

    @Column(name = "scFlag", length = 5)
    private String scFlag;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TContactCitiExtra{");
        sb.append("citiExtraId='").append(citiExtraId).append('\'');
        sb.append(", contactId='").append(contactId).append('\'');
        sb.append(", educationCode='").append(educationCode).append('\'');
        sb.append(", educationOther='").append(educationOther).append('\'');
        sb.append(", employmentCode='").append(employmentCode).append('\'');
        sb.append(", employmentOther='").append(employmentOther).append('\'');
        sb.append(", yearsToSupport=").append(yearsToSupport);
        sb.append(", citiOccupationCode='").append(citiOccupationCode).append('\'');
        sb.append(", retirementAge='").append(retirementAge).append('\'');
        sb.append(", hasExperIndicate=").append(hasExperIndicate);
        sb.append(", noExperConfirm=").append(noExperConfirm);
        sb.append(", hybridFlow='").append(hybridFlow).append('\'');
        sb.append(", hybridFlowUpdateDate=").append(hybridFlowUpdateDate);
        sb.append(", scFlag='").append(scFlag).append('\'');
        sb.append('}');
        return sb.toString();
    }
}


