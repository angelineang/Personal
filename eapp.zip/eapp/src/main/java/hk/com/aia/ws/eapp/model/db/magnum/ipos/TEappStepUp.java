package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "T_EAPPStepUp")
public class TEappStepUp {

    @Column(name = "EAPPStepUpID", length = 60)
    @Id
    private String eappStepUpId;

    @Column(name = "EAPPID", length = 60)
    private String eappId;

    @Column(name = "memberID", length = 20)
    private String memberID;

    @Column(name = "q1_Answer", length = 10)
    private String q1Answer;

    @Column(name = "q2_Answer", length = 10)
    private String q2Answer;

    @Column(name = "resultCode", length = 20)
    private String resultCode;

    @Column(name = "result")
    private String result;

    @Column(name = "tickedCompany", length = 200)
    private String tickedCompany;

    @Column(name = "tickNo", length = 10)
    private String tickNo;

    @Column(name = "result_date", length = 10)
    private String resultDate;

    @Column(name = "parameter")
    private String parameter;

    @Column(name = "token", length = 100)
    private String token;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "schemeDate", length = 10)
    private String schemeDate;

    @Column(name = "tickedPolicyNo", length = 20)
    private String tickedPolicyNo;

    @Column(name = "isPromotion", length = 10)
    private String isPromotion;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TEappStepUp{");
        sb.append("eappStepUpId='").append(eappStepUpId).append('\'');
        sb.append(", eappId='").append(eappId).append('\'');
        sb.append(", memberID='").append(memberID).append('\'');
        sb.append(", q1Answer='").append(q1Answer).append('\'');
        sb.append(", q2Answer='").append(q2Answer).append('\'');
        sb.append(", resultCode='").append(resultCode).append('\'');
        sb.append(", result='").append(result).append('\'');
        sb.append(", tickedCompany='").append(tickedCompany).append('\'');
        sb.append(", tickNo='").append(tickNo).append('\'');
        sb.append(", resultDate='").append(resultDate).append('\'');
        sb.append(", parameter='").append(parameter).append('\'');
        sb.append(", token='").append(token).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", schemeDate='").append(schemeDate).append('\'');
        sb.append(", tickedPolicyNo='").append(tickedPolicyNo).append('\'');
        sb.append(", isPromotion='").append(isPromotion).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
