package hk.com.aia.ws.eapp.model.db.magnum.iverify;

import hk.com.aia.ws.eapp.model.db.magnum.ipos.idclass.TPrcClientId;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import lombok.Data;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@Table(name = "T_PRC_CLIENT")
@IdClass(TPrcClientId.class)
@EntityListeners(AuditingEntityListener.class)
public class TPrcClient {

    @Column(name = "IVERIFYID", length = 60)
    @Id
    private String iverifyId;

    @Column(name = "BOOKINGID", length = 60)
    private String bookingID;

    @Column(name = "CLIENTID", length = 20)
    @Id
    private String clientID;

    @Column(name = "CHINESENAME", length = 500)
    private String chineseName;

    @Column(name = "LASTNAME", length = 100)
    private String lastName;

    @Column(name = "FIRSTNAME", length = 45)
    private String firstName;

    @Column(name = "GENDER", length = 1)
    private String gender;

    @Column(name = "DOB", length = 50)
    private String dob;

    @Column(name = "IDTYPE", length = 50)
    private String idType;

    @Column(name = "IDNO", length = 20)
    private String idNo;

    @Column(name = "IVERIFYIND", length = 1)
    private String iverifyInd;

    @Column(name = "ENTRYDATE", length = 50)
    private String entryDate;

    @Column(name = "AGENTCODE", length = 40)
    private String agentCode;

    @Column(name = "ACCESSCODE", length = 30)
    private String accessCode;

    @Column(name = "STATUS", length = 1)
    private String status;

    @Column(name = "CREATEDBY", length = 40, updatable = false)
    @CreatedBy
    private String createdBy;

    @Column(name = "UPDATEDBY", length = 40)
    @LastModifiedBy
    private String updatedBy;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "LASTUPDATEDATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    @LastModifiedDate
    private Date lastUpdateDateTime;

    @Column(name = "AGENTCODE2", length = 40)
    private String agentCode2;

    @Column(name = "ACCESSCODE2", length = 40)
    private String accessCode2;

    @Column(name = "PICCHECK", length = 4)
    private String picCheck;

    @Column(name = "PICSCORE")
    private Integer picScore;

    @Column(name = "PICERROR", length = 4)
    private String picError;

    @Column(name = "DOCCOUNT")
    private Integer docCount;

    @Column(name = "LIVECHECK", length = 4)
    private String liveCheck;

    @Column(name = "LIVESCORE")
    private Integer liveScore;

    @Column(name = "LIVEERROR", length = 4)
    private String liveError;

    @Column(name = "HASNBF", length = 4)
    private String hasNbf;

    @Column(name = "HASPOS", length = 4)
    private String hasPos;

    @Column(name = "APPROVEDBY", length = 40)
    private String approvedBy;

    @Column(name = "APPROVEDATETIME", length = 50)
    private String approveDateTime;

    @Column(name = "LOSTENTRYSLIP", length = 4)
    private String lostEntrySlip;

/*    @Column(name = "sybfi3_1", length = 40)
    private String sybfi31;*/

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TPrcClient{");
        sb.append("iverifyId='").append(iverifyId).append('\'');
        sb.append(", bookingID='").append(bookingID).append('\'');
        sb.append(", clientID='").append(clientID).append('\'');
        sb.append(", chineseName='").append(ConversionHandler.mask(chineseName)).append('\'');
        sb.append(", lastName='").append(ConversionHandler.mask(lastName)).append('\'');
        sb.append(", firstName='").append(ConversionHandler.mask(firstName)).append('\'');
        sb.append(", gender='").append(gender).append('\'');
        sb.append(", dob='").append(ConversionHandler.mask(dob)).append('\'');
        sb.append(", idType='").append(idType).append('\'');
        sb.append(", idNo='").append(idNo).append('\'');
        sb.append(", iverifyInd='").append(iverifyInd).append('\'');
        sb.append(", entryDate='").append(entryDate).append('\'');
        sb.append(", agentCode='").append(agentCode).append('\'');
        sb.append(", accessCode='").append(accessCode).append('\'');
        sb.append(", status='").append(status).append('\'');
        sb.append(", createdBy='").append(createdBy).append('\'');
        sb.append(", updatedBy='").append(updatedBy).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", lastUpdateDateTime=").append(lastUpdateDateTime);
        sb.append(", agentCode2='").append(agentCode2).append('\'');
        sb.append(", accessCode2='").append(accessCode2).append('\'');
        sb.append(", picCheck='").append(picCheck).append('\'');
        sb.append(", picScore=").append(picScore);
        sb.append(", picError='").append(picError).append('\'');
        sb.append(", docCount=").append(docCount);
        sb.append(", liveCheck='").append(liveCheck).append('\'');
        sb.append(", liveScore=").append(liveScore);
        sb.append(", liveError='").append(liveError).append('\'');
        sb.append(", hasNbf='").append(hasNbf).append('\'');
        sb.append(", hasPos='").append(hasPos).append('\'');
        sb.append(", approvedBy='").append(approvedBy).append('\'');
        sb.append(", approveDateTime='").append(approveDateTime).append('\'');
        sb.append(", lostEntrySlip='").append(lostEntrySlip).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
