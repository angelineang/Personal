package hk.com.aia.ws.eapp.model.request.batch;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@ApiModel(value = "SigMst Model")
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class SigMstDto {

    @JsonProperty("seq")
    @NotNull
    private Integer seq;

    @JsonProperty("doc_id")
    @NotBlank
    private String docId;

    @JsonProperty("sig_role")
    private String sigRole;

    @JsonProperty("sig_no")
    private int sigNo;

    @JsonProperty("sig_seq")
    private int sigSeq;

    @JsonProperty("documents_id")
    private String documentsId;

    @JsonProperty("iverify_id")
    private String iVerifyId;

    @JsonProperty("iverify_client_id")
    private String iVerifyClientId;

    @JsonProperty("iverify_doc_seq")
    private int iVerifyDocSeq;

    @JsonProperty("content_type")
    private String contentType;

}
