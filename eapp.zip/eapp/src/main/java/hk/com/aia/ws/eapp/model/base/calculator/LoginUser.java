package hk.com.aia.ws.eapp.model.base.calculator;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;

@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class LoginUser {
    public static final String HKG = "AGCHK";
    public static final String MAC = "AGCMC";

    public static final String AGT = "AGT";
    public static final String BNK = "BNK";
    public static final String BKG = "BKG";
    public static final String IFA = "IFA";
    public static final String CITI = "CITI";

    public static final String CC = "CC";

    @ApiModelProperty(value = "user id", required = true)
    @JsonProperty("user_id")
    @NotBlank
    public String userId;

    @ApiModelProperty(value = "access id", required = true)
    @JsonProperty("access_id")
    public String accessId;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("LoginUser{");
        sb.append("userId='").append(userId).append('\'');
        sb.append(", accessId='").append(accessId).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
