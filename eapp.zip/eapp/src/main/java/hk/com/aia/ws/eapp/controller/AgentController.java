package hk.com.aia.ws.eapp.controller;


import hk.com.aia.ws.eapp.constant.Constants;
import hk.com.aia.ws.eapp.model.response.error.GatewayError400;
import hk.com.aia.ws.eapp.model.response.error.GatewayError401;
import hk.com.aia.ws.eapp.model.response.error.InternalError500;
import hk.com.aia.ws.eapp.service.jwt.JwtService;
import hk.com.aia.ws.eapp.model.base.AgentProfile;
import hk.com.aia.ws.eapp.model.base.AgentProfileRequest;
import hk.com.aia.ws.eapp.model.base.CustomResponseStatus;
import hk.com.aia.ws.eapp.model.base.ResultMessage;
import hk.com.aia.ws.eapp.model.dto.ResultDto;
import hk.com.aia.ws.eapp.model.request.Request;
import hk.com.aia.ws.eapp.model.response.Response;
import hk.com.aia.ws.eapp.service.AgentProfileService;
import io.swagger.annotations.*;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

import static hk.com.aia.ws.eapp.constant.Constants.RETURN_CODE_1;

@Slf4j
@AllArgsConstructor
@RestController
@RequestMapping("/agents")
@Api(value = "Agent Services", tags = {"API(s) for agent services"})
public class AgentController {

    @Autowired
    private final AgentProfileService agentProfileService;

    @Autowired
    private final JwtService jwtService;

    @ApiOperation(value = "To retrieve agent profiles.")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Agent profile successfully retrieved."),
            @ApiResponse(code = 400, message = "Bad Request", response = GatewayError400.class),
            @ApiResponse(code = 401, message = "Unauthorized", response = GatewayError401.class),
            @ApiResponse(code = 404, message = "Invalid request.", response = Response.class),
            @ApiResponse(code = 500, message = "Internal Server Error", response = InternalError500.class)
    })
    @PostMapping(value = "/enquire-profile", produces = MediaType.APPLICATION_JSON_VALUE)
    public Response<AgentProfile> profile(
            @ApiParam(value = "Local business unit.    | Valid Values |   | ----------   |   | HK, TH, SG   | ", required = true)
            @RequestHeader(value = Constants.RequestHeader.AIA_LBU, required = true) String xAiaLbu,
            @ApiParam(value = "Unique id for the request for tracking purposes.        ", required = true)
            @RequestHeader(value = Constants.RequestHeader.REQUEST_ID, required = true) String xAiaRequestId,
            @ApiParam(value = "Target environment of the request. Note that this header is required only when accessing non-production environments.    | Valid Values       |   | ------------------ |   | qa1, qa2, qa3, qa4 |        ")
            @RequestHeader(value = Constants.RequestHeader.AIA_ENV, required = false) String xAiaEnv,
            @ApiParam(value = "JWT Token for the request to verify Agent Authorization")
            @RequestHeader(value = Constants.RequestHeader.TOKEN_AGENT, required = false) String xAiaTokenAgent,
            @ApiParam(value = "Trace Id for EFK Logging")
            @RequestHeader(value = Constants.RequestHeader.TRACE_ID, required = false) String xAiaHkTraceId,
            @ApiParam(value = "Context Id for EFK Logging")
            @RequestHeader(value = Constants.RequestHeader.CONTEXT_ID, required = true) String xAiaHkContextId,
            @ApiParam(value = "Agent Profile Request", required = true)
            @Valid @RequestBody Request<AgentProfileRequest> request
    ) {

        final AgentProfileRequest agentProfileRequest = request.getData();
        final Response<AgentProfile> payload = new Response<>();

        final ResultDto<AgentProfile> result = agentProfileService.getAgentProfile(agentProfileRequest);

        payload.setTransId(request.getTransId());
        if (RETURN_CODE_1.equals(result.getReturnCode())) {
            payload.setStatus(CustomResponseStatus.SUCCESS.getDescription());
        } else {
            payload.setStatus(CustomResponseStatus.ERROR.getDescription());
        }
        payload.getResultMessages().add(new ResultMessage(result.getReturnCode(),
                result.getReturnMessage()));

        payload.setData(result.getData());

        return payload;
    }

}

