package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.util.Date;

@ApiModel(value = "PrcSearch Model")
@Getter
@Setter
@Data
public class SearchPRCIdentity extends Payload {

    @ApiModelProperty(value = "channel", required = true)
    @JsonProperty("channel")
    @NotBlank
    @Size(max = 10)
    private String channel;

    @ApiModelProperty(value = "policy No", required = true)
    @JsonProperty("pol_no")
    @NotBlank
    @Size(max = 10)
    private String polNo;

    @ApiModelProperty(value = "overwrite",required = true)
    @JsonProperty("overwrite")
    @Size(max = 1)
    private String overwrite;

    @ApiModelProperty(value = "agy code",required = true)
    @JsonProperty("agy_code")
    @Size(max = 5)
    private String agyCode;

    @ApiModelProperty(value = "agt code",required = true)
    @JsonProperty("agt_code")
    @Size(max = 10)
    private String agtCode;

    @ApiModelProperty(value = "agt code 2")
    @JsonProperty("agt_code_2")
    @Size(max = 10)
    private String agtCode2;

    @ApiModelProperty(value = "iverify id")
    @JsonProperty("iverify_id")
    @Size(max = 60)
    private String iverifyId;

    @ApiModelProperty(value = "ins last name",required = true)
    @JsonProperty("ins_last_name")
    @Size(max = 100)
    private String insLastName;

    @ApiModelProperty(value = "ins first name",required = true)
    @JsonProperty("ins_first_name")
    @Size(max = 45)
    private String insFirstName;

    @ApiModelProperty(value = "ins sex",required = true)
    @JsonProperty("ins_sex")
    @Size(max = 1)
    private String insSex;

    @ApiModelProperty(value = "ins dob",required = true)
    @JsonProperty("ins_dob")
    @Size(max = 10)
    private String insDob;

    @ApiModelProperty(value = "ins id")
    @JsonProperty("ins_id")
    @Size(max = 20)
    private String insId;

    @ApiModelProperty(value = "own last name",required = true)
    @JsonProperty("own_last_name")
    @Size(max = 100)
    private String ownLastName;

    @ApiModelProperty(value = "own first name",required = true)
    @JsonProperty("own_first_name")
    @Size(max = 45)
    private String ownFirstName;

    @ApiModelProperty(value = "own sex",required = true)
    @JsonProperty("own_sex")
    @Size(max = 1)
    private String ownSex;

    @ApiModelProperty(value = "own dob",required = true)
    @JsonProperty("own_dob")
    @Size(max = 10)
    private String ownDob;

    @ApiModelProperty(value = "own id")
    @JsonProperty("own_id")
    @Size(max = 20)
    private String ownId;

    @ApiModelProperty(value = "last doc sign date yyyy-MM-dd", example = "2021-12-31")
    @JsonProperty("last_doc_sign_date")
    private String lastDocSignDate;

    @ApiModelProperty(value = "app submit date yyyy-MM-dd", example = "2021-12-31")
    @JsonProperty("app_submit_date")
    private String appSubmitDate;

    @ApiModelProperty(value = "access code")
    @JsonProperty("access_code")
    @Size(max = 30)
    private String accessCode;

    @ApiModelProperty(value = "access code 2")
    @JsonProperty("access_code_2")
    @Size(max = 30)
    private String accessCode2;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("SearchPRCIdentity{");
        sb.append("channel='").append(channel).append('\'');
        sb.append(", polNo='").append(ConversionHandler.mask(polNo)).append('\'');
        sb.append(", overwrite='").append(overwrite).append('\'');
        sb.append(", agyCode='").append(agyCode).append('\'');
        sb.append(", agtCode='").append(agtCode).append('\'');
        sb.append(", agtCode2='").append(agtCode2).append('\'');
        sb.append(", iverifyId='").append(iverifyId).append('\'');
        sb.append(", insLastName='").append(ConversionHandler.mask(insLastName)).append('\'');
        sb.append(", insFirstName='").append(ConversionHandler.mask(insFirstName)).append('\'');
        sb.append(", insSex='").append(insSex).append('\'');
        sb.append(", insDob='").append(ConversionHandler.mask(insDob)).append('\'');
        sb.append(", insId='").append(ConversionHandler.mask(insId)).append('\'');
        sb.append(", ownLastName='").append(ConversionHandler.mask(ownLastName)).append('\'');
        sb.append(", ownFirstName='").append(ConversionHandler.mask(ownFirstName)).append('\'');
        sb.append(", ownSex='").append(ownSex).append('\'');
        sb.append(", ownDob='").append(ConversionHandler.mask(ownDob)).append('\'');
        sb.append(", ownId='").append(ConversionHandler.mask(ownId)).append('\'');
        sb.append(", lastDocSignDate='").append(lastDocSignDate).append('\'');
        sb.append(", appSubmitDate='").append(appSubmitDate).append('\'');
        sb.append(", accessCode='").append(accessCode).append('\'');
        sb.append(", accessCode2='").append(accessCode2).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
