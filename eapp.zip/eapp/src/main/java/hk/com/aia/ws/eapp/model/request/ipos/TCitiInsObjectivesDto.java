package hk.com.aia.ws.eapp.model.request.ipos;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@ApiModel(value = "T_CITIINSOBJECTIVES Model")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TCitiInsObjectivesDto {

	@ApiModelProperty(value = "ins Obj Id", required = true)
    @JsonProperty("ins_obj_id")
	@Size(max = 60)
    @NotBlank
    private String insObjId;

    @JsonProperty("fna_id")
	@Size(max = 60)
    private String fnaId;

    @JsonProperty("needs")
	@Size(max = 60)
    private String needs;

    @JsonProperty("grouped_by")
	@Size(max = 60)
    private String groupedBy;

    @JsonProperty("levels")
	@Size(max = 5)
    private String levels;

    @JsonProperty("remark")
	@Size(max = 200)
    private String remark;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TCitiInsObjectivesDto{");
        sb.append("insObjId='").append(insObjId).append('\'');
        sb.append(", fnaId='").append(fnaId).append('\'');
        sb.append(", needs='").append(needs).append('\'');
        sb.append(", groupedBy='").append(groupedBy).append('\'');
        sb.append(", levels='").append(levels).append('\'');
        sb.append(", remark='").append(remark).append('\'');
        sb.append('}');
        return sb.toString();
    }
}

