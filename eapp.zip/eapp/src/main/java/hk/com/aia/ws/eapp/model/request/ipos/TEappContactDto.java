package hk.com.aia.ws.eapp.model.request.ipos;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@ApiModel(value = "T_EAPPCONTACT Model")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TEappContactDto {

	@ApiModelProperty(value = "eapp Contact Id", required = true)
    @JsonProperty("eapp_contact_id")
	@Size(max = 60)
	@NotBlank
    private String eappContactId;
    
    @JsonProperty("eapp_id")
    @Size(max = 60)
    private String eappId;

    @JsonProperty("contact_id")
    @Size(max = 60)
    private String contactId;

    @JsonProperty("contact_type")
    @Size(max = 1)
    private String contactType;

    @JsonProperty("life_sequence")
    private Integer lifeSequence;

    @JsonProperty("duplicate_contact_id")
    @Size(max = 60)
    private String duplicateContactId;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TEappContactDto{");
        sb.append("eappContactId='").append(eappContactId).append('\'');
        sb.append(", eappId='").append(eappId).append('\'');
        sb.append(", contactId='").append(contactId).append('\'');
        sb.append(", contactType='").append(contactType).append('\'');
        sb.append(", lifeSequence=").append(lifeSequence);
        sb.append(", duplicateContactId='").append(duplicateContactId).append('\'');
        sb.append('}');
        return sb.toString();
    }
}


