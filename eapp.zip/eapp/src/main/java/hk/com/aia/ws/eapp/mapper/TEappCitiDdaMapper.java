package hk.com.aia.ws.eapp.mapper;


import hk.com.aia.ws.eapp.model.db.magnum.ipos.TEapp;
import hk.com.aia.ws.eapp.model.db.magnum.ipos.TEappCitiDda;
import hk.com.aia.ws.eapp.model.request.ipos.TEappCitiDdaDto;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper
public interface TEappCitiDdaMapper {

    TEappCitiDdaMapper MAPPER = Mappers.getMapper(TEappCitiDdaMapper.class);

    List<TEappCitiDda> mapToTEappCitiDdaList(List<TEappCitiDdaDto> tEappCitiDdaDto);
}
