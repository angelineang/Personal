package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.annotation.AllowedValuesValidation;
import hk.com.aia.ws.eapp.annotation.DateTimeValidation;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;

@ApiModel("Send Document Model")
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class SendDocument extends Payload {

	@ApiModelProperty(value = "Document - Base64 Format", required = true)
	@JsonProperty("doc")
	@NotBlank
	private String doc;

	// For Send Document job_id = 'MS-FS' and app_name = 'MS', there are the two allowable values
	// Based on aidcconfig..temail_list and aidcconfig..temail_attachment
	@ApiModelProperty(value = "Document type - LEAD_F/LEAD_TM = Firestorm Leads Report, LEAD_S = Firestorm Application Report", example = "LEAD_F", allowableValues = "LEAD_F,LEAD_S,LEAD_TM",  required = true)
	@JsonProperty("type")
	@NotBlank
	@AllowedValuesValidation(values = {"LEAD_F", "LEAD_S", "LEAD_TM"}, caseSensitive = true)
	private String type;

	@ApiModelProperty(value = "Report date - format = MM/dd/yyyy", example = "10/27/1970" , required = true)
	@JsonProperty("report_date")
	@NotBlank
	@DateTimeValidation(format = "MM/dd/yyyy")
	private String reportDate;

	@ApiModelProperty("Lead number")
	@JsonProperty("lead_no")
	private String leadNo;

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder("SendDocument{");
		sb.append("doc='").append(doc).append('\'');
		sb.append(", type='").append(type).append('\'');
		sb.append(", reportDate='").append(reportDate).append('\'');
		sb.append(", leadNo='").append(leadNo).append('\'');
		sb.append('}');
		return sb.toString();
	}
}
