package hk.com.aia.ws.eapp.model.db.magnum.ichange.idclass;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TblEappBatchPdfId implements Serializable {

    private static final long serialVersionUID = 4000258928784591220L;
    private String batchId;
    private Integer sequence;
    private String docId;
    private String contentType;
}
