package hk.com.aia.ws.eapp.model.dto;

import hk.com.aia.ws.eapp.model.base.ResultMessage;
import lombok.Data;

import java.util.List;

import static hk.com.aia.ws.eapp.constant.Constants.RETURN_CODE_1;

@Data
public class ResultDto<T> {

    private String returnCode;
    private String returnMessage;
    private List<ResultMessage> resultMessageOuts;

    private T data;

    public boolean resultExecuted(){

        return RETURN_CODE_1.equals(returnCode);
    }

    public boolean stagingDocProcessExecuted(){

        return returnCode == null || returnCode.isEmpty() || RETURN_CODE_1.equals(returnCode);
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("ResultDto{");
        sb.append("returnCode='").append(returnCode).append('\'');
        sb.append(", returnMessage='").append(returnMessage).append('\'');
        sb.append(", data=").append(data);
        sb.append('}');
        return sb.toString();
    }
}
