package hk.com.aia.ws.eapp.model.log;

import org.slf4j.MDC;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.annotation.JsonProperty;

import hk.com.aia.ws.eapp.constant.Constants;
import lombok.NoArgsConstructor;
@NoArgsConstructor
public class TranKeys {

	@JsonProperty("policy_no")
	private String policyNo = "";

	@JsonProperty("batch_id")
	private String batchId = "";

	@JsonProperty("submit_type")
	private String submitType = "";

	@JsonProperty("eapp_id")
	private String eappId = "";

	@JsonProperty("user_id")
	private String userId = "";

	@JsonProperty("app_id")
	private String appId = "";

	@JsonProperty("function")
	private String function = "";
	
	@JsonProperty("source_user_id")
	private String sourceUserId = "";
	
	@JsonProperty("source_user_ip")
	private String sourceUserIp = "";
	
	@JsonProperty("source_app")
	private String sourceApp = "";
	
	
	public TranKeys(String policyNo, String submitType, String eappId, String batchId, String appId, String function) {
		super();
		this.submitType = submitType;
		this.eappId = eappId;
		this.batchId = batchId;
		this.appId=appId;
		this.function=function;
		MDC.put(Constants.EFKLogging.APP_FUNCTION, function);
		this.sourceUserId=MDC.get(Constants.EFKLogging.SOURCE_USER_ID);
		this.sourceUserIp=MDC.get(Constants.EFKLogging.SOURCE_USER_IP);
		this.sourceApp=MDC.get(Constants.EFKLogging.SOURCE_APP);
		
		if (StringUtils.hasLength(policyNo)) {
			this.policyNo = "***" + policyNo.substring(3);
		}
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		if (StringUtils.hasLength(policyNo)) {
			this.policyNo = "***" + policyNo.substring(3);
		}

	}

	public String getBatchId() {
		return batchId;
	}

	public void setBatchId(String batchId) {
		this.batchId = batchId;
	}

	public String getSubmitType() {
		return submitType;
	}

	public void setSubmitType(String submitType) {
		this.submitType = submitType;
	}

	public String getEappId() {
		return eappId;
	}

	public void setEappId(String eappId) {
		this.eappId = eappId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

	public String getFunction() {
		return function;
	}

	public void setFunction(String function) {
		this.function = function;
		MDC.put(Constants.EFKLogging.APP_FUNCTION, function);
	}
	
	public String getSourceUserId() {
		return sourceUserId;
	}

	public void setSourceUserId(String sourceUserId) {
		this.sourceUserId = sourceUserId;
	}
	
	public String getSourceUserIp() {
		return sourceUserIp;
	}

	public void setSourceUserIp(String sourceUserIp) {
		this.sourceUserIp = sourceUserIp;
	}
	
	public String getSourceApp() {
		return sourceApp;
	}

	public void setSourceApp(String sourceApp) {
		this.sourceApp = sourceApp;
	}


}