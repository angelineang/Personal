package hk.com.aia.ws.eapp.exception;

import java.util.HashMap;
import java.util.Map;

public class RestTemplateException extends RuntimeException {

    private static final long serialVersionUID = 7718828512143293558L;

    private final String statusCode;

    private final String statusText;

    private final transient Map<String, Object> responseBody;

    public RestTemplateException(String statusCode, String statusText, Map<String, Object> responseBody) {
        super(statusCode + " " + statusText);
        this.statusCode = statusCode;
        this.statusText = statusText;
        this.responseBody = responseBody;
    }

    public RestTemplateException(String statusCode, String statusText) {
        super(statusCode + " " + statusText);
        this.statusCode = statusCode;
        this.statusText = statusText;
        this.responseBody = new HashMap<>();
    }

    public String getStatusCode() {
        return statusCode;
    }

    public String getStatusText() {
        return statusText;
    }

    public Map<String, Object> getResponseBody() {
        return responseBody;
    }
}
