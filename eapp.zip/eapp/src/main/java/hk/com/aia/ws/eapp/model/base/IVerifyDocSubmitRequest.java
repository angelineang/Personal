package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;

@ApiModel(value = "IVerify Document Submit Model")
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class IVerifyDocSubmitRequest extends Payload {

	@ApiModelProperty(value="iVerify Id" , required = true)
	@JsonProperty("iverify_id")
	@NotBlank
	private String iVerifyId;

	@ApiModelProperty(value="Policy number", required = true)
	@JsonProperty("policy_no")
	@NotBlank
	private String policyNo;

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder("IVerifyDocSubmitRequest{");
		sb.append("iVerifyId='").append(iVerifyId).append('\'');
		sb.append(", policyNo='").append(ConversionHandler.mask(policyNo)).append('\'');
		sb.append('}');
		return sb.toString();
	}
}
