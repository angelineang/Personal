package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@ApiModel(value = "Coi Result Model")
@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class CoiResult extends Payload {

    @ApiModelProperty(value = "Response of mini-submission")
    @JsonProperty("response_of_ms")
    private ResponseOfMs responseOfMs;

    @ApiModelProperty(value = "coi master next number")
    @JsonProperty("coi_master_next_no")
    private ResponseDataMeta responseDataMeta;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("CoiResult{");
        sb.append("responseOfMs=").append(responseOfMs);
        sb.append(", responseDataMeta=").append(responseDataMeta);
        sb.append('}');
        return sb.toString();
    }
}
