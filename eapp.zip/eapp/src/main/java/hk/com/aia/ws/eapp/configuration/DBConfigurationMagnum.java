package hk.com.aia.ws.eapp.configuration;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.util.StringUtils;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;
import java.util.Properties;

@Slf4j
@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(basePackages = "hk.com.aia.ws.eapp.repository.magnum",
        entityManagerFactoryRef = "magnumEntityManagerFactory",
        transactionManagerRef = "magnumTransactionManager")
public class DBConfigurationMagnum {

    @Bean(name = "magnumDataSource")
    @ConfigurationProperties(prefix = "connection.magnum.datasource")
    public DataSource magnumDataSourceLocal() {
        return DataSourceBuilder.create().build();
    }

    @Bean(name = "magnumEntityManagerFactory")
    public LocalContainerEntityManagerFactoryBean magnumEntityManagerFactory(
            @Qualifier("magnumDataSource") DataSource dataSource,
            @Qualifier("magnumProperties") Properties properties,
            @Value("${connection.magnum.jpa.show-sql}") Boolean showSql) {

        LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
        em.setDataSource(dataSource);
        em.setPersistenceUnitName("magnum_persist_unit");
        em.setPackagesToScan("hk.com.aia.ws.eapp.model.db.magnum");
        HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
        vendorAdapter.setShowSql(showSql);
        em.setJpaVendorAdapter(vendorAdapter);
        em.setJpaProperties(properties);

        return em;
    }


    @Bean(name = "magnumTransactionManager")
    public PlatformTransactionManager sqlTransactionManager(
            @Qualifier("magnumEntityManagerFactory") EntityManagerFactory sqlEntityManagerFactory) {
        return new JpaTransactionManager(sqlEntityManagerFactory);
    }

    @Bean(name = "magnumProperties")
    public Properties additionalProperties(
            @Value("${connection.magnum.jpa.database-platform}") String hibernateDialect,
            @Value("${connection.magnum.jpa.default-schema}") String schema) {
        Properties properties = new Properties();

        properties.setProperty("hibernate.dialect", hibernateDialect);

        if (!StringUtils.isEmpty(schema)) {
            properties.setProperty("hibernate.default_schema", schema);
        }

        return properties;
    }

}
