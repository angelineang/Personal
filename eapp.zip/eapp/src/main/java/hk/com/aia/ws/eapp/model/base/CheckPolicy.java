package hk.com.aia.ws.eapp.model.base;

import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.annotation.AllowedValuesValidation;
import hk.com.aia.ws.eapp.annotation.DateTimeValidation;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@ApiModel(value = "check policy model")
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class CheckPolicy extends Payload {

    //allowableValues and Size max based on db_magnum..po_ishop_pol_chk
    @ApiModelProperty(value = "Enquire type", allowableValues = "Policy2CN,CN2Policies,PII2Policies", required = true)
    @JsonProperty("enquire_type")
    @NotBlank
    @Size(max = 20)
    @AllowedValuesValidation(values = {"Policy2CN", "CN2Policies", "PII2Policies"})
    private String enquireType;

    @ApiModelProperty(value = "Policy number")
    @JsonProperty("pol_no")
    @Size(max = 10)
    private String polNo;

    @ApiModelProperty(value = "CN number")
    @JsonProperty("cn_no")
    @Size(max = 9)
    private String cnNo;

    @ApiModelProperty(value = "First name")
    @JsonProperty("first_name")
    @Size(max = 50)
    private String firstName;

    @ApiModelProperty(value = "Last name")
    @JsonProperty("last_name")
    @Size(max = 50)
    private String lastName;

    @ApiModelProperty(value = "HK identity")
    @JsonProperty("hk_id")
    @Size(max = 20)
    private String hkId;

    @ApiModelProperty(value = "Date of birth")
    @JsonProperty("dob")
    @DateTimeValidation(format = "MM/dd/yyyy")
    private String dob;

    @ApiModelProperty(value = "Gender")
    @JsonProperty("gender")
    private String gender;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("CheckPolicy{");
        sb.append("enquireType='").append(enquireType).append('\'');
        sb.append(", polNo='").append(ConversionHandler.mask(polNo)).append('\'');
        sb.append(", cnNo='").append(ConversionHandler.mask(cnNo)).append('\'');
        sb.append(", firstName='").append(ConversionHandler.mask(firstName)).append('\'');
        sb.append(", lastName='").append(ConversionHandler.mask(lastName)).append('\'');
        sb.append(", hkId='").append(ConversionHandler.mask(hkId)).append('\'');
        sb.append(", dob='").append(ConversionHandler.mask(dob)).append('\'');
        sb.append(", gender='").append(gender).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
