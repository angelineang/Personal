package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import lombok.Data;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "T_DVAGT")
public class TDvaGt {

    @Column(name = "DVAGTID", length = 60)
    @Id
    private String dvaGtId;

    @Column(name = "EAPPID", length = 60)
    private String eappId;

    @Column(name = "AGENTCODE", length = 10)
    private String agentCode;

    @Column(name = "ACCESSCODE", length = 30)
    private String accessCode;

    @Column(name = "AGENTVISITEDDATE")
    @Temporal(TemporalType.DATE)
    private Date agentVisitDate;

    @Column(name = "DOCUMENTID", length = 60)
    private String documentId;

    @Column(name = "ISCONFIRM")
    private Integer isConfirm;

    @Column(name = "ADDRESSTYPE", length = 20)
    private String addressType;

    @Column(name = "CREATEDBY", length = 10, updatable = false)
    @CreatedBy
    private String createdBy;

    @Column(name = "UPDATEDBY", length = 10)
    @LastModifiedBy
    private String updatedBy;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "LASTUPDATEDATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    @LastModifiedDate
    private Date lastUpdatedDateTime;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TDvaGt{");
        sb.append("dvaGtId='").append(dvaGtId).append('\'');
        sb.append(", eappId='").append(eappId).append('\'');
        sb.append(", agentCode='").append(agentCode).append('\'');
        sb.append(", accessCode='").append(accessCode).append('\'');
        sb.append(", agentVisitDate=").append(agentVisitDate);
        sb.append(", documentId='").append(documentId).append('\'');
        sb.append(", isConfirm=").append(isConfirm);
        sb.append(", addressType='").append(addressType).append('\'');
        sb.append(", createdBy='").append(createdBy).append('\'');
        sb.append(", updatedBy='").append(updatedBy).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", lastUpdatedDateTime=").append(lastUpdatedDateTime);
        sb.append('}');
        return sb.toString();
    }
}
