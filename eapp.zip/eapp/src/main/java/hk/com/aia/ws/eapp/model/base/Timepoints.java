package hk.com.aia.ws.eapp.model.base;

import lombok.Data;

@Data
public class Timepoints {

    private long startTime = 0;
    private long endTime = -1;

    public Timepoints(long startTime) {
        this.startTime = startTime;
    }

    public Timepoints(long startTime, long endTime) {
        this.startTime = startTime;
        this.endTime = endTime;
    }

    public long getElapsedTime() {
        return endTime > 0 ? endTime - startTime : -1;
    }

    public String toString(long denominator, String timeUnit) {
        return String.format("[%10d %s]", getElapsedTime() / denominator, timeUnit);
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Timepoints{");
        sb.append("startTime=").append(startTime);
        sb.append(", endTime=").append(endTime);
        sb.append('}');
        return sb.toString();
    }
}
