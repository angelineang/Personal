package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "T_IRRANSWER")
public class TIrrAnswer {

    @Column(name = "IRRANSWERID", length = 60)
    @Id
    private String irrAnswerId;

    @Column(name = "EAPPID", length = 60)
    private String eAppId;

    @Column(name = "QUESTIONKEY", length = 60)
    private String questionKey;

    @Column(name = "QUESTIONANSWER", length = 20)
    private String questionAnswer;

    @Column(name = "QUESTIONANSWERDETAIL", length = 200)
    private String questionAnswerDetail;

    @Column(name = "REMARK1", length = 400)
    private String remark1;

    @Column(name = "REMARK2", length = 400)
    private String remark2;

    @Column(name = "PROTECTIONNEEDS")
    private BigDecimal protectionNeeds;

    @Column(name = "INITIALSUMASSURED")
    private BigDecimal initialSumAssured;

    @Column(name = "TARGETAMOUNTTIMEFRAME")
    private BigDecimal targetAmountTimeframe;

    @Column(name = "TOTALVALUETIMEFRAME")
    private BigDecimal totalValueTimeframe;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TIrrAnswer{");
        sb.append("irrAnswerId='").append(irrAnswerId).append('\'');
        sb.append(", eAppId='").append(eAppId).append('\'');
        sb.append(", questionKey='").append(questionKey).append('\'');
        sb.append(", questionAnswer='").append(questionAnswer).append('\'');
        sb.append(", questionAnswerDetail='").append(questionAnswerDetail).append('\'');
        sb.append(", remark1='").append(remark1).append('\'');
        sb.append(", remark2='").append(remark2).append('\'');
        sb.append(", protectionNeeds=").append(protectionNeeds);
        sb.append(", initialSumAssured=").append(initialSumAssured);
        sb.append(", targetAmountTimeframe=").append(targetAmountTimeframe);
        sb.append(", totalValueTimeframe=").append(totalValueTimeframe);
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append('}');
        return sb.toString();
    }
}
