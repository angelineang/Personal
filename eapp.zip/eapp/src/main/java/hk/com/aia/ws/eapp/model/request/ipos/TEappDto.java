package hk.com.aia.ws.eapp.model.request.ipos;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.annotation.AllowedValuesIntValidation;
import hk.com.aia.ws.eapp.annotation.AllowedValuesValidation;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.math.BigDecimal;
import java.util.Date;

import static hk.com.aia.ws.eapp.constant.Constants.TIMEZONE;

@ApiModel(value = "T_EAPP Model")
@Data
@NoArgsConstructor
@AllArgsConstructor

public class TEappDto {

    @ApiModelProperty(value = "eapp Id", required = true)
    @JsonProperty("eapp_id")
    @Size(max = 60)
    @NotBlank
    private String eappId;

    @JsonProperty("policy_no")
    @Size(max = 10)
    private String policyNo;

    @JsonProperty("policy_currency")
    @Size(max = 3)
    private String policyCurrency;

    @JsonProperty("policy_language")
    @Size(max = 10)
    private String policyLanguage;

    @JsonProperty("e_reference_no")
    @Size(max = 60)
    private String eReferenceNo;

    @JsonProperty("agent_code_1")
    @Size(max = 5)
    private String agentCode1;

    @JsonProperty("agent_name_1")
    @Size(max = 120)
    private String agentName1;

    @JsonProperty("agent_code_2")
    @Size(max = 5)
    private String agentCode2;

    @JsonProperty("agent_name_2")
    @Size(max = 35)
    private String agentName2;

    @JsonProperty("agency_code")
    @Size(max = 5)
    private String agencyCode;

    @JsonProperty("agency_name")
    @Size(max = 120)
    private String agencyName;

    @JsonProperty("area_code")
    @Size(max = 2)
    private String areaCode;

    @JsonProperty("access_code")
    @Size(max = 30)
    private String accessCode;

    @JsonProperty("payment_mode")
    @Size(max = 20)
    private String paymentMode;

    @JsonProperty("is_autopay")
    @AllowedValuesIntValidation(values = {0, 1})
    @ApiModelProperty(value = "integer accepts 0 and 1 only", example = "0")
    private Integer isAutoPay;

    @JsonProperty("initial_payment_curr")
    @Size(max = 3)
    private String initialPaymentCurr;

    @JsonProperty("initial_payment_amt")
    private BigDecimal initialPaymentAmt;

    @JsonProperty("initial_payment_months")
    private Integer initialPaymentMonths;

    @JsonProperty("is_fhc_completed")
    @AllowedValuesIntValidation(values = {0, 1})
    @ApiModelProperty(value = "integer accepts 0 and 1 only", example = "0")
    private Integer isFhcCompleted;

    @JsonProperty("fhc_in_comp_reason")
    @Size(max = 255)
    private String fhcInCompReason;

    @JsonProperty("is_accept_declar")
    @AllowedValuesIntValidation(values = {0, 1})
    @ApiModelProperty(value = "integer accepts 0 and 1 only", example = "0")
    private Integer isAcceptDeclar;

    @JsonProperty("eapp_signed_at")
    @Size(max = 20)
    private String eappSigneDat;

    @ApiModelProperty(value = "eapp signed date, format = yyyy-MM-dd", example = "2020-12-31")
    @JsonProperty("eapp_signed_date")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = TIMEZONE)
    private Date eappSignedDate;

    @JsonProperty("agent_signed_at")
    @Size(max = 20)
    private String agentSigneDat;

    @ApiModelProperty(value = "agent signed date, format =  yyyy-MM-dd", example = "2020-12-31")
    @JsonProperty("agent_signed_date")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = TIMEZONE)
    private Date agentSignedDate;

    @JsonProperty("payment_type")
    @Size(max = 20)
    private String paymentType;

    @JsonProperty("is_personal_data_for_marketing")
    @AllowedValuesIntValidation(values = {0, 1})
    @ApiModelProperty(value = "integer accepts 0 and 1 only", example = "0")
    private Integer isPersonalDataForMarketing;

    @JsonProperty("version_no")
    @Size(max = 30)
    private String versionNo;

    @JsonProperty("is_select_applicant")
    @AllowedValuesIntValidation(values = {0, 1})
    @ApiModelProperty(value = "integer accepts 0 and 1 only", example = "0")
    private Integer isSelectApplicant;

    @JsonProperty("is_select_insured")
    @AllowedValuesIntValidation(values = {0, 1})
    @ApiModelProperty(value = "integer accepts 0 and 1 only", example = "0")
    private Integer isSelectInsured;

    @JsonProperty("application_form_type")
    @Size(max = 10)
    private String applicationFormType;

    @JsonProperty("medical")
    @Size(max = 20)
    private String medical;

    @JsonProperty("dividends_option")
    @Size(max = 20)
    private String dividendsOption;

    @JsonProperty("ilpe_invest_checked")
    private Integer ilpeInvestChecked;

    @JsonProperty("ilpdca_checked")
    private Integer ilpdcaChecked;

    @JsonProperty("ilpdca_amount")
    private BigDecimal ilpdcaAmount;

    @JsonProperty("fna_answer_id")
    @Size(max = 60)
    private String fnaAnswerId;

    @JsonProperty("rpq_answer_id")
    @Size(max = 60)
    private String rpqAnswerId;

    @JsonProperty("declaration_answer_id")
    @Size(max = 60)
    private String declarationAnswerId;

    @JsonProperty("fhc_reason")
    @Size(max = 1050)
    private String fhcReason;

    @JsonProperty("apply_vitality")
    private Integer applyVitality;

    @JsonProperty("channel_code")
    @Size(max = 20)
    private String channelCode;

    @JsonProperty("user_group")
    @Size(max = 20)
    private String userGroup;

    @JsonProperty("platform")
    @Size(max = 20)
    private String platform;

    @JsonProperty("is_fna")
    @AllowedValuesIntValidation(values = {0, 1})
    @ApiModelProperty(value = "integer accepts 0 and 1 only", example = "0")
    private Integer isFna;

    @JsonProperty("cies")
    private Integer cies;

    @JsonProperty("rpq_total_score")
    private Integer rpqTotalScore;

    @ApiModelProperty(value = "fna signed date, format = yyyy-MM-dd", example = "2020-12-31")
    @JsonProperty("fna_signed_date")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = TIMEZONE)
    private Date fnAsignedDate;

    @ApiModelProperty(value = "pgs signed date, format = yyyy-MM-dd", example = "2020-12-31")
    @JsonProperty("pgs_signed_date")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = TIMEZONE)
    private Date pgsSignedDate;

    @ApiModelProperty(value = "ipos created date time")
    @JsonProperty("ipos_created_date_time")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", timezone = TIMEZONE)
    private Date iposCreatedDateTime;

    @ApiModelProperty(value = "ipos last updated date time")
    @JsonProperty("ipos_last_updated_date_time")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", timezone = TIMEZONE)
    private Date iposLastUpdatedDateTime;

    @JsonProperty("maturity_policy_no")
    @Size(max = 10)
    private String maturityPolicyNo;

    @ApiModelProperty(value = "ifs prc signed date,format = yyyy-MM-dd", example = "2020-12-31")
    @JsonProperty("ifs_prc_signed_date")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = TIMEZONE)
    private Date ifsPrcSignedDate;

    @JsonProperty("magnum_case")
    @Size(max = 1)
    private String magnumCase;

    @JsonProperty("is_prc_case")
    @AllowedValuesValidation(values = {"0", "1"})
    @ApiModelProperty(value = "string accepts 0 and 1 only", example = "0")
    @Size(max = 1)
    private String isPrcCase;

    @JsonProperty("doc_cnt")
    private Integer docCnt;

    @JsonProperty("hand_input_policy_no")
    @Size(max = 5)
    private String handInputPolicyNo;

    @JsonProperty("is_vitality_data_for_marketing")
    @AllowedValuesIntValidation(values = {0, 1})
    @ApiModelProperty(value = "integer accepts 0 and 1 only", example = "0")
    private Integer isVitalityDataForMarketing;

    @JsonProperty("submit_type")
    @Size(max = 20)
    private String submitType;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TEappDto{");
        sb.append("eappId='").append(eappId).append('\'');
        sb.append(", policyNo='").append(ConversionHandler.mask(policyNo)).append('\'');
        sb.append(", policyCurrency='").append(policyCurrency).append('\'');
        sb.append(", policyLanguage='").append(policyLanguage).append('\'');
        sb.append(", eReferenceNo='").append(eReferenceNo).append('\'');
        sb.append(", agentCode1='").append(agentCode1).append('\'');
        sb.append(", agentName1='").append(ConversionHandler.mask(agentName1)).append('\'');
        sb.append(", agentCode2='").append(agentCode2).append('\'');
        sb.append(", agentName2='").append(ConversionHandler.mask(agentName2)).append('\'');
        sb.append(", agencyCode='").append(agencyCode).append('\'');
        sb.append(", agencyName='").append(agencyName).append('\'');
        sb.append(", areaCode='").append(areaCode).append('\'');
        sb.append(", accessCode='").append(accessCode).append('\'');
        sb.append(", paymentMode='").append(paymentMode).append('\'');
        sb.append(", isAutoPay=").append(isAutoPay);
        sb.append(", initialPaymentCurr='").append(initialPaymentCurr).append('\'');
        sb.append(", initialPaymentAmt=").append(initialPaymentAmt);
        sb.append(", initialPaymentMonths=").append(initialPaymentMonths);
        sb.append(", isFhcCompleted=").append(isFhcCompleted);
        sb.append(", fhcInCompReason='").append(fhcInCompReason).append('\'');
        sb.append(", isAcceptDeclar=").append(isAcceptDeclar);
        sb.append(", eappSigneDat='").append(eappSigneDat).append('\'');
        sb.append(", eappSignedDate=").append(eappSignedDate);
        sb.append(", agentSigneDat='").append(agentSigneDat).append('\'');
        sb.append(", agentSignedDate=").append(agentSignedDate);
        sb.append(", paymentType='").append(paymentType).append('\'');
        sb.append(", isPersonalDataForMarketing=").append(isPersonalDataForMarketing);
        sb.append(", versionNo='").append(versionNo).append('\'');
        sb.append(", isSelectApplicant=").append(isSelectApplicant);
        sb.append(", isSelectInsured=").append(isSelectInsured);
        sb.append(", applicationFormType='").append(applicationFormType).append('\'');
        sb.append(", medical='").append(medical).append('\'');
        sb.append(", dividendsOption='").append(dividendsOption).append('\'');
        sb.append(", ilpeInvestChecked=").append(ilpeInvestChecked);
        sb.append(", ilpdcaChecked=").append(ilpdcaChecked);
        sb.append(", ilpdcaAmount=").append(ilpdcaAmount);
        sb.append(", fnaAnswerId='").append(fnaAnswerId).append('\'');
        sb.append(", rpqAnswerId='").append(rpqAnswerId).append('\'');
        sb.append(", declarationAnswerId='").append(declarationAnswerId).append('\'');
        sb.append(", fhcReason='").append(fhcReason).append('\'');
        sb.append(", applyVitality=").append(applyVitality);
        sb.append(", channelCode='").append(channelCode).append('\'');
        sb.append(", userGroup='").append(userGroup).append('\'');
        sb.append(", platform='").append(platform).append('\'');
        sb.append(", isFna=").append(isFna);
        sb.append(", cies=").append(cies);
        sb.append(", rpqTotalScore=").append(rpqTotalScore);
        sb.append(", fnAsignedDate=").append(fnAsignedDate);
        sb.append(", pgsSignedDate=").append(pgsSignedDate);
        sb.append(", iposCreatedDateTime=").append(iposCreatedDateTime);
        sb.append(", iposLastUpdatedDateTime=").append(iposLastUpdatedDateTime);
        sb.append(", maturityPolicyNo='").append(maturityPolicyNo).append('\'');
        sb.append(", ifsPrcSignedDate=").append(ifsPrcSignedDate);
        sb.append(", magnumCase='").append(magnumCase).append('\'');
        sb.append(", isPrcCase='").append(isPrcCase).append('\'');
        sb.append(", docCnt=").append(docCnt);
        sb.append(", handInputPolicyNo='").append(handInputPolicyNo).append('\'');
        sb.append(", isVitalityDataForMarketing=").append(isVitalityDataForMarketing);
        sb.append(", submitType='").append(submitType).append('\'');
        sb.append('}');
        return sb.toString();
    }
}


