package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "T_EAPPREVIEWER")
public class TEappReviewer {
    @Column(name = "EAPPREVIEWERID", length = 60)
    @Id
    private String eappReviewerId;

    @Column(name = "EAPPID", length = 60)
    private String eappId;

    @Column(name = "CHECKERNAME", length = 200)
    private String checkerName;

    @Column(name = "CHECKERLICENSENO", length = 200)
    private String checkerLicenseNo;

    @Column(name = "APPROVERNAME", length = 200)
    private String approverName;

    @Column(name = "APPROVERLICENSENO", length = 200)
    private String approverLicenseeNo;

    @Column(name = "BRANCHCODE", length = 60)
    private String branchCode;

    @Column(name = "BRANCHNAME", length = 200)
    private String branchName;

    @Column(name = "AGENTCODE", length = 10)
    private String agentCode;

    @Column(name = "AGENTNAME", length = 200)
    private String agentName;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "LASTUPDATEDATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    @LastModifiedDate
    private Date lastUpdateDateTime;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TEappReviewer{");
        sb.append("eappReviewerId='").append(eappReviewerId).append('\'');
        sb.append(", eappId='").append(eappId).append('\'');
        sb.append(", checkerName='").append(checkerName).append('\'');
        sb.append(", checkerLicenseNo='").append(checkerLicenseNo).append('\'');
        sb.append(", approverName='").append(approverName).append('\'');
        sb.append(", approverLicenseeNo='").append(approverLicenseeNo).append('\'');
        sb.append(", branchCode='").append(branchCode).append('\'');
        sb.append(", branchName='").append(branchName).append('\'');
        sb.append(", agentCode='").append(agentCode).append('\'');
        sb.append(", agentName='").append(agentName).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", lastUpdateDateTime=").append(lastUpdateDateTime);
        sb.append('}');
        return sb.toString();
    }
}

