package hk.com.aia.ws.eapp.controller;

import hk.com.aia.ws.eapp.annotation.AllowedValuesValidation;
import hk.com.aia.ws.eapp.constant.Constants;
import hk.com.aia.ws.eapp.model.base.CustomResponseStatus;
import hk.com.aia.ws.eapp.model.base.ResultMessage;
import hk.com.aia.ws.eapp.model.request.Request;
import hk.com.aia.ws.eapp.model.request.medical.Doctor;
import hk.com.aia.ws.eapp.model.request.medical.DoctorRequest;
import hk.com.aia.ws.eapp.model.request.medical.MedicalCheckReg;
import hk.com.aia.ws.eapp.model.request.medical.MedicalCheckRegRequest;
import hk.com.aia.ws.eapp.model.response.Response;
import hk.com.aia.ws.eapp.model.response.error.GatewayError400;
import hk.com.aia.ws.eapp.model.response.error.GatewayError401;
import hk.com.aia.ws.eapp.model.response.error.InternalError500;
import hk.com.aia.ws.eapp.model.response.medical.DoctorResponse;
import hk.com.aia.ws.eapp.model.response.medical.MedicalCheckRegResponse;
import hk.com.aia.ws.eapp.service.medical.AzureService;
import hk.com.aia.ws.eapp.service.medical.MedicalService;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import io.swagger.annotations.*;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import java.util.List;

@Slf4j
@AllArgsConstructor
@RestController
@RequestMapping("/medicals")
@Api(value = "Medicals", tags = {"API(s) for medical enquiries"})
@Validated

public class MedicalController {
    private final MedicalService medicalService;
    private final AzureService azureService;

    @ApiOperation("To obtain doctor's list")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Obtain doctors list"),

            @ApiResponse(code = 400, message = "Bad Request", response = GatewayError400.class),
            @ApiResponse(code = 401, message = "Unauthorized", response = GatewayError401.class),
            @ApiResponse(code = 404, message = "Invalid request.", response = Response.class),
            @ApiResponse(code = 500, message = "Internal Server Error", response = InternalError500.class)
    })
    @PostMapping(value = "/get-doctor-list", produces = MediaType.APPLICATION_JSON_VALUE)
    public Response<DoctorResponse> enquiryDoctor(
            @ApiParam(value = "Local business unit.    | Valid Values |   | ----------   |   | HK, TH, SG   | ", required = true)
            @RequestHeader(value = Constants.RequestHeader.AIA_LBU, required = true) String xAiaLbu,
            @ApiParam(value = "Unique id for the request for tracking purposes.        ", required = true)
            @RequestHeader(value = Constants.RequestHeader.REQUEST_ID, required = true) String xAiaRequestId,
            @ApiParam(value = "Trace Id for EFK Logging")
            @RequestHeader(value = Constants.RequestHeader.TRACE_ID, required = true) String xAiaHkTraceId,
            @ApiParam(value = "An access token issued by an AIA Authorization server. This will have the format Bearer + {space} + {accessToken}.")
            @RequestHeader(value = Constants.RequestHeader.AIAACESSTOKEN, required = true) String Authorization,
            @ApiParam(value = "Context Id for EFK Logging")
            @RequestHeader(value = Constants.RequestHeader.CONTEXT_ID) String xAiaHkContextId,
            @ApiParam(value = "Denotes the first record being returned")
            @Min(value = 0)
            @RequestParam(value = "$offset") int offset,
            @Max(value = 5) @Min(value = 1)
            @ApiParam(value = "Number of results returned")
            @RequestParam(value = "$limit") int limit,
            @AllowedValuesValidation(values = {"ASC", "DESC"})
            @ApiParam(value = "Property to sort results")
            @RequestParam(value = "$sort") String sort,
            @ApiParam(value = "Policy details to be submitted", required = true)
            @Valid @RequestBody Request<DoctorRequest> enquireDoctorsList) throws Exception {
        log.info("Check Token {}", ConversionHandler.encode(Authorization));
        final DoctorResponse doctorResponse = new DoctorResponse();
        final Response<DoctorResponse> payload = new Response<>();
        final ResultMessage resultMessage = new ResultMessage();

        azureService.checkAzureToken(Authorization);
        log.info("enquiryDoctor - start");
        try {
            final List<Doctor> doctorResponseLists = medicalService.getDoctor(enquireDoctorsList.getData().getDoctor(), limit, offset, sort);
            doctorResponse.setDoctorResponseLists(doctorResponseLists);
            resultMessage.setCode("1");
            resultMessage.setMessage("SUCCESS");
            payload.setTransId(enquireDoctorsList.getTransId());
            payload.setStatus(CustomResponseStatus.SUCCESS.getDescription());
            payload.setData(doctorResponse);
            payload.getResultMessages().add(new ResultMessage(resultMessage.getCode(), resultMessage.getMessage()));
            log.info("enquiryDoctor - end ");

        } catch (Exception ex) {
            payload.setStatus(CustomResponseStatus.ERROR.getDescription());
            resultMessage.setCode("-99");
            resultMessage.setMessage(ex.getMessage());
            payload.getResultMessages().add(new ResultMessage(resultMessage.getCode(), resultMessage.getMessage()));
            log.error("Error message for enquiryDoctor: {}", ex.getMessage());
            log.info("enquiryDoctor - end ");
        }
        return payload;
    }

    @ApiOperation("To get regular medical check list")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Obtain regular medical check list."),
            @ApiResponse(code = 400, message = "Bad Request", response = GatewayError400.class),
            @ApiResponse(code = 401, message = "Unauthorized", response = GatewayError401.class),
            @ApiResponse(code = 404, message = "Invalid request.", response = Response.class),
            @ApiResponse(code = 500, message = "Internal Server Error", response = InternalError500.class)
    })
    @PostMapping(value = "/get-medical-check-reg-list", produces = MediaType.APPLICATION_JSON_VALUE)
    public Response<MedicalCheckRegResponse> enquiryDoctorReg(
            @ApiParam(value = "Local business unit.    | Valid Values |   | ----------   |   | HK, TH, SG   | ", required = true)
            @RequestHeader(value = Constants.RequestHeader.AIA_LBU, required = true) String xAiaLbu,
            @ApiParam(value = "Unique id for the request for tracking purposes.        ", required = true)
            @RequestHeader(value = Constants.RequestHeader.REQUEST_ID, required = true) String xAiaRequestId,
            @ApiParam(value = "An access token issued by an AIA Authorization server. This will have the format Bearer + {space} + {accessToken}.")
            @RequestHeader(value = Constants.RequestHeader.AIAACESSTOKEN, required = true) String Authorization,
            @ApiParam(value = "Trace Id for EFK Logging")
            @RequestHeader(value = Constants.RequestHeader.TRACE_ID, required = true) String xAiaHkTraceId,
            @ApiParam(value = "Context Id for EFK Logging")
            @RequestHeader(value = Constants.RequestHeader.CONTEXT_ID) String xAiaHkContextId,
            @ApiParam(value = "Denotes the first record being returned")
            @Min(value = 0)
            @RequestParam(value = "$offset") int offset,
            @Max(value = 5) @Min(value = 1)
            @ApiParam(value = "Number of results returned")
            @RequestParam(value = "$limit") int limit,
            @AllowedValuesValidation(values = {"ASC", "DESC"})
            @ApiParam(value = "Property to sort results")
            @RequestParam(value = "$sort") String sort,
            @ApiParam(value = "Policy details to be submitted", required = true)
            @Valid @RequestBody Request<MedicalCheckRegRequest> medicalCheckList) throws Exception {
        log.info("enquiryDoctorReg  - start");
        final MedicalCheckRegResponse medicalCheckRegResponse = new MedicalCheckRegResponse();
        final Response<MedicalCheckRegResponse> payload = new Response<>();
        final ResultMessage resultMessage = new ResultMessage();

        azureService.checkAzureToken(Authorization);

        try {
            final List<MedicalCheckReg> medicalCheckRegList = medicalService.getMedicalCheckReg(medicalCheckList.getData().getMedicalCheckReg(), limit, offset, sort);
            medicalCheckRegResponse.setMedicalCheckRegList(medicalCheckRegList);
            resultMessage.setCode("1");
            resultMessage.setMessage("SUCCESS");
            payload.setTransId(medicalCheckList.getTransId());
            payload.setStatus(CustomResponseStatus.SUCCESS.getDescription());
            payload.setData(medicalCheckRegResponse);
            payload.getResultMessages().add(new ResultMessage(resultMessage.getCode(), resultMessage.getMessage()));
            log.info("enquiryDoctorReg - end ");
        } catch (Exception ex) {
            payload.setStatus(CustomResponseStatus.ERROR.getDescription());
            resultMessage.setCode("-99");
            resultMessage.setMessage(ex.getMessage());
            payload.getResultMessages().add(new ResultMessage(resultMessage.getCode(), resultMessage.getMessage()));
            log.error("Error message for enquiryDoctorReg: {}", ex.getMessage());
            log.info("enquiryDoctorReg - end ");
        }
        return payload;

    }

    @ApiOperation("To update regular medical checkup")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Update regular medical checkup."),
            @ApiResponse(code = 400, message = "Bad Request", response = GatewayError400.class),
            @ApiResponse(code = 401, message = "Unauthorized", response = GatewayError401.class),
            @ApiResponse(code = 404, message = "Invalid request.", response = Response.class),
            @ApiResponse(code = 500, message = "Internal Server Error", response = InternalError500.class)
    })
    @PostMapping(value = "/update-medical-reg", produces = MediaType.APPLICATION_JSON_VALUE)
    public Response<MedicalCheckRegResponse> updateDoctorReg(
            @ApiParam(value = "Local business unit.    | Valid Values |   | ----------   |   | HK, TH, SG   | ", required = true)
            @RequestHeader(value = Constants.RequestHeader.AIA_LBU, required = true) String xAiaLbu,
            @ApiParam(value = "Unique id for the request for tracking purposes.        ", required = true)
            @RequestHeader(value = Constants.RequestHeader.REQUEST_ID, required = true) String xAiaRequestId,
            @ApiParam(value = "An access token issued by an AIA Authorization server. This will have the format Bearer + {space} + {accessToken}.")
            @RequestHeader(value = Constants.RequestHeader.AIAACESSTOKEN, required = true) String Authorization,
            @ApiParam(value = "Trace Id for EFK Logging")
            @RequestHeader(value = Constants.RequestHeader.TRACE_ID, required = true) String xAiaHkTraceId,
            @ApiParam(value = "Context Id for EFK Logging")
            @RequestHeader(value = Constants.RequestHeader.CONTEXT_ID) String xAiaHkContextId,
            @ApiParam(value = "Policy details to be submitted", required = true)
            @Valid @RequestBody Request<MedicalCheckRegRequest> medicalCheckList) throws Exception {
        log.info("updateDoctorReg - start");
        final Response<MedicalCheckRegResponse> payload = new Response<>();
        final ResultMessage resultMessage = new ResultMessage();

        azureService.checkAzureToken(Authorization);
        try {
            int recordUpdated = medicalService.updateMedicalCheckReg(medicalCheckList.getData().getMedicalCheckReg());
            resultMessage.setCode("1");
            resultMessage.setMessage("Updated " + " " + recordUpdated + " " + " record successfully");
            payload.setTransId(medicalCheckList.getTransId());
            payload.setStatus(CustomResponseStatus.SUCCESS.getDescription());
            payload.getResultMessages().add(new ResultMessage(resultMessage.getCode(), resultMessage.getMessage()));
            log.info("updateDoctorReg - end");
        } catch (Exception ex) {
            resultMessage.setCode("-99");
            resultMessage.setMessage(ex.getMessage());
            payload.getResultMessages().add(new ResultMessage(resultMessage.getCode(), resultMessage.getMessage()));
            payload.setStatus(CustomResponseStatus.ERROR.getDescription());
            log.info("updateDoctorReg - end");
            log.error("Error updating medical reg: {}", ex.getMessage());
        }
        return payload;
    }

    @ApiOperation("To insert regular medical checkup")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Insert regular medical checkup."),
            @ApiResponse(code = 400, message = "Bad Request", response = GatewayError400.class),
            @ApiResponse(code = 401, message = "Unauthorized", response = GatewayError401.class),
            @ApiResponse(code = 404, message = "Invalid request.", response = Response.class),
            @ApiResponse(code = 500, message = "Internal Server Error", response = InternalError500.class)
    })
    @PostMapping(value = "/insert-medical-reg", produces = MediaType.APPLICATION_JSON_VALUE)
    public Response<MedicalCheckRegResponse> insertDoctorReg(
            @ApiParam(value = "Local business unit.    | Valid Values |   | ----------   |   | HK, TH, SG   | ", required = true)
            @RequestHeader(value = Constants.RequestHeader.AIA_LBU, required = true) String xAiaLbu,
            @ApiParam(value = "Unique id for the request for tracking purposes.        ", required = true)
            @RequestHeader(value = Constants.RequestHeader.REQUEST_ID, required = true) String xAiaRequestId,
            @ApiParam(value = "An access token issued by an AIA Authorization server. This will have the format Bearer + {space} + {accessToken}.")
            @RequestHeader(value = Constants.RequestHeader.AIAACESSTOKEN, required = true) String Authorization,
            @ApiParam(value = "Trace Id for EFK Logging")
            @RequestHeader(value = Constants.RequestHeader.TRACE_ID, required = true) String xAiaHkTraceId,
            @ApiParam(value = "Context Id for EFK Logging")
            @RequestHeader(value = Constants.RequestHeader.CONTEXT_ID) String xAiaHkContextId,
            @ApiParam(value = "Policy details to be submitted", required = true)
            @Valid @RequestBody Request<MedicalCheckRegRequest> medicalCheckList) throws Exception {
        log.info("insertDoctorReg - start");
        final Response<MedicalCheckRegResponse> payload = new Response<>();
        final ResultMessage resultMessage = new ResultMessage();

        azureService.checkAzureToken(Authorization);
        try {
            int recordInserted = medicalService.insertMedicalCheckReg(medicalCheckList.getData().getMedicalCheckReg());
            resultMessage.setCode("1");
            resultMessage.setMessage("Inserted " + " " + recordInserted + " " + " record successfully");
            payload.setTransId(medicalCheckList.getTransId());
            payload.setStatus(CustomResponseStatus.SUCCESS.getDescription());
            payload.getResultMessages().add(new ResultMessage(resultMessage.getCode(), resultMessage.getMessage()));
            log.info("insertDoctorReg - end");
        } catch (Exception ex) {
            resultMessage.setCode("-99");
            resultMessage.setMessage(ex.getMessage());
            payload.getResultMessages().add(new ResultMessage(resultMessage.getCode(), resultMessage.getMessage()));
            payload.setStatus(CustomResponseStatus.ERROR.getDescription());
            log.info("insertDoctorReg - end");
            log.error("Error inserting medical reg: {}", ex.getMessage());
        }
        return payload;
    }

    @ApiOperation("To delete regular medical checkup record")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Delete regular medical checkup."),
            @ApiResponse(code = 400, message = "Bad Request", response = GatewayError400.class),
            @ApiResponse(code = 401, message = "Unauthorized", response = GatewayError401.class),
            @ApiResponse(code = 404, message = "Invalid request.", response = Response.class),
            @ApiResponse(code = 500, message = "Internal Server Error", response = InternalError500.class)
    })
    @PostMapping(value = "/delete-medical-reg", produces = MediaType.APPLICATION_JSON_VALUE)
    public Response<MedicalCheckRegResponse> deleteDoctorReg(
            @ApiParam(value = "Local business unit.    | Valid Values |   | ----------   |   | HK, TH, SG   | ", required = true)
            @RequestHeader(value = Constants.RequestHeader.AIA_LBU, required = true) String xAiaLbu,
            @ApiParam(value = "Unique id for the request for tracking purposes.        ", required = true)
            @RequestHeader(value = Constants.RequestHeader.REQUEST_ID, required = true) String xAiaRequestId,
            @ApiParam(value = "An access token issued by an AIA Authorization server. This will have the format Bearer + {space} + {accessToken}.")
            @RequestHeader(value = Constants.RequestHeader.AIAACESSTOKEN, required = true) String Authorization,
            @ApiParam(value = "Trace Id for EFK Logging")
            @RequestHeader(value = Constants.RequestHeader.TRACE_ID, required = true) String xAiaHkTraceId,
            @ApiParam(value = "Context Id for EFK Logging")
            @RequestHeader(value = Constants.RequestHeader.CONTEXT_ID) String xAiaHkContextId,
            @ApiParam(value = "Policy details to be submitted", required = true)
            @Valid @RequestBody Request<MedicalCheckRegRequest> medicalCheckList) throws Exception {
        log.info("deleteDoctorReg - start");
        final Response<MedicalCheckRegResponse> payload = new Response<>();
        final ResultMessage resultMessage = new ResultMessage();

        azureService.checkAzureToken(Authorization);

        try {
            int recordDeleted = medicalService.deleteMedicalCheckReg(medicalCheckList.getData().getMedicalCheckReg());
            resultMessage.setCode("1");
            resultMessage.setMessage("Delete " + " " + recordDeleted + " " + " record successfully");
            payload.setTransId(medicalCheckList.getTransId());
            payload.setStatus(CustomResponseStatus.SUCCESS.getDescription());
            payload.getResultMessages().add(new ResultMessage(resultMessage.getCode(), resultMessage.getMessage()));
            log.info("deleteDoctorReg - end");
        } catch (Exception ex) {
            resultMessage.setCode("-99");
            resultMessage.setMessage(ex.getMessage());
            payload.getResultMessages().add(new ResultMessage(resultMessage.getCode(), resultMessage.getMessage()));
            payload.setStatus(CustomResponseStatus.ERROR.getDescription());
            log.info("deleteDoctorReg - end");
            log.error("Delete inserting medical reg: {}", ex.getMessage());
        }
        return payload;
    }
}
