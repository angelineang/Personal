package hk.com.aia.ws.eapp.model.request.ipos;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.annotation.AllowedValuesIntValidation;
import hk.com.aia.ws.eapp.annotation.AllowedValuesValidation;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.util.Date;

import static hk.com.aia.ws.eapp.constant.Constants.TIMEZONE;

@ApiModel(value = "T_EAPPBENEFICIARY Model")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TEappBeneficiaryDto {

    @ApiModelProperty(value = "eapp Beneficiary Id", required = true)
    @JsonProperty("eapp_beneficiary_id")
    @Size(max = 60)
    @NotBlank
    private String eappBeneficiaryId;

    @JsonProperty("eapp_id")
    @Size(max = 60)
    private String eappId;

    @JsonProperty("full_name_en")
    @Size(max = 200)
    private String fullNameEn;

    @JsonProperty("name_chn")
    @Size(max = 650)
    private String nameChn;

    @JsonProperty("bene_sequence")
    private Integer beneSequence;

    @JsonProperty("age")
    private Integer age;

    @JsonProperty("bene_type")
    @Size(max = 10)
    private String beneType;

    @JsonProperty("bene_share")
    private Integer beneShare;

    @JsonProperty("is_equal_share")
    @AllowedValuesIntValidation(values = {0, 1})
    @ApiModelProperty(value = "integer accepts 0 and 1 only", example = "0")
    private Integer isEqualShare;

    @JsonProperty("is_owne_state")
    @AllowedValuesIntValidation(values = {0, 1})
    @ApiModelProperty(value = "integer accepts 0 and 1 only", example = "0")
    private Integer isOwneState;

    @JsonProperty("id_card_passport_no")
    @Size(max = 18)
    private String idCardPassportNo;

    @ApiModelProperty(value = "relationship", example = "P - Parent, S-Spouse, C- Children, B-Brother/Sister, G- Grandparent, J- Grandchildren, T- StepParents, H-Step Children, N-Niece.Nephew U- Uncle/Aunt F-Finance/Financee")
    @JsonProperty("relationship")
    //@AllowedValuesValidation(values = {"P", "S", "C", "B", "G", "J", "T", "H", "N", "U", "F"})
    @Size(max = 2)
    private String relationship;

    @JsonProperty("others")
    @Size(max = 255)
    private String others;

    @JsonProperty("others_reason")
    @Size(max = 255)
    private String othersReason;

    @ApiModelProperty(value = "date of birth, format= yyyy-MM-dd", example = "2020-12-31")
    @JsonProperty("dob")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = TIMEZONE)
    private Date dob;

    @JsonProperty("gender")
    @Size(max = 10)
    private String gender;

    @JsonProperty("id_type")
    @Size(max = 20)
    private String idType;

    @JsonProperty("charity_number")
    @Size(max = 50)
    private String charityNumber;

    @JsonProperty("charity_exist_status")
    private Integer charityExistStatus;

    @JsonProperty("contingent_insure_relationship")
    @Size(max = 1)
    private String contingentInsureRelationship;

    @JsonProperty("contingent_insure_relationship_other")
    @Size(max = 500)
    private String contingentInsureRelationshipOther;

    @JsonProperty("contingent_insure_relationship_other_reason")
    @Size(max = 500)
    private String contingentInsureRelationshipOtherReason;

    @JsonProperty("is_designed_person")
    @Size(max = 10)
    private String isDesignedPerson;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TEappBeneficiaryDto{");
        sb.append("eappBeneficiaryId='").append(eappBeneficiaryId).append('\'');
        sb.append(", eappId='").append(eappId).append('\'');
        sb.append(", fullNameEn='").append(ConversionHandler.mask(fullNameEn)).append('\'');
        sb.append(", nameChn='").append(ConversionHandler.mask(nameChn)).append('\'');
        sb.append(", beneSequence=").append(beneSequence);
        sb.append(", age=").append(ConversionHandler.mask(age));
        sb.append(", beneType='").append(beneType).append('\'');
        sb.append(", beneShare=").append(beneShare);
        sb.append(", isEqualShare=").append(isEqualShare);
        sb.append(", isOwneState=").append(isOwneState);
        sb.append(", idCardPassportNo='").append(ConversionHandler.mask(idCardPassportNo)).append('\'');
        sb.append(", relationship='").append(relationship).append('\'');
        sb.append(", others='").append(others).append('\'');
        sb.append(", othersReason='").append(othersReason).append('\'');
        sb.append(", dob=").append(ConversionHandler.mask(dob));
        sb.append(", gender='").append(gender).append('\'');
        sb.append(", idType='").append(idType).append('\'');
        sb.append(", charityNumber='").append(charityNumber).append('\'');
        sb.append(", charityExistStatus=").append(charityExistStatus);
        sb.append(", contingentInsureRelationship='").append(contingentInsureRelationship).append('\'');
        sb.append(", contingentInsureRelationshipOther='").append(contingentInsureRelationshipOther).append('\'');
        sb.append(", contingentInsureRelationshipOtherReason='").append(contingentInsureRelationshipOtherReason).append('\'');
        sb.append(", isDesignedPerson='").append(isDesignedPerson).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
