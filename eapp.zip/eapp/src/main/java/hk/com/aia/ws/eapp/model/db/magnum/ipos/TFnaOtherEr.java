package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "T_FNAOtherER")
public class TFnaOtherEr {

    @Column(name = "FNAOtherERID", length = 60)
    @Id
    private String fnaOtherERID;

    @Column(name = "FNAID", length = 60)
    private String fnaId;

    @Column(name = "FNAQNo", length = 10)
    private String fnaQno;

    @Column(name = "Answer", length = 50)
    private String answer;

    @Column(name = "CompanyName", length = 300)
    private String companyName;

    @Column(name = "Others")
    private String others;

    @Column(name = "ProductName")
    private String productName;

    @Column(name = "Sequence", length = 10)
    private String sequence;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "OTHERSCONTENT", length = 200)
    private String othersContent;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TFnaOtherEr{");
        sb.append("fnaOtherERID='").append(fnaOtherERID).append('\'');
        sb.append(", fnaId='").append(fnaId).append('\'');
        sb.append(", fnaQno='").append(fnaQno).append('\'');
        sb.append(", answer='").append(answer).append('\'');
        sb.append(", companyName='").append(companyName).append('\'');
        sb.append(", others='").append(others).append('\'');
        sb.append(", productName='").append(productName).append('\'');
        sb.append(", sequence='").append(sequence).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", othersContent='").append(othersContent).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
