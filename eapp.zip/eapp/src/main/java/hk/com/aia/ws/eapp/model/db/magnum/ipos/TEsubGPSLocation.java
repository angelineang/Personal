package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import hk.com.aia.ws.eapp.annotation.DataTruncation;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "T_ESubGPSLocation")
public class TEsubGPSLocation {

    @Column(name = "ESubGPSID", length = 60)
    @Id
    private String esubGpsId;

    @Column(name = "ESubID", length = 60)
    private String esubId;

    @Column(name = "EappID", length = 60)
    private String eappId;

    @Column(name = "LoginID", length = 100)
    @DataTruncation(max = 10, validateByte = true, log = true)
    private String loginId;

    @Column(name = "PolicyNo", length = 50)
    private String policyNo;

    @Column(name = "Latitude", length = 50)
    private String latitude;

    @Column(name = "Longitude", length = 50)
    private String longitude;

    @Column(name = "createddatetime", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TEsubGPSLocation{");
        sb.append("esubGpsId='").append(esubGpsId).append('\'');
        sb.append(", esubId='").append(esubId).append('\'');
        sb.append(", eappId='").append(eappId).append('\'');
        sb.append(", loginId='").append(loginId).append('\'');
        sb.append(", policyNo='").append(ConversionHandler.mask(policyNo)).append('\'');
        sb.append(", latitude='").append(latitude).append('\'');
        sb.append(", longitude='").append(longitude).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append('}');
        return sb.toString();
    }
}