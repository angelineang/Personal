package hk.com.aia.ws.eapp.model.db.magnum.iverify;

import hk.com.aia.ws.eapp.model.db.magnum.ipos.idclass.TPrcOtherServicePolicyId;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import io.micrometer.core.annotation.Counted;
import lombok.Data;

import javax.persistence.*;

@Entity
@Data
@Table( name = "T_PRC_OTHER_SERVICE_POLICY")
@IdClass(TPrcOtherServicePolicyId.class)
public class TPrcOtherServicePolicy {

    @Column(name = "IVERIFYID", length = 60)
    @Id
    private String iverifyId;

    @Column(name = "SERVICETYPE", length = 8)
    @Id
    private String serviceType;

    @Column(name = "POLICYNO", length = 16)
    @Id
    private String policyNo;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TPrcOtherServicePolicy{");
        sb.append("iverifyId='").append(iverifyId).append('\'');
        sb.append(", serviceType='").append(serviceType).append('\'');
        sb.append(", policyNo='").append(ConversionHandler.mask(policyNo)).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
