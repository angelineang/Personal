package hk.com.aia.ws.eapp.model.db.magnum.ipos;


import hk.com.aia.ws.eapp.util.ConversionHandler;
import lombok.Data;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "T_PAYMENTDETAIL")
public class TPaymentDetail {

    @Column(name = "PAYMENTDETAILID", length = 60)
    @Id
    private String paymentDetailId;

    @Column(name = "EAPPID", length = 60)
    private String eappId;

    @Column(name = "PAYORRELATIONSHIP", length = 40)
    private String payOrRelationship;

    @Column(name = "ACCOUNTCARDNO", length = 20)
    private String accountCardNo;

    @Column(name = "PAYMENTMODE", length = 10)
    private String paymentMode;

    @Column(name = "EXPIRYDATE")
    @Temporal(TemporalType.DATE)
    private Date expiryDate;

    @Column(name = "BANKCODE", length = 3)
    private String bankCode;

    @Column(name = "BRANCHCODE", length = 3)
    private String branchCode;

    @Column(name = "BANKNAME", length = 100)
    private String bankName;

    @Column(name = "BRANCHNAME", length = 100)
    private String branchName;

    @Column(name = "DOCUMENTID", length = 60)
    private String documentId;

    @Column(name = "ISSIGNREQUIRED")
    private Integer isSignRequired;

    @Column(name = "ISSIGNED")
    private Integer isSigned;

    @Column(name = "SIGNEDDATE")
    @Temporal(TemporalType.DATE)
    private Date signedDate;

    @Column(name = "CREATEDBY", length = 10, updatable = false)
    @CreatedBy
    private String createdBy;

    @Column(name = "UPDATEDBY", length = 10)
    @LastModifiedBy
    private String updatedBy;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "LASTUPDATEDATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    @LastModifiedDate
    private Date lastUpdateDateTime;

    @Column(name = "EAPPQANSWER", length = 5)
    private String eappQAnswer;

    @Column(name = "CARDPLACE", length = 5)
    private String cardPlace;

    @Column(name = "applyEBankIn", length = 10)
    private String applyEBankIn;

    @Column(name = "sameAsDDA", length = 10)
    private String sameAsDDA;

    @Column(name = "eBankName", length = 300)
    private String eBankName;

    @Column(name = "eBankCode", length = 20)
    private String eBankCode;

    @Column(name = "eBankBranchNo", length = 20)
    private String eBankBranchNo;

    @Column(name = "eBankAccountNo", length = 50)
    private String eBankAccountNo;

    @Column(name = "eBankHolderName", length = 200)
    private String eBankHolderName;

    @Column(name = "EBANKCURRENCY", length = 10)
    private String eBankCurrency;

    @Column(name = "EBankSwiftCode", length = 30)
    private String eBankSwiftCode;

    @Column(name = "EBankAccountType", length = 10)
    private String eBankAccountType;

    @Column(name = "FPSCURRENCY")
    private String fpsCurrency;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TPaymentDetail{");
        sb.append("paymentDetailId='").append(paymentDetailId).append('\'');
        sb.append(", eappId='").append(eappId).append('\'');
        sb.append(", payOrRelationship='").append(payOrRelationship).append('\'');
        sb.append(", accountCardNo='").append(ConversionHandler.mask(accountCardNo)).append('\'');
        sb.append(", paymentMode='").append(paymentMode).append('\'');
        sb.append(", expiryDate=").append(expiryDate);
        sb.append(", bankCode='").append(bankCode).append('\'');
        sb.append(", branchCode='").append(branchCode).append('\'');
        sb.append(", bankName='").append(bankName).append('\'');
        sb.append(", branchName='").append(branchName).append('\'');
        sb.append(", documentId='").append(documentId).append('\'');
        sb.append(", isSignRequired=").append(isSignRequired);
        sb.append(", isSigned=").append(isSigned);
        sb.append(", signedDate=").append(signedDate);
        sb.append(", createdBy='").append(createdBy).append('\'');
        sb.append(", updatedBy='").append(updatedBy).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", lastUpdateDateTime=").append(lastUpdateDateTime);
        sb.append(", eappQAnswer='").append(eappQAnswer).append('\'');
        sb.append(", cardPlace='").append(cardPlace).append('\'');
        sb.append(", applyEBankIn='").append(applyEBankIn).append('\'');
        sb.append(", sameAsDDA='").append(sameAsDDA).append('\'');
        sb.append(", eBankName='").append(eBankName).append('\'');
        sb.append(", eBankCode='").append(eBankCode).append('\'');
        sb.append(", eBankBranchNo='").append(eBankBranchNo).append('\'');
        sb.append(", eBankAccountNo='").append(ConversionHandler.mask(eBankAccountNo)).append('\'');
        sb.append(", eBankHolderName='").append(eBankHolderName).append('\'');
        sb.append(", eBankCurrency='").append(eBankCurrency).append('\'');
        sb.append(", fpsCurrency='").append(fpsCurrency).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
