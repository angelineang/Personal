package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import lombok.Data;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@Table(name = "T_SQSDOCUMENT")
@EntityListeners(AuditingEntityListener.class)
public class TSqsDocument {

    @Column(name = "SQSDOCUMENTID", length = 60)
    @Id
    private String sqsDocumentId;

    @Column(name = "AGENTCODE", length = 10)
    private String agentCode;

    @Column(name = "ACCESSCODE", length = 30)
    private String accessCode;

    @Column(name = "SQSQUOTATIONID", length = 60)
    private String sqsQuotationId;

    @Column(name = "FILENAME", length = 50)
    private String fileName;

    @Column(name = "DOCTYPE")
    private Integer docType;

    @Column(name = "SUBMITSTATUS")
    private Integer submitStatus;

    @Column(name = "SIGNSTATUS")
    private Integer signStatus;

    @Column(name = "SIGNDATE")
    @Temporal(TemporalType.DATE)
    private Date signDate;

    @Column(name = "SIGNAT", length = 50)
    private String signAt;

    @Column(name = "PAGENO")
    private Integer pageNo;

    @Column(name = "CREATEDBY", length = 10, updatable = false)
    @CreatedBy
    private String createdBy;

    @Column(name = "UPDATEDBY", length = 10)
    @LastModifiedBy
    private String updatedBy;

    @Column(name = "CREATEDDATETIME", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "LASTUPDATEDATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    @LastModifiedDate
    private Date lastUpdateDateTime;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TSqsDocument{");
        sb.append("sqsDocumentId='").append(sqsDocumentId).append('\'');
        sb.append(", agentCode='").append(agentCode).append('\'');
        sb.append(", accessCode='").append(accessCode).append('\'');
        sb.append(", sqsQuotationId='").append(sqsQuotationId).append('\'');
        sb.append(", fileName='").append(fileName).append('\'');
        sb.append(", docType=").append(docType);
        sb.append(", submitStatus=").append(submitStatus);
        sb.append(", signStatus=").append(signStatus);
        sb.append(", signDate=").append(signDate);
        sb.append(", signAt='").append(signAt).append('\'');
        sb.append(", pageNo=").append(pageNo);
        sb.append(", createdBy='").append(createdBy).append('\'');
        sb.append(", updatedBy='").append(updatedBy).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", lastUpdateDateTime=").append(lastUpdateDateTime);
        sb.append('}');
        return sb.toString();
    }
}