package hk.com.aia.ws.eapp.model.db.magnum;

import lombok.Data;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Data
@Entity
@Table(name = "tbl_subtasklet_user")
@EntityListeners(AuditingEntityListener.class)
public class SubTaskletUser {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "task_user_name")
    private String taskUserName;

    @Column(name ="is_lock")
    private boolean isLock;

    @Version
    private int version;

    @Column(name = "created_by", length = 50)
    @CreatedBy
    private String createdBy;

    @Column(name = "created_date")
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "last_modified_by", length = 10)
    @LastModifiedBy
    private String lastModifiedBy;

    @Column(name = "last_modified_date")
    @Temporal(TemporalType.TIMESTAMP)
    @LastModifiedDate
    private Date lastModifiedDateTime;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("SubTaskletUser{");
        sb.append("id=").append(id);
        sb.append(", taskUserName='").append(taskUserName).append('\'');
        sb.append(", isLock=").append(isLock);
        sb.append(", version=").append(version);
        sb.append(", createdBy='").append(createdBy).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", lastModifiedBy='").append(lastModifiedBy).append('\'');
        sb.append(", lastModifiedDateTime=").append(lastModifiedDateTime);
        sb.append('}');
        return sb.toString();
    }
}
