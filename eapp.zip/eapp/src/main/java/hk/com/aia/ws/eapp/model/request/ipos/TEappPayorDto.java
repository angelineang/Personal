package hk.com.aia.ws.eapp.model.request.ipos;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.Date;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import static hk.com.aia.ws.eapp.constant.Constants.TIMEZONE;

@ApiModel(value = "T_EAPPPAYOR Model")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TEappPayorDto {

	@ApiModelProperty(value = "eapp_id", required = true)
    @JsonProperty("eapp_id")
	@NotBlank
    private String eappId;

    @JsonProperty("same_as")
    private Integer sameAs;

    @JsonProperty("relationship_code")
    private String relationshipCode;

    @JsonProperty("last_name")
    private String lastName;

    @JsonProperty("first_name")
    private String firstName;

    @JsonProperty("company_name")
    private String companyName;

    @JsonProperty("chn_name")
    private String chnName;

    @JsonProperty("company_name_cn")
    private String companyNameCn;

    @JsonProperty("gender")
    private String gender;

    @ApiModelProperty(value = "Date of birth ,format = yyyy-MM-dd", example = "2020-12-31")
    @JsonProperty("dob")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = TIMEZONE)
    private Date dob;

    @JsonProperty("nationality_code")
    private String nationalityCode;

    @JsonProperty("id_type")
    private String idType;

    @JsonProperty("idnumber")
    private String idnumber;

    @JsonProperty("business_cer_no")
    private String businessCerNo;


    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TWithdrawalDto{");
        sb.append("eapp_id='").append(eappId).append('\'');
        sb.append(", same_as='").append(sameAs).append('\'');
        sb.append(", relationship_code='").append(relationshipCode).append('\'');
        sb.append(", last_name='").append(lastName).append('\'');
        sb.append(", first_name='").append(firstName).append('\'');
        sb.append(", company_name='").append(companyName).append('\'');
        sb.append(", chn_name='").append(chnName).append('\'');
        sb.append(", company_name_cn='").append(companyNameCn).append('\'');
        sb.append(", gender='").append(gender).append('\'');
        sb.append(", dob='").append(dob).append('\'');
        sb.append(", nationality_code='").append(nationalityCode).append('\'');
        sb.append(", id_type='").append(idType).append('\'');
        sb.append(", idnumber='").append(idnumber).append('\'');
        sb.append(", business_cer_no='").append(businessCerNo).append('\'');
        sb.append('}');
        return sb.toString();
    }
}