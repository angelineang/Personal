package hk.com.aia.ws.eapp.model.base.calculator;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@EqualsAndHashCode(callSuper = false)
public class AlphaSearchResultBean {

    private List<AlphaSearchResultCustomerBean> customerList;
    private String matchFlag;
    private String resultCode;
    private String resultMessage;
	public List<AlphaSearchResultCustomerBean> getCustomerList() {
		return customerList;
	}
	public void setCustomerList(List<AlphaSearchResultCustomerBean> customerList) {
		this.customerList = customerList;
	}
	public String getMatchFlag() {
		return matchFlag;
	}
	public void setMatchFlag(String matchFlag) {
		this.matchFlag = matchFlag;
	}
	public String getResultCode() {
		return resultCode;
	}
	public void setResultCode(String resultCode) {
		this.resultCode = resultCode;
	}
	public String getResultMessage() {
		return resultMessage;
	}
	public void setResultMessage(String resultMessage) {
		this.resultMessage = resultMessage;
	}

}
