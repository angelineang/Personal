package hk.com.aia.ws.eapp.model.properties;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CoiProperties {

    private Boolean indicator;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("CoiProperties{");
        sb.append("indicator=").append(indicator);
        sb.append('}');
        return sb.toString();
    }
}
