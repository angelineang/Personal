package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.math.BigDecimal;

@Entity
@Data
@Table(name = "T_CITIANSWER")
@EntityListeners(AuditingEntityListener.class)
public class TCitiAnswer {

    @Column(name = "ANSWERID", length = 60)
    @Id
    private String answerId;

    @Column(name = "FNAID", length = 60)
    private String fnaId;

    @Column(name = "BIZID", length = 60)
    private String bizId;

    @Column(name = "QUESTIONGROUP", length = 60)
    private String questionGroup;

    @Column(name = "QUESTIONTYPE", length = 60)
    private String questionType;

    @Column(name = "QUESTIONKEY", length = 60)
    private String questionKey;

    @Column(name = "FIELDYESORNO")
    private Integer fieldYesOrNo;

    @Column(name = "FIELDSLA", length = 400)
    private String fieldSLA;

    @Column(name = "FIELDSLB", length = 400)
    private String fieldSLB;

    @Column(name = "FIELDSLC", length = 400)
    private String fieldSLC;

    @Column(name = "FIELDFREEINPUT", length = 400)
    private String fieldFreeInputs;

    @Column(name = "FIELDNMA")
    private BigDecimal fieldNMA;

    @Column(name = "FIELDNMB")
    private BigDecimal fieldNMB;

    @Column(name = "FIELDNMC")
    private BigDecimal fieldNMC;

    @Column(name = "FIELDNMD")
    private BigDecimal fieldNMD;

    @Column(name = "FIELDNME")
    private BigDecimal fieldNME;

    @Column(name = "FIELDNSA", length = 100)
    private String fieldNSA;

    @Column(name = "FIELDNSB", length = 100)
    private String fieldNSB;

    @Column(name = "FIELDNSC", length = 100)
    private String fieldNSC;

    @Column(name = "FIELDNSD", length = 100)
    private String fieldNSD;

    @Column(name = "FIELDNSE", length = 100)
    private String fieldNSE;

    @Column(name = "FIELDNSF", length = 100)
    private String fieldNSF;

    @Column(name = "FIELDSLD", length = 400)
    private String fieldSLD;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TCitiAnswer{");
        sb.append("answerId='").append(answerId).append('\'');
        sb.append(", fnaId='").append(fnaId).append('\'');
        sb.append(", bizId='").append(bizId).append('\'');
        sb.append(", questionGroup='").append(questionGroup).append('\'');
        sb.append(", questionType='").append(questionType).append('\'');
        sb.append(", questionKey='").append(questionKey).append('\'');
        sb.append(", fieldYesOrNo=").append(fieldYesOrNo);
        sb.append(", fieldSLA='").append(fieldSLA).append('\'');
        sb.append(", fieldSLB='").append(fieldSLB).append('\'');
        sb.append(", fieldSLC='").append(fieldSLC).append('\'');
        sb.append(", fieldFreeInputs='").append(fieldFreeInputs).append('\'');
        sb.append(", fieldNMA=").append(fieldNMA);
        sb.append(", fieldNMB=").append(fieldNMB);
        sb.append(", fieldNMC=").append(fieldNMC);
        sb.append(", fieldNMD=").append(fieldNMD);
        sb.append(", fieldNME=").append(fieldNME);
        sb.append(", fieldNSA='").append(fieldNSA).append('\'');
        sb.append(", fieldNSB='").append(fieldNSB).append('\'');
        sb.append(", fieldNSC='").append(fieldNSC).append('\'');
        sb.append(", fieldNSD='").append(fieldNSD).append('\'');
        sb.append(", fieldNSE='").append(fieldNSE).append('\'');
        sb.append(", fieldNSF='").append(fieldNSF).append('\'');
        sb.append(", fieldSLD='").append(fieldSLD).append('\'');
        sb.append('}');
        return sb.toString();
    }
}


