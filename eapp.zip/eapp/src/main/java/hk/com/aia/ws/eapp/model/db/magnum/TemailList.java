package hk.com.aia.ws.eapp.model.db.magnum;

import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "temail_list")
public class TemailList {

    @Column(name = "job_id", length = 10)
    @Id
    private String jobId;

    @Column(name = "ref_no", length = 10)
    private String refNo;

    @Column(name = "app_name", length = 5)
    private String appName;

    @Column(name = "script_name", length = 80)
    private String scriptName;

    @Column(name = "recipient_to_1")
    private String recipientTo1;

    @Column(name = "recipient_to_2")
    private String recipientTo2;

    @Column(name = "recipient_to_3")
    private String recipientTo3;

    @Column(name = "recipient_cc_1")
    private String recipientCC1;

    @Column(name = "recipient_cc_2")
    private String recipientCC2;

    @Column(name = "subject", length = 80)
    private String subject;

    @Column(name = "content_txt1", length = 150)
    private String contentTxt1;

    @Column(name = "content_txt2", length = 150)
    private String contentTxt2;

    @Column(name = "content_file", length = 80)
    private String contentFile;

    @Column(name = "backup_flag", length = 1)
    private String backupFlag;

    @Column(name = "remarks", length = 90)
    private String remarks;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TemailList{");
        sb.append("jobId='").append(jobId).append('\'');
        sb.append(", refNo='").append(refNo).append('\'');
        sb.append(", appName='").append(appName).append('\'');
        sb.append(", scriptName='").append(scriptName).append('\'');
        sb.append(", recipientTo1='").append(recipientTo1).append('\'');
        sb.append(", recipientTo2='").append(recipientTo2).append('\'');
        sb.append(", recipientTo3='").append(recipientTo3).append('\'');
        sb.append(", recipientCC1='").append(recipientCC1).append('\'');
        sb.append(", recipientCC2='").append(recipientCC2).append('\'');
        sb.append(", subject='").append(subject).append('\'');
        sb.append(", contentTxt1='").append(contentTxt1).append('\'');
        sb.append(", contentTxt2='").append(contentTxt2).append('\'');
        sb.append(", contentFile='").append(contentFile).append('\'');
        sb.append(", backupFlag='").append(backupFlag).append('\'');
        sb.append(", remarks='").append(remarks).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
