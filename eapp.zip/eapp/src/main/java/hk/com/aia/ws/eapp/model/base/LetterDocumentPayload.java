package hk.com.aia.ws.eapp.model.base;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import hk.com.aia.ws.eapp.model.request.letter.LetterDocResponse;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class LetterDocumentPayload extends Payload{

    @JsonProperty("return_code")
    private String returnCode;

    @JsonProperty("status")
    private String status;

    @JsonProperty("LetterDocumentList")
    private List<LetterDocResponse> letterDocumentList;

}

