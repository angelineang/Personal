package hk.com.aia.ws.eapp.model.db.magnum.ipos;

import hk.com.aia.ws.eapp.util.ConversionHandler;
import lombok.Data;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "T_OCRContact")
public class TOcrContact {

    @Column(name = "OCRContactID", length = 60)
    @Id
    private String ocrContactId;

    @Column(name = "EAPPID", length = 60)
    private String eappId;

    @Column(name = "ContactID", length = 60)
    private String contactId;

    @Column(name = "LastName", length = 100)
    private String lastName;

    @Column(name = "FirstName", length = 100)
    private String firstName;

    @Column(name = "ChineseName", length = 500)
    private String chineseName;

    @Column(name = "Gender", length = 10)
    private String gender;

    @Column(name = "DOB")
    @Temporal(TemporalType.DATE)
    private Date dob;

    @Column(name = "IDNumber", length = 500)
    private String idNumber;

    @Column(name = "AllOCRInfo", length = 1000)
    private String allOcrInfo;

    @Column(name = "createby", length = 10, updatable = false)
    @CreatedBy
    private String createBy;

    @Column(name = "createddatetime", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDateTime;

    @Column(name = "isOCR", length = 10)
    private String isOcr;

    @Column(name = "latestEdited", length = 10)
    private String latestEdited;

    @Column(name = "isCopy", length = 10)
    private String isCopy;

    @Column(name = "IDSymbols", length = 50)
    private String idSymbols;

    @Column(name = "IDExpiryDate")
    @Temporal(TemporalType.DATE)
    private Date idExpiryDate;

    @Column(name = "BackIDNumber", length = 50)
    private String backIdNumber;

    @Column(name = "BackIDType", length = 20)
    private String backIdType;

    @Column(name = "IDTypeSelection", length = 20)
    private String idTypeSelection;

    @Column(name = "IDTypeMatched", length = 5)
    private String idTypeMatched;

    @Column(name = "IDNumberMatched", length = 5)
    private String idNumberMatched;

    @Column(name = "UserStateMatched", length = 5)
    private String userStateMatched;

    @Column(name = "Address", length = 500)
    private String address;

    @Column(name = "IssueDate")
    @Temporal(TemporalType.DATE)
    private Date issueDate;

    @Column(name = "EAPPIDFORMAT", length = 50)
    private String eappIdFormat;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TOcrContact{");
        sb.append("ocrContactId='").append(ocrContactId).append('\'');
        sb.append(", eappId='").append(eappId).append('\'');
        sb.append(", contactId='").append(contactId).append('\'');
        sb.append(", lastName='").append(ConversionHandler.mask(lastName)).append('\'');
        sb.append(", firstName='").append(ConversionHandler.mask(firstName)).append('\'');
        sb.append(", chineseName='").append(ConversionHandler.mask(chineseName)).append('\'');
        sb.append(", gender='").append(gender).append('\'');
        sb.append(", dob=").append(ConversionHandler.mask(dob));
        sb.append(", idNumber='").append(ConversionHandler.mask(idNumber)).append('\'');
        sb.append(", allOcrInfo='").append(allOcrInfo).append('\'');
        sb.append(", createBy='").append(createBy).append('\'');
        sb.append(", createdDateTime=").append(createdDateTime);
        sb.append(", isOcr='").append(isOcr).append('\'');
        sb.append(", latestEdited='").append(latestEdited).append('\'');
        sb.append(", isCopy='").append(isCopy).append('\'');
        sb.append(", idSymbols='").append(idSymbols).append('\'');
        sb.append(", idExpiryDate=").append(idExpiryDate);
        sb.append(", backIdNumber='").append(backIdNumber).append('\'');
        sb.append(", backIdType='").append(backIdType).append('\'');
        sb.append(", idTypeSelection='").append(idTypeSelection).append('\'');
        sb.append(", idTypeMatched='").append(idTypeMatched).append('\'');
        sb.append(", idNumberMatched='").append(idNumberMatched).append('\'');
        sb.append(", userStateMatched='").append(userStateMatched).append('\'');
        sb.append(", address='").append(address).append('\'');
        sb.append(", issueDate=").append(issueDate);
        sb.append(", eappIdFormat='").append(eappIdFormat).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
    
	
	
	
	
	
	
	
	