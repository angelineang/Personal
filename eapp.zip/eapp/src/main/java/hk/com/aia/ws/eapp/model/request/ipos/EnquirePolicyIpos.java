package hk.com.aia.ws.eapp.model.request.ipos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import hk.com.aia.ws.eapp.annotation.DateTimeValidation;
import hk.com.aia.ws.eapp.model.base.Payload;
import hk.com.aia.ws.eapp.util.ConversionHandler;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;

@ApiModel(value = "Enquire Policy - IPOS - Model ")
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class EnquirePolicyIpos extends Payload {

    @ApiModelProperty(value = "eapp Id", required = true)
    @NotBlank
    @JsonProperty("eapp_id")
    private String eappId;

    @ApiModelProperty(value = "Policy Number")
    @JsonProperty("policy_no")
    private String policyNo;

    @ApiModelProperty(value = "Last Sign Date yyyy-MM-dd", example = "2020-12-31", required = true)
    @JsonProperty("last_sign_date")
    @NotBlank
    @DateTimeValidation(format = "yyyy-MM-dd")
    private String lastSignDate;

    @ApiModelProperty(value = "Submit Type")
    @JsonProperty("submit_type")
    private String submitType;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("EnquirePolicyIpos{");
        sb.append("eappId='").append(eappId).append('\'');
        sb.append(", policyNo='").append(ConversionHandler.mask(policyNo)).append('\'');
        sb.append(", lastSignDate='").append(lastSignDate).append('\'');
        sb.append(", submitType='").append(submitType).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
