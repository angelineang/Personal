package hk.com.aia.ws.eapp.model.base;

public enum CustomResponseStatus {

    SUCCESS(1, "success"),
    ERROR(-1, "error");

    private final int value;
    private final String description;

    CustomResponseStatus(int value, String description) {
        this.value = value;
        this.description = description;
    }

    public int value() {
        return this.value;
    }

    public String getDescription() {
        return this.description;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("CustomResponseStatus{");
        sb.append("value=").append(value);
        sb.append(", description='").append(description).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
