package hk.com.aia.ws.eapp.model.properties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AzureStorageProperties {

    private String clientId;
    private String clientSecret;
    private String tenantId;
    private String adUri;
    private String blobResource;
    private String blobAccountName;
    private String blobContainerName;
    private String keyIdentifier;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("AzureStorageProperties{");
        sb.append("clientId='").append(clientId).append('\'');
        sb.append(", clientSecret='").append(clientSecret).append('\'');
        sb.append(", tenantId='").append(tenantId).append('\'');
        sb.append(", adUri='").append(adUri).append('\'');
        sb.append(", blobResource='").append(blobResource).append('\'');
        sb.append(", blobAccountName='").append(blobAccountName).append('\'');
        sb.append(", blobContainerName='").append(blobContainerName).append('\'');
        sb.append(", keyIdentifier='").append(keyIdentifier).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
