package hk.com.aia.ws.eapp.configuration;

import hk.com.aia.ws.eapp.model.properties.AppMailProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;

import java.util.Map;
import java.util.Properties;

@Configuration
public class EmailConfiguration {

    @Bean
    @ConfigurationProperties(prefix = "eapp.mail")
    public AppMailProperties appMailProperties(){

        return new AppMailProperties();
    }

    @Bean(name = "emailSender")
    public JavaMailSender getJavaMailSender(
            AppMailProperties appMailProperties) {

        final Map<String, String> map = appMailProperties.getProperties();

        JavaMailSenderImpl mailSender = new JavaMailSenderImpl();

        mailSender.setHost(appMailProperties.getHost());
        mailSender.setPort(appMailProperties.getPort());
        mailSender.setUsername(appMailProperties.getUsername());
        mailSender.setPassword(appMailProperties.getPassword());

        Properties props = mailSender.getJavaMailProperties();

        props.put("mail.transport.protocol", appMailProperties.getProtocol());
        props.put("mail.smtp.auth", map.get("mail.smtp.auth"));
        props.put("mail.smtp.starttls.enable",
                map.get("mail.smtp.starttls.enable"));
        props.put("mail.smtp.ssl.enable", map.get("mail.smtp.ssl.enable"));

        return mailSender;
    }
}
