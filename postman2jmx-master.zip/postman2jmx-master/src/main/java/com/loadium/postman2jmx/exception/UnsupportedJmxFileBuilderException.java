package com.loadium.postman2jmx.exception;

public class UnsupportedJmxFileBuilderException extends Exception {
    public UnsupportedJmxFileBuilderException(String message) {
        super(message);
    }
}
