package com.loadium.postman2jmx.utils;

public enum CollectionVersion {
    V2
}
